# CLIENT CFv2.1.19 — Adaptive Chat Workspace

Checkpoint: `INT-CHAT-039I`

**Candidate release note. Full Gradle compile/debug-build validation is pending before promotion.**

- Makes Chat conversation-first instead of dashboard-first.
- Collapses onboarding after the first user message and while the keyboard is visible.
- Converts Reasoning Mesh to a compact status strip with expandable detailed provider/routing sheet.
- Hides CLIENT bottom version/navigation chrome while typing.
- Introduces a compact ThemePack/Kapanion composer with bounded auto-growth and Command Center quick actions.
- Preserves response-top follow and LATEST reattachment semantics.
- Adds pure layout policy tests and documentation impact evidence.
