## 2026-07-27 — INT-CHAT-039I

Created an adaptive Chat candidate from CLIENT CFv2.1.18 after on-device evidence showed the parent running. Added test-first `ChatWorkspacePolicy`, IME-aware bottom chrome suppression, compact provider mesh, active-conversation onboarding collapse, secondary telemetry collapse, and compact Kapanion composer. Pure Kotlin acceptance vectors pass. Full Android Gradle compilation is pending because the local execution environment does not contain the Android SDK/dependency cache; this candidate is not promoted as compile/build verified.

---

