# SWRLZ-Core 2.7 Two-Phone Sigil Patch Report

## Patch purpose
Add a clean relay-command UI for group/device identity, saved admin session mode, online device cards, packet sending, and offline queue packet cards.

## Integrated files
- `SecretStore.kt`: encrypted admin session token, group key, and device key storage.
- `Prefs.kt`: relay config and admin session toggle persistence.
- `Models.kt`: `RelayConfig` and `AdminSessionState`.
- `Api.kt`: Local Node 0.7 endpoints for admin sessions, groups, devices, and packets.
- `CommandsScreen.kt`: rebuilt as Two-Phone Sigil relay UI.
- `build.gradle.kts`: version and build identity updated to 0.2.7.

## Preserved laws
- Integrate, do not overwrite project structure.
- No raw admin password persistence.
- No invisible packet execution.
- Offline queued packets require user-visible handling.
- Only safe command packet types are enabled.
