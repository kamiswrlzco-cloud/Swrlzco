# INT-SERVICE-WORKFLOW-DRAGON-JAR-168A — CLIENT R76 Implementation Report

## Purpose
Repair Code 🫙 presentation so the input field exposes editable `[🫙]...[/🫙]` serialization while sent/history messages render true nested Code 🫙 UI, and mirror the dragon persona theme contract used by SERVER.

## Root cause repaired
R75 `ClientMessageStructureOverlayStore.detectLanguage()` contained an invalid regex with an unclosed character class. `parseChatRenderSegments` caught the resulting exception and fell back to canonical raw text, which explains the literal jar markers visible in device screenshots.

## Implemented
- Corrected language-detection regex.
- Removed composer marker-hiding visual transformation; literal markers remain visible/editable before SEND.
- Added canonical display segment parser for jar markers + fenced Markdown.
- Added Unicode variation-selector/zero-width marker normalization.
- Added malformed-display fail-safe that removes structural marker tokens rather than leaking/crashing.
- Added multiple-container support and exact leaked-marker regression fixture.
- Mirrored shared Dragon Persona theme metadata; default is Ancient Dragon.
