# INT-OBSERVABILITY-RECONNECT-LALM-132A — CLIENT R41 validation

## Static/source evidence
- Build identity targets CLIENT R41 / VC167 / `2.1.27-observability-reconnect-r41` / checkpoint 132A.
- Process-start registration reconciliation invalidates stale persisted ONLINE state before network proof.
- Existing valid enrollment restarts heartbeat + ArchiveNodeRuntime; only conclusive lost/rebind responses initiate registration.
- Heartbeat can perform bounded re-registration recovery without spawning a second heartbeat job.
- Explicit disconnect suppresses automatic reconnect.
- Full log store is rotating, app-private and exportable with secret-exclusion contract.
- Chat/stream lifecycle and history commits are instrumented.
- Provider UI recognizes canonical `lalm` and distinguishes remote SERVER identity from CLIENT-local fallback.

## Android build boundary
Focused 132A source verifier: **22/22 PASS**. Previous R40 LALM-cutover semantic verifier remains **7/9 PASS**, with its two expected failures being only the obsolete R40/131A identity checks; all seven runtime-contract checks still pass.

`./gradlew :app:compileDebugKotlin --offline --no-daemon --stacktrace` attempted to fetch Gradle 8.7 and failed with `UnknownHostException: services.gradle.org` before project compilation. Recorded as **WRAPPER_DNS_FAILURE_BEFORE_PROJECT_COMPILATION**, not a compile pass. Authoritative APK Router/GitHub compile/sign remains required.

Final source-manifest target: **1107 entries**; ZIP integrity and fresh-extraction verification are performed after final packaging.

## Device acceptance
Install over R40 without uninstalling. Expected behavior is immediate RECONCILING → ONLINE for the existing canonical enrollment, or a logged proof-rebind/re-registration repair if SERVER explicitly requires it. Verify chat stream logs against SERVER R68 LALM warmup logs.
