# INT-BUILD-VERSION-129A Validation — CLIENT R37

- versionCode: 163
- versionName: `2.1.27-archive-index-r37`
- parent SHA-256: `29486724b8f55455e8829da44f5c2c7b6a808772c2dd789aa4c2a3b0f0f1b051`
- scope: version/package identity refresh only
- functional runtime changes: none
- authoritative APK Router/device acceptance: pending
