# INT-AI-SWRLZX-007A — Implementation Report

SERVER R54 / CLIENT R29 implement the GGUF active-runtime deprecation layer.

### SERVER
- Adds pure `SwrlieModelSelectionPolicy` with SWRLZX-first READY selection and direct-hash lineage migration.
- Adds Model Vault runtime-preference reconciliation and optimized-lineage recognition using integrity-bound `sourceSha256` for SWRLZX.
- Startup/discovery no longer auto-selects an imported/unproven model merely because it is preferred by name/hash; selection requires READY + explicit parity-proven native state, existing selection, or stored last-known-good.
- Model Rack exposes model format/runtime role and labels GGUF as bounded emergency compatibility.

### CLIENT
- Carries the paired Model Rack contract fields.
- Model Rack UI describes SWRLZX as native/default, renders the actual model format and role, and labels GGUF as legacy emergency compatibility.

### Safety
No deployment, installation, repository mutation, model deletion, or automatic promotion of an unproven model is performed. Exact optimized LFM2 parity remains open.
