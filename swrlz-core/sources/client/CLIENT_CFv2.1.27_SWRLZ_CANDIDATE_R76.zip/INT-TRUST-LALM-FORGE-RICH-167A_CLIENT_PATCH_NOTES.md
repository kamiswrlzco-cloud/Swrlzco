# INT-TRUST-LALM-FORGE-RICH-167A — CLIENT R75 / VC201 PATCH NOTES

## Rich Code 🫙
- `[🫙]...[/🫙]` remains durable internal serialization only. Normal chat renders the contained range as a nested code-container card inside the surrounding message.
- Fenced Markdown and jar serialization converge on the same rich renderer with language label, monospace body, `COPY`, and `🫙 REMOVE`.
- The composer visually hides storage markers while preserving correct selection mapping and durable wrap/unwrap state.
- Historical/imported USER/assistant/LALM structure edits remain non-destructive overlays over immutable original content; malformed/legacy structures fall back safely.

## Execution ownership
- CLIENT protocol handling accepts only explicit `CLIENT_LOCAL` jobs.
- The old Android→SERVER `/providers/reason` relay is removed from CLIENT_LOCAL. Until a true on-device executor exists, CLIENT_LOCAL ACKs then fails closed with `CLIENT_LOCAL_EXECUTOR_NOT_CONFIGURED`.
- SERVER-owned canonical §wyrlzx inference uses SERVER R110 `SERVER_LOCAL` and therefore does not depend on Android selection/trust.

## Model/UI
- Active CLIENT model inventory hides GGUF/provenance-only entries. Historical update-ledger evidence remains readable but does not create runtime execution authority.
- Pairs with SERVER R110 group-scoped trust, direct SERVER_LOCAL execution, correlation diagnostics, canonical §wyrlzx auto-selection/background preload, and tile-scoped Auto Fix successor loop.

## Boundary
- Model bytes remain external; `SWRLZ-LALM-001A.§wyrlzx` is not bundled or mutated.
- Fresh Android compile/APK/device acceptance is not claimed by this source package.
