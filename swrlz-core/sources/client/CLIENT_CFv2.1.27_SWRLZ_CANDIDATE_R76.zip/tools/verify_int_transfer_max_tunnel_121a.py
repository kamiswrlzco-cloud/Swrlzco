#!/usr/bin/env python3
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parents[1]
checks=[]
def has(rel,text):
 p=R/rel; ok=p.is_file() and text in p.read_text(errors='ignore'); checks.append((ok,f"{rel} contains {text}"))
def lacks(rel,text):
 p=R/rel; ok=p.is_file() and text not in p.read_text(errors='ignore'); checks.append((ok,f"{rel} excludes {text}"))
def j(rel,key,value):
 d=json.loads((R/rel).read_text()); ok=d.get(key)==value; checks.append((ok,f"{rel} {key}={value}"))
has('android/app/build.gradle.kts','versionCode = 144')
has('android/app/build.gradle.kts','versionName = "2.1.27-transfer-max-r18"')
has('android/app/build.gradle.kts','INT-TRANSFER-MAX-TUNNEL-121A')
has('android/app/build.gradle.kts','CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R18.zip')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','DEVICE_STREAM_MAX_BUFFER_BYTES = 4 * 1024 * 1024')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','const val BENCHMARK_BUFFER_AUTO = 0')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','const val BENCHMARK_BUFFER_MAX = -1')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','sizeBytes >= 100L * 1024L * 1024L -> 4 * 1024 * 1024')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','sizeBytes >= 50L * 1024L * 1024L -> 2 * 1024 * 1024')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','sizeBytes >= 10L * 1024L * 1024L -> 1024 * 1024')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','incrementalSha256Verified')
lacks('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','optBoolean("incrementalShaVerified"')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','serverReadCount')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','serverFsyncMs')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','serverCheckpointMs')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','requestCount = 1')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','minOf(resolvedBufferBytes, VERIFIED_CHUNK_BYTES)')
has('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','bufferBytes.coerceIn(64 * 1024, DEVICE_STREAM_MAX_BUFFER_BYTES)')
has('android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt','BENCHMARK_BUFFER_AUTO')
has('android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt','512 KiB')
has('android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt','1 MiB')
has('android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt','2 MiB')
has('android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt','4 MiB')
has('android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt','MAX · 4 MiB')
has('android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt','SHA ${if (result.incrementalShaVerified) "VERIFIED" else "FINAL-COMMIT"}')
has('android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt','revision = "R18", versionCode = 144, checkpoint = "INT-TRANSFER-MAX-TUNNEL-121A"')
has('ReleaseNotes.md','# CLIENT CFv2.1.27 R18 / VC144 — INT-TRANSFER-MAX-TUNNEL-121A')
j('CHECKPOINT_RECEIPT.json','revision','R18')
j('CHECKPOINT_RECEIPT.json','versionCode',144)
j('CHECKPOINT_RECEIPT.json','checkpoint','INT-TRANSFER-MAX-TUNNEL-121A')
j('SWRLZ_PATCH_LINEAGE_INDEX_V1.json','revision','R18')
has('INT-TRANSFER-MAX-TUNNEL-121A_IMPLEMENTATION_REPORT.md','4,959,916 B/s')
has('INT-TRANSFER-MAX-TUNNEL-121A_ANDROID_COMPILE_ATTEMPT.txt','BLOCKED_BEFORE_COMPILATION')
failed=[d for ok,d in checks if not ok]
for ok,d in checks: print(('PASS' if ok else 'FAIL')+' | '+d)
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)} PASS")
if failed: sys.exit(1)
