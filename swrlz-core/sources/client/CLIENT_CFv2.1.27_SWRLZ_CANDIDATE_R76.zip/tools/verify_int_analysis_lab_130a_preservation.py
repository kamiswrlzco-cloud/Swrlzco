#!/usr/bin/env python3
from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1]
checks=[]
def c(cond,label): checks.append((label,bool(cond)))
ui=(R/'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt').read_text()
coord=(R/'android/app/src/main/java/sh/swurlz/core/archive/ArchiveIndexCoordinator.kt').read_text()
stream=(R/'android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamRuntime.kt').read_text()
c('· PROBING' in ui and 'NO SERVER MODEL' in ui,'R38 truthful probing UX preserved')
c('ArchiveIndexStore.beginBuild' in coord and 'Dispatchers.IO' in coord,'persistent archive index background build preserved')
c('CommittedDelta' in stream or 'COMPLETED' in stream,'client streaming state path preserved')
for label,ok in checks: print(('PASS' if ok else 'FAIL'),label)
print(f'{sum(x for _,x in checks)}/{len(checks)} checks passed')
sys.exit(0 if all(x for _,x in checks) else 1)
