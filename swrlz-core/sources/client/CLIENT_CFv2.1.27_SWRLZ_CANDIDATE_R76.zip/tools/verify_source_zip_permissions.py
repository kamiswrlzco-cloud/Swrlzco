#!/usr/bin/env python3
"""Fail when a SWRLZ source ZIP contains non-traversable Unix directory modes."""
from __future__ import annotations
import argparse, stat, sys, zipfile
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("zip_path", type=Path)
args = parser.parse_args()
bad=[]
with zipfile.ZipFile(args.zip_path) as zf:
    for info in zf.infolist():
        if not info.is_dir():
            continue
        mode=(info.external_attr >> 16) & 0xFFFF
        perms=stat.S_IMODE(mode)
        if mode and not (perms & stat.S_IXUSR):
            bad.append((info.filename, oct(perms)))
if bad:
    for name, mode in bad:
        print(f"NON_TRAVERSABLE_DIRECTORY {mode} {name}")
    raise SystemExit(1)
print(f"PASS: {args.zip_path.name} has no non-traversable Unix directory entries")
