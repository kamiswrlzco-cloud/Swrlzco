#!/usr/bin/env python3
"""INT-AI-SWRLZX-011A exact-source native LALM bring-up runner.

Runs the exact pinned GGUF through the 011A executable-profile converter twice, requires
byte-identical SWRLZX outputs, validates the executable graph/tokenizer/quantizer sections,
and writes a candidate receipt. It never selects/promotes the model and never marks 012A
GGUF↔LALM parity proven.
"""
from __future__ import annotations
import argparse, json, os, sys, tempfile
from pathlib import Path

from swrlzx_gguf_to_swrlzx_v1 import (
    ConversionProfile, LALM_BRANDED_FILE, LALM_DISPLAY_NAME, LALM_MODEL_ID,
    LALM_SOURCE_NAME, LALM_SOURCE_SHA256, LALM_SOURCE_SIZE_BYTES,
    LALM_RUNTIME_CONTRACT, LALM_TENSOR_KV_CONTRACT, LALM_SAMPLER_CONTRACT,
    LALM_GGML_K_QUANT_CONTRACT, SEC_MANIFEST, SEC_ARCH, SEC_TOKENIZER, SEC_QUANT,
    canonical_json, convert, parse_gguf, read_section_json, read_swrlzx_header_toc,
    sha256_file, verify_swrlzx,
)

RECEIPT_NAME = "SWRLZ-LALM-001A.INT-AI-SWRLZX-011A.native-receipt.json"


def fail(message: str) -> "NoReturn":
    raise ValueError(message)


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("output_dir", type=Path)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--receipt", type=Path)
    args=ap.parse_args()
    try:
        if not args.source.is_file(): fail(f"LALM_011A_SOURCE_NOT_FOUND:{args.source}")
        idx=parse_gguf(args.source)
        if args.source.name != LALM_SOURCE_NAME: fail(f"LALM_011A_SOURCE_NAME_MISMATCH:{args.source.name}")
        if idx.file_bytes != LALM_SOURCE_SIZE_BYTES: fail(f"LALM_011A_SOURCE_SIZE_MISMATCH:{idx.file_bytes}")
        if idx.source_sha256.lower() != LALM_SOURCE_SHA256: fail(f"LALM_011A_SOURCE_SHA256_MISMATCH:{idx.source_sha256}")
        if str(idx.metadata.get("general.architecture","")).lower() != "lfm2": fail("LALM_011A_SOURCE_ARCHITECTURE_MISMATCH")
        args.output_dir.mkdir(parents=True, exist_ok=True)
        final=args.output_dir/LALM_BRANDED_FILE
        if final.exists() and not args.force: fail(f"LALM_011A_DESTINATION_EXISTS:{final}")
        profile=ConversionProfile.lalm_011a()
        with tempfile.TemporaryDirectory(prefix="swrlzx-lalm-011a-",dir=str(args.output_dir)) as td:
            td=Path(td); p1=td/"pass1.swrlzx"; p2=td/"pass2.swrlzx"
            convert(args.source,p1,None,None,False,None,profile=profile)
            convert(args.source,p2,None,None,False,None,profile=profile)
            h1=sha256_file(p1); h2=sha256_file(p2)
            if h1 != h2: fail(f"LALM_011A_NONDETERMINISTIC_OUTPUT:{h1}:{h2}")
            verify=verify_swrlzx(p1,source=args.source)
            header,toc=read_swrlzx_header_toc(p1)
            by_type={t.section_type:t for t in toc}
            manifest=read_section_json(p1,by_type[SEC_MANIFEST])
            graph=read_section_json(p1,by_type[SEC_ARCH])
            tokenizer=read_section_json(p1,by_type[SEC_TOKENIZER])
            quant=read_section_json(p1,by_type[SEC_QUANT])
            if manifest.get("modelId") != LALM_MODEL_ID or manifest.get("displayName") != LALM_DISPLAY_NAME: fail("LALM_011A_TARGET_IDENTITY_INVALID")
            required=set(manifest.get("requiredRuntimeContracts",[]))
            for contract in (LALM_RUNTIME_CONTRACT,LALM_TENSOR_KV_CONTRACT,LALM_SAMPLER_CONTRACT,LALM_GGML_K_QUANT_CONTRACT):
                if contract not in required: fail(f"LALM_011A_RUNTIME_CONTRACT_MISSING:{contract}")
            if graph.get("graphStatus") != "EXECUTABLE" or graph.get("graphId") != "swrlz-lalm-001a-lfm2-native-v1": fail("LALM_011A_EXECUTABLE_GRAPH_INVALID")
            if len(graph.get("nodes",[])) != 100: fail(f"LALM_011A_GRAPH_NODE_COUNT_INVALID:{len(graph.get('nodes',[]))}")
            if tokenizer.get("kind") != "GGML_BPE" or len(tokenizer.get("tokens",[])) != 65536: fail("LALM_011A_TOKENIZER_INVALID")
            supported={"f32","f16","bf16","q4_0","q8_0","q4_k","q6_k"}
            reqq=set(q.lower() for q in quant.get("requiredQuantizers",[]))
            unsupported=reqq-supported
            if unsupported: fail(f"LALM_011A_UNSUPPORTED_SOURCE_QUANTIZER:{','.join(sorted(unsupported))}")
            if final.exists(): final.unlink()
            os.replace(p1,final)
        receipt={
            "schemaVersion":1,"checkpoint":"INT-AI-SWRLZX-011A","nativeFamily":"LALM",
            "sourceFileName":args.source.name,"sourceSizeBytes":idx.file_bytes,"sourceSha256":idx.source_sha256,
            "targetModelId":LALM_MODEL_ID,"targetFileName":final.name,"targetSha256":sha256_file(final),
            "targetRootDigestSha256":verify["rootDigestSha256"],"deterministicSecondPassSha256":h2,"deterministicMatch":True,
            "graphId":"swrlz-lalm-001a-lfm2-native-v1","graphNodes":100,"tokenizerKind":"GGML_BPE",
            "requiredQuantizers":sorted(reqq),"tensorCount":idx.tensor_count,"tensorDataByteIdentical":True,
            "nativeReferenceRuntimeCandidate":True,"nativeExecutionParityStatus":"PENDING_012A",
            "productionPromotionPerformed":False,"runtimeSelectionPerformed":False,"ggufRollbackPreserved":True,
        }
        rp=args.receipt or args.output_dir/RECEIPT_NAME; rp.write_bytes(canonical_json(receipt))
        print(json.dumps({"ok":True,"output":str(final),"receipt":str(rp),**receipt},indent=2,sort_keys=True,ensure_ascii=False))
        return 0
    except Exception as e:
        print(f"ERROR: {e}",file=sys.stderr); return 2

if __name__=="__main__": raise SystemExit(main())
