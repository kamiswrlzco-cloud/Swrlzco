#!/usr/bin/env python3
from __future__ import annotations
import json, re, sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
screen = root / 'android/app/src/main/java/sh/swurlz/core/ui/screens/GitHubForgeScreen.kt'
build = root / 'android/app/build.gradle.kts'
github_dir = root / 'android/app/src/main/java/sh/swurlz/core/github'
required = {
    'ForgeAutomatedBuildRunner': github_dir / 'ForgeAutomatedBuildRunner.kt',
    'ForgeAutomationPreferences': github_dir / 'ForgeAutomation.kt',
    'ForgeBuildLedger': github_dir / 'ForgeAutomation.kt',
    'ForgeBuildTarget': github_dir / 'ForgeAutomation.kt',
}
checks = []
def check(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))

def text(path: Path) -> str:
    return path.read_text(encoding='utf-8')

check('screen exists', screen.is_file())
check('build file exists', build.is_file())
s = text(screen)
b = text(build)
check('versionCode 126', 'versionCode = 126' in b)
check('versionName R3', 'versionName = "2.1.26-forge-metadata-bundle-compile-fix-r3"' in b)
for symbol, declaration_file in required.items():
    check(f'{symbol} declaration file exists', declaration_file.is_file())
    declaration = text(declaration_file)
    check(f'{symbol} declared', re.search(rf'\b(?:object|class|enum class|data class)\s+{re.escape(symbol)}\b', declaration) is not None)
    import_line = f'import sh.swurlz.core.github.{symbol}'
    check(f'{symbol} imported exactly once', s.count(import_line) == 1)
    check(f'{symbol} used', re.search(rf'\b{re.escape(symbol)}\b', s) is not None)
check('no wildcard github import', 'import sh.swurlz.core.github.*' not in s)
for preserved in [
    'METADATA BUNDLE READY',
    'validateSourcePairs',
    'ForgeMetadataBundle.inspect',
    'ForgeEvidenceBundle.inspect',
]:
    corpus = s + '\n' + '\n'.join(text(p) for p in github_dir.glob('*.kt'))
    check(f'preserved {preserved}', preserved in corpus)
receipt = json.loads(text(root/'CHECKPOINT_RECEIPT.json'))
check('checkpoint receipt', receipt.get('checkpoint') == 'INT-FIX-064A-CLIENT-R3')
check('candidate receipt', receipt.get('candidate') == 'CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R3')
check('parent receipt SHA', receipt.get('parent', {}).get('sha256') == 'ac248bbdcc3db2d57f64fc5270864c0b93c72ee10e0c34fbd435afbb76c8ec83')
check('no forbidden actions', all(receipt.get(k) is False for k in ['repository_writes','workflow_dispatch','apk_build','installation','promotion','release_or_deployment']))
failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' ' + name)
print(f'RESULT {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    print('FAILED: ' + ', '.join(failed), file=sys.stderr)
    raise SystemExit(1)
