#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT = Path(__file__).resolve().parents[1]
checks=[]
def text(rel): return (ROOT/rel).read_text(errors='replace')
def check(name, cond):
    checks.append((name,bool(cond)))
    print(('PASS' if cond else 'FAIL')+': '+name)

gradle=text('android/app/build.gradle.kts')
check('CLIENT versionCode 143', 'versionCode = 143' in gradle)
check('CLIENT versionName R17', '2.1.27-stream-bootstrap-r17' in gradle)
check('checkpoint label 120A', 'INT-STREAM-BOOTSTRAP-120A' in gradle)
net=text('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt')
check('stream-v2 preferred', 'DEVICE_BINARY_STREAM_V2' in net)
check('SERVER streaming capability consumed', 'deviceStreamingSupported' in net and 'deviceStreamingPath' in net)
check('one-body Ktor content writer', 'OutgoingContent.WriteChannelContent' in net and 'writeTo(channel: ByteWriteChannel)' in net)
check('staged-file streaming helper', 'postBinaryStreamFromFile' in net)
check('bounded writer uses writeFully', 'writeFully' in net)
check('large stream request timeout bounded', 'requestTimeoutMillis = 30L * 60L * 1000L' in net)
check('stream socket idle timeout bounded', 'socketTimeoutMillis = 120_000L' in net)
check('binary chunk compatibility fallback preserved', 'deviceBinaryChunkSupported' in net and 'postBinary(' in net)
check('legacy Base64 compatibility fallback preserved', 'Base64' in net or 'chunkBase64' in net)
check('benchmark records one payload request', 'requestCount = 1' in net and 'payload request(s)' in net)
check('benchmark logs streaming diagnostics', 'clientBufferCount' in net and 'serverReadCount' in net and 'incrementalShaVerified' in net)
ui=text('android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt')
check('UI labels stream buffer/fallback chunk', 'STREAM BUFFER / FALLBACK CHUNK' in ui)
check('UI displays payload request count', 'payload request(s)' in ui)
check('UI displays transport', 'result.transport' in ui)
ledger=text('android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt')
check('R17 update ledger current entry', 'R17' in ledger and 'INT-STREAM-BOOTSTRAP-120A' in ledger)
receipt=json.loads(text('CHECKPOINT_RECEIPT.json'))
check('receipt R17/checkpoint', receipt.get('revision')=='R17' and receipt.get('checkpoint')=='INT-STREAM-BOOTSTRAP-120A')
check('receipt parent R16 hash', receipt.get('parent',{}).get('sha256')=='2b3ffffc804c32b580d4b07d3c9b9f5d9f7498fb0f6ddef8ed16f8a5e7b69645')
lineage=json.loads(text('SWRLZ_PATCH_LINEAGE_INDEX_V1.json'))
ls=json.dumps(lineage)
check('lineage names R17/R16/R39', all(x in ls for x in ['R17','R16','R39','INT-STREAM-BOOTSTRAP-120A']))
check('ReleaseNotes begins with R17 checkpoint', 'INT-STREAM-BOOTSTRAP-120A' in '\n'.join(text('ReleaseNotes.md').splitlines()[:25]))
check('CHANGELOG records checkpoint', 'INT-STREAM-BOOTSTRAP-120A' in '\n'.join(text('CHANGELOG.md').splitlines()[:40]))
failed=[n for n,ok in checks if not ok]
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    print('FAILED: '+', '.join(failed)); sys.exit(1)
