#!/usr/bin/env python3
from pathlib import Path
import json, re, sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
is_server = (root / 'app/src/main/java/sh/swrlz/nodehost/forge').exists()
is_client = (root / 'android/app/src/main/java/sh/swurlz/core/github').exists()
if is_server == is_client:
    raise SystemExit('Unable to resolve exactly one CLIENT/SERVER source root')
component = 'SERVER' if is_server else 'CLIENT'
base = root / ('app/src/main/java/sh/swrlz/nodehost/forge' if is_server else 'android/app/src/main/java/sh/swurlz/core/github')
ui = root / ('app/src/main/java/sh/swrlz/nodehost/forge' if is_server else 'android/app/src/main/java/sh/swurlz/core/ui/screens')
build = root / ('app/build.gradle.kts' if is_server else 'android/app/build.gradle.kts')
checks = []
def chk(name, ok):
    checks.append((name, bool(ok)))

engine = (base / 'ForgeFileLab.kt').read_text()
panel = (ui / 'ForgeFileLabScreen.kt').read_text()
automation = (base / 'ForgeAutomation.kt').read_text()
forge_screen = (ui / ('ServerForgeScreen.kt' if is_server else 'GitHubForgeScreen.kt')).read_text()
repo_screen = (ui / 'ForgeRepositoryBrowser.kt').read_text()
build_text = build.read_text()

expected_version = '2.1.25-file-lab-cartographer-candidate-r1' if is_server else '2.1.27-file-lab-cartographer-candidate-r1'
expected_code = 83 if is_server else 125
chk('versionName', f'versionName = "{expected_version}"' in build_text)
chk('versionCode', f'versionCode = {expected_code}' in build_text)
chk('file lab engine present', 'object ForgeFileLab' in engine)
chk('file lab screen present', 'fun ForgeFileLabScreen()' in panel)
chk('top-level FILES mode routes to File Lab', '"FILES" -> ForgeFileLabScreen()' in forge_screen)
chk('mode selector exposes FILE LAB', '🧭 FILE LAB' in repo_screen)
for token in ['FILELAB_WORKING', 'FILELAB_OUTPUT', 'FILELAB_SHARDS']:
    chk(f'folder slot {token}', token in automation)
for token in ['inspectFile(', 'mapZip(', 'searchEntries(', 'searchTextContents(', 'previewTextEntry(', 'extractSelected(', 'stageTextEdit(', 'commitTextRevision(', 'splitBinary(', 'recombineBinary(', 'createLogicalShards(', 'recombineLogicalShards(', 'recombineFromManifest(', 'exportMap(']:
    chk(f'engine capability {token}', token in engine)
chk('path traversal guard', 'none { it == ".." }' in engine)
chk('staged edits app-private', 'forge_file_lab/staged_edits' in engine)
chk('explicit revised archive output', '.swrlz-revised-' in engine)
chk('binary manifest schema', 'swrlz-binary-split-v1' in engine)
chk('logical shard manifest schema', 'swrlz-logical-shards-v1' in engine)
chk('lineage schema', 'swrlz-file-lineage-v1' in engine)
chk('archive map schema', 'swrlz-archive-map-v1' in engine)
chk('500 MiB default split', '500L * 1024L * 1024L' in engine)
chk('original source never opened for write', 'openOutputStream(stage.archiveUri' not in engine and 'openOutputStream(sourceUri' not in engine and 'openOutputStream(archiveUri' not in engine)
chk('UI states explicit source safety boundary', 'Originals are not modified in place' in panel)
chk('UI requires staged commit', 'STAGE EDIT' in panel and 'COMMIT NEW ARCHIVE' in panel)
chk('UI selective extraction', 'EXTRACT SELECTED' in panel)
chk('UI binary split', 'SPLIT SOURCE INTO 500 MiB BYTE-EXACT PARTS' in panel)
chk('UI logical shards', 'LOGICAL 500 MiB SHARDS' in panel)
chk('UI manifest recombination', 'RECOMBINE MANIFEST' in panel)
chk('lineage index exists', (root / 'SWRLZ_PATCH_LINEAGE_INDEX_V1.json').exists())
chk('checkpoint doc exists', (root / 'INT_FILE_059A_CHECKPOINT.md').exists())
chk('implementation report exists', (root / 'INT_FILE_059A_IMPLEMENTATION_REPORT.md').exists())

passed = sum(ok for _, ok in checks)
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + name)
print(f'RESULT | {component} | {passed}/{len(checks)}')
if passed != len(checks):
    sys.exit(1)
