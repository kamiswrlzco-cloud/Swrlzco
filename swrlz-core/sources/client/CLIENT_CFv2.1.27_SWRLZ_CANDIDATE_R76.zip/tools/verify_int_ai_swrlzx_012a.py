#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path

SERVER_PARENT_SHA='7ef9dc546b54f7aa06b964f30da3911e4e274c08d5487e3ec46d4d4eb5ad82d2'
CLIENT_PARENT_SHA='c05359bded1ac2b7beb40dacb9a8cf92842aeff228054a6902ef536aa79a5e04'
SRC='651cd5c40e4ef24de2ff12c2b53b257d15816ddd4346e2575e6768a6ec1d8590'
TGT='d3e3692f7bd7160baff27ca2b3479033d2a494081a1a8ada17a27c2183fcd565'
ROOT='2378856022cff3191e4efa169a0ab92b419310db9d30ec807de2b969a7c34f72'
TENSOR='d2fec2437a36afff23566eca26df82172c2602f34478c8fd1d7e506c4821fb37'

def read(p:Path)->str: return p.read_text(encoding='utf-8',errors='replace') if p.is_file() else ''
def sha(p:Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()

def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument('root',type=Path); ap.add_argument('--component',choices=['SERVER','CLIENT'],required=True); ap.add_argument('--peer',type=Path); a=ap.parse_args()
    r=a.root.resolve(); comp=a.component; checks=[]
    def ck(n,c): checks.append((n,bool(c)))
    gradle=r/('app/build.gradle.kts' if comp=='SERVER' else 'android/app/build.gradle.kts'); g=read(gradle)
    ck('target versionCode',('versionCode = 182' if comp=='SERVER' else 'versionCode = 160') in g)
    ck('target versionName',('2.1.27-lalm-reference-parity-r59' if comp=='SERVER' else '2.1.27-lalm-reference-parity-r34') in g)
    ck('checkpoint label','INT-AI-SWRLZX-012A' in g)
    ck('candidate identity',('SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R59.zip' if comp=='SERVER' else 'CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R34.zip') in g)
    ck('parent SHA lineage',(SERVER_PARENT_SHA if comp=='SERVER' else CLIENT_PARENT_SHA) in read(r/'SWRLZ_PATCH_LINEAGE_INDEX_V1.json'))

    cp=r/('swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxLalmParityV1.kt' if comp=='SERVER' else 'android/swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxLalmParityV1.kt'); c=read(cp)
    ck('parity contract exists',cp.is_file())
    for n,v in [('contract','swrlzx.lalm.parity.v1'),('source',SRC),('target',TGT),('root',ROOT),('tensor data',TENSOR)]: ck('parity '+n,v in c)
    ck('reference and legacy states separated','REFERENCE_PROVEN' in c and 'LEGACY_PENDING' in c and 'LEGACY_PROVEN' in c)
    ck('production requires legacy proven','productionParityProven' in c and 'legacyEngineParityStatus == SwrlzxLalmParityV1.LEGACY_PROVEN' in c)
    ck('promotion forbidden at 012A','SWRLZX_012A_PRODUCTION_PROMOTION_FORBIDDEN' in c)

    mr=r/('model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt' if comp=='SERVER' else 'android/model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt'); m=read(mr)
    for n,v in [('rack target SHA',TGT),('rack root',ROOT),('rack parity contract','swrlzx.lalm.parity.v1')]: ck(n,v in m)
    ck('snapshot separates reference/legacy parity','lalmReferenceParityProven' in m and 'lalmLegacyEngineParityProven' in m)

    for rel in [
      'docs/checkpoints/INT-AI-SWRLZX-012A_GGUF_LALM_PARITY_WAR.md',
      'docs/contracts/SWRLZX_LALM_PARITY_V1.md',
      'docs/architecture/ADR-0031_SWRLZX_PARITY_EVIDENCE_GATING.md',
      'docs/evidence/INT-AI-SWRLZX-012A_VALIDATION.md',
      'docs/evidence/INT-AI-SWRLZX-012A_REFERENCE_PARITY.json',
      'docs/evidence/INT-AI-SWRLZX-012A_REFERENCE_PARITY.txt',
      'docs/evidence/INT-AI-SWRLZX-012A_REAL_QUANT_PARITY.txt',
      'docs/evidence/SWRLZ-LALM-001A.INT-AI-SWRLZX-012A.reference-parity-receipt.json',
    ]: ck('evidence '+rel,(r/rel).is_file())
    ev=json.loads(read(r/'docs/evidence/INT-AI-SWRLZX-012A_REFERENCE_PARITY.json') or '{}')
    ck('reference evidence 20/20',len(ev.get('checks',[]))==20 and all(x.get('pass') for x in ev.get('checks',[])))
    ck('reference evidence exact zero diff',ev.get('referenceMaxAbsLogitDiff')==0.0)
    ck('reference evidence legacy pending',ev.get('legacyEngineParityStatus')=='PENDING_ANDROID_LLAMA_AAR' and ev.get('parityProven') is False)
    q=read(r/'docs/evidence/INT-AI-SWRLZX-012A_REAL_QUANT_PARITY.txt'); ck('real quant evidence 18/18','RESULT | 18/18 PASS' in q)
    receipt=json.loads(read(r/'docs/evidence/SWRLZ-LALM-001A.INT-AI-SWRLZX-012A.reference-parity-receipt.json') or '{}')
    ck('reference receipt exact identities',receipt.get('sourceGgufSha256')==SRC and receipt.get('targetLalmSha256')==TGT and receipt.get('targetLalmRootDigestSha256')==ROOT)
    ck('reference receipt refuses promotion',receipt.get('legacyEngineParityStatus')=='PENDING_ANDROID_LLAMA_AAR' and receipt.get('productionPromotionPerformed') is False)
    ck('roadmap records 012A status','### 012A source/reference status' in read(r/'docs/architecture/SWRLZX_MODEL_FORMAT_AND_STREAMING_ROADMAP_V1.md'))
    ck('model bytes excluded from source',not any(p.name.endswith('.gguf') or '§wyrlzx' in p.name for p in r.rglob('*') if p.is_file()))

    if comp=='SERVER':
        vault=read(r/'app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelVault.kt'); sel=read(r/'app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelSelectionPolicy.kt')
        ck('old free-form parity marker disabled','SWRLZX_PARITY_STRUCTURED_RECEIPT_REQUIRED' in vault)
        ck('reference receipt method exists','markNativeReferenceParityReceipt' in vault and 'REFERENCE_ONLY' in vault)
        ck('production structured receipt method exists','markNativeParityReceipt' in vault and 'productionParityProven()' in vault)
        ck('canonical target/root required by production gate','TARGET_LALM_SHA256' in vault and 'TARGET_LALM_ROOT_SHA256' in vault)
        ck('runtime/device/prompt evidence required',all(x in vault for x in ['PARITY_RUNTIME_FINGERPRINT_KEY','PARITY_DEVICE_FINGERPRINT_KEY','PARITY_PROMPT_SUITE_SHA_KEY']))
        ck('selection still uses only production parity','nativeParityProven = nativeParityProven(record)' in vault and 'candidate.nativeParityProven' in sel)
        ck('server build identity revision','quotedBuildConfig("R59")' in g and 'quotedBuildConfig("R58")' in g and SERVER_PARENT_SHA in g)
        ck('server patch catalog updated','revision = "R59"' in read(r/'app/src/main/java/sh/swrlz/nodehost/runtime/ServerPatchCatalog.kt'))
        ck('server update ledger updated','CURRENT R59' in read(r/'app/src/main/assets/server-update-ledger.md'))
    else:
        ledger=read(r/'android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt'); ck('client build label updated','PATCH_LABEL", "\\\"INT-AI-SWRLZX-012A\\\"' in g)
        ck('client ledger updated','revision = "R34"' in ledger and 'INT-AI-SWRLZX-012A' in ledger)
        ck('client carries no server vault authority',not (r/'android/app/src/main/java/sh/swurlz/core/ai/local/SwrlieModelVault.kt').exists())

    ck('parity runner present',(r/'tools/swrlzx_lalm_012a_reference_parity.py').is_file())
    ck('real quant runner present',(r/'tools/swrlzx_012a_real_quant_parity.py').is_file())
    ck('contract harness present',(r/'tools/swrlzx_012a_parity_contract_harness.kt').is_file())
    if a.peer:
        peer=a.peer.resolve(); pc=peer/('android/swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxLalmParityV1.kt' if comp=='SERVER' else 'swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxLalmParityV1.kt'); pm=peer/('android/model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt' if comp=='SERVER' else 'model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt')
        ck('peer parity contract byte-identical',pc.is_file() and sha(cp)==sha(pc))
        ck('peer model-rack contract byte-identical',pm.is_file() and sha(mr)==sha(pm))
    for n,ok in checks: print(('PASS' if ok else 'FAIL')+' | '+n)
    passed=sum(ok for _,ok in checks); print(f'RESULT | {passed}/{len(checks)} PASS')
    return 0 if passed==len(checks) else 1
if __name__=='__main__': raise SystemExit(main())
