#!/usr/bin/env python3
"""Create bounded Android runtime derivatives from the SWRLZ theme masters.

The script never edits source masters. It trims transparent padding, creates
role-specific sizes, emits WebP resources, and records exact runtime hashes.
It intentionally does not invent missing art: unsupported roles are handled by
the ThemePack fallback chain at runtime.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageChops, ImageDraw


ROLE_FILES = {
    "frame": "01_empty_frame_shell.png",
    "fill": "02_seamless_fill_texture.png",
    "head": "03_progress_head_ornament.png",
    "particles": "04_particle_energy_overlay.png",
    "emblem": "05_dragon_emblem.png",
    "complete": "06_completion_burst.png",
    "failure": "07_failure_interruption.png",
    "ambient": "08_ambient_loop_layer.png",
    "highlight": "09_highlight_glow_sweep.png",
}

JESTER_ROLE_FILES = {
    **ROLE_FILES,
    "emblem": "05_dragon_jester_emblem.png",
    "failure": "07_failure_interruption_collapse.png",
}

KAMILEON_ROLE_FILES = {
    **ROLE_FILES,
    "failure": "07_failure_interruption_collapse.png",
}

STARTUP_FILES = {
    "dormant": "01_dormant_dragon_core_emblem.png",
    "spark": "02_central_ignition_spark.png",
    "partial": "03_partially_energized_dragon_emblem.png",
    "awakened": "04_fully_awakened_dragon_emblem.png",
    "shockwave": "05_circular_energy_shockwave_ring.png",
    "particles": "06_outward_particle_burst.png",
    "radial": "07_radial_energy_streaks.png",
    "residual": "08_residual_glow_particles.png",
}

NEW_LAUNCHER_SLUGS = {
    "inferno",
    "frost",
    "jade",
    "digital_glitch",
    "crystal_cyber",
    "jester",
}

STAGING_MARKER = ".swrlz-theme-asset-staging"


@dataclass(frozen=True)
class ThemeSource:
    slug: str
    theme_id: str
    display_name: str
    progress_dir: Path
    role_files: dict[str, str]
    identity_index: int | None
    identity_stem: str | None
    palette: tuple[str, str, str]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def rgba(path: Path) -> Image.Image:
    with Image.open(path) as source:
        return source.convert("RGBA")


def alpha_crop(image: Image.Image, padding: int = 12, threshold: int = 2) -> Image.Image:
    alpha = image.getchannel("A")
    mask = alpha.point(lambda value: 255 if value > threshold else 0)
    box = mask.getbbox()
    if box is None:
        return image.copy()
    left = max(0, box[0] - padding)
    top = max(0, box[1] - padding)
    right = min(image.width, box[2] + padding)
    bottom = min(image.height, box[3] + padding)
    return image.crop((left, top, right, bottom))


def dense_head_crop(image: Image.Image) -> Image.Image:
    cropped = alpha_crop(image, padding=14)
    if cropped.width <= cropped.height * 1.8:
        return cropped
    alpha = cropped.getchannel("A")
    energy = list(alpha.resize((cropped.width, 1), Image.Resampling.BOX).getdata())
    window = min(cropped.width, max(cropped.height, int(cropped.height * 1.45)))
    running = sum(energy[:window])
    best_sum = running
    best_left = 0
    for index in range(window, len(energy)):
        running += energy[index] - energy[index - window]
        if running > best_sum:
            best_sum = running
            best_left = index - window + 1
    focus = cropped.crop((best_left, 0, best_left + window, cropped.height))
    return alpha_crop(focus, padding=8)


def fit(image: Image.Image, max_width: int, max_height: int) -> Image.Image:
    result = image.copy()
    result.thumbnail((max_width, max_height), Image.Resampling.LANCZOS)
    return result


def square_canvas(image: Image.Image, size: int, inset: int, circular: bool) -> Image.Image:
    source = image.convert("RGBA")
    if source.width != source.height:
        edge = min(source.width, source.height)
        left = (source.width - edge) // 2
        top = (source.height - edge) // 2
        source = source.crop((left, top, left + edge, top + edge))
    source = source.resize((size - inset * 2, size - inset * 2), Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    if circular:
        mask = Image.new("L", source.size, 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((2, 2, source.width - 2, source.height - 2), fill=255)
        source.putalpha(ImageChops.multiply(source.getchannel("A"), mask))
    canvas.alpha_composite(source, (inset, inset))
    return canvas


def save_webp(image: Image.Image, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path, "WEBP", lossless=True, method=4, exact=True)


def progress_derivative(path: Path, role: str) -> Image.Image:
    image = rgba(path)
    if role == "head":
        return fit(dense_head_crop(image), 280, 220)
    if role == "emblem":
        return fit(alpha_crop(image, padding=16), 420, 420)
    if role in {"complete"}:
        return fit(alpha_crop(image, padding=16), 720, 260)
    return fit(alpha_crop(image, padding=12), 1024, 220)


def runtime_entry(path: Path, role: str, source: Path) -> dict[str, object]:
    with Image.open(path) as image:
        width, height = image.size
    return {
        "role": role,
        "resource": path.stem,
        "runtimeFile": path.name,
        "source": source.as_posix(),
        "width": width,
        "height": height,
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def theme_sources(masters: Path) -> list[ThemeSource]:
    return [
        ThemeSource("inferno", "sh.swrlz.theme.inferno", "Inferno", masters / "05_progress_inferno_ice_jade/Progress_Bars/Inferno", ROLE_FILES, 1, "Inferno", ("#080302", "#FF6A00", "#FFB000")),
        ThemeSource("frost", "sh.swrlz.theme.frost", "Frost", masters / "05_progress_inferno_ice_jade/Progress_Bars/Ice", ROLE_FILES, 2, "Ice", ("#02080E", "#75DFFF", "#B8F4FF")),
        ThemeSource("jade", "sh.swrlz.theme.jade", "Jade", masters / "05_progress_inferno_ice_jade/Progress_Bars/Jade", ROLE_FILES, 3, "Jade", ("#020B07", "#19E38C", "#A8FF58")),
        ThemeSource("digital_glitch", "sh.swrlz.theme.digital_glitch", "Digital Glitch", masters / "06_progress_digital_crystal_teal_kamileon/Progress_Bars/Digital_Glitch_GreenMagenta", ROLE_FILES, 4, "Digital_Glitch", ("#050208", "#31FF9D", "#FF3BD4")),
        ThemeSource("crystal_cyber", "sh.swrlz.theme.crystal_cyber", "Crystal Cyber", masters / "06_progress_digital_crystal_teal_kamileon/Progress_Bars/Crystal_Cyber_BluePurple", ROLE_FILES, 5, "Crystal_Cyber", ("#040511", "#58D7FF", "#A86CFF")),
        ThemeSource("teal_serpent", "sh.swrlz.theme.teal_serpent", "Teal Serpent", masters / "06_progress_digital_crystal_teal_kamileon/Progress_Bars/Teal_Serpent", ROLE_FILES, None, None, ("#02100F", "#32E6D0", "#74FFF0")),
        ThemeSource("kamileon", "sh.swrlz.theme.dragon_kamileon", "Dragon Kamileon", masters / "06_progress_digital_crystal_teal_kamileon/Progress_Bars/Kamileon", KAMILEON_ROLE_FILES, 6, "Kamileon", ("#05030A", "#22E4D5", "#FF4FC8")),
        ThemeSource("jester", "sh.swrlz.theme.jester_glitch_dragon", "Jester Glitch Dragon", masters / "07_jester_progress", JESTER_ROLE_FILES, 7, "Jester", ("#08020D", "#B66CFF", "#FFD34E")),
    ]


def ensure_sources(themes: Iterable[ThemeSource], masters: Path) -> None:
    missing: list[Path] = []
    for theme in themes:
        missing.extend(theme.progress_dir / name for name in theme.role_files.values() if not (theme.progress_dir / name).is_file())
        if theme.identity_index and theme.identity_stem:
            missing.extend(
                [
                    masters / f"01_launchers_kapanions/Kapanions/{theme.identity_index:02d}_{theme.identity_stem}_Kapanion.png",
                    masters / f"01_launchers_kapanions/Launcher_Icons/CLIENT/{theme.identity_index:02d}_{theme.identity_stem}_CLIENT.png",
                    masters / f"01_launchers_kapanions/Launcher_Icons/SERVER/{theme.identity_index:02d}_{theme.identity_stem}_SERVER.png",
                ]
            )
    missing.extend(masters / f"08_jester_startup/{name}" for name in STARTUP_FILES.values())
    missing = [path for path in missing if not path.is_file()]
    if missing:
        raise SystemExit("Missing source assets:\n" + "\n".join(str(path) for path in missing))


def copy_runtime_tree(staging: Path, app_root: Path, target: str) -> None:
    drawable = app_root / "src/main/res/drawable-nodpi"
    legacy_launcher = app_root / "src/main/res/mipmap-nodpi"
    assets = app_root / "src/main/assets/themes"
    drawable.mkdir(parents=True, exist_ok=True)
    legacy_launcher.mkdir(parents=True, exist_ok=True)
    assets.mkdir(parents=True, exist_ok=True)
    for existing in drawable.glob("theme_*.webp"):
        existing.unlink()
    for source in sorted((staging / "drawable").glob("*.webp")):
        shutil.copy2(source, drawable / source.name)
    for slug in sorted(NEW_LAUNCHER_SLUGS):
        source = staging / "drawable" / f"theme_launcher_{target}_{slug}.webp"
        shutil.copy2(source, legacy_launcher / f"ic_launcher_theme_{slug}.webp")
    shutil.copy2(staging / "runtime_asset_catalog.json", assets / "runtime_asset_catalog.json")


def prepare_staging(staging: Path, protected_roots: Iterable[Path]) -> None:
    if staging == Path(staging.anchor) or any(
        staging == root or staging in root.parents or root in staging.parents
        for root in protected_roots
    ):
        raise SystemExit(f"Refusing unsafe staging directory: {staging}")
    marker = staging / STAGING_MARKER
    if staging.exists():
        if not staging.is_dir() or not marker.is_file():
            raise SystemExit(
                "Refusing to clear an existing unmarked staging directory: "
                f"{staging}"
            )
        shutil.rmtree(staging)
    staging.mkdir(parents=True)
    (staging / STAGING_MARKER).write_text(
        "Owned by SWRLZ theme asset preprocessing.\n",
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--masters", type=Path, required=True)
    parser.add_argument("--client-app", type=Path, required=True)
    parser.add_argument("--server-app", type=Path, required=True)
    parser.add_argument("--staging", type=Path, required=True)
    args = parser.parse_args()

    masters = args.masters.resolve()
    client_app = args.client_app.resolve()
    server_app = args.server_app.resolve()
    staging = args.staging.resolve()
    drawable = staging / "drawable"
    prepare_staging(staging, (masters, client_app, server_app))
    drawable.mkdir(parents=True)

    themes = theme_sources(masters)
    ensure_sources(themes, masters)
    catalog: dict[str, object] = {
        "manifestVersion": 1,
        "generatedFrom": "SWRLZ supplied theme master packs",
        "themes": [],
    }

    for theme in themes:
        entries: list[dict[str, object]] = []
        for role, filename in theme.role_files.items():
            source = theme.progress_dir / filename
            output = drawable / f"theme_progress_{theme.slug}_{role}.webp"
            save_webp(progress_derivative(source, role), output)
            entries.append(runtime_entry(output, f"progress.{role}", source.relative_to(masters)))

        if theme.identity_index and theme.identity_stem:
            identity = masters / "01_launchers_kapanions"
            kapanion_source = identity / f"Kapanions/{theme.identity_index:02d}_{theme.identity_stem}_Kapanion.png"
            kapanion_output = drawable / f"theme_kapanion_{theme.slug}.webp"
            save_webp(square_canvas(rgba(kapanion_source), 512, 22, circular=True), kapanion_output)
            entries.append(runtime_entry(kapanion_output, "kapanion.shared", kapanion_source.relative_to(masters)))
            for target in ("CLIENT", "SERVER"):
                source = identity / f"Launcher_Icons/{target}/{theme.identity_index:02d}_{theme.identity_stem}_{target}.png"
                output = drawable / f"theme_launcher_{target.lower()}_{theme.slug}.webp"
                save_webp(square_canvas(rgba(source), 512, 40, circular=True), output)
                entries.append(runtime_entry(output, f"launcher.{target.lower()}", source.relative_to(masters)))

        if theme.slug == "jester":
            startup_dir = masters / "08_jester_startup"
            for role, filename in STARTUP_FILES.items():
                source = startup_dir / filename
                output = drawable / f"theme_startup_jester_{role}.webp"
                max_size = (768, 512) if role == "radial" else (512, 512)
                save_webp(fit(alpha_crop(rgba(source), padding=8), *max_size), output)
                entries.append(runtime_entry(output, f"startup.{role}", source.relative_to(masters)))

        catalog["themes"].append(
            {
                "id": theme.theme_id,
                "displayName": theme.display_name,
                "palette": {
                    "background": theme.palette[0],
                    "primary": theme.palette[1],
                    "secondary": theme.palette[2],
                },
                "assets": sorted(entries, key=lambda item: str(item["role"])),
            }
        )

    catalog_path = staging / "runtime_asset_catalog.json"
    catalog_path.write_text(json.dumps(catalog, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    copy_runtime_tree(staging, client_app, "client")
    copy_runtime_tree(staging, server_app, "server")
    print(f"Generated {sum(len(item['assets']) for item in catalog['themes'])} runtime assets")
    print(f"Catalog: {catalog_path}")


if __name__ == "__main__":
    main()
