#!/usr/bin/env python3
"""Derive bounded CLIENT Glitch Dragon Glass chrome from its approved master.

This script is intentionally CLIENT-only. It does not touch SERVER resources,
the shared 101-asset master-pack set, or application behavior.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw


DENSITIES = {
    "mdpi": 48,
    "hdpi": 72,
    "xhdpi": 96,
    "xxhdpi": 144,
    "xxxhdpi": 192,
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def save_png(image: Image.Image, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path, "PNG", optimize=True, compress_level=9)


def circular(image: Image.Image) -> Image.Image:
    rgba = image.convert("RGBA")
    mask = Image.new("L", rgba.size, 0)
    ImageDraw.Draw(mask).ellipse((0, 0, rgba.width - 1, rgba.height - 1), fill=255)
    rgba.putalpha(ImageChops.multiply(rgba.getchannel("A"), mask))
    return rgba


def update_catalog(
    catalog_path: Path,
    background_path: Path,
    teal_launcher_path: Path,
) -> None:
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    catalog["generatedFrom"] = (
        "SWRLZ supplied theme master packs plus approved built-in "
        "Glitch Dragon Glass masters"
    )
    entry = {
        "id": "sh.swrlz.theme.glitch_dragon_glass",
        "displayName": "Glitch Dragon Glass",
        "palette": {
            "background": "#03030B",
            "primary": "#38E8FF",
            "secondary": "#9A55FF",
        },
        "assets": [
            {
                "role": "background.app",
                "resource": background_path.stem,
                "runtimeFile": background_path.name,
                "source": "drawable-nodpi/swrlz_glitch_dragon_launcher.png",
                "width": 720,
                "height": 1280,
                "bytes": background_path.stat().st_size,
                "sha256": sha256(background_path),
            }
        ],
    }
    themes = [
        theme for theme in catalog.get("themes", [])
        if theme.get("id") != entry["id"]
    ]
    for theme in themes:
        if theme.get("id") != "sh.swrlz.theme.teal_serpent":
            continue
        assets = [
            asset for asset in theme.get("assets", [])
            if asset.get("role") != "launcher.client"
        ]
        assets.append(
            {
                "role": "launcher.client",
                "resource": teal_launcher_path.stem,
                "runtimeFile": teal_launcher_path.name,
                "source": "derived:theme_progress_teal_serpent_emblem.webp",
                "width": 512,
                "height": 512,
                "bytes": teal_launcher_path.stat().st_size,
                "sha256": sha256(teal_launcher_path),
            }
        )
        theme["assets"] = sorted(assets, key=lambda asset: str(asset["role"]))
    catalog["themes"] = [entry, *themes]
    catalog_path.write_text(
        json.dumps(catalog, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--app",
        type=Path,
        required=True,
        help="Path to android/app",
    )
    args = parser.parse_args()
    app = args.app.resolve()
    if not (app / "src/main/AndroidManifest.xml").is_file():
        raise SystemExit(f"Not an Android app root: {app}")

    res = app / "src/main/res"
    drawable = res / "drawable-nodpi"
    master_path = drawable / "swrlz_glitch_dragon_launcher.png"
    if not master_path.is_file():
        raise SystemExit(f"Missing approved launcher master: {master_path}")

    with Image.open(master_path) as source_image:
        source = source_image.convert("RGBA")

    background = Image.new("RGB", (720, 1280), "#03030B")
    background_art = source.convert("RGB").resize((720, 720), Image.Resampling.LANCZOS)
    background.paste(background_art, (0, 280))
    background_path = drawable / "theme_background_glitch_dragon_glass.webp"
    background.save(background_path, "WEBP", quality=82, method=6)

    foreground_art = source.resize((356, 356), Image.Resampling.LANCZOS)
    for seed in (
        (0, 0),
        (foreground_art.width - 1, 0),
        (0, foreground_art.height - 1),
        (foreground_art.width - 1, foreground_art.height - 1),
    ):
        ImageDraw.floodfill(foreground_art, seed, (0, 0, 0, 0), thresh=28)
    foreground = Image.new("RGBA", (432, 432), (0, 0, 0, 0))
    foreground.alpha_composite(foreground_art, (38, 38))
    save_png(
        foreground,
        drawable / "ic_launcher_glitch_dragon_glass_foreground.png",
    )

    for density, size in DENSITIES.items():
        icon = source.resize((size, size), Image.Resampling.LANCZOS)
        target = res / f"mipmap-{density}"
        save_png(icon, target / "ic_launcher_glitch_dragon.png")
        save_png(circular(icon), target / "ic_launcher_glitch_dragon_round.png")

    teal_emblem_path = drawable / "theme_progress_teal_serpent_emblem.webp"
    if not teal_emblem_path.is_file():
        raise SystemExit(f"Missing Teal Serpent emblem: {teal_emblem_path}")
    with Image.open(teal_emblem_path) as teal_image:
        teal = teal_image.convert("RGBA")
    teal.thumbnail((420, 420), Image.Resampling.LANCZOS)
    teal_canvas = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
    teal_canvas.alpha_composite(
        teal,
        ((512 - teal.width) // 2, (512 - teal.height) // 2),
    )
    teal_launcher_path = drawable / "theme_launcher_client_teal_serpent.webp"
    teal_canvas.save(
        teal_launcher_path,
        "WEBP",
        lossless=True,
        method=6,
        exact=True,
    )
    teal_mipmap_path = res / "mipmap-nodpi/ic_launcher_theme_teal_serpent.webp"
    teal_mipmap_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(teal_launcher_path, teal_mipmap_path)

    catalog_path = app / "src/main/assets/themes/runtime_asset_catalog.json"
    update_catalog(catalog_path, background_path, teal_launcher_path)
    print(f"Derived CLIENT chrome from {master_path.name}")
    print(f"Background SHA-256: {sha256(background_path)}")
    print(f"Adaptive foreground: {foreground.size[0]}x{foreground.size[1]}")
    print(f"Launcher densities: {len(DENSITIES) * 2}")
    print(f"Teal launcher SHA-256: {sha256(teal_launcher_path)}")


if __name__ == "__main__":
    main()
