# Theme runtime asset pipeline

`preprocess_theme_assets.py` creates bounded Android derivatives from the supplied SWRLZ master artwork.

The pipeline:

- never edits source masters;
- verifies all expected input files before output;
- trims transparent padding;
- crops progress heads around the densest visible ornament;
- creates bounded progress, identity, launcher, Kapanion, and startup sizes;
- writes lossless WebP without frame-by-frame allocation;
- emits exact runtime dimensions, byte sizes, SHA-256 values, source paths, and roles;
- copies one identical runtime catalog/resource set into CLIENT and SERVER;
- regenerates target-specific legacy launcher WebP derivatives while adaptive-icon XML remains source-controlled;
- clears only its generated `theme_*.webp` namespace and refuses to clear an existing unmarked staging directory;
- intentionally does not invent missing theme art.

Example:

```bash
python tools/theme_assets/preprocess_theme_assets.py \
  --masters /path/to/inspected/theme-masters \
  --client-app /path/to/client/android/app \
  --server-app /path/to/server/app \
  --staging /path/to/temporary/theme-runtime
```

Source packages contain the deterministic tool and runtime derivatives, not duplicate full-resolution masters. Jester is the only complete startup family in this checkpoint. Teal Serpent has progress assets but no dedicated launcher/Kapanion identity.

## CLIENT Glitch Dragon Glass chrome

`derive_client_theme_chrome.py` is the CLIENT-only deterministic derivative step added by `INT-THEME-035C`. It keeps the 1536×1536 approved launcher master out of the full-screen rendering path and regenerates:

- the bounded 720×1280 runtime background WebP;
- the transparent 432×432 adaptive foreground;
- five standard and five round launcher density resources;
- a distinct Teal Serpent CLIENT launcher derived from Teal’s own emblem;
- the exact background entry in `runtime_asset_catalog.json`.

```bash
python tools/theme_assets/derive_client_theme_chrome.py \
  --app android/app
```

This tool does not modify SERVER or the shared 101-asset master-pack output.

## INT-THEME-039A ignition resource input

`SWRLZ_Core_Ignition_Resource_Pack_Jester_to_Kamileon.zip` was accepted as a user-supplied runtime-art source at SHA-256 `fc5e41188e429cf5b088f8da47ead713ba0e39849b75e79e6f5011e532d58c3c`. Its root manifest was fully revalidated before integration. CFv2.1.15 normalizes the five missing non-Jester families into lossless WebP runtime derivatives and keeps the pre-existing Jester startup resources unchanged. The runtime mapping is documented in `docs/implementation/INT_THEME_035A_ASSET_PROVENANCE.md`.

