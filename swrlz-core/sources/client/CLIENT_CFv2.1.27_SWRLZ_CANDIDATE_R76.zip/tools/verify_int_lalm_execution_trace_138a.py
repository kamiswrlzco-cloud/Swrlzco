#!/usr/bin/env python3
"""Focused source/static verifier for INT-LALM-EXECUTION-TRACE-138A."""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from pathlib import Path
CHECKPOINT='INT-LALM-EXECUTION-TRACE-138A'
def sha256(p:Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()
def require_text(p:Path, snippets:list[str], failures:list[str]):
    if not p.is_file(): failures.append(f'missing: {p}'); return
    t=p.read_text(encoding='utf-8')
    for x in snippets:
        if x not in t: failures.append(f'missing snippet {x!r}: {p}')
def kotlin_balanced(p:Path):
    text=p.read_text(encoding='utf-8'); stack=[]; pairs={')':'(',']':'[','}':'{'}; opens=set(pairs.values()); i=0; state='code'; depth=0
    while i<len(text):
        two=text[i:i+2]; three=text[i:i+3]; c=text[i]
        if state=='code':
            if three=='"""': state='triple'; i+=3; continue
            if two=='//': state='line'; i+=2; continue
            if two=='/*': state='block'; depth=1; i+=2; continue
            if c=='"': state='string'; i+=1; continue
            if c=="'": state='char'; i+=1; continue
            if c in opens: stack.append((c,i))
            elif c in pairs:
                if not stack or stack[-1][0]!=pairs[c]: return False,f'unexpected {c} at {i}'
                stack.pop()
        elif state=='line':
            if c=='\n': state='code'
        elif state=='block':
            if two=='/*': depth+=1; i+=2; continue
            if two=='*/':
                depth-=1; i+=2
                if depth==0: state='code'
                continue
        elif state=='triple':
            if three=='"""': state='code'; i+=3; continue
        elif state in {'string','char'}:
            if c=='\\': i+=2; continue
            if (state=='string' and c=='"') or (state=='char' and c=="'"): state='code'
        i+=1
    if state not in {'code','line'}: return False,f'unterminated lexical state {state}'
    if stack: return False,f'unclosed {stack[-1][0]} at {stack[-1][1]}'
    return True,'balanced'
def validate_json(root, failures):
    n=0
    for p in sorted(root.rglob('*.json')):
        if any(x in {'build','.gradle','node_modules'} for x in p.parts): continue
        n+=1
        try: json.loads(p.read_text(encoding='utf-8-sig'))
        except Exception as e: failures.append(f'invalid JSON {p}: {e}')
    return n
def validate_manifest(root, failures):
    m=root/'SOURCE_MANIFEST.sha256'
    if not m.is_file(): failures.append(f'missing manifest: {m}'); return 0
    listed={}
    for i,line in enumerate(m.read_text().splitlines(),1):
        z=re.fullmatch(r'([0-9a-f]{64})  (.+)',line)
        if not z: failures.append(f'malformed manifest line {m}:{i}'); continue
        listed[z.group(2)]=z.group(1)
    expected={p.relative_to(root).as_posix():sha256(p) for p in root.rglob('*') if p.is_file() and p.resolve()!=m.resolve()}
    if listed!=expected:
        failures.append(f'manifest mismatch {root}: missing={sorted(set(expected)-set(listed))[:5]} extra={sorted(set(listed)-set(expected))[:5]} changed={sorted(k for k in set(expected)&set(listed) if expected[k]!=listed[k])[:5]}')
    return len(listed)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--client',type=Path,required=True); ap.add_argument('--server',type=Path,required=True); ap.add_argument('--skip-manifest',action='store_true'); a=ap.parse_args(); c=a.client.resolve(); s=a.server.resolve(); failures=[]
    require_text(c/'android/app/build.gradle.kts',['versionCode = 174','R48',CHECKPOINT,'lalm-execution-trace-r48'],failures)
    require_text(s/'app/build.gradle.kts',['versionCode = 199','R76',CHECKPOINT,'lalm-execution-trace-r76'],failures)
    cc=c/'android/llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2.kt'; sc=s/'llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2.kt'
    for p in (cc,sc): require_text(p,['object SwrlzLlmOperationalPhaseV2','TRUTH_CAPSULE_READY','TOOL_REVIEW_READY','PREFILL','FIRST_TOKEN','hidden reasoning'],failures)
    if not cc.is_file() or not sc.is_file() or cc.read_bytes()!=sc.read_bytes(): failures.append('paired stream contract is not byte-identical')
    ctest=c/'android/llm-contract/src/test/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2Test.kt'; stest=s/'llm-contract/src/test/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2Test.kt'
    if not ctest.is_file() or not stest.is_file() or ctest.read_bytes()!=stest.read_bytes(): failures.append('paired stream contract test is not byte-identical')
    require_text(c/'android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamStateMachine.kt',['ClientLlmProgressStep','advanceProgressTrail','progressTrail = advanceProgressTrail','takeLast(16)'],failures)
    require_text(c/'android/app/src/main/java/sh/swurlz/core/data/ClientChatHistoryStore.kt',['swrlz-client-chat-history-v3','ClientChatTraceStep','executionTrace','traceToJson','traceFromJson'],failures)
    require_text(c/'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt',['§WYRLZ · WORKING','§WYRLZ · STREAMING','Worked for ','Operational stages only · hidden reasoning is not exposed'],failures)
    require_text(s/'app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLlmRuntime.kt',['phase = "TRUTH_CAPSULE_READY"','phase = "TOOL_REVIEW_READY"','phase = "MODEL_READY"','GENERATING_HEARTBEAT','phase = "FIRST_TOKEN"'],failures)
    require_text(s/'app/src/main/java/sh/swrlz/nodehost/ui/ServerChatScreen.kt',['ServerLalmTraceStep','advanceServerTrace','toExecutionTraceJson','parseServerExecutionTrace','§WYRLZ · WORKING','Worked for ','hidden reasoning is not exposed'],failures)
    require_text(s/'app/src/main/java/sh/swrlz/nodehost/data/entity/ChatMessageEntity.kt',['executionTraceJson'],failures)
    require_text(s/'app/src/main/java/sh/swrlz/nodehost/data/NodeHostDatabase.kt',['version = 17'],failures)
    require_text(s/'app/src/main/java/sh/swrlz/nodehost/di/AppModule.kt',['MIGRATION_16_17','ALTER TABLE chat_messages ADD COLUMN executionTraceJson TEXT NOT NULL DEFAULT'],failures)
    require_text(s/'app/src/main/java/sh/swrlz/nodehost/data/repository/ChatRepository.kt',['executionTraceJson = cleanNullable(evidence.executionTraceJson'],failures)
    # No trace code may accidentally treat draft/model reasoning as display content.
    for p in [c/'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt', s/'app/src/main/java/sh/swrlz/nodehost/ui/ServerChatScreen.kt']:
        t=p.read_text(encoding='utf-8') if p.is_file() else ''
        if 'DraftDelta' in t or 'TokenGenerated' in t: failures.append(f'UI directly references private generation events: {p}')
    kpaths=[cc, c/'android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamStateMachine.kt', c/'android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamRuntime.kt', c/'android/app/src/main/java/sh/swurlz/core/data/ClientChatHistoryStore.kt', c/'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt', sc, s/'app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLlmRuntime.kt', s/'app/src/main/java/sh/swrlz/nodehost/ui/ServerChatScreen.kt', s/'app/src/main/java/sh/swrlz/nodehost/data/entity/ChatMessageEntity.kt', s/'app/src/main/java/sh/swrlz/nodehost/data/repository/ChatRepository.kt', s/'app/src/main/java/sh/swrlz/nodehost/data/repository/ChatResponseEvidence.kt', s/'app/src/main/java/sh/swrlz/nodehost/data/NodeHostDatabase.kt', s/'app/src/main/java/sh/swrlz/nodehost/di/AppModule.kt']
    for p in kpaths:
        if not p.is_file(): failures.append(f'missing Kotlin path: {p}'); continue
        ok,d=kotlin_balanced(p)
        if not ok: failures.append(f'Kotlin structural scan failed {p}: {d}')
    cj=validate_json(c,failures); sj=validate_json(s,failures); cm=sm=0
    if not a.skip_manifest: cm=validate_manifest(c,failures); sm=validate_manifest(s,failures)
    out={'checkpoint':CHECKPOINT,'status':'PASS' if not failures else 'FAIL','clientJsonFiles':cj,'serverJsonFiles':sj,'clientManifestEntries':cm,'serverManifestEntries':sm,'pairedContractSha256':sha256(sc) if sc.is_file() else '','failures':failures,'buildBoundary':'STATIC_ONLY_NO_APK_NO_ANDROID_COMPILE'}
    print(json.dumps(out,indent=2,sort_keys=True)); return 0 if not failures else 1
if __name__=='__main__': sys.exit(main())
