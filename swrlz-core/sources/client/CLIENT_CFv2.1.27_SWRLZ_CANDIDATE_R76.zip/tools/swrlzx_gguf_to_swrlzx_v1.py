#!/usr/bin/env python3
"""SWRLZX checkpoint 002A GGUF -> SWRLZX conversion bridge.

Design rules:
- GGUF v2/v3 little-endian source only.
- Bounded parsing of metadata/tensor tables; tensor payload is never loaded wholesale.
- The GGUF tensor-data blob is copied byte-for-byte into one SWRLZX TENSOR_DATA section.
- Each tensor descriptor points at its original section-relative offset and is SHA-256 bound.
- Output is deterministic for identical input bytes + converter revision.
- No runtime switch is performed by this tool.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO, Iterable

CONVERTER_REVISION = "swrlzx-gguf-bridge-v1/INT-AI-SWRLZX-002A"
LALM_010A_CONVERTER_REVISION = "swrlzx-lalm-bringup-v1/INT-AI-SWRLZX-010A"
LALM_010A_CHECKPOINT = "INT-AI-SWRLZX-010A"
LALM_011A_CONVERTER_REVISION = "swrlzx-lalm-native-graph-v1/INT-AI-SWRLZX-011A"
LALM_011A_CHECKPOINT = "INT-AI-SWRLZX-011A"
LALM_RUNTIME_CONTRACT = "swrlzx.lalm.runtime.v1"
LALM_TENSOR_KV_CONTRACT = "swrlzx.lalm.tensor_kv.v1"
LALM_CHAT_TEMPLATE_CONTRACT = "swrlzx.lalm.chat_template.v1"
LALM_SAMPLER_CONTRACT = "swrlzx.lalm.sampler.v1"
LALM_GGML_K_QUANT_CONTRACT = "swrlzx.quant.ggml-k.v1"
LALM_IDENTITY_CONTRACT = "swrlzx.lalm.identity.v1"
LALM_MODEL_ID = "swrlz-lalm-001a"
LALM_DISPLAY_NAME = "SWRLZ-LALM-001A"
LALM_LINEAGE_ROOT_ID = "swrlz-lalm-lineage"
LALM_BRANDED_FILE = "SWRLZ-LALM-001A.§wyrlzx"
LALM_SOURCE_NAME = "SWRLZ-LFM-OPT-001A.gguf"
LALM_SOURCE_SIZE_BYTES = 229_315_680
LALM_SOURCE_SHA256 = "651cd5c40e4ef24de2ff12c2b53b257d15816ddd4346e2575e6768a6ec1d8590"
SWRLZX_MAGIC = b"SWRLZX\r\n"
SWRLZX_MAJOR = 1
SWRLZX_MINOR = 0
HEADER_BYTES = 128
TOC_ENTRY_BYTES = 128
ENDIAN_MARKER = 0x01020304
ALIGNMENT = 64
MAX_ALIGNMENT = 1 << 20
MAX_SECTIONS = 4096
INTEGRITY_MAGIC = b"SXI1"
INTEGRITY_HEADER_BYTES = 40
INTEGRITY_RECORD_BYTES = 36
COPY_BUFFER = 1 << 20
MAX_GGUF_METADATA = 100_000
MAX_GGUF_TENSORS = 2_000_000
MAX_STRING_BYTES = 16 * 1024 * 1024
MAX_ARRAY_ELEMENTS = 2_000_000
MAX_METADATA_JSON_BYTES = 64 * 1024 * 1024

# SWRLZX section wire IDs from SWRLZX_CONTAINER_V1.
SEC_MANIFEST = 1
SEC_ARCH = 2
SEC_TOKENIZER = 3
SEC_TENSOR_DIR = 4
SEC_TENSOR_DATA = 5
SEC_QUANT = 6
SEC_GENERATION = 7
SEC_STREAM = 8
SEC_MODULES = 9
SEC_LINEAGE = 10
SEC_INTEGRITY = 11
SEC_SIGNATURE = 12
SEC_VENDOR = 0x7FFFFFFF

CODEC_RAW = 0
CODEC_JSON = 1
CODEC_BINARY = 2

# GGUF metadata value types.
GGUF_UINT8 = 0
GGUF_INT8 = 1
GGUF_UINT16 = 2
GGUF_INT16 = 3
GGUF_UINT32 = 4
GGUF_INT32 = 5
GGUF_FLOAT32 = 6
GGUF_BOOL = 7
GGUF_STRING = 8
GGUF_ARRAY = 9
GGUF_UINT64 = 10
GGUF_INT64 = 11
GGUF_FLOAT64 = 12

GGML_TYPE_NAMES = {
    0: "f32", 1: "f16", 2: "q4_0", 3: "q4_1", 4: "deprecated_q4_2", 5: "deprecated_q4_3",
    6: "q5_0", 7: "q5_1", 8: "q8_0", 9: "q8_1", 10: "q2_k", 11: "q3_k", 12: "q4_k",
    13: "q5_k", 14: "q6_k", 15: "q8_k", 16: "iq2_xxs", 17: "iq2_xs", 18: "iq3_xxs",
    19: "iq1_s", 20: "iq4_nl", 21: "iq3_s", 22: "iq2_s", 23: "iq4_xs", 24: "i8", 25: "i16",
    26: "i32", 27: "i64", 28: "f64", 29: "iq1_m", 30: "bf16", 31: "removed_q4_0_4_4",
    32: "removed_q4_0_4_8", 33: "removed_q4_0_8_8", 34: "tq1_0", 35: "tq2_0",
    36: "removed_iq4_nl_4_4", 37: "removed_iq4_nl_4_8", 38: "removed_iq4_nl_8_8",
    39: "mxfp4", 40: "nvfp4", 41: "q1_0", 42: "q2_0",
}

@dataclass(frozen=True)
class ConversionProfile:
    checkpoint: str = "INT-AI-SWRLZX-002A"
    converter_revision: str = CONVERTER_REVISION
    default_model_id: str | None = None
    default_display_name: str | None = None
    lineage_root_id: str | None = None
    required_runtime_contracts: tuple[str, ...] = ()
    capabilities: tuple[str, ...] = ()
    change_note: str = "Checkpoint 002A deterministic byte-preserving GGUF to SWRLZX conversion; no runtime-path switch."
    require_exact_lalm_source: bool = False
    emit_lalm_executable_graph: bool = False

    @staticmethod
    def lalm_010a() -> "ConversionProfile":
        return ConversionProfile(
            checkpoint=LALM_010A_CHECKPOINT,
            converter_revision=LALM_010A_CONVERTER_REVISION,
            default_model_id=LALM_MODEL_ID,
            default_display_name=LALM_DISPLAY_NAME,
            lineage_root_id=LALM_LINEAGE_ROOT_ID,
            required_runtime_contracts=(LALM_IDENTITY_CONTRACT,),
            capabilities=("lalm_native_identity", "source_provenance_preserved"),
            change_note=(
                "Checkpoint 010A creates SWRLZ-LALM-001A as the native LALM identity while preserving "
                "the exact optimized LFM source artifact, architecture family and SHA-256 provenance. "
                "No production promotion or runtime-parity claim is performed by conversion."
            ),
            require_exact_lalm_source=True,
        )

    @staticmethod
    def lalm_011a() -> "ConversionProfile":
        return ConversionProfile(
            checkpoint=LALM_011A_CHECKPOINT,
            converter_revision=LALM_011A_CONVERTER_REVISION,
            default_model_id=LALM_MODEL_ID,
            default_display_name=LALM_DISPLAY_NAME,
            lineage_root_id=LALM_LINEAGE_ROOT_ID,
            required_runtime_contracts=(
                LALM_IDENTITY_CONTRACT,
                LALM_RUNTIME_CONTRACT,
                LALM_TENSOR_KV_CONTRACT,
                LALM_CHAT_TEMPLATE_CONTRACT,
                LALM_SAMPLER_CONTRACT,
                LALM_GGML_K_QUANT_CONTRACT,
            ),
            capabilities=(
                "lalm_native_identity",
                "source_provenance_preserved",
                "lalm_native_execution_graph",
                "lalm_tensor_kv",
                "ggml_bpe_reference",
                "ggml_k_reference_quantization",
            ),
            change_note=(
                "Checkpoint 011A emits the executable LFM2-derived LALM graph, tokenizer, sampler and "
                "quantization contracts for the pinned source lineage. Native execution remains a candidate "
                "until real-model conversion and checkpoint 012A parity evidence are complete."
            ),
            require_exact_lalm_source=True,
            emit_lalm_executable_graph=True,
        )


@dataclass(frozen=True)
class TensorInfo:
    name: str
    shape: tuple[int, ...]
    ggml_type: int
    offset: int
    span_length: int = 0
    sha256: str = ""

@dataclass(frozen=True)
class GgufIndex:
    version: int
    tensor_count: int
    metadata_count: int
    metadata: dict[str, Any]
    metadata_types: dict[str, Any]
    tensors: tuple[TensorInfo, ...]
    alignment: int
    tensor_data_offset: int
    file_bytes: int
    source_sha256: str

@dataclass(frozen=True)
class Section:
    section_id: int
    section_type: int
    codec: int
    schema_version: int
    alignment: int
    flags: int
    length: int
    sha256: bytes
    payload: bytes | None = None
    source_path: Path | None = None
    source_offset: int = 0

@dataclass(frozen=True)
class Toc:
    section_id: int
    section_type: int
    flags: int
    alignment: int
    offset: int
    stored_length: int
    logical_length: int
    codec: int
    schema_version: int
    sha256: bytes


def fail(msg: str) -> "NoReturn":
    raise ValueError(msg)


def align_up(value: int, alignment: int) -> int:
    if alignment < ALIGNMENT or alignment > MAX_ALIGNMENT or alignment & (alignment - 1):
        fail(f"SWRLZX_ALIGNMENT_INVALID:{alignment}")
    return (value + alignment - 1) & ~(alignment - 1)


def sha256_file(path: Path, buffer_bytes: int = COPY_BUFFER) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(buffer_bytes)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def sha256_range(path: Path, offset: int, length: int, buffer_bytes: int = COPY_BUFFER) -> bytes:
    if offset < 0 or length < 0:
        fail("RANGE_INVALID")
    h = hashlib.sha256()
    with path.open("rb") as f:
        f.seek(offset)
        remaining = length
        while remaining:
            chunk = f.read(min(buffer_bytes, remaining))
            if not chunk:
                fail("UNEXPECTED_EOF")
            h.update(chunk)
            remaining -= len(chunk)
    return h.digest()


class GgufReader:
    def __init__(self, f: BinaryIO):
        self.f = f

    def read_exact(self, n: int) -> bytes:
        if n < 0:
            fail("GGUF_NEGATIVE_READ")
        b = self.f.read(n)
        if len(b) != n:
            fail("GGUF_UNEXPECTED_EOF")
        return b

    def u8(self) -> int: return self.read_exact(1)[0]
    def i8(self) -> int: return struct.unpack("<b", self.read_exact(1))[0]
    def u16(self) -> int: return struct.unpack("<H", self.read_exact(2))[0]
    def i16(self) -> int: return struct.unpack("<h", self.read_exact(2))[0]
    def u32(self) -> int: return struct.unpack("<I", self.read_exact(4))[0]
    def i32(self) -> int: return struct.unpack("<i", self.read_exact(4))[0]
    def u64(self) -> int: return struct.unpack("<Q", self.read_exact(8))[0]
    def i64(self) -> int: return struct.unpack("<q", self.read_exact(8))[0]
    def f32(self) -> float: return struct.unpack("<f", self.read_exact(4))[0]
    def f64(self) -> float: return struct.unpack("<d", self.read_exact(8))[0]

    def string(self) -> str:
        n = self.u64()
        if n > MAX_STRING_BYTES:
            fail(f"GGUF_STRING_TOO_LARGE:{n}")
        try:
            return self.read_exact(n).decode("utf-8")
        except UnicodeDecodeError as e:
            fail(f"GGUF_STRING_UTF8_INVALID:{e.start}")

    def value(self, typ: int) -> Any:
        if typ == GGUF_UINT8: return self.u8()
        if typ == GGUF_INT8: return self.i8()
        if typ == GGUF_UINT16: return self.u16()
        if typ == GGUF_INT16: return self.i16()
        if typ == GGUF_UINT32: return self.u32()
        if typ == GGUF_INT32: return self.i32()
        if typ == GGUF_FLOAT32: return self.f32()
        if typ == GGUF_BOOL:
            v = self.u8()
            if v not in (0, 1): fail(f"GGUF_BOOL_INVALID:{v}")
            return bool(v)
        if typ == GGUF_STRING: return self.string()
        if typ == GGUF_UINT64: return self.u64()
        if typ == GGUF_INT64: return self.i64()
        if typ == GGUF_FLOAT64: return self.f64()
        if typ == GGUF_ARRAY:
            element_type = self.u32()
            if element_type == GGUF_ARRAY:
                fail("GGUF_NESTED_ARRAY_UNSUPPORTED")
            count = self.u64()
            if count > MAX_ARRAY_ELEMENTS:
                fail(f"GGUF_ARRAY_TOO_LARGE:{count}")
            return [self.value(element_type) for _ in range(count)]
        fail(f"GGUF_METADATA_TYPE_UNSUPPORTED:{typ}")


def _metadata_type_shape(typ: int, value: Any) -> Any:
    if typ == GGUF_ARRAY:
        # Type details are not directly retained after value(); infer a stable diagnostic class only.
        if not value:
            return {"type": "array", "element": "empty"}
        return {"type": "array", "element": type(value[0]).__name__}
    return {"type": typ}


def parse_gguf(path: Path) -> GgufIndex:
    file_bytes = path.stat().st_size
    if file_bytes < 24:
        fail("GGUF_FILE_TOO_SMALL")
    source_sha = sha256_file(path)
    with path.open("rb") as f:
        r = GgufReader(f)
        if r.read_exact(4) != b"GGUF":
            fail("GGUF_MAGIC_INVALID")
        version = r.u32()
        if version not in (2, 3):
            fail(f"GGUF_VERSION_UNSUPPORTED:{version}")
        tensor_count = r.u64()
        metadata_count = r.u64()
        if tensor_count < 1:
            fail("GGUF_TENSOR_COUNT_INVALID:0")
        if metadata_count < 1:
            fail("GGUF_METADATA_COUNT_INVALID:0")
        if tensor_count > MAX_GGUF_TENSORS:
            fail(f"GGUF_TENSOR_COUNT_TOO_LARGE:{tensor_count}")
        if metadata_count > MAX_GGUF_METADATA:
            fail(f"GGUF_METADATA_COUNT_TOO_LARGE:{metadata_count}")

        metadata: dict[str, Any] = {}
        metadata_types: dict[str, Any] = {}
        for _ in range(metadata_count):
            key = r.string()
            if not key or len(key.encode("utf-8")) > 65535:
                fail("GGUF_METADATA_KEY_INVALID")
            if key in metadata:
                fail(f"GGUF_METADATA_DUPLICATE:{key}")
            typ = r.u32()
            value = r.value(typ)
            metadata[key] = value
            metadata_types[key] = _metadata_type_shape(typ, value)

        alignment = metadata.get("general.alignment", 32)
        if not isinstance(alignment, int) or alignment < 8 or alignment > MAX_ALIGNMENT or alignment & (alignment - 1):
            fail(f"GGUF_ALIGNMENT_INVALID:{alignment}")

        tensors: list[TensorInfo] = []
        names: set[str] = set()
        for _ in range(tensor_count):
            name = r.string()
            if len(name.encode("utf-8")) > 64:
                fail(f"GGUF_TENSOR_NAME_TOO_LONG:{name[:80]}")
            if name in names:
                fail(f"GGUF_TENSOR_NAME_DUPLICATE:{name}")
            names.add(name)
            n_dims = r.u32()
            if n_dims < 1 or n_dims > 8:
                fail(f"GGUF_TENSOR_DIMS_INVALID:{name}:{n_dims}")
            shape = tuple(r.u64() for _ in range(n_dims))
            if any(d <= 0 for d in shape):
                fail(f"GGUF_TENSOR_SHAPE_INVALID:{name}")
            ggml_type = r.u32()
            offset = r.u64()
            if offset % alignment:
                fail(f"GGUF_TENSOR_OFFSET_ALIGNMENT:{name}:{offset}")
            tensors.append(TensorInfo(name=name, shape=shape, ggml_type=ggml_type, offset=offset))

        tensor_data_offset = (f.tell() + alignment - 1) & ~(alignment - 1)
        if tensor_data_offset > file_bytes:
            fail("GGUF_TENSOR_DATA_OFFSET_OUTSIDE_FILE")
        data_bytes = file_bytes - tensor_data_offset
        sorted_by_offset = sorted(tensors, key=lambda t: (t.offset, t.name))
        for i, tensor in enumerate(sorted_by_offset):
            if tensor.offset > data_bytes:
                fail(f"GGUF_TENSOR_OFFSET_OUTSIDE_DATA:{tensor.name}")
            next_offset = sorted_by_offset[i + 1].offset if i + 1 < len(sorted_by_offset) else data_bytes
            if next_offset <= tensor.offset:
                fail(f"GGUF_TENSOR_RANGE_OVERLAP:{tensor.name}")
        # Spans intentionally include any GGUF inter-tensor alignment padding. This preserves the source blob
        # byte-for-byte while checkpoint 003A owns typed runtime row-size interpretation.
        resolved: dict[str, TensorInfo] = {}
        for i, tensor in enumerate(sorted_by_offset):
            next_offset = sorted_by_offset[i + 1].offset if i + 1 < len(sorted_by_offset) else data_bytes
            span = next_offset - tensor.offset
            digest = sha256_range(path, tensor_data_offset + tensor.offset, span).hex()
            resolved[tensor.name] = TensorInfo(tensor.name, tensor.shape, tensor.ggml_type, tensor.offset, span, digest)
        tensors = [resolved[t.name] for t in tensors]

    # Bound the semantic metadata representation. The tensor blob itself is streamed separately.
    probe = canonical_json(metadata)
    if len(probe) > MAX_METADATA_JSON_BYTES:
        fail(f"GGUF_METADATA_CANONICAL_JSON_TOO_LARGE:{len(probe)}")
    return GgufIndex(version, tensor_count, metadata_count, metadata, metadata_types, tuple(tensors), alignment, tensor_data_offset, file_bytes, source_sha)


def canonical_json(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def safe_id(value: str, fallback: str) -> str:
    out = []
    for ch in value.strip().lower():
        if ch.isalnum() and ord(ch) < 128:
            out.append(ch)
        elif ch in "._-":
            out.append(ch)
        elif ch in " /:+":
            out.append("-")
    s = "".join(out).strip("-._")
    if len(s) < 3:
        s = fallback
    return s[:127]



LALM_011A_LAYER_KV_HEADS = [0, 0, 8, 0, 0, 8, 0, 0, 8, 0, 8, 0, 8, 0, 8, 0]


def _lalm_011a_validate_metadata(md: dict[str, Any]) -> None:
    def req_int(key: str, expected: int) -> None:
        got = md.get(key)
        if not isinstance(got, (int, float)) or int(got) != expected:
            fail(f"LALM_011A_METADATA_MISMATCH:{key}:{got}:{expected}")
    req_int("lfm2.block_count", 16)
    req_int("lfm2.embedding_length", 1024)
    req_int("lfm2.attention.head_count", 16)
    req_int("lfm2.feed_forward_length", 4608)
    req_int("lfm2.shortconv.l_cache", 3)
    kv = md.get("lfm2.attention.head_count_kv")
    if (list(kv) if isinstance(kv, list) else None) != LALM_011A_LAYER_KV_HEADS:
        fail(f"LALM_011A_LAYER_LAYOUT_MISMATCH:{kv}")
    rope = md.get("lfm2.rope.freq_base")
    if not isinstance(rope, (int, float)) or abs(float(rope) - 1_000_000.0) > 0.5:
        fail(f"LALM_011A_ROPE_MISMATCH:{rope}")
    eps = md.get("lfm2.attention.layer_norm_rms_epsilon")
    if not isinstance(eps, (int, float)) or abs(float(eps) - 1e-5) > 1e-9:
        fail(f"LALM_011A_NORM_EPS_MISMATCH:{eps}")
    if md.get("tokenizer.ggml.model") != "gpt2" or md.get("tokenizer.ggml.pre") != "lfm2":
        fail("LALM_011A_TOKENIZER_PROFILE_MISMATCH")
    tokens = md.get("tokenizer.ggml.tokens")
    merges = md.get("tokenizer.ggml.merges")
    if not isinstance(tokens, list) or len(tokens) != 65_536:
        fail(f"LALM_011A_VOCAB_MISMATCH:{0 if not isinstance(tokens, list) else len(tokens)}")
    if not isinstance(merges, list) or not merges:
        fail("LALM_011A_BPE_MERGES_REQUIRED")
    req_int("tokenizer.ggml.bos_token_id", 1)
    req_int("tokenizer.ggml.eos_token_id", 7)
    req_int("tokenizer.ggml.padding_token_id", 0)


def _lalm_011a_runtime_metadata(index: GgufIndex, tensors: list[dict[str, Any]], quant_hist: dict[str, int]) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    md = index.metadata
    _lalm_011a_validate_metadata(md)
    by_name = {t["name"]: t["tensorId"] for t in tensors}

    def tid(name: str) -> str:
        got = by_name.get(name)
        if not got:
            fail(f"LALM_011A_REQUIRED_TENSOR_MISSING:{name}")
        return got

    nodes: list[dict[str, Any]] = []
    def node(node_id: str, op: str, inputs: list[str], output: str, tensor_ids: list[str] | None = None, attrs: dict[str, str] | None = None) -> None:
        nodes.append({
            "id": node_id,
            "op": op,
            "inputs": inputs,
            "output": output,
            "tensorIds": tensor_ids or [],
            "attributes": attrs or {},
        })

    current = "hidden.embed"
    node("embed", "TOKEN_EMBED", ["token_id"], current, [tid("token_embd.weight")])
    for layer, kv_heads in enumerate(LALM_011A_LAYER_KV_HEADS):
        normed = f"l{layer}.operator_norm"
        node(f"l{layer}.operator_norm", "RMS_NORM", [current], normed, [tid(f"blk.{layer}.attn_norm.weight")], {"epsilon": "1.0E-5"})
        operated = f"l{layer}.operator"
        if kv_heads == 0:
            node(
                f"l{layer}.shortconv", "LFM_CONV", [normed], operated,
                [
                    tid(f"blk.{layer}.shortconv.in_proj.weight"),
                    tid(f"blk.{layer}.shortconv.conv.weight"),
                    tid(f"blk.{layer}.shortconv.out_proj.weight"),
                ],
                {"layer": str(layer), "kernel": "3"},
            )
        else:
            node(
                f"l{layer}.gqa", "GQA_ATTENTION", [normed], operated,
                [
                    tid(f"blk.{layer}.attn_q.weight"), tid(f"blk.{layer}.attn_k.weight"),
                    tid(f"blk.{layer}.attn_v.weight"), tid(f"blk.{layer}.attn_output.weight"),
                    tid(f"blk.{layer}.attn_q_norm.weight"), tid(f"blk.{layer}.attn_k_norm.weight"),
                ],
                {"layer": str(layer), "heads": "16", "kvHeads": "8", "headDim": "64", "ropeTheta": "1000000.0"},
            )
        resid = f"l{layer}.residual"
        node(f"l{layer}.residual", "ADD", [current, operated], resid)
        ffn_norm = f"l{layer}.ffn_norm"
        node(f"l{layer}.ffn_norm", "RMS_NORM", [resid], ffn_norm, [tid(f"blk.{layer}.ffn_norm.weight")], {"epsilon": "1.0E-5"})
        ffn = f"l{layer}.ffn"
        node(
            f"l{layer}.ffn", "GATED_MLP", [ffn_norm], ffn,
            [tid(f"blk.{layer}.ffn_gate.weight"), tid(f"blk.{layer}.ffn_up.weight"), tid(f"blk.{layer}.ffn_down.weight")],
        )
        current = f"l{layer}.hidden"
        node(f"l{layer}.ffn_residual", "ADD", [resid, ffn], current)

    final_norm = "hidden.final_norm"
    node("final_norm", "RMS_NORM", [current], final_norm, [tid("token_embd_norm.weight")], {"epsilon": "1.0E-5"})
    logits = "logits"
    output_tid = by_name.get("output.weight") or tid("token_embd.weight")
    node("lm_head", "LM_HEAD", [final_norm], logits, [output_tid])
    node("sample", "SAMPLE", [logits], "next_token", attrs={"temperature": "0.1", "topK": "50", "repetitionPenalty": "1.05"})

    arch = {
        "schemaVersion": 1,
        "contract": "swrlzx.arch_graph.v1",
        "graphStatus": "EXECUTABLE",
        "architectureId": "lfm2",
        "graphId": "swrlz-lalm-001a-lfm2-native-v1",
        "inputTokenName": "token_id",
        "outputTokenName": "next_token",
        "contextLimitTokens": min(int(md.get("lfm2.context_length", 32_768)), 32_768),
        "kvCacheLayers": 6,
        "nodes": nodes,
        "requiredOperators": list(dict.fromkeys(n["op"] for n in nodes)),
    }
    tokenizer = {
        "schemaVersion": 1,
        "contract": "swrlzx.tokenizer.v1",
        "kind": "GGML_BPE",
        "tokens": md["tokenizer.ggml.tokens"],
        "merges": md["tokenizer.ggml.merges"],
        "bosTokenId": int(md["tokenizer.ggml.bos_token_id"]),
        "eosTokenId": int(md["tokenizer.ggml.eos_token_id"]),
        "unkTokenId": int(md["tokenizer.ggml.unknown_token_id"]) if "tokenizer.ggml.unknown_token_id" in md else None,
        "padTokenId": int(md["tokenizer.ggml.padding_token_id"]),
        "addBos": bool(md.get("tokenizer.ggml.add_bos_token", True)),
        "addEos": bool(md.get("tokenizer.ggml.add_eos_token", False)),
    }
    required_quantizers = sorted(k for k, v in quant_hist.items() if v > 0)
    quant = {
        "schemaVersion": 1,
        "contract": "swrlzx.quantization.v1",
        "requiredQuantizers": required_quantizers,
        "tensorTypeHistogram": dict(sorted(quant_hist.items())),
        "sourceAlignmentBytes": index.alignment,
    }
    generation = {
        "schemaVersion": 1,
        "contract": LALM_SAMPLER_CONTRACT,
        "temperature": 0.1,
        "topK": 50,
        "repetitionPenalty": 1.05,
        "bosTokenId": 1,
        "eosTokenId": 7,
        "padTokenId": 0,
        "chatTemplateContract": LALM_CHAT_TEMPLATE_CONTRACT,
        "sourceChatTemplate": md.get("tokenizer.chat_template"),
        "note": "Canonical 011A reference generation profile; exact tokenizer/logit parity remains a 012A acceptance gate.",
    }
    return arch, tokenizer, quant, generation


def build_semantic_sections(index: GgufIndex, source: Path, model_id: str | None, display_name: str | None, profile: ConversionProfile | None = None) -> list[Section]:
    profile = profile or ConversionProfile()
    md = index.metadata
    arch = str(md.get("general.architecture", "unknown")).lower()
    source_name = str(md.get("general.name") or source.stem)
    mid = safe_id(model_id or profile.default_model_id or source_name, "swrlzx-imported-model")
    dname = (display_name or profile.default_display_name or source_name).strip()[:160] or "Imported SWRLZX Model"
    if profile.require_exact_lalm_source:
        if source.name != LALM_SOURCE_NAME:
            fail(f"LALM_010A_SOURCE_NAME_MISMATCH:{source.name}")
        if index.file_bytes != LALM_SOURCE_SIZE_BYTES:
            fail(f"LALM_010A_SOURCE_SIZE_MISMATCH:{index.file_bytes}")
        if index.source_sha256.lower() != LALM_SOURCE_SHA256:
            fail(f"LALM_010A_SOURCE_SHA256_MISMATCH:{index.source_sha256}")
        if arch != "lfm2":
            fail(f"LALM_010A_SOURCE_ARCHITECTURE_MISMATCH:{arch}")
        if mid != LALM_MODEL_ID or dname != LALM_DISPLAY_NAME:
            fail("LALM_010A_TARGET_IDENTITY_OVERRIDE_FORBIDDEN")

    tokenizer_meta = {k: v for k, v in md.items() if k.startswith("tokenizer.")}
    generation_meta = {k: v for k, v in md.items() if k.startswith("general.sampling.")}
    architecture_meta = {
        k: v for k, v in md.items()
        if k.startswith("general.") or k.startswith(arch + ".")
        if not k.startswith("general.sampling.")
    }
    quant_meta = {
        "schemaVersion": 1,
        "sourceFormat": "GGUF",
        "ggufVersion": index.version,
        "generalFileType": md.get("general.file_type"),
        "quantizationVersion": md.get("general.quantization_version"),
        "tensorTypeHistogram": {},
        "sourceTensorAlignment": index.alignment,
        "note": "Tensor spans preserve the exact GGUF tensor-data blob, including source alignment padding between tensor starts.",
    }
    hist: dict[str, int] = {}
    for t in index.tensors:
        label = GGML_TYPE_NAMES.get(t.ggml_type, f"ggml_type_{t.ggml_type}")
        hist[label] = hist.get(label, 0) + 1
    quant_meta["tensorTypeHistogram"] = dict(sorted(hist.items()))

    manifest = {
        "schemaVersion": 1,
        "modelId": mid,
        "displayName": dname,
        "generation": 1,
        "architectureId": safe_id(arch, "unknown-architecture"),
        "containerMajor": SWRLZX_MAJOR,
        "containerMinor": SWRLZX_MINOR,
        "tensorDirectorySectionId": 4,
        "architectureGraphSectionId": 2,
        "tokenizerSectionId": 3 if tokenizer_meta else None,
        "generationProfileSectionId": 7 if generation_meta else None,
        "streamContractSectionId": None,
        "moduleInterfacesSectionId": None,
        "requiredRuntimeContracts": ["swrlzx.container.v1", "swrlzx.tensor_data.raw.v1", *profile.required_runtime_contracts],
        "optionalRuntimeContracts": ["swrlzx.gguf.reverse_map.v1"],
        "capabilities": ["conversion_provenance", "tensor_range_integrity", *profile.capabilities],
        "sourceFormat": "GGUF",
        "sourceSha256": index.source_sha256,
    }
    lineage = {
        "schemaVersion": 1,
        "modelId": mid,
        "generation": 1,
        "lineageRootId": safe_id(profile.lineage_root_id or (mid + "-lineage"), "swrlzx-lineage-root"),
        "parentModelRootDigest": None,
        "producerRevision": profile.converter_revision,
        "sourceArtifactSha256": index.source_sha256,
        "changeNote": profile.change_note,
    }
    arch_payload = {
        "schemaVersion": 1,
        "kind": "GGUF_IMPORT_ARCHITECTURE_DESCRIPTOR",
        "architectureId": arch,
        "metadata": architecture_meta,
        "executionGraphStatus": "DEFERRED_TO_INT-AI-SWRLZX-003A",
    }
    tokenizer_payload = {
        "schemaVersion": 1,
        "kind": "GGUF_IMPORT_TOKENIZER_DESCRIPTOR",
        "metadata": tokenizer_meta,
    }
    generation_payload = {
        "schemaVersion": 1,
        "kind": "GGUF_IMPORT_GENERATION_PROFILE",
        "metadata": generation_meta,
    }
    tensors = []
    reverse_tensors = []
    for i, t in enumerate(index.tensors):
        typ = GGML_TYPE_NAMES.get(t.ggml_type, f"ggml_type_{t.ggml_type}")
        tensors.append({
            "tensorId": f"tensor-{i:06d}",
            "name": t.name,
            "shape": list(t.shape),
            "dataType": typ,
            "quantization": typ if typ.startswith(("q", "iq", "tq", "mxfp", "nvfp")) else None,
            "dataSectionId": 5,
            "dataOffsetBytes": t.offset,
            "storedLengthBytes": t.span_length,
            "logicalLengthBytes": t.span_length,
            "alignment": max(64, index.alignment) if max(64, index.alignment) & (max(64, index.alignment) - 1) == 0 else 64,
            "sha256": t.sha256,
        })
        reverse_tensors.append({
            "name": t.name,
            "ggmlType": t.ggml_type,
            "ggmlTypeName": typ,
            "sourceTensorDataRelativeOffset": t.offset,
            "sourceSpanBytes": t.span_length,
            "sourceSpanSha256": t.sha256,
        })
    tensor_dir = {"schemaVersion": 1, "tensors": tensors}
    if profile.emit_lalm_executable_graph:
        arch_payload, tokenizer_payload, quant_meta, generation_payload = _lalm_011a_runtime_metadata(index, tensors, hist)
        tokenizer_meta = {"011a": True}
        generation_meta = {"011a": True}
        manifest["generationProfileSectionId"] = 7
        manifest["capabilities"] = list(dict.fromkeys([*manifest["capabilities"], "executable_architecture_graph", "ggml_bpe_tokenizer", "target_authoritative_sampling"]))
    reverse = {
        "schemaVersion": 1,
        "contract": "swrlzx.gguf.reverse_map.v1",
        "source": {
            "fileName": source.name,
            "sha256": index.source_sha256,
            "sizeBytes": index.file_bytes,
            "ggufVersion": index.version,
            "metadataCount": index.metadata_count,
            "tensorCount": index.tensor_count,
            "alignment": index.alignment,
            "tensorDataOffset": index.tensor_data_offset,
        },
        "metadataTypes": index.metadata_types,
        "tensors": reverse_tensors,
        "nativeIdentity": {
            "family": "LALM" if profile.require_exact_lalm_source else None,
            "familyExpansion": "Local Adaptive Language Model" if profile.require_exact_lalm_source else None,
            "identityContract": LALM_IDENTITY_CONTRACT if profile.require_exact_lalm_source else None,
            "modelId": mid,
            "displayName": dname,
            "sourceFamily": "LFM" if profile.require_exact_lalm_source else None,
            "sourceArchitecture": arch,
        },
    }

    raw_sections: list[tuple[int, int, int, Any]] = [
        (1, SEC_MANIFEST, CODEC_JSON, manifest),
        (2, SEC_ARCH, CODEC_JSON, arch_payload),
        (4, SEC_TENSOR_DIR, CODEC_JSON, tensor_dir),
        (6, SEC_QUANT, CODEC_JSON, quant_meta),
        (10, SEC_LINEAGE, CODEC_JSON, lineage),
        (20, SEC_VENDOR, CODEC_JSON, reverse),
    ]
    if tokenizer_meta:
        raw_sections.append((3, SEC_TOKENIZER, CODEC_JSON, tokenizer_payload))
    if generation_meta:
        raw_sections.append((7, SEC_GENERATION, CODEC_JSON, generation_payload))

    sections: list[Section] = []
    for sid, stype, codec, obj in raw_sections:
        payload = canonical_json(obj)
        sections.append(Section(sid, stype, codec, 1, ALIGNMENT, 0, len(payload), hashlib.sha256(payload).digest(), payload=payload))

    tensor_data_len = index.file_bytes - index.tensor_data_offset
    tensor_data_sha = sha256_range(source, index.tensor_data_offset, tensor_data_len)
    sections.append(Section(5, SEC_TENSOR_DATA, CODEC_RAW, 1, ALIGNMENT, 0, tensor_data_len, tensor_data_sha, source_path=source, source_offset=index.tensor_data_offset))
    return sorted(sections, key=lambda s: s.section_id)


def pack_toc(t: Toc) -> bytes:
    base = struct.pack("<IIIIQQQII", t.section_id, t.section_type, t.flags, t.alignment,
                       t.offset, t.stored_length, t.logical_length, t.codec, t.schema_version) + t.sha256
    if len(base) > TOC_ENTRY_BYTES:
        fail("SWRLZX_TOC_PACK_OVERFLOW")
    return base + b"\x00" * (TOC_ENTRY_BYTES - len(base))


def root_digest(entries: Iterable[Toc]) -> bytes:
    h = hashlib.sha256()
    for e in sorted((x for x in entries if x.section_type not in (SEC_INTEGRITY, SEC_SIGNATURE)), key=lambda x: x.section_id):
        canonical = struct.pack("<IIIIQQQII", e.section_id, e.section_type, e.flags, e.alignment,
                                e.offset, e.stored_length, e.logical_length, e.codec, e.schema_version) + e.sha256
        if len(canonical) != 80:
            fail(f"SWRLZX_ROOT_CANONICAL_SIZE:{len(canonical)}")
        h.update(canonical)
    return h.digest()


def integrity_payload(root: bytes, entries: Iterable[Toc]) -> bytes:
    relevant = sorted((x for x in entries if x.section_type not in (SEC_INTEGRITY, SEC_SIGNATURE)), key=lambda x: x.section_id)
    return INTEGRITY_MAGIC + root + struct.pack("<I", len(relevant)) + b"".join(struct.pack("<I", e.section_id) + e.sha256 for e in relevant)


def pack_header(file_bytes: int, toc: list[Toc], root: bytes) -> bytes:
    manifest_id = next(x.section_id for x in toc if x.section_type == SEC_MANIFEST)
    tensor_dir_id = next(x.section_id for x in toc if x.section_type == SEC_TENSOR_DIR)
    lineage_id = next(x.section_id for x in toc if x.section_type == SEC_LINEAGE)
    integrity_id = next(x.section_id for x in toc if x.section_type == SEC_INTEGRITY)
    base = SWRLZX_MAGIC + struct.pack("<HHIIIQQIIIIII", SWRLZX_MAJOR, SWRLZX_MINOR, HEADER_BYTES, 0,
                                      ENDIAN_MARKER, file_bytes, HEADER_BYTES, len(toc), TOC_ENTRY_BYTES,
                                      manifest_id, tensor_dir_id, lineage_id, integrity_id) + root
    if len(base) > HEADER_BYTES:
        fail("SWRLZX_HEADER_PACK_OVERFLOW")
    return base + b"\x00" * (HEADER_BYTES - len(base))


def plan_sections(sections: list[Section]) -> tuple[list[Toc], bytes, bytes, int]:
    if not sections or len(sections) + 1 >= MAX_SECTIONS:
        fail("SWRLZX_SECTION_COUNT_INVALID")
    ids = [s.section_id for s in sections]
    if len(ids) != len(set(ids)) or any(i <= 0 for i in ids):
        fail("SWRLZX_SECTION_ID_INVALID_OR_DUPLICATE")
    if SEC_INTEGRITY in [s.section_type for s in sections]:
        fail("SWRLZX_INTEGRITY_AUTOGENERATED")
    toc_count = len(sections) + 1
    cursor = align_up(HEADER_BYTES + toc_count * TOC_ENTRY_BYTES, ALIGNMENT)
    prelim: list[Toc] = []
    for s in sorted(sections, key=lambda x: x.section_id):
        cursor = align_up(cursor, s.alignment)
        prelim.append(Toc(s.section_id, s.section_type, s.flags, s.alignment, cursor, s.length, s.length, s.codec, s.schema_version, s.sha256))
        cursor += s.length
    root = root_digest(prelim)
    ip = integrity_payload(root, prelim)
    cursor = align_up(cursor, ALIGNMENT)
    integrity = Toc(11, SEC_INTEGRITY, 0, ALIGNMENT, cursor, len(ip), len(ip), CODEC_BINARY, 1, hashlib.sha256(ip).digest())
    toc = sorted(prelim + [integrity], key=lambda x: x.section_id)
    file_bytes = integrity.offset + integrity.stored_length
    return toc, root, ip, file_bytes


def write_padding(out: BinaryIO, target: int) -> None:
    pos = out.tell()
    if pos > target:
        fail(f"SWRLZX_WRITE_POSITION_PAST_TARGET:{pos}>{target}")
    remaining = target - pos
    zero = b"\x00" * min(COPY_BUFFER, max(1, remaining))
    while remaining:
        n = min(len(zero), remaining)
        out.write(zero[:n])
        remaining -= n


def copy_range(source: Path, source_offset: int, length: int, out: BinaryIO) -> None:
    with source.open("rb") as f:
        f.seek(source_offset)
        remaining = length
        while remaining:
            chunk = f.read(min(COPY_BUFFER, remaining))
            if not chunk:
                fail("GGUF_TENSOR_DATA_UNEXPECTED_EOF")
            out.write(chunk)
            remaining -= len(chunk)


def write_swrlzx(source: Path, destination: Path, sections: list[Section], force: bool = False) -> dict[str, Any]:
    if destination.exists() and not force:
        fail(f"DESTINATION_EXISTS:{destination}")
    if source.resolve() == destination.resolve():
        fail("SOURCE_DESTINATION_SAME")
    toc, root, ip, file_bytes = plan_sections(sections)
    by_id = {s.section_id: s for s in sections}
    tmp = destination.with_name(destination.name + ".tmp")
    tmp.parent.mkdir(parents=True, exist_ok=True)
    if tmp.exists(): tmp.unlink()
    try:
        with tmp.open("wb") as out:
            out.write(pack_header(file_bytes, toc, root))
            for t in toc:
                out.write(pack_toc(t))
            for t in sorted(toc, key=lambda x: x.offset):
                write_padding(out, t.offset)
                if t.section_type == SEC_INTEGRITY:
                    out.write(ip)
                else:
                    s = by_id[t.section_id]
                    if s.payload is not None:
                        out.write(s.payload)
                    elif s.source_path is not None:
                        copy_range(s.source_path, s.source_offset, s.length, out)
                    else:
                        fail(f"SECTION_SOURCE_MISSING:{s.section_id}")
            if out.tell() != file_bytes:
                fail(f"SWRLZX_FILE_LENGTH_WRITE_MISMATCH:{out.tell()}:{file_bytes}")
            out.flush()
            os.fsync(out.fileno())
        os.replace(tmp, destination)
    except Exception:
        if tmp.exists(): tmp.unlink()
        raise
    return {
        "output": str(destination),
        "outputBytes": destination.stat().st_size,
        "outputSha256": sha256_file(destination),
        "rootDigestSha256": root.hex(),
        "sectionCount": len(toc),
    }


def read_swrlzx_header_toc(path: Path) -> tuple[dict[str, Any], list[Toc]]:
    with path.open("rb") as f:
        h = f.read(HEADER_BYTES)
        if len(h) != HEADER_BYTES or h[:8] != SWRLZX_MAGIC:
            fail("SWRLZX_MAGIC_OR_HEADER_INVALID")
        major, minor, hbytes, flags, endian, file_bytes, toc_offset, toc_count, toc_entry_bytes, manifest_id, tensor_dir_id, lineage_id, integrity_id = struct.unpack_from("<HHIIIQQIIIIII", h, 8)
        root = h[64:96]
        if major != 1 or hbytes != 128 or endian != ENDIAN_MARKER or toc_entry_bytes != 128:
            fail("SWRLZX_HEADER_CONTRACT_INVALID")
        if file_bytes != path.stat().st_size or toc_offset != 128 or toc_count <= 0 or toc_count > MAX_SECTIONS:
            fail("SWRLZX_HEADER_RANGE_INVALID")
        toc: list[Toc] = []
        f.seek(toc_offset)
        for _ in range(toc_count):
            b = f.read(TOC_ENTRY_BYTES)
            if len(b) != TOC_ENTRY_BYTES: fail("SWRLZX_TOC_EOF")
            sid, stype, sflags, align, off, stored, logical, codec, schema = struct.unpack_from("<IIIIQQQII", b, 0)
            sha = b[48:80]
            toc.append(Toc(sid, stype, sflags, align, off, stored, logical, codec, schema, sha))
    return ({"major":major,"minor":minor,"flags":flags,"fileBytes":file_bytes,"tocCount":toc_count,
             "manifestSectionId":manifest_id,"tensorDirectorySectionId":tensor_dir_id,"lineageSectionId":lineage_id,
             "integritySectionId":integrity_id,"rootDigestSha256":root.hex()}, toc)


def read_section_json(path: Path, entry: Toc) -> Any:
    if entry.stored_length > MAX_METADATA_JSON_BYTES:
        fail(f"SWRLZX_JSON_SECTION_TOO_LARGE:{entry.section_id}")
    with path.open("rb") as f:
        f.seek(entry.offset)
        b = f.read(entry.stored_length)
    if len(b) != entry.stored_length: fail("SWRLZX_JSON_SECTION_EOF")
    return json.loads(b)


def verify_swrlzx(path: Path, source: Path | None = None) -> dict[str, Any]:
    header, toc = read_swrlzx_header_toc(path)
    ids = [t.section_id for t in toc]
    if len(ids) != len(set(ids)): fail("SWRLZX_TOC_DUPLICATE_ID")
    by_type = {t.section_type: t for t in toc}
    for required in (SEC_MANIFEST, SEC_TENSOR_DIR, SEC_LINEAGE, SEC_INTEGRITY, SEC_TENSOR_DATA):
        if required not in by_type: fail(f"SWRLZX_REQUIRED_SECTION_MISSING:{required}")
    for t in toc:
        if t.alignment < ALIGNMENT or t.alignment & (t.alignment - 1) or t.offset % t.alignment:
            fail(f"SWRLZX_SECTION_ALIGNMENT_INVALID:{t.section_id}")
        if t.offset < HEADER_BYTES + len(toc)*TOC_ENTRY_BYTES or t.stored_length < 0 or t.offset + t.stored_length > header["fileBytes"]:
            fail(f"SWRLZX_SECTION_RANGE_INVALID:{t.section_id}")
        actual = sha256_range(path, t.offset, t.stored_length)
        if actual != t.sha256: fail(f"SWRLZX_SECTION_SHA_MISMATCH:{t.section_id}")
    ordered = sorted(toc, key=lambda x: x.offset)
    for a,b in zip(ordered, ordered[1:]):
        if a.offset+a.stored_length > b.offset: fail("SWRLZX_SECTION_OVERLAP")
    root = root_digest(toc)
    if root.hex() != header["rootDigestSha256"]: fail("SWRLZX_ROOT_DIGEST_MISMATCH")
    integrity = by_type[SEC_INTEGRITY]
    with path.open("rb") as f:
        f.seek(integrity.offset); ip = f.read(integrity.stored_length)
    if ip[:4] != INTEGRITY_MAGIC or ip[4:36] != root: fail("SWRLZX_INTEGRITY_ROOT_INVALID")
    count = struct.unpack_from("<I", ip, 36)[0]
    expected = sorted((x for x in toc if x.section_type not in (SEC_INTEGRITY, SEC_SIGNATURE)), key=lambda x:x.section_id)
    if count != len(expected) or len(ip) != INTEGRITY_HEADER_BYTES + count*INTEGRITY_RECORD_BYTES:
        fail("SWRLZX_INTEGRITY_COUNT_OR_LENGTH_INVALID")
    p=40
    for e in expected:
        sid = struct.unpack_from("<I", ip, p)[0]; dig=ip[p+4:p+36]; p+=36
        if sid != e.section_id or dig != e.sha256: fail(f"SWRLZX_INTEGRITY_RECORD_MISMATCH:{e.section_id}")

    manifest = read_section_json(path, by_type[SEC_MANIFEST])
    tensor_dir = read_section_json(path, by_type[SEC_TENSOR_DIR])
    tdata = by_type[SEC_TENSOR_DATA]
    for i, td in enumerate(tensor_dir.get("tensors", [])):
        off = int(td["dataOffsetBytes"]); n = int(td["storedLengthBytes"])
        if off < 0 or n <= 0 or off+n > tdata.stored_length: fail(f"SWRLZX_TENSOR_RANGE_INVALID:{i}")
        got = sha256_range(path, tdata.offset+off, n).hex()
        if got != td["sha256"]: fail(f"SWRLZX_TENSOR_SHA_MISMATCH:{i}")
    if source is not None:
        if manifest.get("sourceSha256") != sha256_file(source): fail("SWRLZX_SOURCE_SHA_PROVENANCE_MISMATCH")
        with source.open("rb") as sf, path.open("rb") as of:
            idx=parse_gguf(source)
            sf.seek(idx.tensor_data_offset); of.seek(tdata.offset)
            remaining=tdata.stored_length
            while remaining:
                a=sf.read(min(COPY_BUFFER,remaining)); b=of.read(len(a))
                if a!=b: fail("SWRLZX_TENSOR_DATA_NOT_BYTE_IDENTICAL")
                remaining-=len(a)
    return {"ok":True,"fileBytes":header["fileBytes"],"rootDigestSha256":root.hex(),"sections":len(toc),
            "tensors":len(tensor_dir.get("tensors",[])),"modelId":manifest.get("modelId"),"sourceSha256":manifest.get("sourceSha256")}


def convert(source: Path, destination: Path, model_id: str | None, display_name: str | None, force: bool, report_path: Path | None, profile: ConversionProfile | None = None) -> dict[str, Any]:
    profile = profile or ConversionProfile()
    index = parse_gguf(source)
    sections = build_semantic_sections(index, source, model_id, display_name, profile=profile)
    write = write_swrlzx(source, destination, sections, force=force)
    verified = verify_swrlzx(destination, source=source)
    result = {
        "schema": "swrlzx-gguf-conversion-report-v1",
        "checkpoint": profile.checkpoint,
        "converterRevision": profile.converter_revision,
        "source": {"path": str(source), "fileName": source.name, "sizeBytes": index.file_bytes, "sha256": index.source_sha256,
                   "ggufVersion": index.version, "tensorCount": index.tensor_count, "metadataCount": index.metadata_count,
                   "alignment": index.alignment, "tensorDataOffset": index.tensor_data_offset},
        "output": write,
        "verification": verified,
        "runtimeSwitchPerformed": False,
        "tensorDataByteIdentical": True,
        "deterministicInputs": ["source bytes", "converter revision", "explicit modelId/displayName arguments"],
        "nativeIdentity": {
            "family": "LALM" if profile.require_exact_lalm_source else None,
            "familyExpansion": "Local Adaptive Language Model" if profile.require_exact_lalm_source else None,
            "identityContract": LALM_IDENTITY_CONTRACT if profile.require_exact_lalm_source else None,
            "sourceFamily": "LFM" if profile.require_exact_lalm_source else None,
            "productionPromotionPerformed": False,
        },
    }
    if report_path:
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_bytes(canonical_json(result))
    return result


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("destination", type=Path)
    ap.add_argument("--model-id")
    ap.add_argument("--display-name")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--report", type=Path)
    ap.add_argument("--verify-only", action="store_true")
    ap.add_argument("--lalm-010a", action="store_true", help="Require the exact optimized source identity and emit canonical SWRLZ-LALM-001A metadata.")
    ap.add_argument("--lalm-011a", action="store_true", help="Require the exact optimized source and emit the executable native LALM architecture/tokenizer/quantizer profile.")
    args=ap.parse_args()
    try:
        if args.verify_only:
            result=verify_swrlzx(args.destination, source=args.source if args.source.is_file() else None)
        else:
            if not args.source.is_file(): fail(f"SOURCE_NOT_FOUND:{args.source}")
            if args.lalm_010a and args.lalm_011a: fail("LALM_PROFILE_FLAGS_MUTUALLY_EXCLUSIVE")
            profile = ConversionProfile.lalm_011a() if args.lalm_011a else (ConversionProfile.lalm_010a() if args.lalm_010a else ConversionProfile())
            result=convert(args.source,args.destination,args.model_id,args.display_name,args.force,args.report,profile=profile)
        print(json.dumps(result,sort_keys=True,indent=2,ensure_ascii=False))
        return 0
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

if __name__ == "__main__":
    raise SystemExit(main())
