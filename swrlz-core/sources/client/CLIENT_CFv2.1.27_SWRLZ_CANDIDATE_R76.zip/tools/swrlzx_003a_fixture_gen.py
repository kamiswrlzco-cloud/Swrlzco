#!/usr/bin/env python3
import argparse, hashlib, json, struct
from pathlib import Path
MAGIC=b'SWRLZX\r\n'; HEADER=128; TOC=128; ALIGN=64; ENDIAN=0x01020304
SEC_MANIFEST=1; SEC_ARCH=2; SEC_TOKEN=3; SEC_TDIR=4; SEC_TDATA=5; SEC_QUANT=6; SEC_LINEAGE=10; SEC_INTEGRITY=11
CODEC_RAW=0; CODEC_JSON=1; CODEC_BINARY=2

def cj(o): return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def align(n,a=ALIGN): return (n+a-1)//a*a
def f32(vals): return b''.join(struct.pack('<f',x) for x in vals)
def root_digest(toc):
    h=hashlib.sha256()
    for e in sorted([x for x in toc if x[1] not in (SEC_INTEGRITY,12)]):
        sid,st,flags,al,off,stored,logical,codec,schema,sha=e
        h.update(struct.pack('<IIIIQQQII',sid,st,flags,al,off,stored,logical,codec,schema)+sha)
    return h.digest()
def pack_toc(e):
    sid,st,flags,al,off,stored,logical,codec,schema,sha=e
    b=struct.pack('<IIIIQQQII',sid,st,flags,al,off,stored,logical,codec,schema)+sha
    return b+b'\0'*(TOC-len(b))
def build(path):
    tokens=['A','B','C','<eos>']
    # shape convention [columns, rows]. Embedding is identity; head maps A->B, B->C, C->EOS.
    emb=[]
    for r in range(4): emb += [1.0 if c==r else 0.0 for c in range(4)]
    head=[0,0,0,5, 5,0,0,0, 0,5,0,0, 0,0,5,0]
    tensor_data=f32(emb)+f32(head)
    tensors=[
      {'tensorId':'tok-embeddings','name':'tok_embeddings.weight','shape':[4,4],'dataType':'f32','quantization':None,'dataSectionId':5,'dataOffsetBytes':0,'storedLengthBytes':64,'logicalLengthBytes':64,'alignment':64,'sha256':hashlib.sha256(tensor_data[:64]).hexdigest()},
      {'tensorId':'lm-head','name':'output.weight','shape':[4,4],'dataType':'f32','quantization':None,'dataSectionId':5,'dataOffsetBytes':64,'storedLengthBytes':64,'logicalLengthBytes':64,'alignment':64,'sha256':hashlib.sha256(tensor_data[64:]).hexdigest()},
    ]
    manifest={'schemaVersion':1,'modelId':'swrlzx-reference-probe','displayName':'SWRLZX 003A Reference Probe','generation':1,'architectureId':'swrlzx-reference','containerMajor':1,'containerMinor':0,'tensorDirectorySectionId':4,'architectureGraphSectionId':2,'tokenizerSectionId':3,'generationProfileSectionId':None,'streamContractSectionId':None,'moduleInterfacesSectionId':None,'requiredRuntimeContracts':['swrlzx.container.v1','swrlzx.runtime.v1','swrlzx.arch_graph.v1','swrlzx.tokenizer.v1'],'optionalRuntimeContracts':[],'capabilities':['native_loader','reference_execution'],'sourceFormat':None,'sourceSha256':None}
    graph={'schemaVersion':1,'contract':'swrlzx.arch_graph.v1','graphStatus':'EXECUTABLE','architectureId':'swrlzx-reference','graphId':'reference-cycle-v1','inputTokenName':'token_id','outputTokenName':'next_token','contextLimitTokens':128,'kvCacheLayers':1,'nodes':[
      {'id':'embed-node','op':'TOKEN_EMBED','inputs':['token_id'],'output':'hidden','tensorIds':['tok-embeddings'],'attributes':{}},
      {'id':'head-node','op':'MATMUL','inputs':['hidden'],'output':'logits','tensorIds':['lm-head'],'attributes':{}},
      {'id':'argmax-node','op':'ARGMAX','inputs':['logits'],'output':'next_token','tensorIds':[],'attributes':{}},
    ],'requiredOperators':['TOKEN_EMBED','MATMUL','ARGMAX']}
    tokenizer={'schemaVersion':1,'contract':'swrlzx.tokenizer.v1','kind':'REFERENCE_TOKEN_LIST','tokens':tokens,'merges':[],'bosTokenId':0,'eosTokenId':3,'unkTokenId':0,'padTokenId':None,'addBos':False,'addEos':False}
    quant={'schemaVersion':1,'contract':'swrlzx.quantization.v1','requiredQuantizers':['f32'],'tensorTypeHistogram':{'f32':2},'sourceAlignmentBytes':64}
    tdir={'schemaVersion':1,'tensors':tensors}
    lineage={'schemaVersion':1,'modelId':'swrlzx-reference-probe','generation':1,'lineageRootId':'swrlzx-reference-lineage','parentModelRootDigest':None,'producerRevision':'INT-AI-SWRLZX-003A-fixture','sourceArtifactSha256':None,'changeNote':'Tiny deterministic runtime graph fixture; not a production language model.'}
    sections=[(1,SEC_MANIFEST,CODEC_JSON,cj(manifest)),(2,SEC_ARCH,CODEC_JSON,cj(graph)),(3,SEC_TOKEN,CODEC_JSON,cj(tokenizer)),(4,SEC_TDIR,CODEC_JSON,cj(tdir)),(5,SEC_TDATA,CODEC_RAW,tensor_data),(6,SEC_QUANT,CODEC_JSON,cj(quant)),(10,SEC_LINEAGE,CODEC_JSON,cj(lineage))]
    count=len(sections)+1; cur=align(HEADER+count*TOC); toc=[]
    for sid,st,codec,payload in sections:
        cur=align(cur); toc.append((sid,st,0,ALIGN,cur,len(payload),len(payload),codec,1,hashlib.sha256(payload).digest())); cur+=len(payload)
    root=root_digest(toc); ip=b'SXI1'+root+struct.pack('<I',len(toc))+b''.join(struct.pack('<I',e[0])+e[9] for e in sorted(toc))
    cur=align(cur); integ=(11,SEC_INTEGRITY,0,ALIGN,cur,len(ip),len(ip),CODEC_BINARY,1,hashlib.sha256(ip).digest()); toc=sorted(toc+[integ]); size=cur+len(ip)
    hdr=MAGIC+struct.pack('<HHIIIQQIIIIII',1,0,HEADER,0,ENDIAN,size,HEADER,len(toc),TOC,1,4,10,11)+root
    hdr+=b'\0'*(HEADER-len(hdr))
    byid={x[0]:x[3] for x in sections}
    with path.open('wb') as f:
        f.write(hdr); [f.write(pack_toc(e)) for e in toc]
        for e in sorted(toc,key=lambda x:x[4]):
            f.write(b'\0'*(e[4]-f.tell())); f.write(ip if e[1]==SEC_INTEGRITY else byid[e[0]])
    return {'file':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'rootDigest':root.hex(),'expectedPrompt':'A','expectedOutput':'BC'}
if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('output',type=Path); a=ap.parse_args(); print(json.dumps(build(a.output),indent=2,sort_keys=True))
