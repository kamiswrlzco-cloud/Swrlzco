#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
is_client=(ROOT/'android/app/build.gradle.kts').is_file()
checks=[]
def check(name, cond):
    checks.append((name,bool(cond))); print(('PASS' if cond else 'FAIL')+' | '+name)
def text(rel): return (ROOT/rel).read_text(errors='replace')

def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()

if is_client:
    build=text('android/app/build.gradle.kts')
    api=text('android/app/src/main/java/sh/swurlz/core/net/Api.kt')
    runtime=text('android/app/src/main/java/sh/swurlz/core/ai/ModelRackClientRuntime.kt')
    ui=text('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt')
    base='android/model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/'
    check('CLIENT R30 versionCode 156','versionCode = 156' in build)
    check('CLIENT R30 versionName','2.1.27-swrlzx-evolution-r30' in build)
    check('008A patch label','INT-AI-SWRLZX-008A' in build)
    check('V3 evolution API present','ModelRackProtocolV3.EVOLUTION_STATUS' in api and 'ModelRackProtocolV3.PROMOTE' in api and 'ModelRackProtocolV3.ROLLBACK_GENERATION' in api)
    check('CLIENT runtime exposes evolution requests','promoteEvolution' in runtime and 'rollbackEvolution' in runtime and 'recordEvolutionEvaluation' in runtime)
    check('CLIENT displays logical identity','MODEL EVOLUTION' in ui and 'Active logical ID' in ui and 'evolutionRevision' in ui)
else:
    build=text('app/build.gradle.kts')
    store=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelEvolutionStore.kt')
    vault=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelVault.kt')
    selection=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelSelectionPolicy.kt')
    module=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModuleVault.kt')
    protocol=text('app/src/main/java/sh/swrlz/nodehost/service/ModelRackProtocol.kt')
    rack=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelRack.kt')
    base='model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/'
    check('SERVER R55 versionCode 178','versionCode = 178' in build)
    check('SERVER R55 versionName','2.1.27-swrlzx-evolution-r55' in build)
    check('008A patch id','INT-AI-SWRLZX-008A' in build)
    check('evolution registry exists','evolution-v1.json' in store and 'training_never_auto_promotes' not in store)
    check('import registers SWRLZX candidate','registerImportedSwrlzxCandidate' in vault and 'SwrlzxLineageV1' in vault)
    check('known-good without implicit select','setLastKnownGoodOnly' in vault)
    check('007A selector evolution gate','evolutionSelectionApproved' in selection and 'nativeParityProven && candidate.evolutionSelectionApproved' in selection)
    check('content-addressed active overlays','overlayIdentities' in module and 'validateOverlayComposition' in module)
    check('V3 model-rack routes','ModelRackProtocolV3.REGISTER_CANDIDATE' in protocol and 'ModelRackProtocolV3.RECORD_EVALUATION' in protocol and 'ModelRackProtocolV3.PROMOTE' in protocol and 'ModelRackProtocolV3.ROLLBACK_GENERATION' in protocol)
    check('rack publishes evolution snapshot','evolutionRecords = evolution.records' in rack and 'activeLogicalModelSha256' in rack)

contract=text(base+'ModelEvolutionContract.kt')
rack_contract=text(base+'ModelRackContract.kt')
check('immutable full-model lineage contract','data class ModelGenerationLineageV1' in contract and 'parentModelRootDigest' in contract and 'changeSummarySha256' in contract)
check('overlay classes cover future revisions','TOKENIZER_EXTENSION' in contract and 'QUANTIZER_REVISION' in contract and 'LORA' in contract)
check('logical identity binds base+runtime+ordered overlays','swrlz.logical-model.v1' in contract and 'overlays.sortedBy { it.order }' in contract and 'runtimeContractRevision' in contract)
check('hidden reasoning training truth forbidden','MODEL_EVOLUTION_HIDDEN_REASONING_TRAINING_FORBIDDEN' in contract)
check('explicit promotion required','MODEL_EVOLUTION_EXPLICIT_APPROVAL_REQUIRED' in contract)
check('linear promotion stages','CANDIDATE' in contract and 'EVALUATED' in contract and 'COMPATIBLE' in contract and 'LAST_KNOWN_GOOD' in contract and 'SELECTED' in contract)
check('compatibility requires safety+compat+regression','latestEvaluation.safetyPassed && latestEvaluation.compatibilityPassed && latestEvaluation.regressionPassed' in contract)
check('Model Rack snapshot carries evolution state','evolutionRevision' in rack_contract and 'evolutionRecords' in rack_contract and 'activeLogicalModelSha256' in rack_contract)

for rel in [
 'docs/checkpoints/INT-AI-SWRLZX-008A_EVOLVABLE_MODEL_GENERATIONS.md',
 'docs/contracts/SWRLZX_MODEL_GENERATION_LINEAGE_V1.md',
 'docs/contracts/SWRLZX_DELTA_OVERLAY_V1.md',
 'docs/policy/SWRLZX_TRAINING_PROVENANCE_AND_EVALUATION_POLICY_V1.md',
 'docs/contracts/SWRLZX_MODEL_PROMOTION_ROLLBACK_V1.md',
 'docs/architecture/ADR-0027_SWRLZX_IMMUTABLE_MODEL_EVOLUTION.md',
 'docs/evidence/INT-AI-SWRLZX-008A_REGRESSION_DASHBOARD.md',
 'docs/evidence/INT-AI-SWRLZX-008A_REGRESSION_DASHBOARD.json',
]: check('doc '+rel,(ROOT/rel).is_file())
failed=[n for n,ok in checks if not ok]
print(f'RESULT | {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    print('FAILED | '+', '.join(failed)); sys.exit(1)
