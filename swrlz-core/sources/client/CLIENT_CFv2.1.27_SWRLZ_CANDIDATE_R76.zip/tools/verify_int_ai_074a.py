#!/usr/bin/env python3
"""Static paired gate for INT-AI-074A. Does not build Android or contact a network."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


class Gate:
    def __init__(self) -> None:
        self.rows: list[dict[str, object]] = []

    def check(self, name: str, condition: bool, detail: str = "") -> None:
        self.rows.append({"name": name, "passed": bool(condition), "detail": detail})

    @property
    def failed(self) -> list[dict[str, object]]:
        return [row for row in self.rows if not row["passed"]]


def text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--server-root", type=Path, required=True)
    parser.add_argument("--client-root", type=Path, required=True)
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()
    server = args.server_root.resolve()
    client = args.client_root.resolve()
    gate = Gate()

    gate.check("server root", server.is_dir(), str(server))
    gate.check("client root", client.is_dir(), str(client))

    s_contract = server / "llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmContract.kt"
    c_contract = client / "android/llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmContract.kt"
    gate.check("shared contract sources present", s_contract.is_file() and c_contract.is_file())
    gate.check("shared contract sources byte-identical", s_contract.read_bytes() == c_contract.read_bytes(), sha(s_contract))
    s_contract_doc = server / "docs/contracts/SWRLZ_LLM_RUNTIME_TRAINING_CONTRACT_V1.md"
    c_contract_doc = client / "docs/contracts/SWRLZ_LLM_RUNTIME_TRAINING_CONTRACT_V1.md"
    gate.check("shared contract docs byte-identical", s_contract_doc.read_bytes() == c_contract_doc.read_bytes(), sha(s_contract_doc))
    for root, prefix in ((server, "server"), (client, "client")):
        settings = text(root / "settings.gradle.kts") if prefix == "server" else text(root / "android/settings.gradle.kts")
        app_gradle = text(root / "app/build.gradle.kts") if prefix == "server" else text(root / "android/app/build.gradle.kts")
        gate.check(f"{prefix} llm module included", 'include(":llm-contract")' in settings)
        gate.check(f"{prefix} app depends on contract", 'implementation(project(":llm-contract"))' in app_gradle)

    contract = text(s_contract)
    for route in ("STATUS", "CHAT", "CLIENT_CONTEXT", "TRAINING_EXPORT", "TRAINING_IMPORT", "KNOWLEDGE_UPSERT", "KNOWLEDGE_RETIRE", "EXAMPLE_UPSERT", "EXAMPLE_RETIRE", "SETTINGS", "EVALUATE"):
        gate.check(f"contract route {route}", f"const val {route}" in contract)
    for symbol in ("SwrlzLlmSettingsV1", "SwrlzKnowledgeRecordV1", "SwrlzTeachingExampleV1", "SwrlzClientContextV1", "SwrlzLlmChatRequestV1", "SwrlzEvaluationResultV1"):
        gate.check(f"contract type {symbol}", f"data class {symbol}" in contract)
    gate.check("contract has client/admin access", "enum class SwrlzLlmAccessV1 { CLIENT, SERVER_ADMIN }" in contract)
    gate.check("contract has three knowledge scopes", all(value in contract for value in ("CLIENT_PUBLIC", "SERVER_PUBLIC", "SERVER_ADMIN")))
    gate.check("remote host has alias not URL", "remoteHostAlias" in contract and "remoteHostUrl" not in contract)
    gate.check("settings normalization bounds", all(value in contract for value in ("coerceIn(1, 12)", "coerceIn(64, 2_048)", "coerceIn(60, 86_400)")))

    asset_path = server / "app/src/main/assets/swrlz_llm/builtin_knowledge_v1.json"
    asset = json.loads(text(asset_path))
    knowledge = asset.get("knowledge", [])
    examples = asset.get("examples", [])
    ids = [row.get("id") for row in knowledge]
    gate.check("built-in JSON schema", asset.get("schemaVersion") == 1)
    gate.check("built-in knowledge count", len(knowledge) == 32, str(len(knowledge)))
    gate.check("built-in example count", len(examples) == 3, str(len(examples)))
    gate.check("built-in IDs unique", len(ids) == len(set(ids)))
    gate.check("built-in scopes valid", all(row.get("scope") in {"CLIENT_PUBLIC", "SERVER_PUBLIC", "SERVER_ADMIN"} for row in knowledge))
    gate.check("admin seed present", any(row.get("scope") == "SERVER_ADMIN" for row in knowledge))
    gate.check("client seed present", any(row.get("scope") == "CLIENT_PUBLIC" for row in knowledge))
    gate.check("server-public seed present", any(row.get("scope") == "SERVER_PUBLIC" for row in knowledge))
    serialized_asset = json.dumps(asset)
    gate.check("built-in has no secret assignment", not re.search(r"(?i)(api[_-]?key|pairing[_-]?token|authorization)\s*[:=]\s*\S{8,}", serialized_asset))

    store = text(server / "app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLlmTrainingStore.kt")
    retriever = text(server / "app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLlmRetriever.kt")
    runtime = text(server / "app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLlmRuntime.kt")
    protocol = text(server / "app/src/main/java/sh/swrlz/nodehost/service/SwrlzLlmProtocol.kt")
    node_runtime = text(server / "app/src/main/java/sh/swrlz/nodehost/service/NodeRuntime.kt")
    admin_policy = text(server / "app/src/main/java/sh/swrlz/nodehost/messaging/ServerAdminRegistryPolicy.kt")
    studio = text(server / "app/src/main/java/sh/swrlz/nodehost/ui/SwrlzLlmStudioScreen.kt")
    user_screen = text(server / "app/src/main/java/sh/swrlz/nodehost/ui/SwurlzerUserScreen.kt")

    gate.check("atomic private training store", "AtomicFile" in store and "noBackupFilesDir" in store)
    gate.check("generation conflict gate", "LLM_TRAINING_GENERATION_CONFLICT" in store)
    gate.check("retire-not-delete lifecycle", "SwrlzTrainingStateV1.RETIRED" in store)
    gate.check("secret-like training rejection", "LLM_TRAINING_SECRET_LIKE_DATA_REJECTED" in store)
    gate.check("built-in override by ID", "overrides.containsKey" in store)
    gate.check("access filtered before retrieval", "filter { it.scope in allowed }" in retriever)
    gate.check("direct answer threshold", "directAnswerMinimumScore" in runtime and "DIRECT_KNOWLEDGE" in runtime)
    gate.check("deprecated adapter explicit", "legacyGgufAdapterEnabled" in runtime and "LEGACY_GGUF_ADAPTER" in runtime)
    gate.check("remote route fails closed", "I did not send your prompt anywhere" in runtime and "REMOTE_SWRLZ_HOST" in runtime)
    gate.check("output firewall", "SwrlieOutputFirewall.inspect" in runtime)
    gate.check("evaluation implemented", "suspend fun evaluate" in runtime and "forbiddenPhrasesFound" in runtime)
    gate.check("proof-bound actor resolver", "AuthenticatedNodeActorResolver.resolve" in protocol)
    gate.check(
        "admin knowledge derived from server state and capability",
        "ServerAdminRegistryPolicy.isActiveAdmin" in protocol and "llm.server_knowledge.read" in protocol,
    )
    gate.check("training capability checks", all(value in protocol for value in ("llm.training.read", "llm.training.write", "llm.settings.write", "llm.evaluation.run")))
    gate.check("no-store responses", protocol.count('"Cache-Control" to "no-store"') >= 2)
    gate.check("protocol wired before model rack", node_runtime.index("SwrlzLlmProtocol.handles") < node_runtime.index("ModelRackProtocol.handles"))
    gate.check("new admin capabilities declared", all(value in admin_policy for value in ("llm.chat", "llm.server_knowledge.read", "llm.training.write", "llm.evaluation.run")))

    for section in ("OVERVIEW", "ENGINE", "KNOWLEDGE", "TEACHING", "EVALUATE"):
        gate.check(f"studio section {section}", section in studio)
    gate.check("studio import export", "CreateDocument" in studio and "OpenDocument" in studio)
    gate.check("studio exposes legacy controls", "ServerProviderMeshSettingsPanel()" in studio)
    gate.check("studio top-level separate from Chat", 'Llm("LLM"' in user_screen and "SwurlzerTab.Llm -> SwrlzLlmStudioScreen()" in user_screen)
    gate.check("server chat routes custom local", "SwrlzLlmRuntime.asProviderResponse" in text(server / "app/src/main/java/sh/swrlz/nodehost/ui/ServerChatScreen.kt"))

    api = text(client / "android/app/src/main/java/sh/swurlz/core/net/Api.kt")
    bridge = text(client / "android/app/src/main/java/sh/swurlz/core/data/ClientLlmContextBridge.kt")
    client_chat = text(client / "android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt")
    gate.check("client sends registered node ID", "ClientNodeMessaging.currentNodeId" in api)
    gate.check("client sends device proof", 'header("X-SWRLZ-Device-Proof"' in api)
    gate.check("client LLM status/chat/context methods", all(value in api for value in ("swrlzLlmStatus", "swrlzLlmChat", "publishSwrlzLlmContext")))
    constructor = bridge[bridge.index("return SwrlzClientContextV1("):bridge.index(").normalized()")]
    for forbidden in ("nodeUrl", "pairingToken", "deviceProof", "buildFingerprint", "clipboard", "installedApps"):
        gate.check(f"context excludes {forbidden}", forbidden not in constructor)
    for allowed in ("appVersionName", "deviceManufacturer", "accessibilityEnabled", "serverConfigured", "interfaceMode", "themeId", "chatStyle"):
        gate.check(f"context includes {allowed}", allowed in constructor)
    gate.check("client default chat calls LLM", "CoreNodeApi.swrlzLlmChat" in client_chat)
    gate.check("client no silent remote fallback", "I did not send this prompt to a remote provider" in client_chat)
    gate.check("client sends bounded history", "dropLast(1).takeLast(12)" in client_chat)

    s_gradle = text(server / "app/build.gradle.kts")
    c_gradle = text(client / "android/app/build.gradle.kts")
    gate.check("server identity VC129", 'versionCode = 129' in s_gradle and 'versionName = "2.1.27-swrlz-llm-studio-r1"' in s_gradle)
    gate.check("client identity VC132", 'versionCode = 132' in c_gradle and 'versionName = "2.1.27-swrlz-llm-client-bridge-r1"' in c_gradle)
    database = text(server / "app/src/main/java/sh/swrlz/nodehost/data/NodeHostDatabase.kt")
    gate.check("Room schema unchanged at 16", re.search(r"version\s*=\s*16", database) is not None)
    s_manifest = text(server / "app/src/main/AndroidManifest.xml")
    c_strings = text(client / "android/app/src/main/res/values/strings.xml")
    gate.check("server visible §wyrlzer label", s_manifest.count('android:label="§wyrlzer"') == 13)
    gate.check("client visible §wyrlz label", '<string name="app_name">§wyrlz</string>' in c_strings)
    gate.check("server package preserved", "package sh.swrlz.nodehost" in protocol)
    gate.check("client package preserved", "package sh.swurlz.core" in bridge)

    shared_relatives = (
        "docs/architecture/SWRLZ_LLM_RUNTIME_V1.md",
        "docs/checkpoints/INT-AI-074A_SWRLZ_LLM_STUDIO_ROLE_AWARE_RUNTIME.md",
        "docs/handoffs/INT-AI-074A_SOURCE_HANDOFF.md",
        "docs/terminology/SWRLZ_DISPLAY_IDENTITY_V1.md",
    )
    for relative in shared_relatives:
        gate.check(f"shared doc identical {relative}", (server / relative).read_bytes() == (client / relative).read_bytes())
    for root, prefix in ((server, "server"), (client, "client")):
        for relative in ("README.md", "CHANGELOG.md", "ReleaseNotes.md", "CHECKPOINT_RECEIPT.json", "SWRLZ_PATCH_LINEAGE_INDEX_V1.json"):
            gate.check(f"{prefix} documentation {relative}", (root / relative).is_file())
        gate.check(f"{prefix} docs current checkpoint", "INT-AI-074A" in text(root / "README.md") and "INT-AI-074A" in text(root / "CHANGELOG.md"))
        json_files = list(root.rglob("*.json"))
        failures: list[str] = []
        for path in json_files:
            try:
                json.loads(text(path))
            except Exception as exc:  # noqa: BLE001
                failures.append(f"{path.relative_to(root)}: {exc}")
        gate.check(f"{prefix} JSON parse", not failures, f"{len(json_files)} files" if not failures else "; ".join(failures[:3]))
        gate.check(f"{prefix} contains no nested source ZIP", not any(root.rglob("*.zip")))

    xml_targets = [
        server / "app/src/main/AndroidManifest.xml",
        client / "android/app/src/main/AndroidManifest.xml",
        client / "android/app/src/main/res/values/strings.xml",
    ]
    xml_failures = []
    for path in xml_targets:
        try:
            ET.parse(path)
        except Exception as exc:  # noqa: BLE001
            xml_failures.append(f"{path}: {exc}")
    gate.check("modified XML parse", not xml_failures, "; ".join(xml_failures))

    passed = len(gate.rows) - len(gate.failed)
    report = {
        "checkpoint": "INT-AI-074A",
        "kind": "PAIRED_STATIC_SOURCE_VERIFICATION",
        "passed": passed,
        "failed": len(gate.failed),
        "total": len(gate.rows),
        "androidCompile": "NOT_RUN",
        "apkBuild": "NOT_RUN",
        "deviceAcceptance": "NOT_RUN",
        "rows": gate.rows,
    }
    rendered = json.dumps(report, indent=2, ensure_ascii=False) + "\n"
    if args.json_output:
        args.json_output.parent.mkdir(parents=True, exist_ok=True)
        args.json_output.write_text(rendered, encoding="utf-8")
    print(f"INT-AI-074A static verification: {passed}/{len(gate.rows)} PASS")
    for row in gate.failed:
        print(f"FAIL: {row['name']} — {row['detail']}")
    return 1 if gate.failed else 0


if __name__ == "__main__":
    sys.exit(main())
