#!/usr/bin/env python3
"""INT-AI-SWRLZX-010A exact-size preflight without fabricating the real source model.

Creates a sparse/deterministic GGUF v3 fixture with the *same filename and exact byte size*
as the pinned optimized source, but a deliberately different SHA-256. It proves three things:
1. the bounded 002A converter still handles a source at the production byte size;
2. two generic conversions from identical bytes are byte-deterministic;
3. the 010A LALM bring-up gate rejects the fixture specifically on source SHA-256.

This tool never marks parity proven and never emits a canonical LALM target.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import struct
import subprocess
import sys
from pathlib import Path

TARGET_NAME = "SWRLZ-LFM-OPT-001A.gguf"
TARGET_SIZE = 229_315_680
TARGET_SHA = "651cd5c40e4ef24de2ff12c2b53b257d15816ddd4346e2575e6768a6ec1d8590"
U32=4; F32=6; BOOL=7; STRING=8; ARRAY=9


def s(value: str) -> bytes:
    b = value.encode("utf-8")
    return struct.pack("<Q", len(b)) + b


def val(typ: int, value) -> bytes:
    if typ == U32: return struct.pack("<I", value)
    if typ == F32: return struct.pack("<f", value)
    if typ == BOOL: return bytes([1 if value else 0])
    if typ == STRING: return s(value)
    if typ == ARRAY:
        et, items = value
        out = struct.pack("<IQ", et, len(items))
        for item in items: out += val(et, item)
        return out
    raise ValueError(typ)


def align(v: int, a: int) -> int:
    return (v + a - 1) & ~(a - 1)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def build_exact_size_fixture(path: Path) -> dict:
    alignment = 32
    tokens = [f"tok_{i:04d}" for i in range(64)]
    kv = [
        ("general.architecture", STRING, "lfm2"),
        ("general.name", STRING, "SWRLZX-010A-EXACT-SIZE-PREFLIGHT-NOT-REAL-MODEL"),
        ("general.alignment", U32, alignment),
        ("general.quantization_version", U32, 2),
        ("general.file_type", U32, 15),
        ("lfm2.block_count", U32, 16),
        ("lfm2.context_length", U32, 32768),
        ("lfm2.embedding_length", U32, 1024),
        ("tokenizer.ggml.model", STRING, "synthetic-preflight"),
        ("tokenizer.ggml.tokens", ARRAY, (STRING, tokens)),
        ("tokenizer.ggml.scores", ARRAY, (F32, [0.0 for _ in tokens])),
        ("tokenizer.chat_template", STRING, "{{ bos_token }}{{ messages }}"),
        ("general.sampling.top_k", U32, 50),
        ("general.sampling.top_p", F32, 0.9),
        ("general.sampling.temp", F32, 0.1),
        ("swrlz.synthetic", BOOL, True),
    ]
    # Three tensors. Their exact type/shape is intentionally synthetic; the preflight is
    # about container scale/determinism and exact-source identity rejection, not LFM2 parity.
    names_shapes_types = [
        ("token_embd.weight", (1024, 64), 1),
        ("blk.0.attn_q.weight", (1024, 1024), 12),
        ("output.weight", (1024, 64), 12),
    ]
    header = b"GGUF" + struct.pack("<IQQ", 3, len(names_shapes_types), len(kv))
    for key, typ, value in kv:
        header += s(key) + struct.pack("<I", typ) + val(typ, value)

    # First compute table length with placeholder offsets, then assign aligned spans that
    # consume the entire remaining file exactly.
    placeholder = b""
    for name, shape, ggml_type in names_shapes_types:
        placeholder += s(name) + struct.pack("<I", len(shape))
        placeholder += b"".join(struct.pack("<Q", d) for d in shape)
        placeholder += struct.pack("<IQ", ggml_type, 0)
    data_start = align(len(header) + len(placeholder), alignment)
    payload = TARGET_SIZE - data_start
    if payload <= 3 * alignment:
        raise RuntimeError("preflight payload unexpectedly small")
    span1 = align(payload // 4, alignment)
    span2 = align(payload // 2, alignment)
    span3 = payload - span1 - span2
    if span3 <= 0 or span3 % alignment != 0:
        # TARGET_SIZE and data_start are both 32-byte aligned for this fixture, so this
        # should be impossible; fail rather than silently changing the exact size.
        raise RuntimeError(f"preflight span alignment invalid: {span3}")
    spans = [span1, span2, span3]
    offsets = [0, span1, span1 + span2]

    table = b""
    for (name, shape, ggml_type), offset in zip(names_shapes_types, offsets):
        table += s(name) + struct.pack("<I", len(shape))
        table += b"".join(struct.pack("<Q", d) for d in shape)
        table += struct.pack("<IQ", ggml_type, offset)
    actual_data_start = align(len(header) + len(table), alignment)
    if actual_data_start != data_start:
        raise RuntimeError("preflight table-size instability")

    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as f:
        f.write(header)
        f.write(table)
        f.write(b"\0" * (data_start - f.tell()))
        # Sparse allocation is intentional: unread holes are deterministic zero bytes and
        # still exercise full-file hashing + full tensor-data streaming during conversion.
        f.seek(TARGET_SIZE - 1)
        f.write(b"\0")
    if path.stat().st_size != TARGET_SIZE:
        raise RuntimeError(f"preflight size mismatch: {path.stat().st_size}")
    got_sha = sha256_file(path)
    if got_sha == TARGET_SHA:
        raise RuntimeError("synthetic preflight unexpectedly matched pinned real-source SHA")
    return {
        "fileName": path.name,
        "sizeBytes": path.stat().st_size,
        "sha256": got_sha,
        "expectedRealSourceSha256": TARGET_SHA,
        "architecture": "lfm2",
        "tensorDataOffset": data_start,
        "tensorDataBytes": payload,
        "synthetic": True,
    }


def run(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("work_dir", type=Path)
    ap.add_argument("--converter", type=Path, required=True)
    ap.add_argument("--bringup", type=Path, required=True)
    ap.add_argument("--keep-large-files", action="store_true")
    args = ap.parse_args()

    wd = args.work_dir.resolve()
    if wd.exists():
        shutil.rmtree(wd)
    wd.mkdir(parents=True)
    source = wd / TARGET_NAME
    source_info = build_exact_size_fixture(source)

    out1 = wd / "generic-pass-1.swrlzx"
    out2 = wd / "generic-pass-2.swrlzx"
    c1 = run([sys.executable, str(args.converter), str(source), str(out1)])
    if c1.returncode != 0:
        raise RuntimeError(f"generic conversion pass 1 failed: {c1.stderr.strip()}")
    c2 = run([sys.executable, str(args.converter), str(source), str(out2)])
    if c2.returncode != 0:
        raise RuntimeError(f"generic conversion pass 2 failed: {c2.stderr.strip()}")
    sha1 = sha256_file(out1)
    sha2 = sha256_file(out2)
    if sha1 != sha2:
        raise RuntimeError(f"generic full-size determinism failed: {sha1} != {sha2}")

    lalm_dir = wd / "lalm-gate-output"
    lalm = run([sys.executable, str(args.bringup), str(source), str(lalm_dir)])
    combined = (lalm.stdout + "\n" + lalm.stderr).strip()
    expected_fragment = "LALM_010A_SOURCE_SHA256_MISMATCH"
    if lalm.returncode == 0 or expected_fragment not in combined:
        raise RuntimeError(
            "LALM exact-source gate did not fail closed on the expected SHA mismatch; "
            f"rc={lalm.returncode} output={combined[:2000]}"
        )
    canonical = lalm_dir / "SWRLZ-LALM-001A.§wyrlzx"
    if canonical.exists():
        raise RuntimeError("LALM gate failure left a canonical target behind")

    report = {
        "schema": "swrlzx-010a-preflight-v1",
        "checkpoint": "INT-AI-SWRLZX-010A",
        "sourceFixture": source_info,
        "genericFullSizeConversion": {
            "pass1Sha256": sha1,
            "pass2Sha256": sha2,
            "deterministic": True,
            "pass1Bytes": out1.stat().st_size,
            "pass2Bytes": out2.stat().st_size,
        },
        "exactSourceGate": {
            "rejected": True,
            "reason": expected_fragment,
            "canonicalTargetCreated": False,
        },
        "productionPromotionPerformed": False,
        "realModelConversionClaimed": False,
        "note": "Exact-size synthetic preflight only; it is intentionally not the pinned real source bytes.",
    }
    report_path = wd / "INT-AI-SWRLZX-010A_PREFLIGHT.json"
    report_path.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, sort_keys=True, indent=2))

    if not args.keep_large_files:
        for p in (source, out1, out2):
            p.unlink(missing_ok=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
