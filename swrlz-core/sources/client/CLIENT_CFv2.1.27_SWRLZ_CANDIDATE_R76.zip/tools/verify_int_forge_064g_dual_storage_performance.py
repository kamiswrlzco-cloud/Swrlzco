#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re, sys
from pathlib import Path
import xml.etree.ElementTree as ET

root=Path(sys.argv[1]).resolve()
component=sys.argv[2].upper()
expected_vc=int(sys.argv[3])
expected_revision=sys.argv[4]
checks=[]

def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
    print(('PASS' if cond else 'FAIL'), name, detail)

def text(rel): return (root/rel).read_text(encoding='utf-8')
if component=='CLIENT':
    src='android/app/src/main/java/sh/swurlz/core'
    build='android/app/build.gradle.kts'
    manifest='android/app/src/main/AndroidManifest.xml'
    auto=f'{src}/github/ForgeAutomation.kt'
    storage=f'{src}/github/ForgeStoragePerformance.kt'
    runner=f'{src}/github/ForgeAutomatedBuildRunner.kt'
    settings=f'{src}/ui/client/ForgeSettingsControls.kt'
    screen=f'{src}/ui/screens/GitHubForgeScreen.kt'
    package='sh.swurlz.core.github'
else:
    src='app/src/main/java/sh/swrlz/nodehost'
    build='app/build.gradle.kts'
    manifest='app/src/main/AndroidManifest.xml'
    auto=f'{src}/forge/ForgeAutomation.kt'
    storage=f'{src}/forge/ForgeStoragePerformance.kt'
    runner=f'{src}/forge/ForgeAutomatedBuildRunner.kt'
    settings=f'{src}/ui/ForgeSettingsControls.kt'
    screen=f'{src}/forge/ServerForgeScreen.kt'
    package='sh.swrlz.nodehost.forge'

for rel in (build,manifest,auto,storage,runner,settings,screen): check(f'exists {rel}',(root/rel).is_file())
b=text(build); m=text(manifest); a=text(auto); st=text(storage); r=text(runner); se=text(settings); sc=text(screen)
check('versionCode',f'versionCode = {expected_vc}' in b)
check('versionName revision',expected_revision.lower() in b.lower())
check('manifest parses', ET.parse(root/manifest) is not None)
check('explicit all-files permission declared','android.permission.MANAGE_EXTERNAL_STORAGE' in m)
check('legacy read permission bounded','android.permission.READ_EXTERNAL_STORAGE' in m and 'maxSdkVersion="32"' in m)
check('public Downloads access helper','Environment.isExternalStorageManager()' in st and 'DIRECTORY_DOWNLOADS' in st)
check('explicit settings intent','ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION' in st)
check('custom inbox precedes public default','customDownloadsInboxDirectory(context) ?: ForgePublicDownloadsAccess.directory' in a)
check('single-flight mutex','private val mutex = Mutex()' in st and 'mutex.lock()' in st and 'mutex.unlock()' in st)
check('scan work on IO','withContext(Dispatchers.IO)' in st)
check('hash cache','ConcurrentHashMap<Key, String>()' in st and 'allowCache' in st)
check('pre-upload uncached revalidation','revalidateCandidate(context, candidate)' in r and 'allowHashCache = false' in a)
check('one-pass snapshot','snapshotDownloads(root)' in a and 'childFileIndexes' in a and 'val snapshot = snapshotDownloads(root)' in a)
check('screen uses coordinator','ForgeScanCoordinator.scan' in sc)
check('screen avoids direct resolver scan','ForgeSourceResolver.discoverDownloads(context' not in sc)
check('async settings work','rememberCoroutineScope()' in se and 'withContext(Dispatchers.IO)' in se)
check('access control UI','GRANT PUBLIC DOWNLOADS ACCESS' in se and 'CUSTOM INBOX' in se)
check('impossible Select Downloads label removed','SELECT DOWNLOADS' not in se)
check('progress state surfaced','SETTING UP PROJECT ROOT' in se and ('SCANNING' in sc))
check('package declaration',text(storage).startswith(f'package {package}\n'))
# Guard against accidental UI-thread direct scan calls in settings/screens.
check('no synchronous ensure layout assignment in picker','layoutStatus = ForgeAutomationPreferences.ensureProjectLayout(context)' not in se)
# Kotlin rough lexical balance
for rel in (auto,storage,runner,settings,screen):
    s=text(rel); pairs={'{':'}','(':')','[':']'}; stack=[]; i=0; in_str=False; esc=False; line=False; block=False
    ok=True
    while i<len(s):
        c=s[i]; n=s[i+1] if i+1<len(s) else ''
        if line:
            if c=='\n': line=False
        elif block:
            if c=='*' and n=='/': block=False; i+=1
        elif in_str:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c=='"': in_str=False
        else:
            if c=='/' and n=='/': line=True; i+=1
            elif c=='/' and n=='*': block=True; i+=1
            elif c=='"': in_str=True
            elif c in pairs: stack.append(c)
            elif c in pairs.values():
                if not stack or pairs[stack.pop()]!=c: ok=False; break
        i+=1
    ok=ok and not stack and not in_str and not block
    check(f'lexical balance {Path(rel).name}',ok)
failed=[n for n,v,d in checks if not v]
print(json.dumps({'component':component,'passed':len(checks)-len(failed),'total':len(checks),'failed':failed},indent=2))
sys.exit(1 if failed else 0)
