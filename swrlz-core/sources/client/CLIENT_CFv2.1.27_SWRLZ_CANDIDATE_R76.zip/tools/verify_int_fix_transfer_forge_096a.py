#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name, cond):
    checks.append((name,bool(cond))); print(('PASS' if cond else 'FAIL'), name)
def text(rel): return (ROOT/rel).read_text(encoding='utf-8')

gradle=text('android/app/build.gradle.kts')
presence=text('android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt')
bridge=text('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt')
screen=text('android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt')
forge=text('android/app/src/main/java/sh/swurlz/core/ui/screens/GitHubForgeScreen.kt')
selector=text('android/app/src/main/java/sh/swurlz/core/ui/screens/ForgeRepositoryBrowser.kt')
ledger=text('android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt')

check('version code 135','versionCode = 135' in gradle)
check('version name r9','2.1.27-server-transfer-forge-r9' in gradle)
check('checkpoint 096a','INT-FIX-TRANSFER-FORGE-096A' in gradle)
check('source zip r9','CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R9.zip' in gradle)
check('package identity preserved','applicationId = "sh.swurlz.core"' in gradle)
for cap in ['forge.upload','transfers.create','transfers.chunks.write','transfers.status.read','transfers.finalize','transfers.cancel','forge.auto.stage','forge.auto.status.read']:
    check('capability '+cap,cap in presence)
check('no forge auto approve capability','forge.auto.approve' not in presence)
check('no forge auto dispatch capability','forge.auto.dispatch' not in presence)
check('generic start route','/forge/uploads/start' in bridge)
check('generic chunk route','/forge/uploads/$uploadId/chunk' in bridge)
check('generic commit route','/forge/uploads/$uploadId/commit' in bridge)
check('verified create route','/v1/transfers/create' in bridge)
check('verified chunk route','/v1/transfers/chunks/write' in bridge)
check('verified finalize route','/v1/transfers/finalize' in bridge)
check('forge stage route','/v1/forge/auto/stage' in bridge)
check('explicit approval dispatch policy','REQUIRE_EXPLICIT_APPROVAL' in bridge and '.put("approvePolicyDispatch", false)' in bridge)
check('metadata prevalidation','ForgeMetadataBundle.inspect' in bridge)
check('metadata filename binding','metadataInfo.sourceZipName.equals(source.name' in bridge)
check('metadata size binding','metadataInfo.sizeBytes == source.sizeBytes' in bridge)
check('metadata sha binding','metadataInfo.sha256.equals(sourceDigest.fullSha256' in bridge)
check('device proof header','X-SWRLZ-Device-Proof' in bridge)
check('registered node id','ClientNodeMessaging.currentNodeId' in bridge)
check('pair upload UI','SELECT SOURCE + METADATA' in screen)
check('generic file UI','SELECT FILES → SERVER' in screen)
check('forge stage UI','REQUEST SERVER FORGE STAGE' in screen)
check('server authority copy','SERVER-side explicit approval is still required' in screen)
check('io transfer execution','withContext(Dispatchers.IO)' in screen)
check('transfer mode screen','"TRANSFER" -> ServerTransferScreen()' in forge)
check('transfer mode selector','"TRANSFER" to "⇅ SERVER"' in selector)
check('update ledger r9','R9' in ledger and 'INT-FIX-TRANSFER-FORGE-096A' in ledger)
receipt=json.loads(text('CHECKPOINT_RECEIPT.json'))
lineage=json.loads(text('SWRLZ_PATCH_LINEAGE_INDEX_V1.json'))
check('receipt current r9',receipt.get('candidate')=='CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R9' and receipt.get('versionCode')==135)
check('lineage current r9',lineage.get('candidate')=='CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R9' and lineage.get('versionCode')==135)
check('no apk/aab in source',not any(p.suffix.lower() in {'.apk','.aab'} for p in ROOT.rglob('*') if p.is_file()))
for rel in [
 'docs/contracts/SWRLZ_CLIENT_SERVER_TRANSFER_FORGE_V1.md',
 'docs/checkpoints/INT-FIX-TRANSFER-FORGE-096A.md',
 'docs/implementation/INT-FIX-TRANSFER-FORGE-096A_IMPLEMENTATION_REPORT.md',
 'docs/validation/INT-FIX-TRANSFER-FORGE-096A_VALIDATION.md',
 'docs/releases/CLIENT_CFv2.1.27_R9_SERVER_TRANSFER_FORGE.md',
 'docs/handoffs/INT-FIX-TRANSFER-FORGE-096A_SOURCE_HANDOFF.md',
]: check('doc '+Path(rel).name,(ROOT/rel).is_file())
failed=[n for n,o in checks if not o]
print(f'SUMMARY pass={len(checks)-len(failed)} fail={len(failed)} total={len(checks)}')
if failed:
    print('FAILED:', ', '.join(failed)); sys.exit(1)
