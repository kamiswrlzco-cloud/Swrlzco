#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def need(path,*terms):
    text=(ROOT/path).read_text()
    for term in terms: checks.append((f'{path}: {term[:48]}', term in text))
    return text
build=need('android/app/build.gradle.kts','versionCode = 141','2.1.27-transfer-presence-r15','INT-TRANSFER-PRESENCE-118A','SWRLZ_CANDIDATE_R15.zip')
pres=need('android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt','val httpStatus: Int = 0','val protocolCode: String = ""','val elapsedMs: Long = 0L')
transfer=need('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','first.httpStatus == 404','NOT_REGISTERED','ClientPresenceRegistration.register','PREFLIGHT_PRESENCE_FAILED','failureStage = "PRESENCE"','startRoundTripMs')
checks.append(('benchmark log precedes presence',transfer.index('ServerTransferBenchmarkLogStore.start(') < transfer.index('val presence = ensureTransferPresence(app, connection)', transfer.index('runLoopbackStreamBenchmarkOnIo'))))
checks.append(('binary path preserved','postBinaryChunkWithRetry' in transfer and 'LEGACY_BASE64_JSON' in transfer))
ui=need('android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt','var benchmarkStatus','Running presence preflight','presence ${result.presenceMs} ms','failed@$it')
checks.append(('benchmark status isolated','benchmarkStatus = if (outcome.ok)' in ui and 'status = if (outcome.ok) outcome.detail' not in ui[ui.index('RUN CLIENT → SERVER LOOPBACK')-1500:ui.index('RUN CLIENT → SERVER LOOPBACK')+2500]))
lineage=json.loads((ROOT/'SWRLZ_PATCH_LINEAGE_INDEX_V1.json').read_text())
checks += [('lineage identity',lineage['revision']=='R15' and lineage['versionCode']==141),('paired server R37',lineage.get('sibling',{}).get('candidate','').endswith('_R37'))]
receipt=json.loads((ROOT/'CHECKPOINT_RECEIPT.json').read_text())
checks += [('receipt identity', receipt.get('candidate','').endswith('_R15') and receipt.get('revision')=='R15' and receipt.get('versionCode')==141),('receipt parent R14', receipt.get('parent',{}).get('name','').endswith('_R14.zip')),('receipt paired server R37', receipt.get('sibling',{}).get('name','').endswith('_R37.zip')),('receipt checkpoint', receipt.get('checkpoint')=='INT-TRANSFER-PRESENCE-118A')]
notes=(ROOT/'ReleaseNotes.md').read_text(); checks.append(('patch notes current',notes.startswith('# CLIENT CFv2.1.27 R15 / VC141')))
for name,ok in checks: print(('PASS' if ok else 'FAIL'), '|', name)
failed=[n for n,o in checks if not o]
print(f'SUMMARY {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
