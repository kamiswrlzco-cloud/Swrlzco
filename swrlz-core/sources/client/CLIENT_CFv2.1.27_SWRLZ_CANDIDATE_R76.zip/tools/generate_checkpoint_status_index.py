#!/usr/bin/env python3
"""Generate a bounded current-vs-historical checkpoint index from source identity + root evidence files."""
from pathlib import Path
import re, sys
root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
out = root / 'ACTIVE_CHECKPOINT_INDEX.md'
component = 'SERVER' if (root/'app/build.gradle.kts').exists() else 'CLIENT'
build = (root/('app/build.gradle.kts' if component=='SERVER' else 'android/app/build.gradle.kts')).read_text(errors='replace')
rev = re.search(r'SWRLZ_REVISION"\s*,\s*(?:quotedBuildConfig\()?"(R\d+)"', build)
if not rev:
    rev = re.search(r'SWRLZ_REVISION"\s*,\s*"\\"(R\d+)\\""', build)
patch = re.search(r'(?:SWRLZ_PATCH_ID|PATCH_LABEL)"\s*,\s*(?:quotedBuildConfig\()?"(?:\\")?(INT-[A-Z0-9-]+)', build)
version_code = re.search(r'versionCode\s*=\s*(\d+)', build)
version_name = re.search(r'versionName\s*=\s*"([^"]+)"', build)
current_rev = rev.group(1) if rev else 'UNKNOWN'
current_patch = patch.group(1) if patch else 'UNKNOWN'
files = []
for p in root.glob('INT-*'):
    if p.is_file() and p.suffix.lower() in {'.md','.txt'}:
        files.append(p.name)
files.sort()
current = [n for n in files if current_patch in n]
historical = [n for n in files if n not in current]
text = [
    '# ACTIVE / SUPERSEDED CHECKPOINT INDEX', '',
    f'- Component: **{component}**',
    f'- Current revision: **{current_rev}**',
    f'- Current patch: **{current_patch}**',
    f'- Version code: **{version_code.group(1) if version_code else "UNKNOWN"}**',
    f'- Version name: **{version_name.group(1) if version_name else "UNKNOWN"}**',
    '- Evidence class: **SOURCE_STATIC** unless a receipt explicitly says otherwise.',
    '- Historical files are retained as lineage/evidence and are **not** current capability claims.', '',
    '## Current checkpoint evidence',
]
text += [f'- `{n}`' for n in current] or ['- No root evidence file matched the current patch ID yet.']
text += ['', '## Historical / superseded checkpoint evidence',
         'The files below remain useful lineage, but their prose must not override the current source identity or newer validation boundaries.']
text += [f'- `{n}`' for n in historical]
text += ['', '## Evidence boundary',
         'A source/static checkpoint does not imply Android compilation, APK installation, device regression, model activation, deployment, or promotion. Those require their own receipts.', '']
out.write_text('\n'.join(text))
print(out)
