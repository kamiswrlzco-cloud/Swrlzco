#!/usr/bin/env python3
"""Focused source/static verifier for INT-LALM-SESSION-BOOTSTRAP-139A."""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from pathlib import Path
CP='INT-LALM-SESSION-BOOTSTRAP-139A'
def sha(p:Path): return hashlib.sha256(p.read_bytes()).hexdigest()
def req(p:Path, xs:list[str], f:list[str]):
    if not p.is_file(): f.append(f'missing: {p}'); return
    t=p.read_text(encoding='utf-8')
    for x in xs:
        if x not in t: f.append(f'missing snippet {x!r}: {p}')
def balanced(p:Path):
    text=p.read_text(encoding='utf-8'); stack=[]; pairs={')':'(',']':'[','}':'{'}; opens=set(pairs.values()); i=0; state='code'; depth=0
    while i<len(text):
        two=text[i:i+2]; three=text[i:i+3]; c=text[i]
        if state=='code':
            if three=='"""': state='triple'; i+=3; continue
            if two=='//': state='line'; i+=2; continue
            if two=='/*': state='block'; depth=1; i+=2; continue
            if c=='"': state='string'; i+=1; continue
            if c=="'": state='char'; i+=1; continue
            if c in opens: stack.append((c,i))
            elif c in pairs:
                if not stack or stack[-1][0]!=pairs[c]: return False,f'unexpected {c} at {i}'
                stack.pop()
        elif state=='line':
            if c=='\n': state='code'
        elif state=='block':
            if two=='/*': depth+=1; i+=2; continue
            if two=='*/':
                depth-=1; i+=2
                if depth==0: state='code'
                continue
        elif state=='triple':
            if three=='"""': state='code'; i+=3; continue
        elif state in {'string','char'}:
            if c=='\\': i+=2; continue
            if (state=='string' and c=='"') or (state=='char' and c=="'"): state='code'
        i+=1
    return (state in {'code','line'} and not stack), (f'state={state} stack={stack[-1:]}' if state not in {'code','line'} or stack else 'balanced')
def jsons(root:Path,f:list[str]):
    n=0
    for p in root.rglob('*.json'):
        if any(x in {'build','.gradle','node_modules'} for x in p.parts): continue
        n+=1
        try: json.loads(p.read_text(encoding='utf-8-sig'))
        except Exception as e: f.append(f'invalid JSON {p}: {e}')
    return n
def manifest(root:Path,f:list[str]):
    m=root/'SOURCE_MANIFEST.sha256'; listed={}
    if not m.is_file(): f.append(f'missing manifest {m}'); return 0
    for i,line in enumerate(m.read_text().splitlines(),1):
        z=re.fullmatch(r'([0-9a-f]{64})  (.+)',line)
        if not z: f.append(f'malformed manifest line {i}: {m}'); continue
        listed[z.group(2)]=z.group(1)
    exp={p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file() and p.resolve()!=m.resolve()}
    if listed!=exp:
        f.append(f'manifest mismatch {root}: missing={sorted(set(exp)-set(listed))[:4]} extra={sorted(set(listed)-set(exp))[:4]} changed={sorted(k for k in set(exp)&set(listed) if exp[k]!=listed[k])[:4]}')
    return len(listed)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--client',type=Path,required=True); ap.add_argument('--server',type=Path,required=True); ap.add_argument('--skip-manifest',action='store_true'); a=ap.parse_args(); c=a.client.resolve(); s=a.server.resolve(); f=[]
    req(c/'android/app/build.gradle.kts',['versionCode = 175','lalm-session-bootstrap-r49','R49',CP],f)
    req(s/'app/build.gradle.kts',['versionCode = 200','lalm-session-bootstrap-r77','R77',CP],f)
    cc=c/'android/llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2.kt'; sc=s/'llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2.kt'
    cv1=c/'android/llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmContract.kt'; sv1=s/'llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmContract.kt'
    for p in (cc,sc): req(p,['CHAT_BOOTSTRAP','SwrlzLalmChatBootstrapChunkV1','SwrlzLalmHistoryMessageV1','orientationGreeting'],f)
    for p in (cv1,sv1): req(p,['val threadId: String = ""','val ingress: String = "CLIENT_CHAT"'],f)
    if cc.read_bytes()!=sc.read_bytes(): f.append('V2 paired contract not byte-identical')
    if cv1.read_bytes()!=sv1.read_bytes(): f.append('V1 paired contract not byte-identical')
    ctest=c/'android/llm-contract/src/test/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2Test.kt'; stest=s/'llm-contract/src/test/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2Test.kt'
    cv1t=c/'android/llm-contract/src/test/kotlin/sh/swrlz/llm/SwrlzLlmContractTest.kt'; sv1t=s/'llm-contract/src/test/kotlin/sh/swrlz/llm/SwrlzLlmContractTest.kt'
    if ctest.read_bytes()!=stest.read_bytes(): f.append('V2 paired tests not byte-identical')
    if cv1t.read_bytes()!=sv1t.read_bytes(): f.append('V1 paired tests not byte-identical')
    req(c/'android/app/src/main/java/sh/swurlz/core/ai/ClientLalmBootstrapRuntime.kt',['bootstrapThread','TARGET_CHUNK_TEXT_BYTES = 500_000','readyByThread','SwrlzLalmChatBootstrapChunkV1'],f)
    req(c/'android/app/src/main/java/sh/swurlz/core/data/ClientChatHistoryStore.kt',['bootstrapMessages','BOOTSTRAP_MESSAGE_FRAGMENT_CHARS = 160_000','untouchedFallbackOnly','applyOrientationGreeting'],f)
    req(c/'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt',['bootstrapThread(context, threadId, responseDirective, force = true)','val bootstrapReady = ClientLalmBootstrapRuntime.isReady(targetThreadId)','if (bootstrapReady) {\n                                                    emptyList()','clientContext = if (bootstrapReady) null else ClientLlmContextBridge.capture(context)'],f)
    req(c/'android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamRuntime.kt',['threadId = original.threadId','ingress = original.ingress'],f)
    req(s/'app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLalmBootstrapStoreV1.kt',['onNodeConnected','SwrlzLlmTrainingStore.builtins(context)','ingestChatBootstrap','commitSnapshot','sessionDeltaFile','resolveHistory','Tool recognition and tool knowledge never grant execution authority'],f)
    req(s/'app/src/main/java/sh/swrlz/nodehost/service/SwrlzLlmProtocol.kt',['SwrlzLlmStreamProtocolV2.CHAT_BOOTSTRAP','ingestChatBootstrap'],f)
    req(s/'app/src/main/java/sh/swrlz/nodehost/service/NodeRuntime.kt',['connectedNode = node','SwrlzLalmBootstrapStoreV1.onNodeConnected(appContext, node)','repository.mirrorNodeInventoryAsync()'],f)
    req(s/'app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLlmRuntime.kt',['historySource','CHAT_BOOTSTRAP','environmentDirective','effectiveRequest.history','SwrlzLalmBootstrapStoreV1.appendTurn'],f)
    # prove connect bootstrap call occurs after transaction closing brace, not inside node upsert body
    nr=(s/'app/src/main/java/sh/swrlz/nodehost/service/NodeRuntime.kt').read_text()
    if nr.find('connectedNode?.let { node ->') < nr.find('val registrationResponse = repository.inRegistrationTransaction'):
        f.append('environment bootstrap ordering not proven outside registration transaction')
    k=[cc,cv1,ctest,cv1t,c/'android/app/src/main/java/sh/swurlz/core/ai/ClientLalmBootstrapRuntime.kt',c/'android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamRuntime.kt',c/'android/app/src/main/java/sh/swurlz/core/data/ClientChatHistoryStore.kt',c/'android/app/src/main/java/sh/swurlz/core/net/Api.kt',c/'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt',c/'android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt',sc,sv1,stest,sv1t,s/'app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLalmBootstrapStoreV1.kt',s/'app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLlmRuntime.kt',s/'app/src/main/java/sh/swrlz/nodehost/service/SwrlzLlmProtocol.kt',s/'app/src/main/java/sh/swrlz/nodehost/service/NodeRuntime.kt',s/'app/src/main/java/sh/swrlz/nodehost/runtime/ServerPatchCatalog.kt']
    for p in k:
        if not p.is_file(): f.append(f'missing Kotlin {p}'); continue
        ok,d=balanced(p)
        if not ok: f.append(f'Kotlin structural scan failed {p}: {d}')
    cj=jsons(c,f); sj=jsons(s,f); cm=sm=0
    if not a.skip_manifest: cm=manifest(c,f); sm=manifest(s,f)
    out={'checkpoint':CP,'status':'PASS' if not f else 'FAIL','clientJsonFiles':cj,'serverJsonFiles':sj,'clientManifestEntries':cm,'serverManifestEntries':sm,'streamContractSha256':sha(sc),'v1ContractSha256':sha(sv1),'failures':f,'androidCompile':'BLOCKED_BEFORE_COMPILATION_GRADLE_DISTRIBUTION_UNAVAILABLE','apkBuilt':False}
    print(json.dumps(out,indent=2,sort_keys=True)); return 0 if not f else 1
if __name__=='__main__': sys.exit(main())
