#!/usr/bin/env python3
from __future__ import annotations
import argparse, math, struct, subprocess, tempfile, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from swrlzx_gguf_to_swrlzx_v1 import parse_gguf, GGML_TYPE_NAMES


def f16(b): return struct.unpack('<e',b)[0]
def q4_scale_min(j,q):
    if j<4:return q[j]&63,q[j+4]&63
    return ((q[j+4]&15)|((q[j-4]>>6)<<4),(q[j+4]>>4)|((q[j]>>6)<<4))
def q4_ref(b):
    d,dmin=f16(b[:2]),f16(b[2:4]);sc=b[4:16];qs=b[16:];out=[];q=0;isc=0
    for _ in range(4):
        s1,m1=q4_scale_min(isc,sc);s2,m2=q4_scale_min(isc+1,sc)
        out += [d*s1*(qs[q+l]&15)-dmin*m1 for l in range(32)]
        out += [d*s2*(qs[q+l]>>4)-dmin*m2 for l in range(32)]
        q+=32;isc+=2
    return out
def q6_ref(b):
    ql=b[:128];qh=b[128:192];sc=list(struct.unpack('<16b',b[192:208]));d=f16(b[208:210]);out=[];qlo=qho=sco=0
    for _ in range(2):
        ch=[0.0]*128
        for l in range(32):
            hi=qh[qho+l];lo0=ql[qlo+l];lo1=ql[qlo+32+l];si=l//16
            vals=[((lo0&15)|(((hi>>0)&3)<<4))-32,((lo1&15)|(((hi>>2)&3)<<4))-32,(((lo0>>4)&15)|(((hi>>4)&3)<<4))-32,(((lo1>>4)&15)|(((hi>>6)&3)<<4))-32]
            for k,v in enumerate(vals): ch[k*32+l]=d*sc[sco+2*k+si]*v
        out+=ch;qlo+=64;qho+=32;sco+=8
    return out

def compile_cli(root,tmp):
    src=tmp/'Q.kt';src.write_text('''package sh.swrlz.nodehost.ai.local\nfun main(a:Array<String>){val b=ByteArray(a[1].length/2){i->a[1].substring(i*2,i*2+2).toInt(16).toByte()};val o=if(a[0]=="q4")SwrlzxLalmQuantV1.decodeQ4K(b,256) else SwrlzxLalmQuantV1.decodeQ6K(b,256);println(o.joinToString(","){java.lang.Float.toHexString(it)})}\n''')
    jar=tmp/'q.jar'; subprocess.run(['kotlinc',str(root/'app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlzxLalmNativeRuntime.kt'),str(src),'-include-runtime','-d',str(jar)],check=True,capture_output=True,text=True);return jar

def run(jar,kind,b): return [float.fromhex(x) for x in subprocess.check_output(['java','-jar',str(jar),kind,b.hex()],text=True).strip().split(',')]
def close(a,b): return math.isclose(a,b,rel_tol=3e-6,abs_tol=3e-6)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);ap.add_argument('gguf',type=Path);a=ap.parse_args();idx=parse_gguf(a.gguf);raw=a.gguf.read_bytes();tests=[]
    selected=[]
    for typ,bs in [('q4_k',144),('q6_k',210)]:
        tensors=[t for t in idx.tensors if GGML_TYPE_NAMES[t.ggml_type]==typ]
        for t in (tensors[0],tensors[len(tensors)//2],tensors[-1]):
            nblocks=t.span_length//bs
            for bi in sorted(set([0,nblocks//2,nblocks-1])):
                off=idx.tensor_data_offset+t.offset+bi*bs;selected.append((typ,t.name,bi,raw[off:off+bs]))
    with tempfile.TemporaryDirectory() as td:
        jar=compile_cli(a.root,Path(td))
        for typ,name,bi,b in selected:
            ref=q4_ref(b) if typ=='q4_k' else q6_ref(b); got=run(jar,'q4' if typ=='q4_k' else 'q6',b);ok=len(got)==256 and all(close(x,y) for x,y in zip(ref,got));tests.append(ok);print(('PASS' if ok else 'FAIL')+f' | {typ} | {name} | block {bi}')
    print(f'RESULT | {sum(tests)}/{len(tests)} PASS | actual pinned model blocks')
    return 0 if all(tests) else 1
if __name__=='__main__':raise SystemExit(main())
