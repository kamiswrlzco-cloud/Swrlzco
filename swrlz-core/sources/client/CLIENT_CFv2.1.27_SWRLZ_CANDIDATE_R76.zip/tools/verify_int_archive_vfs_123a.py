#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
checks=[]
def has(path,text,label):
    p=root/path; ok=p.exists() and text in p.read_text(errors='ignore'); checks.append((label,ok)); return ok
has('android/app/build.gradle.kts','versionCode = 145','CLIENT VC145')
has('android/app/build.gradle.kts','2.1.27-archive-vfs-r19','CLIENT R19 version')
has('android/app/build.gradle.kts','INT-ARCHIVE-VFS-123A','checkpoint identity')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveSourceStore.kt','takePersistableUriPermission','persistable SAF read')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveSourceStore.kt','archiveId','opaque archive identity')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveSourceStore.kt','.put("archiveId", source.archiveId)','advertised opaque id')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt','RESPONSE_CEILING_BYTES = 512 * 1024','512 KiB response bound')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt','ZipFile(File("/proc/self/fd/${descriptor.fd}"))','seekable ZIP VFS')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt','ZipInputStream','sequential/nested ZIP')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt','JsonReader','streaming JSON')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt','virtualPath.split(\'!\')','nested ! path')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt','READ_LIMIT_EXCEEDED','bounded read error')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt','.put("provenance"','provenance')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveNodeRuntime.kt','swrlz-archive-query-v1','archive query schema')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveNodeRuntime.kt','setOf("MESSAGE_RECEIVED")','durable inbox worker')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveNodeRuntime.kt','archive.read','archive capability gate')
has('android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt','"archive.read","archive.vfs.v1"','presence capabilities')
has('android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt','put("archiveSources", ArchiveSourceStore.advertisement(context))','presence advertisement')
has('android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt','ArchiveNodeRuntime.start','background runtime start')
has('android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt','ArchiveNodeRuntime.stop','background runtime stop')
has('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt','ARCHIVES("Archives & Data"','settings category')
has('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt','ADD ZIP ARCHIVE SOURCE','archive picker UI')
has('android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt','revision = "R19"','client ledger')
has('ReleaseNotes.md','INT-ARCHIVE-VFS-123A','release notes')
has('CHANGELOG.md','INT-ARCHIVE-VFS-123A','changelog')
has('CHECKPOINT_RECEIPT.json','CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R19','receipt')
has('SWRLZ_PATCH_LINEAGE_INDEX_V1.json','SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R43','sibling lineage')
for rel in ['android/app/src/main/java/sh/swurlz/core/archive/ArchiveSourceStore.kt','android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt','android/app/src/main/java/sh/swurlz/core/archive/ArchiveNodeRuntime.kt','android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt','android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt']:
    t=(root/rel).read_text(); checks.append((f'brace balance {rel}',t.count('{')==t.count('}')))
for label,ok in checks: print(('PASS' if ok else 'FAIL'),'|',label)
failed=[x for x in checks if not x[1]]
print(f'RESULT {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
