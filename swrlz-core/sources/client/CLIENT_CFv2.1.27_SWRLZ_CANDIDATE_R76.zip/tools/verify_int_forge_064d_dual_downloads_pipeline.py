#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
component='CLIENT' if ROOT.name.startswith('CLIENT_') else 'SERVER'
checks=[]

def check(name, condition):
    checks.append((name,bool(condition)))

def text(rel): return (ROOT/rel).read_text(encoding='utf-8')

if component=='CLIENT':
    app='android/app/src/main/java/sh/swurlz/core'
    automation=f'{app}/github/ForgeAutomation.kt'
    runner=f'{app}/github/ForgeAutomatedBuildRunner.kt'
    monitor=f'{app}/github/ForgeBuildMonitor.kt'
    watch=f'{app}/github/ForgeBuildWatchStore.kt'
    extractor=f'{app}/github/ForgeArtifactExtractor.kt'
    evidence=f'{app}/github/ForgeEvidenceBundle.kt'
    screen=f'{app}/ui/screens/GitHubForgeScreen.kt'
    settings=f'{app}/ui/client/ForgeSettingsControls.kt'
    build='android/app/build.gradle.kts'
    version_code='versionCode = 128'
    version_name='2.1.26-downloads-inbox-forge-pipeline-r5'
    local_workflow='.github/workflows/build-apk.yml'
    identity='CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R5'
else:
    app='app/src/main/java/sh/swrlz/nodehost'
    automation=f'{app}/forge/ForgeAutomation.kt'
    runner=f'{app}/forge/ForgeAutomatedBuildRunner.kt'
    monitor=f'{app}/forge/ForgeBuildMonitor.kt'
    watch=f'{app}/forge/ForgeBuildWatchStore.kt'
    extractor=f'{app}/forge/ForgeArtifactExtractor.kt'
    evidence=f'{app}/forge/ForgeEvidenceBundle.kt'
    screen=f'{app}/forge/ServerForgeScreen.kt'
    settings=f'{app}/ui/ForgeSettingsControls.kt'
    build='app/build.gradle.kts'
    version_code='versionCode = 89'
    version_name='2.1.26-downloads-inbox-forge-pipeline-r6'
    local_workflow='.github/workflows/android.yml'
    identity='SERVER_CFv2.1.26_SWRLZ_CANDIDATE_R6'

a=text(automation); r=text(runner); m=text(monitor); w=text(watch); e=text(extractor); ev=text(evidence); sc=text(screen); st=text(settings); bg=text(build); rs=text('tools/ci/resolve_swrlz_source.py'); rt=text('tools/ci/test_resolve_swrlz_source.py'); wf=text(local_workflow); patch=text('repo-patches/swrlz-core/.github/workflows/swrlz-apk-router-source-description.patch')

check('identity versionCode',version_code in bg)
check('identity versionName',version_name in bg)
check('downloads slot','DOWNLOADS_INBOX' in a and 'Downloads inbox' in a)
check('downloads resolver','fun discoverDownloads' in a and 'downloadsInboxDirectory' in a)
check('metadata pair','METADATA_BUNDLE' in a and 'metadataBundleNameForZip' in a)
check('legacy root sidecars','rootChecksum' in a and 'rootManifest' in a)
check('one-level extractor fallback','childDirectories.mapNotNull' in a and 'ambiguous legacy companions' in a)
check('client server both detection','ForgeBuildTarget.BOTH' in a and 'ForgeBuildTarget.CLIENT' in a and 'ForgeBuildTarget.SERVER' in a)
check('hash conflict fails closed','different SHA-256 values' in a)
check('operator source description','fun operatorDescription' in a and 'repositoryLane' in a and 'build ' in a)
check('actual apk store','fun saveApk' in a and 'application/vnd.android.package-archive' in a)
check('project name from root','explicitRootName' in a and 'DEFAULT_PROJECT_DIRECTORY_NAME = "swrlz core"' in a)
check('runner scans downloads','discoverDownloads' in r and 'Scanning configured Downloads inbox' in r)
check('runner exact descriptions','operatorDescription(repositoryLane' in r and 'VERIFIED FOR UPLOAD' in r)
check('runner exact commit message','commitMessage = "forge: upload verified $sourceSummary"' in r)
check('per source build watch','descriptions.forEach' in r and 'sourceDescription = description' in r)
check('watch source identity','val sourceName:' in w and 'val sourceSha256:' in w and 'val component:' in w)
check('component outcome dedupe','component.uppercase()' in w and 'markOutcomeNotified' in w)
check('artifact path safety','path traversal rejected' in e and 'duplicate entry' in e)
check('artifact ambiguity guard','multiple ambiguous APKs' in e and 'stable-signed' in e)
check('monitor extracts actual apk','ForgeArtifactExtractor.extractApk' in m and 'ForgeArtifactStore.saveApk' in m)
check('monitor verifies apk hash','Saved APK SHA-256 differs' in m)
check('monitor derived apk destination','Download/${ForgeAutomationPreferences.projectDirectoryName(appContext)}/apk' in m)
check('optional artifact zip','keepArtifactZip' in m and 'saveArtifactZip' in m)
check('monitor source grounded ledger','buildDescription' in m and 'sourceName = watch.sourceName' in m)
check('screen downloads labels','DOWNLOADS INBOX AUTO-DETECT' in sc and 'RESCAN DOWNLOADS' in sc and 'FIND DOWNLOADS & FORGE VERIFIED SET' in sc)
check('screen exact source','SOURCE · ${candidate.displayName}' in sc and 'SHA-256 · ${candidate.sha256}' in sc and 'REPOSITORY · $repositoryLane' in sc)
check('screen requires verified discovery','projectDiscovery?.ready == true' in sc or 'detectedDiscovery?.ready == true' in sc)
check('settings downloads inbox','Downloads inbox' in st and 'Project root' in st)
check('settings actual apk','Auto-download successful APK' in st and 'Download/<projectName>/apk' in st)
check('settings keep artifact zip','Keep workflow artifact ZIP' in st)
check('resolver schema5','"schema": 5' in rs)
check('resolver source descriptions','source_description' in rs and 'build_description' in rs and 'evidence_description' in rs and 'metadata_mode' in rs)
check('resolver preserves legacy','legacy-loose-sidecars' in rs and 'chunked-git-blobs-v1' in rs)
check('resolver tests descriptions',"metadata_mode" in rt and "build_description" in rt)
check('root scripts patch',(ROOT/'repo-patches/swrlz-core/scripts/ci/resolve_swrlz_source.py').is_file())
check('workflow description patch','SOURCE_BUILD_DESCRIPTION.txt' in patch and 'SWRLZ ${COMPONENT} source selected' in patch and 'Source transport' in patch)
check('workflow allowlisted','.github/workflows/swrlz-apk-router.yml' in ev and 'scripts/ci/resolve_swrlz_source.py' in ev)
check('local workflow source identity',identity in wf and 'Describe ' in wf and 'GITHUB_STEP_SUMMARY' in wf)
check('contract file',(ROOT/'docs/contracts/SWRLZ_FORGE_DOWNLOADS_INBOX_AND_SOURCE_DESCRIPTION_CONTRACT_V1.md').is_file())
check('checkpoint file',(ROOT/'docs/checkpoints/INT_FORGE_064D_DUAL_DOWNLOADS_PIPELINE.md').is_file())
check('report file',(ROOT/'reports/INT_FORGE_064D_DUAL_DOWNLOADS_PIPELINE_IMPLEMENTATION_REPORT.md').is_file())
check('no apk outputs',not any(p.suffix.lower() in {'.apk','.aab','.dex','.class','.so'} for p in ROOT.rglob('*') if p.is_file()))

failed=[n for n,ok in checks if not ok]
for n,ok in checks: print(f"{'PASS' if ok else 'FAIL'} {n}")
print(f"SUMMARY {len(checks)-len(failed)}/{len(checks)} PASS")
if failed:
    print('FAILED: '+', '.join(failed),file=sys.stderr)
    raise SystemExit(1)
