#!/usr/bin/env python3
"""INT-AI-SWRLZX-010A exact-source LALM bring-up runner.

This runner intentionally does *not* promote or activate a model. It only:
1. verifies the exact optimized source GGUF identity,
2. converts it twice through the bounded 002A bridge using the canonical LALM identity profile,
3. requires byte-identical deterministic outputs,
4. verifies SWRLZX integrity + source tensor-data identity,
5. commits one canonical SWRLZ-LALM-001A file and a bounded receipt.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

from swrlzx_gguf_to_swrlzx_v1 import (
    ConversionProfile,
    LALM_BRANDED_FILE,
    LALM_DISPLAY_NAME,
    LALM_IDENTITY_CONTRACT,
    LALM_MODEL_ID,
    LALM_SOURCE_NAME,
    LALM_SOURCE_SHA256,
    LALM_SOURCE_SIZE_BYTES,
    SEC_MANIFEST,
    canonical_json,
    convert,
    parse_gguf,
    read_section_json,
    read_swrlzx_header_toc,
    sha256_file,
    verify_swrlzx,
)

MACHINE_SAFE_FILE = "SWRLZ-LALM-001A.swrlzx"
RECEIPT_NAME = "SWRLZ-LALM-001A.INT-AI-SWRLZX-010A.receipt.json"


def fail(message: str) -> "NoReturn":
    raise ValueError(message)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path, help=f"Exact source artifact: {LALM_SOURCE_NAME}")
    ap.add_argument("output_dir", type=Path)
    ap.add_argument("--machine-safe-name", action="store_true", help="Use .swrlzx instead of branded .§wyrlzx filename.")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--receipt", type=Path)
    args = ap.parse_args()

    try:
        if not args.source.is_file():
            fail(f"LALM_010A_SOURCE_NOT_FOUND:{args.source}")
        index = parse_gguf(args.source)
        if args.source.name != LALM_SOURCE_NAME:
            fail(f"LALM_010A_SOURCE_NAME_MISMATCH:{args.source.name}")
        if index.file_bytes != LALM_SOURCE_SIZE_BYTES:
            fail(f"LALM_010A_SOURCE_SIZE_MISMATCH:{index.file_bytes}")
        if index.source_sha256.lower() != LALM_SOURCE_SHA256:
            fail(f"LALM_010A_SOURCE_SHA256_MISMATCH:{index.source_sha256}")
        architecture = str(index.metadata.get("general.architecture", "")).lower()
        if architecture != "lfm2":
            fail(f"LALM_010A_SOURCE_ARCHITECTURE_MISMATCH:{architecture}")

        args.output_dir.mkdir(parents=True, exist_ok=True)
        final_name = MACHINE_SAFE_FILE if args.machine_safe_name else LALM_BRANDED_FILE
        final = args.output_dir / final_name
        if final.exists() and not args.force:
            fail(f"LALM_010A_DESTINATION_EXISTS:{final}")

        profile = ConversionProfile.lalm_010a()
        with tempfile.TemporaryDirectory(prefix="swrlzx-lalm-010a-", dir=str(args.output_dir)) as tmp_dir:
            tmp = Path(tmp_dir)
            pass1 = tmp / "pass1.swrlzx"
            pass2 = tmp / "pass2.swrlzx"
            report1 = tmp / "pass1.report.json"
            report2 = tmp / "pass2.report.json"
            r1 = convert(args.source, pass1, None, None, False, report1, profile=profile)
            r2 = convert(args.source, pass2, None, None, False, report2, profile=profile)
            sha1 = sha256_file(pass1)
            sha2 = sha256_file(pass2)
            if sha1 != sha2:
                fail(f"LALM_010A_NONDETERMINISTIC_OUTPUT:{sha1}:{sha2}")

            v1 = verify_swrlzx(pass1, source=args.source)
            v2 = verify_swrlzx(pass2, source=args.source)
            if v1 != v2:
                fail("LALM_010A_VERIFICATION_RESULT_MISMATCH")

            header, toc = read_swrlzx_header_toc(pass1)
            manifest_entry = next(t for t in toc if t.section_type == SEC_MANIFEST)
            manifest = read_section_json(pass1, manifest_entry)
            if manifest.get("modelId") != LALM_MODEL_ID or manifest.get("displayName") != LALM_DISPLAY_NAME:
                fail("LALM_010A_TARGET_MODEL_IDENTITY_INVALID")
            if manifest.get("sourceSha256", "").lower() != LALM_SOURCE_SHA256:
                fail("LALM_010A_SOURCE_PROVENANCE_LOST")
            if LALM_IDENTITY_CONTRACT not in manifest.get("requiredRuntimeContracts", []):
                fail("LALM_010A_IDENTITY_CONTRACT_MISSING")

            if final.exists():
                final.unlink()
            os.replace(pass1, final)

        receipt = {
            "schemaVersion": 1,
            "checkpoint": "INT-AI-SWRLZX-010A",
            "identityContract": LALM_IDENTITY_CONTRACT,
            "nativeFamily": "LALM",
            "nativeFamilyExpansion": "Local Adaptive Language Model",
            "sourceFamily": "LFM",
            "sourceArchitecture": architecture,
            "sourceArchitectureDisplay": "LFM2.5",
            "sourceModelLineage": "LiquidAI/LFM2.5-350M",
            "sourceFileName": args.source.name,
            "sourceSizeBytes": index.file_bytes,
            "sourceSha256": index.source_sha256,
            "sourceIdentityVerified": True,
            "targetModelId": LALM_MODEL_ID,
            "targetDisplayName": LALM_DISPLAY_NAME,
            "targetFileName": final.name,
            "targetSha256": sha256_file(final),
            "targetRootDigestSha256": v1["rootDigestSha256"],
            "targetBytes": final.stat().st_size,
            "tensorCount": index.tensor_count,
            "metadataCount": index.metadata_count,
            "tensorDataByteIdentical": True,
            "deterministicSecondPassSha256": sha2,
            "deterministicMatch": True,
            "productionPromotionPerformed": False,
            "nativeExecutionParityStatus": "PENDING",
            "runtimeSwitchPerformed": False,
            "outputValidation": "PASS",
        }
        receipt_path = args.receipt or (args.output_dir / RECEIPT_NAME)
        receipt_path.write_bytes(canonical_json(receipt))
        print(json.dumps({"ok": True, "output": str(final), "receipt": str(receipt_path), **receipt}, indent=2, sort_keys=True, ensure_ascii=False))
        return 0
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
