#!/usr/bin/env python3
"""INT-AI-SWRLZX-012A exact-source GGUF↔LALM reference parity runner.

This runner compares the pinned deprecated GGUF against the canonical SWRLZX/LALM conversion.
It proves format/tensor/tokenizer/graph/reference-numerical parity. It intentionally does NOT
claim legacy Android llama.cpp runtime parity; that remains a separately gated field because the
pinned llama-android AAR exposes completion text but not logits/token callbacks in this host.
"""
from __future__ import annotations
import argparse, hashlib, json, math, re, struct, sys, time
from pathlib import Path
from typing import Any
import numpy as np

from swrlzx_gguf_to_swrlzx_v1 import (
    parse_gguf, GGML_TYPE_NAMES, read_swrlzx_header_toc, read_section_json,
    SEC_MANIFEST, SEC_ARCH, SEC_TOKENIZER, SEC_TENSOR_DIR, SEC_TENSOR_DATA,
    SEC_QUANT, SEC_GENERATION, sha256_file,
    LALM_SOURCE_NAME, LALM_SOURCE_SHA256, LALM_SOURCE_SIZE_BYTES,
    LALM_MODEL_ID, LALM_BRANDED_FILE,
)

EXPECTED_LALM_SHA256 = "d3e3692f7bd7160baff27ca2b3479033d2a494081a1a8ada17a27c2183fcd565"
EXPECTED_LALM_ROOT = "2378856022cff3191e4efa169a0ab92b419310db9d30ec807de2b969a7c34f72"
LAYER_KV = [0,0,8,0,0,8,0,0,8,0,8,0,8,0,8,0]


def hregion(mm: np.memmap, start: int, length: int, chunk: int = 8*1024*1024) -> str:
    h=hashlib.sha256(); end=start+length
    for p in range(start,end,chunk): h.update(memoryview(mm[p:min(end,p+chunk)]))
    return h.hexdigest()


def q4_scale_min(sc: np.ndarray) -> tuple[np.ndarray,np.ndarray]:
    nb=sc.shape[0]; S=np.empty((nb,8),np.int16); M=np.empty((nb,8),np.int16)
    S[:,:4]=sc[:,:4]&63; M[:,:4]=sc[:,4:8]&63
    for j in range(4,8):
        S[:,j]=(sc[:,j+4]&15)|((sc[:,j-4]>>6)<<4)
        M[:,j]=(sc[:,j+4]>>4)|((sc[:,j]>>6)<<4)
    return S,M


def deq_q4k(raw: np.ndarray, cols: int, rows: int) -> np.ndarray:
    nb=rows*(cols//256); b=raw.reshape(nb,144)
    d=b[:,0:2].copy().view('<f2').reshape(-1).astype(np.float32)
    dm=b[:,2:4].copy().view('<f2').reshape(-1).astype(np.float32)
    sc=b[:,4:16]; qs=b[:,16:]; S,M=q4_scale_min(sc)
    out=np.empty((nb,256),np.float32)
    for g in range(4):
        q=qs[:,g*32:(g+1)*32]
        out[:,g*64:g*64+32]=(d*S[:,2*g])[:,None]*(q&15)-(dm*M[:,2*g])[:,None]
        out[:,g*64+32:g*64+64]=(d*S[:,2*g+1])[:,None]*(q>>4)-(dm*M[:,2*g+1])[:,None]
    return out.reshape(rows,cols)


def deq_q6k(raw: np.ndarray, cols: int, rows: int) -> np.ndarray:
    nb=rows*(cols//256); b=raw.reshape(nb,210)
    ql=b[:,:128]; qh=b[:,128:192]; sc=b[:,192:208].view(np.int8).astype(np.int16)
    d=b[:,208:210].copy().view('<f2').reshape(-1).astype(np.float32)
    out=np.empty((nb,256),np.float32); ix=np.arange(32)//16
    for half in range(2):
        lo0=ql[:,half*64:half*64+32]; lo1=ql[:,half*64+32:half*64+64]; hi=qh[:,half*32:(half+1)*32]
        s=half*8; o=half*128
        q1=((lo0&15)|(((hi>>0)&3)<<4)).astype(np.int16)-32
        q2=((lo1&15)|(((hi>>2)&3)<<4)).astype(np.int16)-32
        q3=(((lo0>>4)&15)|(((hi>>4)&3)<<4)).astype(np.int16)-32
        q4=(((lo1>>4)&15)|(((hi>>6)&3)<<4)).astype(np.int16)-32
        out[:,o:o+32]=d[:,None]*sc[:,s+ix]*q1
        out[:,o+32:o+64]=d[:,None]*sc[:,s+2+ix]*q2
        out[:,o+64:o+96]=d[:,None]*sc[:,s+4+ix]*q3
        out[:,o+96:o+128]=d[:,None]*sc[:,s+6+ix]*q4
    return out.reshape(rows,cols)


def deq(kind: str, raw: np.ndarray, shape: tuple[int,...]) -> np.ndarray:
    cols=int(shape[0]); rows=int(shape[1]) if len(shape)>1 else 1
    if kind=='f32': return raw.copy().view('<f4').reshape(rows,cols)
    if kind=='f16': return raw.copy().view('<f2').astype(np.float32).reshape(rows,cols)
    if kind=='bf16':
        u=raw.copy().view('<u2').astype(np.uint32)<<16
        return u.view(np.float32).reshape(rows,cols)
    if kind=='q4_k': return deq_q4k(raw,cols,rows)
    if kind=='q6_k': return deq_q6k(raw,cols,rows)
    raise ValueError(f'PARITY_QUANT_UNSUPPORTED:{kind}')


class Reader:
    def __init__(self, path: Path, kind: str):
        self.path=path; self.kind=kind; self.mm=np.memmap(path,mode='r',dtype=np.uint8)
        if kind=='GGUF':
            self.idx=parse_gguf(path); self.base=self.idx.tensor_data_offset
            self.desc={t.name:{'shape':tuple(t.shape),'kind':GGML_TYPE_NAMES[t.ggml_type], 'off':t.offset,'len':t.span_length,'sha':t.sha256} for t in self.idx.tensors}
            self.metadata=self.idx.metadata; self.graph=None; self.tokenizer={
                'tokens':self.metadata['tokenizer.ggml.tokens'],'merges':self.metadata['tokenizer.ggml.merges'],
                'bosTokenId':int(self.metadata['tokenizer.ggml.bos_token_id']),'eosTokenId':int(self.metadata['tokenizer.ggml.eos_token_id']),
                'padTokenId':int(self.metadata['tokenizer.ggml.padding_token_id']),'addBos':bool(self.metadata.get('tokenizer.ggml.add_bos_token',True)),
                'addEos':bool(self.metadata.get('tokenizer.ggml.add_eos_token',False)), 'kind':'GGML_BPE'}
        else:
            self.header,self.toc=read_swrlzx_header_toc(path); bt={e.section_type:e for e in self.toc}
            self.manifest=read_section_json(path,bt[SEC_MANIFEST]); self.graph=read_section_json(path,bt[SEC_ARCH]); self.tokenizer=read_section_json(path,bt[SEC_TOKENIZER]); self.quant=read_section_json(path,bt[SEC_QUANT]); self.generation=read_section_json(path,bt[SEC_GENERATION]); td=read_section_json(path,bt[SEC_TENSOR_DIR]); data=bt[SEC_TENSOR_DATA]; self.base=data.offset; self.data_len=data.stored_length
            self.desc={d['name']:{'shape':tuple(d['shape']),'kind':(d.get('quantization') or d['dataType']).lower(),'off':int(d['dataOffsetBytes']),'len':int(d['storedLengthBytes']),'sha':d['sha256'],'id':d['tensorId']} for d in td['tensors']}
    def raw(self,name:str)->np.ndarray:
        d=self.desc[name]; return self.mm[self.base+d['off']:self.base+d['off']+d['len']]
    def matrix(self,name:str)->np.ndarray:
        d=self.desc[name]; return deq(d['kind'],self.raw(name),d['shape'])
    def row(self,name:str,row:int)->np.ndarray:
        d=self.desc[name]; cols=int(d['shape'][0]); rows=int(d['shape'][1]) if len(d['shape'])>1 else 1
        kind=d['kind']
        rb={'f32':cols*4,'f16':cols*2,'bf16':cols*2,'q4_k':(cols//256)*144,'q6_k':(cols//256)*210}[kind]
        rr=self.raw(name)[row*rb:(row+1)*rb]
        return deq(kind,rr,(cols,1)).reshape(-1)
    def vector(self,name:str)->np.ndarray: return self.matrix(name).reshape(-1)
    def matvec(self,name:str,x:np.ndarray)->np.ndarray: return (self.matrix(name)@x).astype(np.float32)


def bytes_to_unicode():
    bs=list(range(ord('!'),ord('~')+1))+list(range(0xA1,0xAC+1))+list(range(0xAE,0xFF+1)); cs=bs.copy(); n=0
    for b in range(256):
        if b not in bs: bs.append(b); cs.append(256+n); n+=1
    return {b:chr(c) for b,c in zip(bs,cs)}

PRE=re.compile(r"'s|'t|'re|'ve|'m|'ll|'d| ?[^\W\d_]+| ?\d+| ?[^\s\w]+|\s+(?!\S)|\s+",re.UNICODE)

def bpe_encode(text:str,tok:dict[str,Any])->list[int]:
    token_to_id={t:i for i,t in enumerate(tok['tokens'])}; ranks={tuple(m.split(' ',1)):i for i,m in enumerate(tok['merges']) if ' ' in m}; b2u=bytes_to_unicode()
    specials=sorted(((t,i) for i,t in enumerate(tok['tokens']) if t.startswith('<|') and t.endswith('|>')),key=lambda x:-len(x[0]))
    out=[]; cursor=0
    while cursor<len(text):
        hit=next(((s,i) for s,i in specials if text.startswith(s,cursor)),None)
        if hit: out.append(hit[1]); cursor+=len(hit[0]); continue
        nexts=[text.find(s,cursor) for s,_ in specials]; nexts=[p for p in nexts if p>=0]; end=min(nexts) if nexts else len(text); seg=text[cursor:end]
        for m in PRE.finditer(seg):
            symbols=list(''.join(b2u[b] for b in m.group(0).encode('utf-8')))
            while len(symbols)>1:
                best=(-1,10**12)
                for i in range(len(symbols)-1):
                    r=ranks.get((symbols[i],symbols[i+1]))
                    if r is not None and r<best[1]: best=(i,r)
                if best[0]<0: break
                i=best[0]; symbols[i]=symbols[i]+symbols[i+1]; del symbols[i+1]
            for s in symbols:
                if s not in token_to_id: raise ValueError(f'PARITY_BPE_TOKEN_MISSING:{s!r}')
                out.append(token_to_id[s])
        cursor=end
    if tok.get('addBos') and (not out or out[0]!=tok.get('bosTokenId')): out.insert(0,int(tok['bosTokenId']))
    if tok.get('addEos') and (not out or out[-1]!=tok.get('eosTokenId')): out.append(int(tok['eosTokenId']))
    return out


def rms(x,w,eps=1e-5):
    return (x/np.sqrt(np.mean(x*x,dtype=np.float32)+np.float32(eps),dtype=np.float32)*w).astype(np.float32)
def silu(x): return (x/(1+np.exp(-x,dtype=np.float32))).astype(np.float32)
def rope(x,heads,hd,pos,theta=1_000_000.0):
    y=x.reshape(heads,hd).copy(); half=hd//2; inv=1.0/(theta**(np.arange(half,dtype=np.float64)*2.0/hd)); ang=pos*inv; c=np.cos(ang).astype(np.float32); s=np.sin(ang).astype(np.float32); a=y[:,:half].copy(); b=y[:,half:].copy(); y[:,:half]=a*c-b*s; y[:,half:]=b*c+a*s; return y.reshape(-1)

class State:
    def __init__(self):
        self.conv={i:np.zeros((2,1024),np.float32) for i,k in enumerate(LAYER_KV) if k==0}; self.kv={i:[] for i,k in enumerate(LAYER_KV) if k}; self.pos=0


def forward(reader:Reader, token:int, state:State)->tuple[np.ndarray,dict[str,float]]:
    timings={}; t0=time.perf_counter(); x=reader.row('token_embd.weight',token).astype(np.float32); timings['embed']=time.perf_counter()-t0
    for i,kvh in enumerate(LAYER_KV):
        n=rms(x,reader.vector(f'blk.{i}.attn_norm.weight'))
        if kvh==0:
            p=reader.matvec(f'blk.{i}.shortconv.in_proj.weight',n); B,C,z=np.split(p,3); bx=(B*z).astype(np.float32); cw=reader.matrix(f'blk.{i}.shortconv.conv.weight')
            hist=state.conv[i]; cv=(hist[0]*cw[:,0]+hist[1]*cw[:,1]+bx*cw[:,2]).astype(np.float32); state.conv[i][0]=hist[1].copy(); state.conv[i][1]=bx
            op=reader.matvec(f'blk.{i}.shortconv.out_proj.weight',(C*cv).astype(np.float32))
        else:
            q=reader.matvec(f'blk.{i}.attn_q.weight',n); k=reader.matvec(f'blk.{i}.attn_k.weight',n); v=reader.matvec(f'blk.{i}.attn_v.weight',n)
            qn=reader.vector(f'blk.{i}.attn_q_norm.weight'); kn=reader.vector(f'blk.{i}.attn_k_norm.weight')
            q=np.concatenate([rms(q.reshape(16,64)[h],qn) for h in range(16)]).astype(np.float32); k=np.concatenate([rms(k.reshape(8,64)[h],kn) for h in range(8)]).astype(np.float32)
            q=rope(q,16,64,state.pos); k=rope(k,8,64,state.pos); state.kv[i].append((k.copy(),v.copy())); att=np.zeros((16,64),np.float32)
            for h in range(16):
                kh=h//2; qh=q.reshape(16,64)[h]; scores=np.array([np.dot(qh,K.reshape(8,64)[kh])/8.0 for K,V in state.kv[i]],np.float32); p=np.exp(scores-scores.max(),dtype=np.float32); p/=p.sum(dtype=np.float32)
                for pp,(K,V) in zip(p,state.kv[i]): att[h]+=pp*V.reshape(8,64)[kh]
            op=reader.matvec(f'blk.{i}.attn_output.weight',att.reshape(-1))
        r=(x+op).astype(np.float32); fn=rms(r,reader.vector(f'blk.{i}.ffn_norm.weight')); gate=reader.matvec(f'blk.{i}.ffn_gate.weight',fn); up=reader.matvec(f'blk.{i}.ffn_up.weight',fn); ff=reader.matvec(f'blk.{i}.ffn_down.weight',(silu(gate)*up).astype(np.float32)); x=(r+ff).astype(np.float32)
    x=rms(x,reader.vector('token_embd_norm.weight')); logits=reader.matvec('token_embd.weight',x); state.pos+=1; timings['total']=time.perf_counter()-t0; return logits,timings


def graph_semantics(graph:dict[str,Any], sw:Reader)->list[str]:
    expected=[]; expected.append(('embed','TOKEN_EMBED',['token_embd.weight']))
    for i,k in enumerate(LAYER_KV):
        expected.append((f'l{i}.operator_norm','RMS_NORM',[f'blk.{i}.attn_norm.weight']))
        expected.append((f'l{i}.shortconv' if k==0 else f'l{i}.gqa','LFM_CONV' if k==0 else 'GQA_ATTENTION',
                         [f'blk.{i}.shortconv.in_proj.weight',f'blk.{i}.shortconv.conv.weight',f'blk.{i}.shortconv.out_proj.weight'] if k==0 else [f'blk.{i}.attn_q.weight',f'blk.{i}.attn_k.weight',f'blk.{i}.attn_v.weight',f'blk.{i}.attn_output.weight',f'blk.{i}.attn_q_norm.weight',f'blk.{i}.attn_k_norm.weight']))
        expected.append((f'l{i}.residual','ADD',[])); expected.append((f'l{i}.ffn_norm','RMS_NORM',[f'blk.{i}.ffn_norm.weight'])); expected.append((f'l{i}.ffn','GATED_MLP',[f'blk.{i}.ffn_gate.weight',f'blk.{i}.ffn_up.weight',f'blk.{i}.ffn_down.weight'])); expected.append((f'l{i}.ffn_residual','ADD',[]))
    expected += [('final_norm','RMS_NORM',['token_embd_norm.weight']),('lm_head','LM_HEAD',['token_embd.weight']),('sample','SAMPLE',[])]
    id_to_name={d.get('id'):n for n,d in ((n,v) for n,v in sw.desc.items())}
    errs=[]; nodes=graph.get('nodes',[])
    if len(nodes)!=len(expected): errs.append(f'node_count:{len(nodes)}:{len(expected)}'); return errs
    for node,(eid,eop,enames) in zip(nodes,expected):
        got_names=[id_to_name.get(tid,'?'+tid) for tid in node.get('tensorIds',[])]
        if node.get('id')!=eid or node.get('op')!=eop or got_names!=enames: errs.append(f'{eid}:got={node.get("id")}/{node.get("op")}/{got_names}:expected={eop}/{enames}')
    return errs


def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument('gguf',type=Path); ap.add_argument('lalm',type=Path); ap.add_argument('--out',type=Path); ap.add_argument('--tokens',default='1,535',help='comma separated token IDs for recurrent numerical parity')
    args=ap.parse_args(); started=time.time(); checks=[]
    def ck(name,cond,detail=''): checks.append({'name':name,'pass':bool(cond),'detail':detail})
    g=Reader(args.gguf,'GGUF'); s=Reader(args.lalm,'SWRLZX')
    ck('pinned GGUF filename',args.gguf.name==LALM_SOURCE_NAME,args.gguf.name); ck('pinned GGUF bytes',args.gguf.stat().st_size==LALM_SOURCE_SIZE_BYTES,str(args.gguf.stat().st_size)); ck('pinned GGUF SHA-256',sha256_file(args.gguf)==LALM_SOURCE_SHA256,sha256_file(args.gguf))
    lsha=sha256_file(args.lalm); ck('canonical LALM filename',args.lalm.name==LALM_BRANDED_FILE,args.lalm.name); ck('canonical LALM SHA-256',lsha==EXPECTED_LALM_SHA256,lsha); ck('canonical LALM root',s.header['rootDigestSha256']==EXPECTED_LALM_ROOT,s.header['rootDigestSha256']); ck('manifest model identity',s.manifest.get('modelId')==LALM_MODEL_ID,str(s.manifest.get('modelId')))
    ck('tensor count 148',len(g.desc)==148 and len(s.desc)==148,f'{len(g.desc)}/{len(s.desc)}')
    names=sorted(g.desc); ck('tensor name set exact',names==sorted(s.desc))
    desc_errors=[]
    for n in names:
        gd,sd=g.desc[n],s.desc[n]
        if gd['shape']!=sd['shape'] or gd['kind']!=sd['kind'] or gd['len']!=sd['len'] or gd['sha']!=sd['sha']: desc_errors.append(n)
    ck('all tensor descriptors reconcile',not desc_errors,','.join(desc_errors[:8]))
    gg_data_len=args.gguf.stat().st_size-g.base; sw_data_len=s.data_len; gh=hregion(g.mm,g.base,gg_data_len); sh=hregion(s.mm,s.base,sw_data_len)
    ck('tensor-data byte length exact',gg_data_len==sw_data_len,f'{gg_data_len}/{sw_data_len}'); ck('tensor-data SHA-256 byte-identical',gh==sh,f'{gh}/{sh}')
    gm=g.metadata; stok=s.tokenizer
    ck('token vocabulary exact',gm['tokenizer.ggml.tokens']==stok['tokens'],str(len(stok['tokens']))); ck('BPE merges exact',gm['tokenizer.ggml.merges']==stok['merges'],str(len(stok['merges']))); ck('special token IDs exact',int(gm['tokenizer.ggml.bos_token_id'])==stok['bosTokenId'] and int(gm['tokenizer.ggml.eos_token_id'])==stok['eosTokenId'] and int(gm['tokenizer.ggml.padding_token_id'])==stok['padTokenId'])
    ck('source chat template preserved',gm.get('tokenizer.chat_template')==s.generation.get('sourceChatTemplate'))
    gerrs=graph_semantics(s.graph,s); ck('100-node graph semantic mapping',not gerrs,';'.join(gerrs[:4]))
    prompts=['Hello','The sky is blue.','<|im_start|>user\nHi<|im_end|>\n<|im_start|>assistant\n']
    tok_vectors={}; tok_ok=True
    for p in prompts:
        gt=bpe_encode(p,g.tokenizer); st=bpe_encode(p,s.tokenizer); tok_vectors[p]=gt; tok_ok &= (gt==st)
    ck('real tokenizer vectors GGUF↔LALM exact',tok_ok,json.dumps(tok_vectors,ensure_ascii=False))
    tokens=[int(x) for x in args.tokens.split(',') if x.strip()]; gs=State(); ss=State(); numerical=[]; max_abs=0.0; top_equal=True
    for ordinal,tok in enumerate(tokens):
        gl,gtm=forward(g,tok,gs); sl,stm=forward(s,tok,ss); diff=np.abs(gl-sl); ma=float(diff.max()); max_abs=max(max_abs,ma); gtop=int(np.argmax(gl)); stop=int(np.argmax(sl)); top_equal &= gtop==stop
        numerical.append({'ordinal':ordinal,'inputToken':tok,'ggufTop1':gtop,'lalmTop1':stop,'maxAbsLogitDiff':ma,'ggufSeconds':gtm['total'],'lalmSeconds':stm['total'],'ggufTop5':[int(x) for x in np.argsort(gl)[-5:][::-1]],'lalmTop5':[int(x) for x in np.argsort(sl)[-5:][::-1]]})
    ck('full reference logits exact',max_abs==0.0,f'max_abs={max_abs}'); ck('full reference top-1 exact',top_equal,str(numerical))
    legacy='PENDING_ANDROID_LLAMA_AAR'
    parity_proven=False
    result={'schemaVersion':1,'checkpoint':'INT-AI-SWRLZX-012A','contract':'swrlzx.lalm.parity.v1','sourceGgufSha256':LALM_SOURCE_SHA256,'targetLalmSha256':lsha,'targetLalmRootDigestSha256':s.header['rootDigestSha256'],'tensorCount':148,'tensorDataSha256':gh,'referenceTokenSequence':tokens,'referenceNumerical':numerical,'referenceMaxAbsLogitDiff':max_abs,'referenceParityStatus':'PROVEN' if all(x['pass'] for x in checks) else 'FAILED','legacyEngineParityStatus':legacy,'parityProven':parity_proven,'productionPromotionAllowed':False,'checks':checks,'elapsedSeconds':time.time()-started,'boundary':'Reference/format parity proven on exact bytes; PARITY_PROVEN remains false until legacy Android llama.cpp completion parity executes on target runtime.'}
    for x in checks: print(('PASS' if x['pass'] else 'FAIL')+' | '+x['name']+((' | '+x['detail']) if x['detail'] else ''))
    print(f"RESULT | {sum(x['pass'] for x in checks)}/{len(checks)} PASS | reference_max_abs_logit_diff={max_abs} | legacy={legacy}")
    if args.out: args.out.write_text(json.dumps(result,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
    return 0 if all(x['pass'] for x in checks) else 1

if __name__=='__main__': raise SystemExit(main())
