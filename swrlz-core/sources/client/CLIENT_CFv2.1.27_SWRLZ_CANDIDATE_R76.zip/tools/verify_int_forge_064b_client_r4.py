#!/usr/bin/env python3
from pathlib import Path
import json, re, sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name, cond):
    checks.append((name,bool(cond)))
    print(('PASS' if cond else 'FAIL')+': '+name)
def text(rel): return (ROOT/rel).read_text(encoding='utf-8')

auto=text('android/app/src/main/java/sh/swurlz/core/github/ForgeAutomation.kt')
runner=text('android/app/src/main/java/sh/swurlz/core/github/ForgeAutomatedBuildRunner.kt')
pending=text('android/app/src/main/java/sh/swurlz/core/github/ForgePendingTransactionStore.kt')
client=text('android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt')
screen=text('android/app/src/main/java/sh/swurlz/core/ui/screens/GitHubForgeScreen.kt')
runtime=text('android/app/src/main/java/sh/swurlz/core/github/ForgeRuntimeState.kt')
shell=text('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt')
build=text('android/app/build.gradle.kts')

check('versionCode 127','versionCode = 127' in build)
check('R4 versionName','2.1.26-project-root-forge-auto-detect-r4' in build)
check('project-root discovery function','fun discoverProject' in auto and 'ForgeFolderSlot.ROOT' in auto)
check('AUTO target supported','ForgeBuildTarget.ASK -> detected' in auto)
check('CLIENT/SERVER/BOTH detection','ForgeBuildTarget.BOTH' in auto and 'ForgeBuildTarget.CLIENT' in auto and 'ForgeBuildTarget.SERVER' in auto)
check('equal-rank hash conflict guard','conflicting candidates' in auto and 'distinctHashes.size > 1' in auto)
check('metadata pair format','METADATA_BUNDLE' in auto and 'stagedFileCount' in auto)
check('legacy triple format','LEGACY_TRIPLE' in auto)
check('matching evidence resolver','matchingEvidence' in auto and 'delivery/INT_' in auto)
check('runner accepts ASK','ForgeBuildTarget.ASK' in runner)
check('runner removed fixed triple count','expectedCount * 3' not in runner and 'sumOf { it.stagedFileCount }' in runner)
check('runner includes evidence','asLocalFiles(candidates, discovery.evidenceBundle)' in runner)
check('one-action label','SCAN PROJECT & UPLOAD VERIFIED SET' in screen)
check('project preview panel','PROJECT ROOT AUTO-DETECT' in screen and 'RESCAN PROJECT ROOT' in screen)
check('scan on screen entry','discoverProject(context, ForgeBuildTarget.ASK)' in screen)
success_pos = screen.find('latest?.status == \"completed\"')
failure_pos = screen.find('status.contains(\"failed\"')
check('authoritative workflow success precedence', success_pos >= 0 and failure_pos >= 0 and success_pos < failure_pos)
check('RECONCILING runtime state','RECONCILING("RECONCILING")' in runtime and 'Phase.RECONCILING' in screen and 'Phase.RECONCILING' in shell)
check('pending transaction fingerprint','object ForgePendingTransactionStore' in pending and 'beginOrReuse' in pending)
check('transaction reuse wired','ForgePendingTransactionStore.beginOrReuse' in client)
check('transaction completion cleanup','ForgePendingTransactionStore.complete' in client)
check('recent commit transaction lookup','SWRLZ-Forge-Transaction:' in client and 'RepositoryCommitSummaryResponse' in client)
check('transient GitHub classification','setOf(408, 425, 429, 500, 502, 503, 504)' in client)
check('post-commit reconciliation','reconcileCommittedTransaction' in client and 'verificationDegraded' in client)
check('reconciled result surfaced','val reconciled: Boolean' in client and 'val verificationDegraded: Boolean' in client)
check('manual transient state not terminal','ForgeRuntimeState.Phase.RECONCILING' in screen and 'preserved TX' in screen)

receipt=json.loads(text('CHECKPOINT_RECEIPT.json'))
check('candidate receipt identity',receipt.get('candidate')=='CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R4')
check('byte-exact R3 parent',receipt.get('parent',{}).get('sha256')=='fd6a65ba7043be4870d222835b9c61b95dbf493b42b03253db813b36ac4cbda8')
check('no prohibited action claimed',not any(receipt.get(k) for k in ['repository_writes','workflow_dispatch','apk_build','installation','promotion','release_or_deployment']))

# Lightweight delimiter scanner ignoring strings and comments.
def balanced(src):
    stack=[]; pairs={')':'(',']':'[','}':'{'}; i=0; mode='code'; quote=''
    while i<len(src):
        c=src[i]; n=src[i+1] if i+1<len(src) else ''
        if mode=='code':
            if c=='/' and n=='/': mode='line'; i+=2; continue
            if c=='/' and n=='*': mode='block'; i+=2; continue
            if src.startswith('"""',i): mode='triple'; i+=3; continue
            if c in ('"',"'"): mode='string'; quote=c; i+=1; continue
            if c in '([{': stack.append(c)
            elif c in ')]}':
                if not stack or stack.pop()!=pairs[c]: return False
        elif mode=='line':
            if c=='\n': mode='code'
        elif mode=='block':
            if c=='*' and n=='/': mode='code'; i+=2; continue
        elif mode=='triple':
            if src.startswith('"""',i): mode='code'; i+=3; continue
        elif mode=='string':
            if c=='\\': i+=2; continue
            if c==quote: mode='code'
        i+=1
    return not stack and mode in ('code','line')
for rel in [
'android/app/src/main/java/sh/swurlz/core/github/ForgeAutomation.kt',
'android/app/src/main/java/sh/swurlz/core/github/ForgeAutomatedBuildRunner.kt',
'android/app/src/main/java/sh/swurlz/core/github/ForgePendingTransactionStore.kt',
'android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt',
'android/app/src/main/java/sh/swurlz/core/github/ForgeRuntimeState.kt',
'android/app/src/main/java/sh/swurlz/core/ui/screens/GitHubForgeScreen.kt',
'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt']:
    check('balanced delimiters '+rel, balanced(text(rel)))

passed=sum(v for _,v in checks)
print(f'RESULT: {passed}/{len(checks)} PASS')
sys.exit(0 if passed==len(checks) else 1)
