#!/usr/bin/env python3
from pathlib import Path
import json, sys
root=Path(__file__).resolve().parents[1]
checks=[]
def has(path,text,label):
    p=root/path; ok=p.exists() and text in p.read_text(errors='ignore'); checks.append((label,ok)); return ok
has('android/app/build.gradle.kts','versionCode = 162','CLIENT VC162')
has('android/app/build.gradle.kts','2.1.27-archive-index-r36','CLIENT R36 version')
has('android/app/build.gradle.kts','INT-ARCHIVE-INDEX-128A','checkpoint identity')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveIndexStore.kt','CREATE TABLE archive_index','persistent archive index table')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveIndexStore.kt','CREATE TABLE archive_entry','persistent entry catalog')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveIndexCoordinator.kt','Dispatchers.IO','background IO index build')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveIndexCoordinator.kt','scanCentralDirectory','seek-first central index')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveIndexCoordinator.kt','scanSequential','background sequential fallback')
has('android/app/src/main/java/sh/swurlz/core/archive/ZipCentralDirectoryParser.kt','ZIP64_EOCD_SIG','ZIP64 EOCD parser')
has('android/app/src/main/java/sh/swurlz/core/archive/ZipCentralDirectoryParser.kt','localHeaderOffset','entry local-header offset')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveSeekReader.kt','withIndexedEntryStream','direct indexed entry stream')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveSeekReader.kt','Inflater(true)','raw DEFLATE direct inflate')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt','ARCHIVE_INDEX_BUILDING','fail-fast while index builds')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt','ArchiveIndexStore.scanFromOrdinal','indexed bounded tree/list')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt','ArchiveIndexStore.conversationCandidates','indexed conversation candidate discovery')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt','ArchiveSeekReader.withIndexedEntryStream','direct outer-entry read path')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveSourceStore.kt','ArchiveIndexStore.state(context, source).status','advertised index status')
has('android/app/src/main/java/sh/swurlz/core/archive/ArchiveNodeRuntime.kt','ArchiveIndexCoordinator.ensureAllAsync','startup background index resume')
has('INT-ARCHIVE-INDEX-128A_ZIP64_HARNESS.txt','PASS | indexed direct entry read','direct seek evidence')
has('INT-ARCHIVE-INDEX-128A_ANDROID_COMPILE_ATTEMPT.txt','UnknownHostException','honest Android build boundary')
has('ReleaseNotes.md','CLIENT R36 — INT-ARCHIVE-INDEX-128A','release notes')
has('CHANGELOG.md','CLIENT R36 — INT-ARCHIVE-INDEX-128A','changelog')
has('README.md','CLIENT R36 — INT-ARCHIVE-INDEX-128A','readme')
has('android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt','revision = "R36"','client update ledger')
receipt=json.loads((root/'CHECKPOINT_RECEIPT.json').read_text())
checks.append(('receipt candidate',receipt.get('candidate')=='CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R36'))
lineage=json.loads((root/'SWRLZ_PATCH_LINEAGE_INDEX_V1.json').read_text())
checks.append(('lineage parent R35',lineage.get('parent',{}).get('candidate')=='CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R35'))
checks.append(('lineage sibling R61',lineage.get('sibling')=='SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R61'))
for rel in [
 'android/app/src/main/java/sh/swurlz/core/archive/ArchiveIndexStore.kt',
 'android/app/src/main/java/sh/swurlz/core/archive/ArchiveIndexCoordinator.kt',
 'android/app/src/main/java/sh/swurlz/core/archive/ZipCentralDirectoryParser.kt',
 'android/app/src/main/java/sh/swurlz/core/archive/ArchiveSeekReader.kt',
 'android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt']:
    t=(root/rel).read_text(); checks.append((f'brace balance {rel}',t.count('{')==t.count('}')))
for label,ok in checks: print(('PASS' if ok else 'FAIL'),'|',label)
failed=[x for x in checks if not x[1]]
print(f'RESULT {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
