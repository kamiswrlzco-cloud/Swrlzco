#!/usr/bin/env python3
"""Focused source/static verifier for INT-LALM-INTERACTIVE-MEMORY-137A."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path


CHECKPOINT = "INT-LALM-INTERACTIVE-MEMORY-137A"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def kotlin_balanced(path: Path) -> tuple[bool, str]:
    text = path.read_text(encoding="utf-8")
    stack: list[tuple[str, int]] = []
    pairs = {")": "(", "]": "[", "}": "{"}
    openings = set(pairs.values())
    i = 0
    state = "code"
    while i < len(text):
        two = text[i : i + 2]
        three = text[i : i + 3]
        char = text[i]
        if state == "code":
            if three == '\"\"\"':
                state = "triple"
                i += 3
                continue
            if two == "//":
                state = "line_comment"
                i += 2
                continue
            if two == "/*":
                state = "block_comment"
                i += 2
                continue
            if char == '"':
                state = "string"
                i += 1
                continue
            if char == "'":
                state = "char"
                i += 1
                continue
            if char in openings:
                stack.append((char, i))
            elif char in pairs:
                if not stack or stack[-1][0] != pairs[char]:
                    return False, f"unexpected {char} at offset {i}"
                stack.pop()
        elif state == "line_comment":
            if char == "\n":
                state = "code"
        elif state == "block_comment":
            if two == "*/":
                state = "code"
                i += 2
                continue
        elif state == "triple":
            if three == '\"\"\"':
                state = "code"
                i += 3
                continue
        elif state in {"string", "char"}:
            if char == "\\":
                i += 2
                continue
            if (state == "string" and char == '"') or (state == "char" and char == "'"):
                state = "code"
        i += 1
    if state in {"block_comment", "triple", "string", "char"}:
        return False, f"unterminated lexical state {state}"
    if stack:
        return False, f"unclosed {stack[-1][0]} at offset {stack[-1][1]}"
    return True, "balanced"


def require_text(path: Path, snippets: list[str], failures: list[str]) -> None:
    if not path.is_file():
        failures.append(f"missing: {path}")
        return
    text = path.read_text(encoding="utf-8")
    for snippet in snippets:
        if snippet not in text:
            failures.append(f"missing snippet {snippet!r}: {path}")


def validate_json(root: Path, failures: list[str]) -> int:
    count = 0
    for path in sorted(root.rglob("*.json")):
        if any(part in {"build", ".gradle", "node_modules"} for part in path.parts):
            continue
        count += 1
        try:
            json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception as exc:  # noqa: BLE001 - verifier must report every malformed corpus file.
            failures.append(f"invalid JSON {path}: {exc}")
    return count


def validate_manifest(root: Path, failures: list[str]) -> int:
    manifest = root / "SOURCE_MANIFEST.sha256"
    if not manifest.is_file():
        failures.append(f"missing manifest: {manifest}")
        return 0
    listed: dict[str, str] = {}
    for number, line in enumerate(manifest.read_text(encoding="utf-8").splitlines(), 1):
        match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if not match:
            failures.append(f"malformed manifest line {manifest}:{number}")
            continue
        listed[match.group(2)] = match.group(1)
    expected = {
        path.relative_to(root).as_posix(): sha256(path)
        for path in root.rglob("*")
        if path.is_file() and path.resolve() != manifest.resolve()
    }
    if listed != expected:
        missing = sorted(set(expected) - set(listed))[:5]
        extra = sorted(set(listed) - set(expected))[:5]
        changed = sorted(key for key in set(expected) & set(listed) if expected[key] != listed[key])[:5]
        failures.append(f"manifest mismatch {root}: missing={missing} extra={extra} changed={changed}")
    return len(listed)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--client", type=Path, required=True)
    parser.add_argument("--server", type=Path, required=True)
    parser.add_argument("--skip-manifest", action="store_true")
    args = parser.parse_args()
    client = args.client.resolve()
    server = args.server.resolve()
    failures: list[str] = []

    require_text(client / "android/app/build.gradle.kts", ["versionCode = 173", "R47", CHECKPOINT], failures)
    require_text(server / "app/build.gradle.kts", ["versionCode = 198", "R75", CHECKPOINT], failures)
    require_text(server / "app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieLocalRuntime.kt", [
        "REFERENCE_INTERACTIVE_MAX_OUTPUT_TOKENS = 128",
        "REFERENCE_INTERACTIVE_MAX_CONTEXT_TOKENS = 1_536",
        "INTERACTIVE_HEARTBEAT_MS = 10_000L",
        "classificationPrompt",
        "interactive_reference_cpu_admitted",
        "channelFlow",
    ], failures)
    require_text(server / "app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLlmRuntime.kt", [
        "SwrlzMemoryStoreV1.captureUserTurn",
        "SwrlzToolPlanStoreV1.resolveResultEvidence",
        "GENERATING_HEARTBEAT",
        "memoryDecision = memoryDecision",
        "toolPlanId = toolPlanId",
    ], failures)
    require_text(server / "app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzMemoryStoreV1.kt", ["AtomicFile", "CORRECTION_STORED", "REJECTED_SECRET_LIKE"], failures)
    require_text(server / "app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzToolPlanStoreV1.kt", ["WAITING_FOR_CAPABLE_EXECUTOR", "LALM_TOOL_EXECUTOR_CAPABILITY_REQUIRED", "resultId"], failures)
    require_text(client / "android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamRuntime.kt", ["decideToolPlan", "stream_event_received", "tool_plan_decision_recorded"], failures)
    require_text(client / "android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt", ["APPROVE PLAN", "Approval is not execution or success", "first text"], failures)

    guard = "LALM_REFERENCE_CPU_INTERACTIVE_GUARD"
    for root in (client, server):
        for path in root.rglob("*.kt"):
            if guard in path.read_text(encoding="utf-8"):
                failures.append(f"retired interactive guard remains in executable/test Kotlin: {path}")

    server_contract = server / "llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2.kt"
    client_contract = client / "android/llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2.kt"
    if not server_contract.is_file() or not client_contract.is_file() or server_contract.read_bytes() != client_contract.read_bytes():
        failures.append("paired stream contract is not byte-identical")
    server_contract_test = server / "llm-contract/src/test/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2Test.kt"
    client_contract_test = client / "android/llm-contract/src/test/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2Test.kt"
    if not server_contract_test.is_file() or not client_contract_test.is_file() or server_contract_test.read_bytes() != client_contract_test.read_bytes():
        failures.append("paired stream contract test is not byte-identical")

    kotlin_paths = [
        server_contract,
        server / "app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieLocalRuntime.kt",
        server / "app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieStreamingTruthFirewall.kt",
        server / "app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLlmRuntime.kt",
        server / "app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzTruthCapsuleV1.kt",
        server / "app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzMemoryStoreV1.kt",
        server / "app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzToolPlanStoreV1.kt",
        server / "app/src/main/java/sh/swrlz/nodehost/service/SwrlzLlmProtocol.kt",
        client / "android/app/src/main/java/sh/swurlz/core/net/Api.kt",
        client / "android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamRuntime.kt",
        client / "android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamStateMachine.kt",
        client / "android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt",
    ]
    for path in kotlin_paths:
        if not path.is_file():
            failures.append(f"missing Kotlin path: {path}")
            continue
        ok, detail = kotlin_balanced(path)
        if not ok:
            failures.append(f"Kotlin structural scan failed {path}: {detail}")

    client_json = validate_json(client, failures)
    server_json = validate_json(server, failures)
    client_manifest = server_manifest = 0
    if not args.skip_manifest:
        client_manifest = validate_manifest(client, failures)
        server_manifest = validate_manifest(server, failures)

    for receipt in (client / "CHECKPOINT_RECEIPT.json", server / "CHECKPOINT_RECEIPT.json"):
        if receipt.is_file() and "PENDING_" in receipt.read_text(encoding="utf-8"):
            failures.append(f"pending receipt placeholder remains: {receipt}")

    result = {
        "checkpoint": CHECKPOINT,
        "status": "PASS" if not failures else "FAIL",
        "clientJsonFiles": client_json,
        "serverJsonFiles": server_json,
        "clientManifestEntries": client_manifest,
        "serverManifestEntries": server_manifest,
        "pairedContractSha256": sha256(server_contract) if server_contract.is_file() else "",
        "failures": failures,
        "buildBoundary": "STATIC_ONLY_NO_APK_NO_ANDROID_COMPILE",
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
