#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(sys.argv[1])
required=[
"docs/contracts/SWRLZ_FORGE_PROGRESSIVE_ARCHITECTURE_ENGINEERING_CONTRACT_V1.md",
"docs/architecture/SWRLZ_FORGE_PROJECT_CONVEYOR_AND_COUNCIL_ARCHITECTURE_V1.md",
"docs/checkpoints/INT-FORGE-079A_ADAPTIVE_FORGE_PROJECT_CONVEYOR.md",
"INT_FORGE_079A_IMPLEMENTATION_REPORT.md",
"INT_FORGE_079A_CHANGED_PATHS.txt",
]
missing=[p for p in required if not (root/p).is_file()]
kt=list(root.rglob("forge/architecture/*.kt"))
text="\n".join(p.read_text(errors="ignore") for p in kt)
markers=["ForgeConveyorRun", "ForgeSpecialistRouter", "ForgeArchitectureGenomeBuilder", "ForgeReviewEligibility", "ForgeConveyorStateStore"]
missing_markers=[m for m in markers if m not in text]
assert not missing, f"missing files: {missing}"
assert not missing_markers, f"missing markers: {missing_markers}"
assert "requireApprovalForMutation" in text
assert "mayExecuteCurrentStage" in text
print(f"PASS INT-FORGE-079A files={len(required)} kotlin={len(kt)}")
