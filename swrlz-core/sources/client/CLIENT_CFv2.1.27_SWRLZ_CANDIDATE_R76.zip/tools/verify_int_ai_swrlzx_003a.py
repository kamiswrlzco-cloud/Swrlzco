#!/usr/bin/env python3
from pathlib import Path
import json,sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
checks=[]
def ck(name,cond): checks.append((name,bool(cond)))
contract_root=(root/'swrlzx-contract') if (root/'swrlzx-contract').exists() else (root/'android/swrlzx-contract')
rt=(contract_root/'src/main/kotlin/sh/swrlz/swrlzx/SwrlzxRuntimeContractV1.kt').read_text()
eng=(root/'app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlzxNativeEngine.kt').read_text() if (root/'app').exists() else ''
road=(root/'docs/architecture/SWRLZX_MODEL_FORMAT_AND_STREAMING_ROADMAP_V1.md').read_text()
notes=(root/'ReleaseNotes.md').read_text()
receipt=json.loads((root/'CHECKPOINT_RECEIPT.json').read_text())
ck('runtime contract present','swrlzx.runtime.v1' in rt and 'SwrlzxRuntimeNegotiatorV1' in rt)
ck('operator negotiation','missingOperators' in rt and 'missingQuantizers' in rt)
ck('tokenizer contract','SwrlzxTokenizerV1' in rt)
ck('kv contract','KV_CACHE_CONTRACT' in rt)
ck('checkpoint doc',(root/'docs/checkpoints/INT-AI-SWRLZX-003A_NATIVE_LOADER_EXECUTION_GRAPH.md').is_file())
ck('operator spec',(root/'docs/contracts/SWRLZX_NATIVE_RUNTIME_OPERATOR_V1.md').is_file())
ck('graph spec',(root/'docs/contracts/SWRLZX_ARCHITECTURE_GRAPH_V1.md').is_file())
ck('tokenizer spec',(root/'docs/contracts/SWRLZX_TOKENIZER_V1.md').is_file())
ck('quant matrix',(root/'docs/contracts/SWRLZX_QUANTIZATION_COMPATIBILITY_V1.md').is_file())
ck('ADR',(root/'docs/architecture/ADR-0021_SWRLZX_NATIVE_RUNTIME_CONTRACT.md').is_file())
ck('roadmap status','SERVER R50 / CLIENT R25' in road)
ck('release notes','INT-AI-SWRLZX-003A' in notes)
ck('receipt checkpoint',receipt.get('checkpoint')=='INT-AI-SWRLZX-003A')
if eng:
  ck('native engine','class SwrlzxNativeEngine' in eng)
  ck('single delta truth','003A intentionally preserves completed-result behavior' in eng)
  ck('router',(root/'app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieEngineRouter.kt').is_file())
  vault=(root/'app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelVault.kt').read_text(); ck('vault native import','importSwrlzx' in vault and 'format = "SWRLZX"' in vault)
  local=(root/'app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieLocalRuntime.kt').read_text(); ck('runtime router','SwrlieEngineRouter()' in local)
else:
  ck('client no native executor required',True); ck('client no router required',True); ck('client shared contract',True); ck('client runtime boundary',True)
failed=[n for n,c in checks if not c]
print(f'INT-AI-SWRLZX-003A focused verifier: {len(checks)-len(failed)}/{len(checks)} PASS')
for n,c in checks: print(('PASS' if c else 'FAIL'),n)
if failed: sys.exit(1)
