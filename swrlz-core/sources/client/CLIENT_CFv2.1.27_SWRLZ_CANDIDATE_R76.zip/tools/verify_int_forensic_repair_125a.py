#!/usr/bin/env python3
from pathlib import Path
import json, sys
root=Path(__file__).resolve().parents[1]
checks=[]
def has(path,text,label):
    p=root/path; ok=p.exists() and text in p.read_text(errors='ignore'); checks.append((label,ok)); return ok
def lacks_tree(base,needle,label):
    hits=[]
    for p in (root/base).rglob('*.kt'):
        if needle in p.read_text(errors='ignore'): hits.append(str(p.relative_to(root)))
    checks.append((label,not hits));
    if hits: print('DETAIL',label,'hits=',','.join(hits[:10]))

has('android/app/build.gradle.kts','versionCode = 147','CLIENT VC147')
has('android/app/build.gradle.kts','2.1.27-forensic-repair-r21','CLIENT R21 version')
has('android/app/build.gradle.kts','INT-FORENSIC-REPAIR-125A','R21 patch label')
has('android/app/build.gradle.kts','CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R21.zip','R21 source identity')
has('android/app/src/main/java/sh/swurlz/core/github/ForgePendingTransactionStore.kt','contentSha256(context, file)','transaction fingerprint hashes file content')
has('android/app/src/main/java/sh/swurlz/core/github/ForgePendingTransactionStore.kt','.commit()','pending transaction durable commit')
has('android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt','prior.commitSha != null && prior.pathsVerified','reconciliation requires path verification')
has('android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt','TRANSACTION_MISMATCH','stale transaction marker rejected')
has('android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt','expectedShaByPath: Map<String, String> = emptyMap()','mutation SHA preconditions')
has('android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt','mustBeAbsent: Set<String> = emptySet()','mutation destination preconditions')
has('android/app/src/main/java/sh/swurlz/core/github/ForgeAutomatedBuildRunner.kt','forceRefreshIfAvailable','automated Forge one-shot credential refresh')
has('android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt','downloadArtifactToTempFile','artifact stream-to-file API')
has('android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt','downloadWorkflowLogsToTempFile','workflow-log stream-to-file API')
has('android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt','output.fd.sync()','download fsync')
has('android/app/src/main/java/sh/swurlz/core/github/ForgeArtifactExtractor.kt','val file: File','APK extraction file-backed')
has('android/app/src/main/java/sh/swurlz/core/github/ForgeArtifactExtractor.kt','MAX_EXPANDED_BYTES','APK artifact expanded-byte bound')
lacks_tree('android/app/src/main/java','GitHubForgeClient.downloadArtifact(','legacy unbounded artifact callsites removed')
lacks_tree('android/app/src/main/java','GitHubForgeClient.downloadWorkflowLogs(','legacy unbounded workflow-log callsites removed')
for rel in ['CHECKPOINT_RECEIPT.json','SWRLZ_PATCH_LINEAGE_INDEX_V1.json']:
    try:
        json.loads((root/rel).read_text()); checks.append((f'{rel} valid JSON',True))
    except Exception:
        checks.append((f'{rel} valid JSON',False))
for rel in [
'android/app/src/main/java/sh/swurlz/core/github/ForgePendingTransactionStore.kt',
'android/app/src/main/java/sh/swurlz/core/github/ForgeAutomatedBuildRunner.kt',
'android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt',
'android/app/src/main/java/sh/swurlz/core/github/ForgeArtifactExtractor.kt',
'android/app/src/main/java/sh/swurlz/core/github/ForgeAutomation.kt',
'android/app/src/main/java/sh/swurlz/core/github/ForgeBuildMonitor.kt',
'android/app/src/main/java/sh/swurlz/core/github/ForgeFailureAnalyzer.kt',
'android/app/src/main/java/sh/swurlz/core/github/ChatForgeCoordinator.kt',
'android/app/src/main/java/sh/swurlz/core/ui/screens/GitHubForgeScreen.kt',
'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt',
'android/app/src/main/java/sh/swurlz/core/update/AutonomousUpdateCoordinator.kt',
]:
    t=(root/rel).read_text(errors='ignore')
    checks.append((f'brace balance {rel}',t.count('{')==t.count('}')))
for label,ok in checks: print(('PASS' if ok else 'FAIL'),'|',label)
failed=[x for x in checks if not x[1]]
print(f'RESULT {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
