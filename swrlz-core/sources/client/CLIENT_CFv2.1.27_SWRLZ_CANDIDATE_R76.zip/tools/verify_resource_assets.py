#!/usr/bin/env python3
"""Conservative Android resource reference audit for SWRLZ source checkpoints.

Reports drawable/mipmap resources that have no direct R.* or @type/name reference.
It never deletes files because aliases, reflection, generated code, or future variants
may make a resource intentionally retained.
"""
from __future__ import annotations

import argparse
import pathlib
import re
import sys

TEXT_SUFFIXES = {".kt", ".java", ".xml", ".kts", ".properties", ".json"}
RESOURCE_TYPES = {"drawable", "mipmap", "raw", "font", "color", "anim", "animator", "xml"}

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_root", type=pathlib.Path)
    parser.add_argument("res_dir", type=pathlib.Path)
    args = parser.parse_args()

    root = args.project_root.resolve()
    res = (root / args.res_dir).resolve()
    if not res.is_dir():
        print(f"Resource directory not found: {res}", file=sys.stderr)
        return 2

    corpus_parts: list[str] = []
    for path in root.rglob("*"):
        if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES:
            try:
                corpus_parts.append(path.read_text(encoding="utf-8", errors="ignore"))
            except OSError:
                pass
    corpus = "\n".join(corpus_parts)

    groups: dict[tuple[str, str], list[pathlib.Path]] = {}
    for path in res.rglob("*"):
        if not path.is_file():
            continue
        resource_type = path.parent.name.split("-", 1)[0]
        if resource_type in RESOURCE_TYPES:
            groups.setdefault((resource_type, path.stem), []).append(path)

    candidates = []
    for (resource_type, name), paths in sorted(groups.items()):
        direct_patterns = (
            f"R.{resource_type}.{name}",
            f"@{resource_type}/{name}",
        )
        if not any(pattern in corpus for pattern in direct_patterns):
            candidates.append((resource_type, name, paths))

    if not candidates:
        print("No direct-reference candidates found.")
        return 0

    print("Potentially unreferenced resources (manual review required):")
    for resource_type, name, paths in candidates:
        print(f"- {resource_type}/{name}")
        for path in paths:
            print(f"  {path.relative_to(root)}")
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
