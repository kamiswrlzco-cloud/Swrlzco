#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, sys
from pathlib import Path

PINNED_SHA="651cd5c40e4ef24de2ff12c2b53b257d15816ddd4346e2575e6768a6ec1d8590"
PINNED_SIZE="229_315_680"


def read(p: Path) -> str:
    if not p.is_file(): return ""
    return p.read_text(encoding="utf-8", errors="replace")

def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main() -> int:
    ap=argparse.ArgumentParser(); ap.add_argument("root",type=Path); ap.add_argument("--component",choices=["SERVER","CLIENT"],required=True); ap.add_argument("--allow-descendant",action="store_true"); args=ap.parse_args()
    r=args.root.resolve(); comp=args.component
    checks=[]
    def ck(label, cond): checks.append((label,bool(cond)))

    gradle = r / ("app/build.gradle.kts" if comp=="SERVER" else "android/app/build.gradle.kts")
    g=read(gradle)
    if args.allow_descendant:
        ck(f"{comp} descendant retains 010A checkpoint history", "INT-AI-SWRLZX-010A" in read(r/"CHANGELOG.md"))
        ck(f"{comp} descendant retains 010A real-model identity", "SWRLZ-LALM-001A" in read(r/"docs/checkpoints/INT-AI-SWRLZX-010A_LALM_REAL_MODEL_BRINGUP.md"))
        ck("010A roadmap lineage retained", "INT-AI-SWRLZX-010A" in read(r/"docs/architecture/SWRLZX_MODEL_FORMAT_AND_STREAMING_ROADMAP_V1.md"))
        ck("010A exact-source boundary retained", PINNED_SHA in read(r/"docs/checkpoints/INT-AI-SWRLZX-010A_LALM_REAL_MODEL_BRINGUP.md"))
    else:
        ck(f"{comp} target versionCode", ("versionCode = 180" if comp=="SERVER" else "versionCode = 158") in g)
        ck(f"{comp} target versionName", ("2.1.27-lalm-real-model-bringup-r57" if comp=="SERVER" else "2.1.27-lalm-real-model-bringup-r32") in g)
        ck("010A patch id", "INT-AI-SWRLZX-010A" in g)
        ck("parent/source lineage identity present", ("9cfc239273299dd5f859d0266ca9894c9796e52530c3e3fc07bfb2d242074e51" in g) if comp=="SERVER" else ("CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R32.zip" in g))

    contract = r / ("swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxLalmIdentityV1.kt" if comp=="SERVER" else "android/swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxLalmIdentityV1.kt")
    c=read(contract)
    ck("LALM identity contract exists", contract.is_file())
    ck("LALM expands Local Adaptive Language Model", 'FAMILY_EXPANSION = "Local Adaptive Language Model"' in c)
    ck("canonical LALM model id", 'MODEL_ID = "swrlz-lalm-001a"' in c and 'DISPLAY_NAME = "SWRLZ-LALM-001A"' in c)
    ck("LFM retained as source family", 'SOURCE_FAMILY = "LFM"' in c)
    ck("upstream architecture retained", 'SOURCE_ARCHITECTURE = "lfm2"' in c and 'SOURCE_ARCHITECTURE_DISPLAY = "LFM2.5"' in c)
    ck("source artifact name contract", 'SOURCE_ARTIFACT_NAME = SwrlzxGgufBridgeV1.CURRENT_OPTIMIZED_GGUF_NAME' in c)
    ck("receipt forbids production promotion", "SWRLZX_010A_PRODUCTION_PROMOTION_FORBIDDEN" in c)
    ck("receipt requires deterministic conversion", "SWRLZX_LALM_CONVERSION_NOT_DETERMINISTIC" in c)

    conv=read(r/"tools/swrlzx_gguf_to_swrlzx_v1.py")
    bring=read(r/"tools/swrlzx_lalm_010a_bringup.py")
    pre=read(r/"tools/swrlzx_010a_preflight.py")
    ck("converter LALM profile", "ConversionProfile.lalm_010a" in conv and "--lalm-010a" in conv)
    ck("converter exact source filename gate", 'LALM_SOURCE_NAME = "SWRLZ-LFM-OPT-001A.gguf"' in conv and "LALM_010A_SOURCE_NAME_MISMATCH" in conv)
    ck("converter exact source size gate", "LALM_SOURCE_SIZE_BYTES = 229_315_680" in conv and "LALM_010A_SOURCE_SIZE_MISMATCH" in conv)
    ck("converter exact source SHA gate", PINNED_SHA in conv and "LALM_010A_SOURCE_SHA256_MISMATCH" in conv)
    ck("converter architecture gate", 'arch != "lfm2"' in conv and "LALM_010A_SOURCE_ARCHITECTURE_MISMATCH" in conv)
    ck("converter target override forbidden", "LALM_010A_TARGET_IDENTITY_OVERRIDE_FORBIDDEN" in conv)
    ck("bring-up runner two pass", "pass1" in bring and "pass2" in bring and "deterministicMatch" in bring)
    ck("bring-up runner promotion false", '"productionPromotionPerformed": False' in bring)
    ck("bring-up runner parity pending", '"nativeExecutionParityStatus": "PENDING"' in bring)
    ck("preflight exact production byte size", "TARGET_SIZE = 229_315_680" in pre)
    ck("preflight deliberate SHA rejection", "LALM_010A_SOURCE_SHA256_MISMATCH" in pre and '"realModelConversionClaimed": False' in pre)

    rack = r / ("model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt" if comp=="SERVER" else "android/model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt")
    rt=read(rack)
    ck("Model Rack native family LALM", 'NATIVE_MODEL_FAMILY = "LALM"' in rt)
    ck("Model Rack source family LFM", 'SOURCE_MODEL_FAMILY = "LFM"' in rt)
    ck("GGUF emergency window through 014A", 'LEGACY_GGUF_COMPATIBILITY_WINDOW = "INT-AI-SWRLZX-007A..014A"' in rt)
    ck("Model Rack exposes bring-up state", all(x in rt for x in ["lalmBringupPhase","lalmSourceReady","lalmTargetPresent","lalmTargetParityProven","lalmTargetSelected"]))

    if comp=="SERVER":
        vault=read(r/"app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelVault.kt")
        select=read(r/"app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelSelectionPolicy.kt")
        folder=read(r/"app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieAssetFolderStore.kt")
        bringup=read(r/"app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieLalmBringup.kt")
        ui=read(r/"app/src/main/java/sh/swrlz/nodehost/ui/ServerProviderMeshSettingsPanel.kt")
        ck("Model Vault canonical LALM validation", "isCanonicalLalmLineage" in vault and "SwrlzxLalmIdentityV1.isCanonicalManifest" in vault)
        ck("Model Vault spoof claims fail closed", "claimsLalmIdentity" in vault and "identity claim rejected" in vault)
        ck("selection prefers LALM without authority relaxation", 'nativeFamily.equals("LALM", true)' in select and "nativeParityProven" in select and "evolutionSelectionApproved" in select)
        ck("selection compatibility window through 014A", 'GGUF_COMPATIBILITY_WINDOW = "INT-AI-SWRLZX-007A..014A"' in select)
        ck("folder discovery prefers branded LALM", "BRANDED_FILE_NAME" in folder and "MACHINE_SAFE_FILE_NAME" in folder)
        ck("read-only bring-up state machine", all(x in bringup for x in ["SOURCE_MISSING","SOURCE_READY","TARGET_IMPORTED","TARGET_PARITY_PROVEN","TARGET_SELECTED"]))
        ck("server UI presents native LALM family", "nativeModelFamily" in ui and "LALM" in ui)
    else:
        ui=read(r/"android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt")
        ck("client UI presents native model family", "Native model family" in ui)
        ck("client UI exposes 010A source target parity", "lalmBringupPhase" in ui and "lalmTargetParityProven" in ui)
        ck("client UI retains LFM source provenance language", "LFM source provenance" in ui)

    docs=[
      "docs/contracts/SWRLZX_LALM_IDENTITY_V1.md",
      "docs/checkpoints/INT-AI-SWRLZX-010A_LALM_REAL_MODEL_BRINGUP.md",
      "docs/architecture/ADR-0029_SWRLZX_LALM_NATIVE_IDENTITY.md",
      "docs/evidence/INT-AI-SWRLZX-010A_LIVE_SOURCE_STATUS.md",
    ]
    for d in docs: ck(f"doc {d}", (r/d).is_file())
    road=read(r/"docs/architecture/SWRLZX_MODEL_FORMAT_AND_STREAMING_ROADMAP_V1.md")
    ck("roadmap phase II 010A", "Checkpoint 10" in road and "SWRLZ-LALM-001A.§wyrlzx" in road)
    ck("roadmap carries 011A..014A", all(x in road for x in ["011A","012A","013A","014A"]))
    ck("no exact target hash claimed in live-source status", "No target model hash is invented" in read(r/docs[3]) or "target SHA-256: **not generated**" in read(r/docs[3]))

    for label, ok in checks:
        print(("PASS" if ok else "FAIL") + " | " + label)
    passed=sum(ok for _,ok in checks)
    print(f"RESULT | {passed}/{len(checks)} PASS")
    return 0 if passed==len(checks) else 1

if __name__=="__main__": raise SystemExit(main())
