#!/usr/bin/env python3
from datetime import datetime, timezone
import re, statistics, json
shards=[f'conversations-{i:03d}.json' for i in range(25)]
noise=['conversation_asset_file_names.json','shared_conversations.json']
pat=re.compile(r'^conversations-\d{3,}\.json$',re.I)
accepted=[n for n in shards+noise if n.lower()=='conversations.json' or pat.match(n)]
assert len(accepted)==25 and not set(noise)&set(accepted)
# Opaque archive authority: filename hint alone is insufficient; PK magic is required.
def zipmagic(b): return len(b)>=4 and b[:2]==b'PK' and b[2:4] in (b'\x03\x04',b'\x05\x06',b'\x07\x08')
assert zipmagic(b'PK\x03\x04payload')
assert not zipmagic(b'not a zip')
# Deterministic cadence fixture: update -> user field test -> next update.
events=[
 ('assistant','2026-08-13T10:00:00Z','SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R65.zip'),
 ('user','2026-08-13T10:05:00Z','installed and test works'),
 ('assistant','2026-08-13T10:20:00Z','CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R39.zip'),
 ('user','2026-08-13T10:28:00Z','failed with error in APK Router'),
 ('assistant','2026-08-13T11:00:00Z','SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R66.zip'),
]
ts=lambda s:int(datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()*1000)
updates=[ts(t) for r,t,x in events if r=='assistant' and '_CANDIDATE_R' in x]
tests=[ts(t) for r,t,x in events if r=='user' and re.search(r'failed|error|installed|works|test|apk|router',x,re.I)]
lat=[]
for i,u in enumerate(updates):
 end=updates[i+1] if i+1<len(updates) else 2**63-1
 nxt=next((x for x in tests if u<=x<end),None)
 if nxt is not None: lat.append(nxt-u)
assert lat==[300000,480000]
print(json.dumps({'classifierRealShards':len(accepted),'opaqueZipMagic':True,'pairedCycles':len(lat),'medianUpdateToTestMs':statistics.median(lat)},sort_keys=True))
