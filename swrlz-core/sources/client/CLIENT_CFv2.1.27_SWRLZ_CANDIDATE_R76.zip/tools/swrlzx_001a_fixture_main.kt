package sh.swrlz.swrlzx

import java.io.File

fun main(args: Array<String>) {
    val sections = listOf(
        SwrlzxSectionPayloadV1(1, SwrlzxSectionTypeV1.MANIFEST, "{\"schemaVersion\":1}".toByteArray(), SwrlzxPayloadCodecV1.JSON_UTF8),
        SwrlzxSectionPayloadV1(2, SwrlzxSectionTypeV1.TENSOR_DIRECTORY, "{\"schemaVersion\":1,\"tensors\":[]}".toByteArray(), SwrlzxPayloadCodecV1.JSON_UTF8),
        SwrlzxSectionPayloadV1(3, SwrlzxSectionTypeV1.LINEAGE, "{\"schemaVersion\":1}".toByteArray(), SwrlzxPayloadCodecV1.JSON_UTF8),
    )
    val bytes = SwrlzxBinaryCodecV1.buildMetadataContainer(sections)
    val inspection = SwrlzxBinaryCodecV1.inspect(bytes)
    val temp = File.createTempFile("swrlzx-001a-", ".swrlzx")
    temp.writeBytes(bytes)
    val fileInspection = try { SwrlzxBinaryCodecV1.inspectFile(temp, 4096) } finally { temp.delete() }
    check(fileInspection.verifiedRootDigest == inspection.verifiedRootDigest)
    check(inspection.toc.size == 4)
    check(inspection.verifiedRootDigest.length == 64)

    val manifest = inspection.toc.single { it.sectionType == SwrlzxSectionTypeV1.MANIFEST }
    val tampered = bytes.copyOf()
    tampered[manifest.offset.toInt()] = (tampered[manifest.offset.toInt()].toInt() xor 1).toByte()
    check(runCatching { SwrlzxBinaryCodecV1.inspect(tampered) }.exceptionOrNull()?.message?.contains("SHA256_MISMATCH") == true)

    check(runCatching {
        SwrlzxBinaryCodecV1.buildMetadataContainer(
            listOf(
                SwrlzxSectionPayloadV1(1, SwrlzxSectionTypeV1.MANIFEST, "{}".toByteArray(), SwrlzxPayloadCodecV1.JSON_UTF8),
                SwrlzxSectionPayloadV1(2, SwrlzxSectionTypeV1.TENSOR_DIRECTORY, "{}".toByteArray(), SwrlzxPayloadCodecV1.JSON_UTF8),
                SwrlzxSectionPayloadV1(3, SwrlzxSectionTypeV1.LINEAGE, "{}".toByteArray(), SwrlzxPayloadCodecV1.JSON_UTF8, alignment = 96),
            )
        )
    }.isFailure)

    args.firstOrNull()?.let { outputPath -> File(outputPath).writeBytes(bytes) }
    println("INT-AI-SWRLZX-001A pure Kotlin contract fixture: PASS")
    println("rootDigest=${inspection.verifiedRootDigest}")
    println("containerBytes=${bytes.size}")
    println("sections=${inspection.toc.size}")
}
