#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def c(name, cond): checks.append((name,bool(cond)))
def t(rel): return (ROOT/rel).read_text(encoding="utf-8")
client=t("android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt")
gradle=t("android/app/build.gradle.kts")
ledger=t("android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt")
lineage=json.loads(t("SWRLZ_PATCH_LINEAGE_INDEX_V1.json"))
c("loopback helper is suspend", "private suspend fun loopbackConnection(context: Context): Connection" in client)
c("suspend datastore call retained", "val config = Prefs.coreNodeConfig(context)" in client)
c("only loopback call remains in suspend benchmark", client.count("loopbackConnection(") == 2 and "suspend fun runLoopbackLegacyBenchmark" in client)
c("no runBlocking shim", "runBlocking" not in client)
c("CLIENT VC137", "versionCode = 137" in gradle)
c("CLIENT R11 version", 'versionName = "2.1.27-client-build-repair-r11"' in gradle)
c("ledger R11", 'revision = "R11", versionCode = 137' in ledger and "INT-FIX-CLIENT-BUILD-112A" in ledger)
c("lineage candidate", lineage.get("candidate") == "CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R11")
c("lineage parent R10", lineage.get("parent",{}).get("candidate") == "CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R10")
c("SERVER R33 unchanged sibling", lineage.get("sibling",{}).get("candidate") == "SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R33" and lineage.get("sibling",{}).get("changed") is False)
c("R10 benchmark preserved", "LOCAL LEGACY TRANSFER BENCHMARK" in t("android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt"))
c("R10 transfer profiler verifier preserved", (ROOT/"tools/verify_int_transfer_profiler_111a_client.py").exists())
for name,ok in checks: print(("PASS" if ok else "FAIL")+" | "+name)
failed=[name for name,ok in checks if not ok]
print(f"RESULT {len(checks)-len(failed)}/{len(checks)} PASS")
sys.exit(1 if failed else 0)
