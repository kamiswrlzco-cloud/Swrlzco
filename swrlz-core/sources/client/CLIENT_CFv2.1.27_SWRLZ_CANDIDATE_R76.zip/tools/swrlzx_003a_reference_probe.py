#!/usr/bin/env python3
import json,struct,hashlib,sys
from pathlib import Path

def run(path):
    b=path.read_bytes(); assert b[:8]==b'SWRLZX\r\n'; toc_count=struct.unpack_from('<I',b,40)[0]; entries=[]
    for i in range(toc_count):
        o=128+i*128; sid,st,flags,al,off,n,logical,codec,schema=struct.unpack_from('<IIIIQQQII',b,o); entries.append((sid,st,off,n))
    sec={st:b[off:off+n] for sid,st,off,n in entries}; graph=json.loads(sec[2]); tok=json.loads(sec[3]); td=json.loads(sec[4]); data=sec[5]
    tensors={t['tensorId']:t for t in td['tensors']}
    def row(tid,r):
        t=tensors[tid]; cols=t['shape'][0]; off=t['dataOffsetBytes']+r*cols*4; return struct.unpack_from('<'+'f'*cols,data,off)
    current=tok['tokens'].index('A'); out=''; logits_trace=[]
    for _ in range(8):
        hidden=row('tok-embeddings',current); logits=[]
        for r in range(4): logits.append(sum(a*c for a,c in zip(row('lm-head',r),hidden)))
        nxt=max(range(len(logits)),key=lambda i:logits[i]); logits_trace.append(logits)
        if nxt==tok['eosTokenId']: break
        out += tok['tokens'][nxt]; current=nxt
    assert out=='BC',out
    return {'ok':True,'prompt':'A','output':out,'steps':len(logits_trace),'logits':logits_trace,'tensorAccess':'ROW_BOUNDED','wholeTensorSectionBuffered':False}
if __name__=='__main__': print(json.dumps(run(Path(sys.argv[1])),indent=2,sort_keys=True))
