#!/usr/bin/env python3
from pathlib import Path
import json, sys
root=Path(__file__).resolve().parents[1]
checks=[]
def need(path,*needles):
    text=(root/path).read_text()
    for n in needles:
        checks.append((f'{path}: {n[:72]}', n in text))
need('android/app/build.gradle.kts','versionCode = 140','versionName = "2.1.27-transfer-stream-r14"','INT-TRANSFER-STREAM-117A','SWRLZ_CANDIDATE_R14.zip')
need('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','runLoopbackStreamBenchmark','ensureTransferPresence','ClientPresenceRegistration.heartbeat','deviceBinaryChunkSupported','application/octet-stream' if False else 'ContentType.Application.OctetStream','/v1/transfers/chunks/write-binary','withContext(Dispatchers.IO)','LEGACY_BASE64_JSON')
need('android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt','LOCAL STREAM TRANSFER BENCHMARK','raw binary chunks','runLoopbackStreamBenchmark')
need('android/app/src/main/java/sh/swurlz/core/net/ServerTransferBenchmarkLogStore.kt','swyrlz-client-transfer-benchmark-v2')
lineage=json.loads((root/'SWRLZ_PATCH_LINEAGE_INDEX_V1.json').read_text())
checks += [('lineage candidate R14',lineage.get('revision')=='R14' and lineage.get('versionCode')==140),('paired SERVER R36',lineage.get('sibling',{}).get('candidate','').endswith('_R36'))]
failed=[name for name,ok in checks if not ok]
for name,ok in checks: print(('PASS' if ok else 'FAIL'),name)
print(f'RESULT {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
