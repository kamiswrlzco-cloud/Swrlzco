#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import json, re, sys, hashlib

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
name = root.name.upper()
component = 'SERVER' if name.startswith('SERVER_') else 'CLIENT' if name.startswith('CLIENT_') else None
if not component:
    print('FAIL: root name does not identify SERVER/CLIENT candidate')
    raise SystemExit(2)

checks=[]
def check(label, ok, detail=''):
    checks.append((label,bool(ok),detail))

def text(rel):
    p=root/rel
    return p.read_text(errors='replace') if p.exists() else ''

def exists(rel): return (root/rel).is_file()

if component=='SERVER':
    forge='app/src/main/java/sh/swrlz/nodehost/forge'
    settings='app/src/main/java/sh/swrlz/nodehost/ui/ForgeSettingsControls.kt'
    screen=f'{forge}/ServerForgeScreen.kt'
    gradle='app/build.gradle.kts'
    expected_vc='versionCode = 82'; expected_vn='2.1.24-forge-conveyor-lineage-candidate-r1'
else:
    forge='android/app/src/main/java/sh/swurlz/core/github'
    settings='android/app/src/main/java/sh/swurlz/core/ui/client/ForgeSettingsControls.kt'
    screen='android/app/src/main/java/sh/swurlz/core/ui/screens/GitHubForgeScreen.kt'
    gradle='android/app/build.gradle.kts'
    expected_vc='versionCode = 124'; expected_vn='2.1.26-forge-parity-chat-settings-candidate-r1'

auto=f'{forge}/ForgeAutomation.kt'
runner=f'{forge}/ForgeAutomatedBuildRunner.kt'
monitor=f'{forge}/ForgeBuildMonitor.kt'

for rel in [auto,runner,monitor,settings,screen,'INT_FORGE_054A_R2_CHECKPOINT.md','INT_FORGE_054A_R2_IMPLEMENTATION_REPORT.md','SWRLZ_CLIENT_SERVER_FEATURE_PARITY_V1.md','SWRLZ_PATCH_LINEAGE_INDEX_V1.json','INT_FORGE_054A_R2_CHANGED_PATHS.txt']:
    check(f'exists:{rel}', exists(rel))

G=text(gradle)
check('versionCode', expected_vc in G)
check('versionName', expected_vn in G)
if component=='CLIENT': check('CLIENT DocumentFile dependency', 'androidx.documentfile:documentfile:1.0.1' in G)

A=text(auto); R=text(runner); M=text(monitor); S=text(settings); U=text(screen)
for enum in ['ASK','CLIENT','SERVER','BOTH','FILES']:
    check(f'target:{enum}', enum in A)
for slot in ['ROOT','CLIENT_SOURCE','SERVER_SOURCE','APK_ARTIFACT','FAILED_BUILD_LOG','LLM_MODELS','SWRLZMODS','EVIDENCE']:
    check(f'folder:{slot}', slot in A)
for default_on in ['getBoolean(KEY_AUTO_SELECT, true)','getBoolean(KEY_AUTO_APK, true)','getBoolean(KEY_AUTO_LOGS, true)','getBoolean(KEY_REMEMBER_TARGET, true)']:
    check(f'default-on:{default_on}', default_on in A)
for token in ['versionCode','sourceZip','sha256','checksumText','manifestComponent','actualSha','latestForTarget']:
    check(f'resolver:{token}', token in A)
check('resolver no mtime ordering', 'lastModified' not in A)
check('ledger source SHA', 'sourceSha256' in A)
check('ledger artifact SHA', 'artifactSha256' in A and 'artifactSizeBytes' in A)
check('ledger RUNNING support', 'ForgeLedgerState.RUNNING' in M and 'hasState' in M)
check('artifact success auto-download', 'autoDownloadArtifact' in M and 'downloadArtifact' in M)
check('failure logs auto-download', 'autoDownloadFailureLogs' in M and 'downloadWorkflowLogs' in M)
check('no automatic package install API', 'ACTION_INSTALL_PACKAGE' not in A+R+M+S+U and 'PackageInstaller' not in A+R+M+S+U)
check('runner is user-driven API', 'BUILD LATEST requires CLIENT, SERVER, or BOTH.' in R)
check('runner requires full triples', 'expectedCount * 3' in R)
check('source guard preserved', 'inspectSourceZip' in R)
check('pair validation preserved', 'validateSourcePairs' in R)
check('credential lifecycle preserved', 'GitHubCredentialLifecycle.ensureValid' in R)
check('build watch armed', 'ForgeBuildWatchStore.add' in R)
check('screen one-button', 'BUILD LATEST VERIFIED' in U and 'ForgeAutomatedBuildRunner.run' in U)
check('settings SAF picker', 'OpenDocumentTree' in S)
check('settings folder slots', 'ForgeFolderSlot.entries' in S)
check('settings artifact toggle', 'Auto-download successful artifact' in S)
check('settings failure toggle', 'Auto-download failed workflow logs' in S)
check('settings last-target toggle', 'Remember last build target' in S)
check('release notes updated', 'INT-FORGE-054A-R2' in text('ReleaseNotes.md'))

if component=='SERVER':
    check('SERVER source transport parity', 'source_transport_mode' in S and 'sourceTransportMode = sourceTransportMode' in U)
else:
    chat_store='android/app/src/main/java/sh/swurlz/core/data/ClientChatHistoryStore.kt'
    chat_ui='android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt'
    C=text(chat_store); CU=text(chat_ui)
    check('CLIENT chat history store', exists(chat_store) and 'swrlz-client-chat-history-v1' in C)
    check('CLIENT chat thread CRUD', all(x in C for x in ['newThread','selectThread','renameThread','deleteThread','saveMessages']))
    check('CLIENT chat history UI', all(x in CU for x in ['HISTORY','NEW','ClientChatHistoryStore','CLIENT-local history']))
    check('CLIENT paired SERVER model selector in Chat', all(x in CU for x in ['modelRackSnapshot', 'onActivateChatModel', 'NO SERVER MODEL', 'ModelRackClientRuntime.activateModel']))
    check('CLIENT unique mission preserved', 'MissionBus' in CU)

# Lineage structure.
try:
    lineage=json.loads(text('SWRLZ_PATCH_LINEAGE_INDEX_V1.json'))
    check('lineage schema', lineage.get('schema')=='swrlz-patch-lineage-v1')
    check('lineage component', lineage.get('component')==component)
    cp=lineage.get('checkpoint',{})
    check('lineage checkpoint id', cp.get('id')=='INT-FORGE-054A-R2')
    check('lineage changed paths', isinstance(cp.get('changedPaths'),list) and len(cp.get('changedPaths'))>=8)
    check('lineage notClaimed APK build', 'APK build' in cp.get('notClaimed',[]))
    check('lineage historical policy', 'not revalidated' in lineage.get('historicalDocumentPolicy','').lower())
except Exception as e:
    check('lineage JSON parse', False, repr(e))

# Kotlin delimiter check on changed/new Kotlin files only, ignoring comments and strings.
changed=[x.strip() for x in text('INT_FORGE_054A_R2_CHANGED_PATHS.txt').splitlines() if x.strip().endswith('.kt')]

def strip_kotlin(src:str)->str:
    out=[]; i=0; n=len(src); state='code'; block_depth=0
    while i<n:
        if state=='code':
            if src.startswith('//',i): state='line'; out.extend('  '); i+=2; continue
            if src.startswith('/*',i): state='block'; block_depth=1; out.extend('  '); i+=2; continue
            if src.startswith('"""',i): state='triple'; out.extend('   '); i+=3; continue
            c=src[i]
            if c=='"': state='string'; out.append(' '); i+=1; continue
            if c=="'": state='char'; out.append(' '); i+=1; continue
            out.append(c); i+=1; continue
        if state=='line':
            c=src[i]; out.append('\n' if c=='\n' else ' '); i+=1
            if c=='\n': state='code'
            continue
        if state=='block':
            if src.startswith('/*',i): block_depth+=1; out.extend('  '); i+=2; continue
            if src.startswith('*/',i): block_depth-=1; out.extend('  '); i+=2; state='code' if block_depth==0 else 'block'; continue
            out.append('\n' if src[i]=='\n' else ' '); i+=1; continue
        if state=='triple':
            if src.startswith('"""',i): out.extend('   '); i+=3; state='code'; continue
            out.append('\n' if src[i]=='\n' else ' '); i+=1; continue
        if state in ('string','char'):
            quote='"' if state=='string' else "'"
            c=src[i]
            if c=='\\': out.extend('  '); i+=2; continue
            out.append('\n' if c=='\n' else ' '); i+=1
            if c==quote: state='code'
            continue
    return ''.join(out)

def balanced(src:str):
    cleaned=strip_kotlin(src); stack=[]; match={')':'(',']':'[','}':'{'}
    for idx,c in enumerate(cleaned):
        if c in '([{': stack.append((c,idx))
        elif c in ')]}':
            if not stack or stack[-1][0]!=match[c]: return False
            stack.pop()
    return not stack

for rel in changed:
    check(f'kotlin delimiters:{rel}', balanced(text(rel)))

passed=sum(1 for _,ok,_ in checks if ok)
failed=[x for x in checks if not x[1]]
print(f'INT-FORGE-054A-R2 {component}: {passed}/{len(checks)} PASS')
for label,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+f' | {label}'+(f' | {detail}' if detail else ''))
if failed: raise SystemExit(1)
