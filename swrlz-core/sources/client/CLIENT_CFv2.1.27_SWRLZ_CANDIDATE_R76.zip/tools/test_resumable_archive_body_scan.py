#!/usr/bin/env python3
from pathlib import Path
import importlib.util
import json
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("scanner", HERE / "resumable_archive_body_scan.py")
scanner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(scanner)


def convo(i: int):
    return {
        "id": f"c{i}",
        "mapping": {
            "u": {"message": {"author": {"role": "user"}, "content": {"parts": [f"hello shard {i}"]}}},
            "a": {"message": {"author": {"role": "assistant"}, "content": {"parts": [f"reply shard {i}"]}, "metadata": {"attachments": [{"id": "x"}]}}},
        },
    }


def make_archive(path: Path):
    with zipfile.ZipFile(path, "w", allowZip64=True) as z:
        for i in range(25):
            z.writestr(f"conversations-{i:03d}.json", json.dumps([convo(i)]))
        z.writestr("user.json", "{}")
        z.writestr("media/secret.jpg", b"not opened")


def main():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        archive = root / "export.zip"
        make_archive(archive)
        uninterrupted = scanner.run(archive, root / "full")
        assert uninterrupted["coverageState"] == "BODY_RECONCILED"
        assert uninterrupted["completedShards"] == 25
        assert uninterrupted["metrics"]["conversations"] == 25
        assert uninterrupted["metrics"]["nodes"] == 50
        assert uninterrupted["metrics"]["messages"] == 50
        assert uninterrupted["nonConversationEntriesNeverOpened"] == 2

        # Hostile interruption after every boundary, always resuming the same state directory.
        state = root / "resume"
        for _ in range(25):
            scanner.run(archive, state, stop_after_shards=1)
        resumed = scanner.run(archive, state)
        assert resumed["coverageState"] == "BODY_RECONCILED"
        for key in ("metrics", "receiptDigestChain", "conversationShardCount", "nonConversationEntriesNeverOpened"):
            assert resumed[key] == uninterrupted[key], (key, resumed[key], uninterrupted[key])
        print("PASS 25/25 hostile interruption/resume boundaries; merged metrics/digest chain match uninterrupted scan")

if __name__ == "__main__":
    main()
