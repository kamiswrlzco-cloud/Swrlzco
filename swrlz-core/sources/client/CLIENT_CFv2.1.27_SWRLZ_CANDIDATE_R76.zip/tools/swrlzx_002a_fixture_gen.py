#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, struct
from pathlib import Path

# GGUF metadata types
U32=4; F32=6; BOOL=7; STRING=8; ARRAY=9; U64=10

def s(value:str)->bytes:
    b=value.encode('utf-8'); return struct.pack('<Q',len(b))+b

def val(typ, value):
    if typ==U32: return struct.pack('<I',value)
    if typ==U64: return struct.pack('<Q',value)
    if typ==F32: return struct.pack('<f',value)
    if typ==BOOL: return bytes([1 if value else 0])
    if typ==STRING: return s(value)
    if typ==ARRAY:
        et, items=value
        out=struct.pack('<IQ',et,len(items))
        for x in items: out+=val(et,x)
        return out
    raise ValueError(typ)

def align(v,a): return (v+a-1)&~(a-1)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('out',type=Path); ap.add_argument('--tensor-mib',type=int,default=64); args=ap.parse_args()
    alignn=32
    tokens=[f'tok_{i:04d}' for i in range(512)]
    kv=[
      ('general.architecture',STRING,'lfm2'),
      ('general.name',STRING,'SWRLZX-002A-SYNTHETIC'),
      ('general.alignment',U32,alignn),
      ('general.quantization_version',U32,2),
      ('general.file_type',U32,2),
      ('lfm2.block_count',U32,16),
      ('lfm2.context_length',U32,32768),
      ('lfm2.embedding_length',U32,1024),
      ('tokenizer.ggml.model',STRING,'synthetic'),
      ('tokenizer.ggml.tokens',ARRAY,(STRING,tokens)),
      ('tokenizer.ggml.scores',ARRAY,(F32,[0.0 for _ in tokens])),
      ('tokenizer.chat_template',STRING,'{{ bos_token }}{{ messages }}'),
      ('general.sampling.top_k',U32,50),
      ('general.sampling.top_p',F32,0.9),
      ('general.sampling.temp',F32,0.1),
      ('swrlz.synthetic',BOOL,True),
    ]
    total=max(1,args.tensor_mib)*1024*1024
    # Three tensors with aligned spans totaling requested tensor area.
    a=align(total//4,alignn); b=align(total//2,alignn); c=total-a-b
    c=max(alignn,c); total=a+b+c
    tensors=[
      ('token_embd.weight',(1024,512),1,0,a),
      ('blk.0.attn_q.weight',(1024,1024),2,a,b),
      ('output.weight',(1024,512),2,a+b,c),
    ]
    header=b'GGUF'+struct.pack('<IQQ',3,len(tensors),len(kv))
    for key,typ,v in kv:
        header+=s(key)+struct.pack('<I',typ)+val(typ,v)
    table=b''
    for name,shape,gt,off,span in tensors:
        table+=s(name)+struct.pack('<I',len(shape))+b''.join(struct.pack('<Q',d) for d in shape)+struct.pack('<IQ',gt,off)
    data_start=align(len(header)+len(table),alignn)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    with args.out.open('wb') as f:
        f.write(header); f.write(table); f.write(b'\x00'*(data_start-f.tell()))
        # Deterministic low-memory byte patterns per tensor.
        for idx,(_,_,_,_,span) in enumerate(tensors):
            remaining=span; counter=0
            while remaining:
                seed=hashlib.sha256(f'fixture:{idx}:{counter}'.encode()).digest()
                chunk=(seed*4096)[:min(128*1024,remaining)]
                f.write(chunk); remaining-=len(chunk); counter+=1
    print(f'{args.out} bytes={args.out.stat().st_size} sha256={hashlib.sha256(args.out.read_bytes()).hexdigest()} tensorDataBytes={total}')
if __name__=='__main__': main()
