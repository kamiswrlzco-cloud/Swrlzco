#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib
from pathlib import Path

SERVER_PARENT_SHA="fa32235f2cbcbf058a2dfd1dc80623bbdc6f66decacc60dbad25a6e2dc09414a"
CLIENT_PARENT_SHA="d641b23ebb48341676469079573a5baac00136f2a474955e9511489c74ed5f62"

def read(p:Path)->str:
    return p.read_text(encoding='utf-8',errors='replace') if p.is_file() else ''
def sha(p:Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()

def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument('root',type=Path); ap.add_argument('--component',choices=['SERVER','CLIENT'],required=True); ap.add_argument('--peer',type=Path); args=ap.parse_args()
    r=args.root.resolve(); comp=args.component; checks=[]
    def ck(label,cond): checks.append((label,bool(cond)))

    gradle=r/('app/build.gradle.kts' if comp=='SERVER' else 'android/app/build.gradle.kts'); g=read(gradle)
    ck('target versionCode', ('versionCode = 181' if comp=='SERVER' else 'versionCode = 159') in g)
    ck('target versionName', ('2.1.27-lalm-native-execution-r58' if comp=='SERVER' else '2.1.27-lalm-native-execution-r33') in g)
    ck('011A checkpoint label','INT-AI-SWRLZX-011A' in g)
    ck('source archive identity', ('SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R58.zip' if comp=='SERVER' else 'CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R33.zip') in g)
    ck('parent SHA lineage', (SERVER_PARENT_SHA if comp=='SERVER' else CLIENT_PARENT_SHA) in read(r/'SWRLZ_PATCH_LINEAGE_INDEX_V1.json'))

    contract=r/('swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxLalmRuntimeV1.kt' if comp=='SERVER' else 'android/swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxLalmRuntimeV1.kt')
    c=read(contract)
    ck('LALM runtime contract exists',contract.is_file())
    for needle in ['swrlzx.lalm.runtime.v1','swrlzx.lalm.tensor_kv.v1','swrlzx.lalm.chat_template.v1','swrlzx.lalm.sampler.v1','swrlzx.quant.ggml-k.v1']:
        ck(f'contract {needle}',needle in c)
    ck('canonical 16-layer layout', 'NUM_LAYERS = 16' in c and 'CANONICAL_LAYER_TYPES' in c and c.count('LalmLayerTypeV1.CONV') >= 10 and c.count('LalmLayerTypeV1.FULL_ATTENTION') >= 6)
    ck('GQA canonical dimensions',all(x in c for x in ['HIDDEN_SIZE = 1024','NUM_ATTENTION_HEADS = 16','NUM_KEY_VALUE_HEADS = 8','HEAD_DIM = 64']))
    ck('sampling profile includes repetition penalty','DEFAULT_REPETITION_PENALTY = 1.05' in c)
    runtime=r/('swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxRuntimeContractV1.kt' if comp=='SERVER' else 'android/swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxRuntimeContractV1.kt')
    ck('SAMPLE additive operator','SAMPLE' in read(runtime))

    docs=[
      'docs/checkpoints/INT-AI-SWRLZX-011A_LALM_NATIVE_ARCHITECTURE_EXECUTION.md',
      'docs/contracts/SWRLZX_LALM_RUNTIME_V1.md',
      'docs/architecture/ADR-0030_SWRLZX_LALM_REFERENCE_RUNTIME.md',
      'docs/evidence/INT-AI-SWRLZX-011A_OPERATOR_PARITY_MATRIX.md',
      'docs/evidence/INT-AI-SWRLZX-011A_VALIDATION.md',
    ]
    for d in docs: ck(f'doc {d}',(r/d).is_file())
    roadmap=read(r/'docs/architecture/SWRLZX_MODEL_FORMAT_AND_STREAMING_ROADMAP_V1.md')
    ck('roadmap 011A status recorded','INT-AI-SWRLZX-011A' in roadmap and '011A source implementation status' in roadmap)
    ck('roadmap keeps 012A parity separate','INT-AI-SWRLZX-012A' in roadmap and 'parity' in roadmap.lower())

    if comp=='SERVER':
        mathsrc=read(r/'app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlzxLalmNativeRuntime.kt')
        toksrc=read(r/'app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlzxLalmTokenizerRuntime.kt')
        nsrc=read(r/'app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlzxNativeRuntime.kt')
        eng=read(r/'app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlzxNativeEngine.kt')
        conv=read(r/'tools/swrlzx_gguf_to_swrlzx_v1.py'); bring=read(r/'tools/swrlzx_lalm_011a_native_bringup.py')
        ck('reference LALM math/state source',all(x in mathsrc for x in ['SwrlzxLalmMathV1','SwrlzxTensorKvCacheV1','SwrlzxLfmConvStateV1','SwrlzxLalmSamplerV1']))
        ck('Q4_K/Q6_K/BF16 reference decoders',all(x in mathsrc for x in ['decodeQ4K','decodeQ6K','decodeBf16']))
        ck('GGML BPE tokenizer source','SwrlzxGgmlBpeV1' in toksrc and 'SwrlzxGpt2ByteCodecV1' in toksrc)
        for op in ['LFM_CONV','GQA_ATTENTION','ROPE','GATED_MLP','SAMPLE']:
            ck(f'native execution operator {op}',f'SwrlzxOperatorV1.{op}' in nsrc)
        ck('tensor-valued KV used by GQA','state.tensorKv.append' in nsrc and 'state.tensorKv.forEach' in nsrc)
        ck('reference tokenizer accepts GGML_BPE','SwrlzxTokenizerKindV1.GGML_BPE' in nsrc)
        ck('native engine advertises 011A contract','SwrlzxLalmRuntimeContractV1.' in eng and '011A' in eng)
        ck('converter 011A profile','ConversionProfile.lalm_011a' in conv and '--lalm-011a' in conv)
        ck('converter executable graph','LFM_CONV' in conv and 'GQA_ATTENTION' in conv and 'GATED_MLP' in conv and 'graphStatus' in conv)
        ck('converter canonical final norm','token_embd_norm.weight' in conv)
        ck('converter GGML BPE tokenizer','"kind": "GGML_BPE"' in conv)
        ck('exact bring-up runner exists',(r/'tools/swrlzx_lalm_011a_native_bringup.py').is_file())
        ck('bring-up keeps parity pending','"nativeExecutionParityStatus":"PENDING_012A"'.replace(' ','') in bring.replace(' ',''))
        ck('bring-up forbids promotion','"productionPromotionPerformed":False'.replace(' ','') in bring.replace(' ',''))
        for f in ['tools/swrlzx_011a_lalm_primitives_harness.kt','tools/swrlzx_011a_tokenizer_harness.kt','tools/swrlzx_011a_contract_harness.kt','tools/swrlzx_011a_quant_reference_test.py','tools/swrlzx_011a_graph_profile_test.py']:
            ck(f'test tool {f}',(r/f).is_file())
    else:
        ck('CLIENT does not host SERVER native LALM executor',not (r/'android/app/src/main/java/sh/swurlz/core/ai/local/SwrlzxLalmNativeRuntime.kt').exists())
        ck('CLIENT carries shared runtime contract',(r/'android/swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxLalmRuntimeV1.kt').is_file())
        ck('CLIENT carries paired converter profile','--lalm-011a' in read(r/'tools/swrlzx_gguf_to_swrlzx_v1.py'))
        ck('CLIENT carries 011A bring-up verifier',(r/'tools/swrlzx_lalm_011a_native_bringup.py').is_file())

    if args.peer:
        peer=args.peer.resolve()
        pc=peer/('android/swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxLalmRuntimeV1.kt' if comp=='SERVER' else 'swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxLalmRuntimeV1.kt')
        pr=peer/('android/swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxRuntimeContractV1.kt' if comp=='SERVER' else 'swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/SwrlzxRuntimeContractV1.kt')
        ck('peer LALM runtime contract byte-identical',pc.is_file() and sha(contract)==sha(pc))
        ck('peer runtime operator contract byte-identical',pr.is_file() and sha(runtime)==sha(pr))

    for label,ok in checks: print(('PASS' if ok else 'FAIL')+' | '+label)
    passed=sum(ok for _,ok in checks); print(f'RESULT | {passed}/{len(checks)} PASS')
    return 0 if passed==len(checks) else 1
if __name__=='__main__': raise SystemExit(main())
