import sh.swurlz.core.archive.ArchiveConversationClassifier

fun main() {
    val realShards = (0..24).map { "conversations-${it.toString().padStart(3, '0')}.json" }
    val falseCandidates = listOf("conversation_asset_file_names.json", "shared_conversations.json")
    check(realShards.count(ArchiveConversationClassifier::isMainConversationShard) == 25)
    check(falseCandidates.none(ArchiveConversationClassifier::isMainConversationShard))
    check(ArchiveConversationClassifier.isMainConversationShard("conversations.json"))
    check(!ArchiveConversationClassifier.isMainConversationShard("conversations-01.json"))
    check(ArchiveConversationClassifier.isSharedConversationReferenceFile("shared_conversations.json"))
    check(ArchiveConversationClassifier.isAssetFilenameMap("conversation_asset_file_names.json"))
    check(ArchiveConversationClassifier.isOpaqueDatCandidate("assets/file-123.dat"))
    check(ArchiveConversationClassifier.isZipMagic(byteArrayOf(0x50, 0x4b, 0x03, 0x04)))
    check(ArchiveConversationClassifier.isZipMagic(byteArrayOf(0x50, 0x4b, 0x05, 0x06)))
    check(ArchiveConversationClassifier.isZipMagic(byteArrayOf(0x50, 0x4b, 0x07, 0x08)))
    check(!ArchiveConversationClassifier.isZipMagic(byteArrayOf(0x50, 0x4b, 0x00, 0x00)))
    println("ANALYSIS_LAB_130A_CLASSIFIER_PASS realShards=25 falseCorpusEntries=2 zipMagicVariants=3")
}
