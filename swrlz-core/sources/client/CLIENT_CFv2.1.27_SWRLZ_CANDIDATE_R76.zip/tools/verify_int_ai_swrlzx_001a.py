#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys, re

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
component = sys.argv[2].upper() if len(sys.argv) > 2 else ('SERVER' if (root/'app').exists() else 'CLIENT')
if component == 'SERVER':
    contract = root / 'swrlzx-contract'
    expected_revision, expected_vc = 'R48', '171'
    expected_name = '2.1.27-swrlzx-container-r48'
    build_file = root / 'app/build.gradle.kts'
    settings = root / 'settings.gradle.kts'
else:
    contract = root / 'android/swrlzx-contract'
    expected_revision, expected_vc = 'R23', '149'
    expected_name = '2.1.27-swrlzx-container-r23'
    build_file = root / 'android/app/build.gradle.kts'
    settings = root / 'android/settings.gradle.kts'

checks = []
def check(name, ok):
    checks.append((name, bool(ok)))
    print(('PASS' if ok else 'FAIL') + ' | ' + name)

core = contract / 'src/main/kotlin/sh/swrlz/swrlzx/SwrlzxContainerV1.kt'
meta = contract / 'src/main/kotlin/sh/swrlz/swrlzx/SwrlzxMetadataContractV1.kt'
check('swrlzx-contract module exists', contract.is_dir())
check('core binary contract exists', core.is_file())
check('metadata contract exists', meta.is_file())
fixture = contract / 'src/test/resources/SWRLZX_CONTAINER_V1_MINIMAL.swrlzx'
check('minimal SWRLZX fixture exists', fixture.is_file() and fixture.stat().st_size == 980)
check('minimal SWRLZX fixture hash', fixture.is_file() and hashlib.sha256(fixture.read_bytes()).hexdigest() == 'e2b6166e82804d70b9a0404810374e5efe9d12babc5e036c4ee09b612cd42c7f')
text = core.read_text(encoding='utf-8') if core.exists() else ''
check('SWRLZX magic declared', '0x53, 0x57, 0x52, 0x4C, 0x5A, 0x58, 0x0D, 0x0A' in text)
check('128-byte header', 'HEADER_BYTES = 128' in text)
check('128-byte TOC', 'TOC_ENTRY_BYTES = 128' in text)
check('stream section reserved', 'STREAM_CONTRACT(8)' in text)
check('integrity section implemented', 'INTEGRITY(11)' in text and 'INTEGRITY_MAGIC = "SXI1"' in text)
check('root digest excludes signature/integrity', 'SwrlzxSectionTypeV1.INTEGRITY, SwrlzxSectionTypeV1.SIGNATURE' in text)
check('metadata fixture builder exists', 'buildMetadataContainer' in text)
check('bounded inspector exists', 'fun inspect(bytes: ByteArray)' in text and 'fun inspectFile(file: File' in text)
meta_text = meta.read_text(encoding='utf-8') if meta.exists() else ''
check('manifest contract exists', 'data class SwrlzxManifestV1' in meta_text)
check('lineage contract exists', 'data class SwrlzxLineageV1' in meta_text)
check('tensor descriptor contract exists', 'data class SwrlzxTensorDescriptorV1' in meta_text)
check('tensor range validation exists', 'rangeValidationErrors' in meta_text)
check('roadmap exists', (root/'docs/architecture/SWRLZX_MODEL_FORMAT_AND_STREAMING_ROADMAP_V1.md').is_file())
check('container spec exists', (root/'docs/contracts/SWRLZX_CONTAINER_V1.md').is_file())
check('checkpoint doc exists', (root/'docs/checkpoints/INT-AI-SWRLZX-001A_NATIVE_CONTAINER_FOUNDATION.md').is_file())
check('evidence doc exists', (root/'docs/evidence/INT-AI-SWRLZX-001A_STATIC_VERIFICATION.md').is_file())
settings_text = settings.read_text(encoding='utf-8') if settings.exists() else ''
check('module included in settings', 'include(":swrlzx-contract")' in settings_text)
build_text = build_file.read_text(encoding='utf-8') if build_file.exists() else ''
check('app compiles against contract module', 'implementation(project(":swrlzx-contract"))' in build_text)
check('candidate revision updated', expected_revision in build_text)
check('candidate versionCode updated', f'versionCode = {expected_vc}' in build_text)
check('candidate versionName updated', expected_name in build_text)
check('checkpoint identity updated', 'INT-AI-SWRLZX-001A' in build_text)
check('patch notes updated', 'INT-AI-SWRLZX-001A' in (root/'CHANGELOG.md').read_text(encoding='utf-8')[:6000])
check('release notes updated', 'INT-AI-SWRLZX-001A' in (root/'ReleaseNotes.md').read_text(encoding='utf-8')[:6000])
check('receipt updated', 'INT-AI-SWRLZX-001A' in (root/'CHECKPOINT_RECEIPT.json').read_text(encoding='utf-8'))
check('lineage updated', 'INT-AI-SWRLZX-001A' in (root/'SWRLZ_PATCH_LINEAGE_INDEX_V1.json').read_text(encoding='utf-8'))

failed = [name for name, ok in checks if not ok]
print(f'RESULT | {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    print('FAILED | ' + ', '.join(failed))
    raise SystemExit(1)
