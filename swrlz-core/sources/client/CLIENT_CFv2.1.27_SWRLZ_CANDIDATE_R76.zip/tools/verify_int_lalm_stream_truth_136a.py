#!/usr/bin/env python3
"""Focused source/static verifier for INT-LALM-STREAM-TRUTH-136A."""

from pathlib import Path
import re
import sys


def require(condition: bool, label: str, failures: list[str]) -> None:
    if condition:
        print(f"PASS {label}")
    else:
        print(f"FAIL {label}")
        failures.append(label)


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    client = root / "android" / "app"
    is_client = client.is_dir()
    contract = (
        root / "android" / "llm-contract" / "src/main/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2.kt"
        if is_client
        else root / "llm-contract" / "src/main/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2.kt"
    )
    failures: list[str] = []
    wire = contract.read_text(encoding="utf-8")
    require("const val PROTOCOL_VERSION = 2" in wire, "protocol remains 2", failures)
    require("const val SCHEMA_VERSION = 1" in wire, "schema remains 1", failures)
    require("STATUS" not in re.search(r"enum class SwrlzLlmStreamEventTypeV2 \{(.*?)\}", wire, re.S).group(1), "no competing STATUS event enum", failures)
    for field in (
        "threadId", "ingress", "phase", "truthCapsuleId", "normalizedRequestSha256",
        "firstTokenLatencyMs", "retrievalLatencyMs", "truthResolutionLatencyMs",
        "prefillLatencyMs", "generationLatencyMs", "toolDecision",
    ):
        require(f"val {field}" in wire, f"additive field {field}", failures)

    stream_doc = (root / "docs/contracts/SWRLZ_LLM_STREAM_WIRE_V2.md").read_text(encoding="utf-8")
    require("INT-LALM-STREAM-TRUTH-136A" in stream_doc, "wire documentation synchronized", failures)
    require((root / "docs/architecture/SWRLZ_LALM_TRUTH_CAPSULE_PIPELINE_V1.md").is_file(), "architecture document present", failures)
    require((root / "docs/checkpoints/INT-LALM-STREAM-TRUTH-136A.md").is_file(), "checkpoint document present", failures)

    if is_client:
        state = (client / "src/main/java/sh/swurlz/core/ai/ClientLlmStreamStateMachine.kt").read_text(encoding="utf-8")
        runtime = (client / "src/main/java/sh/swurlz/core/ai/ClientLlmStreamRuntime.kt").read_text(encoding="utf-8")
        ui = (client / "src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt").read_text(encoding="utf-8")
        history = (client / "src/main/java/sh/swurlz/core/data/ClientChatHistoryStore.kt").read_text(encoding="utf-8")
        gradle = (client / "build.gradle.kts").read_text(encoding="utf-8")
        require("bubbleText()" not in state and "bubbleText()" not in ui, "status cannot become assistant bubble text", failures)
        require("if (live.text.isNotBlank())" in ui, "assistant bubble requires committed text", failures)
        require("responseTotalMs" in history and "firstTextMs" in history, "terminal timing persists", failures)
        require('"prompt" to request.prompt' not in runtime and '"prompt" to normalized.prompt' not in runtime, "stream logs omit raw prompt", failures)
        require('versionCode = 172' in gradle and 'CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R46.zip' in gradle, "CLIENT identity R46/VC172", failures)
    else:
        runtime = (root / "app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLlmRuntime.kt").read_text(encoding="utf-8")
        local = (root / "app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieLocalRuntime.kt").read_text(encoding="utf-8")
        ui = (root / "app/src/main/java/sh/swrlz/nodehost/ui/ServerChatScreen.kt").read_text(encoding="utf-8")
        capsule = (root / "app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzTruthCapsuleV1.kt").read_text(encoding="utf-8")
        gradle = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
        guard = local.split('if (interactiveRecord != null && engine.isReferenceCpuRuntime()) {', 2)[-1].split('return@flow', 1)[0]
        require("InferenceEvent.Failed" in guard and "CommittedDelta" not in guard, "reference guard is telemetry, not assistant prose", failures)
        require("truthCapsule.inferenceDirective()" in runtime, "Truth Capsule precedes LALM presentation", failures)
        require(runtime.index("truthCapsule.inferenceDirective()") < runtime.index("PRESENTATION PROFILE"), "profile applied after truth semantics", failures)
        require("asProviderStreamResponse" in runtime and "asProviderStreamResponse" in ui, "SERVER Chat reuses V2 Flow", failures)
        require("semanticRequestSha256" in capsule and "responseDirective" not in capsule.split("private fun semanticRequestSha256", 1)[1].split("private fun tokens", 1)[0], "profile excluded from capsule semantic identity", failures)
        require('versionCode = 197' in gradle and 'quotedBuildConfig("R74")' in gradle, "SERVER identity R74/VC197", failures)

    if failures:
        print(f"RESULT FAIL {len(failures)}")
        return 1
    print("RESULT PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
