#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
MOD_PATH = ROOT / "swrlzx_gguf_to_swrlzx_v1.py"
spec = importlib.util.spec_from_file_location("swrlzx_conv", MOD_PATH)
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
assert spec.loader
spec.loader.exec_module(mod)

md = {
    "general.architecture": "lfm2",
    "lfm2.block_count": 16,
    "lfm2.embedding_length": 1024,
    "lfm2.attention.head_count": 16,
    "lfm2.attention.head_count_kv": list(mod.LALM_011A_LAYER_KV_HEADS),
    "lfm2.feed_forward_length": 4608,
    "lfm2.shortconv.l_cache": 3,
    "lfm2.rope.freq_base": 1_000_000.0,
    "lfm2.attention.layer_norm_rms_epsilon": 1e-5,
    "lfm2.context_length": 128_000,
    "tokenizer.ggml.model": "gpt2",
    "tokenizer.ggml.pre": "lfm2",
    "tokenizer.ggml.tokens": [f"tok{i}" for i in range(65_536)],
    "tokenizer.ggml.merges": ["a b", "b c"],
    "tokenizer.ggml.bos_token_id": 1,
    "tokenizer.ggml.eos_token_id": 7,
    "tokenizer.ggml.padding_token_id": 0,
    "tokenizer.ggml.add_bos_token": True,
    "tokenizer.ggml.add_eos_token": False,
    "tokenizer.chat_template": "fixture",
}

names = ["token_embd.weight", "token_embd_norm.weight"]
for layer, kv in enumerate(mod.LALM_011A_LAYER_KV_HEADS):
    names += [
        f"blk.{layer}.attn_norm.weight", f"blk.{layer}.ffn_norm.weight",
        f"blk.{layer}.ffn_gate.weight", f"blk.{layer}.ffn_up.weight", f"blk.{layer}.ffn_down.weight",
    ]
    if kv == 0:
        names += [f"blk.{layer}.shortconv.in_proj.weight", f"blk.{layer}.shortconv.conv.weight", f"blk.{layer}.shortconv.out_proj.weight"]
    else:
        names += [
            f"blk.{layer}.attn_q.weight", f"blk.{layer}.attn_k.weight", f"blk.{layer}.attn_v.weight",
            f"blk.{layer}.attn_output.weight", f"blk.{layer}.attn_q_norm.weight", f"blk.{layer}.attn_k_norm.weight",
        ]
assert len(names) == 148, len(names)
tensors = [{"name": n, "tensorId": f"tensor-{i:06d}"} for i, n in enumerate(names)]
index = mod.GgufIndex(3, 148, len(md), md, {}, tuple(), 32, 4096, 100_000, "00"*32)
arch, tok, quant, gen = mod._lalm_011a_runtime_metadata(index, tensors, {"f32": 55, "q4_k": 87, "q6_k": 6})

checks = {
    "graph_executable": arch["graphStatus"] == "EXECUTABLE",
    "graph_nodes_100": len(arch["nodes"]) == 100,
    "conv_layers_10": sum(n["op"] == "LFM_CONV" for n in arch["nodes"]) == 10,
    "attention_layers_6": sum(n["op"] == "GQA_ATTENTION" for n in arch["nodes"]) == 6,
    "context_clamped_32768": arch["contextLimitTokens"] == 32768,
    "tokenizer_ggml_bpe": tok["kind"] == "GGML_BPE" and len(tok["tokens"]) == 65_536,
    "special_tokens": (tok["bosTokenId"], tok["eosTokenId"], tok["padTokenId"]) == (1,7,0),
    "quantizers_exact": quant["requiredQuantizers"] == ["f32","q4_k","q6_k"],
    "sampler_profile": gen["topK"] == 50 and gen["repetitionPenalty"] == 1.05,
    "tied_lm_head": next(n for n in arch["nodes"] if n["id"] == "lm_head")["tensorIds"] == ["tensor-000000"],
}
for name, ok in checks.items():
    if not ok: raise AssertionError(name)
    print(f"PASS {name}")
print(f"RESULT {len(checks)}/{len(checks)} PASS")
