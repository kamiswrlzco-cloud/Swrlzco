#!/usr/bin/env python3
"""SWRLZ resumable GPT-export conversation-body scanner.

F0 repair for E-01/E-04/E-05:
- opens only allowlisted conversation shard entries from a ZIP/ZIP64 export;
- writes one immutable per-shard receipt after each completed shard;
- resumes by validating the archive central-directory fingerprint and receipt hashes;
- exposes INDEX_READY/BODY_PARTIAL/BODY_RECONCILED coverage states;
- never opens non-conversation/media payload entries.

The parser incrementally decodes top-level JSON arrays so a shard does not need to be loaded wholly
into memory. It intentionally reports lexical/body metrics as body-derived evidence, separate from
central-directory/index facts.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import time
import zipfile
from typing import Any, Dict, Iterable, Iterator, Tuple

SHARD_RE = re.compile(r"^conversations-\d{3,}\.json$", re.I)
LEGACY_SHARD = "conversations.json"
SCHEMA = "swrlz-resumable-archive-body-scan-v1"
RECEIPT_SCHEMA = "swrlz-archive-shard-receipt-v1"
CHUNK_CHARS = 1 << 20


def is_conversation_shard(name: str) -> bool:
    base = name.replace("\\", "/").rsplit("/", 1)[-1]
    return base.lower() == LEGACY_SHARD or bool(SHARD_RE.fullmatch(base))


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def atomic_write_json(path: Path, value: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    payload = (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()
    with open(temp, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp, path)
    try:
        dir_fd = os.open(str(path.parent), os.O_DIRECTORY)
    except (AttributeError, OSError):
        return
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)


def archive_fingerprint(zf: zipfile.ZipFile, archive_path: Path) -> Tuple[str, list[zipfile.ZipInfo], int]:
    infos = zf.infolist()
    shards = sorted((i for i in infos if not i.is_dir() and is_conversation_shard(i.filename)), key=lambda i: i.filename)
    material = {
        "archiveSize": archive_path.stat().st_size,
        "conversationShards": [
            {
                "name": i.filename,
                "crc32": f"{i.CRC:08x}",
                "uncompressed": i.file_size,
                "compressed": i.compress_size,
            }
            for i in shards
        ],
    }
    return sha256_bytes(json.dumps(material, sort_keys=True, separators=(",", ":")).encode()), shards, len(infos)


def iter_top_level_array(stream: io.TextIOBase) -> Iterator[Any]:
    decoder = json.JSONDecoder()
    buffer = ""
    pos = 0
    started = False
    ended = False
    eof = False

    while not ended:
        if not eof and (len(buffer) - pos < CHUNK_CHARS // 4):
            extra = stream.read(CHUNK_CHARS)
            if extra == "":
                eof = True
            if pos:
                buffer = buffer[pos:] + extra
                pos = 0
            else:
                buffer += extra
        while pos < len(buffer) and buffer[pos].isspace():
            pos += 1
        if not started:
            if pos >= len(buffer):
                if eof:
                    raise ValueError("empty JSON shard")
                continue
            if buffer[pos] != "[":
                raise ValueError("conversation shard top-level must be a JSON array")
            started = True
            pos += 1
            continue
        while pos < len(buffer) and (buffer[pos].isspace() or buffer[pos] == ","):
            pos += 1
        if pos < len(buffer) and buffer[pos] == "]":
            ended = True
            pos += 1
            break
        if pos >= len(buffer):
            if eof:
                raise ValueError("unterminated JSON array")
            continue
        try:
            value, next_pos = decoder.raw_decode(buffer, pos)
        except json.JSONDecodeError as exc:
            if eof:
                raise
            # Value may straddle a chunk boundary. Preserve undecoded tail and fetch more.
            buffer = buffer[pos:]
            pos = 0
            extra = stream.read(CHUNK_CHARS)
            if extra == "":
                eof = True
            buffer += extra
            continue
        yield value
        pos = next_pos
    if not ended:
        raise ValueError("unterminated JSON array")


def message_text(message: Dict[str, Any]) -> str:
    content = message.get("content")
    if not isinstance(content, dict):
        return ""
    parts = content.get("parts")
    if not isinstance(parts, list):
        return ""
    text_parts = [p for p in parts if isinstance(p, str)]
    return "\n".join(text_parts)


def attachment_refs_in(value: Any) -> int:
    count = 0
    stack = [value]
    seen = 0
    while stack and seen < 200_000:
        current = stack.pop()
        seen += 1
        if isinstance(current, dict):
            for key, child in current.items():
                lower = str(key).lower()
                if lower in {"asset_pointer", "file_id", "attachment_id"} and isinstance(child, str) and child:
                    count += 1
                elif lower == "attachments" and isinstance(child, list):
                    count += len(child)
                stack.append(child)
        elif isinstance(current, list):
            stack.extend(current)
    return count


def words(text: str) -> int:
    return len(re.findall(r"[A-Za-z0-9§_+'-]+", text))


def scan_conversation(conversation: Any, totals: Dict[str, int]) -> None:
    if not isinstance(conversation, dict):
        totals["nonObjectTopLevelItems"] += 1
        return
    totals["conversations"] += 1
    mapping = conversation.get("mapping")
    if not isinstance(mapping, dict):
        totals["conversationsWithoutMapping"] += 1
        return
    totals["nodes"] += len(mapping)
    for node in mapping.values():
        if not isinstance(node, dict):
            continue
        message = node.get("message")
        if not isinstance(message, dict):
            continue
        totals["messages"] += 1
        role = (((message.get("author") or {}).get("role")) if isinstance(message.get("author"), dict) else "") or "unknown"
        role = str(role).lower()
        text = message_text(message)
        chars = len(text)
        word_count = words(text)
        totals["textChars"] += chars
        totals["words"] += word_count
        totals[f"role_{role}_messages"] = totals.get(f"role_{role}_messages", 0) + 1
        totals[f"role_{role}_chars"] = totals.get(f"role_{role}_chars", 0) + chars
        totals[f"role_{role}_words"] = totals.get(f"role_{role}_words", 0) + word_count
        totals["attachmentReferences"] += attachment_refs_in(message)


def empty_totals() -> Dict[str, int]:
    return {
        "conversations": 0,
        "conversationsWithoutMapping": 0,
        "nonObjectTopLevelItems": 0,
        "nodes": 0,
        "messages": 0,
        "textChars": 0,
        "words": 0,
        "attachmentReferences": 0,
    }


def scan_shard(zf: zipfile.ZipFile, info: zipfile.ZipInfo) -> Dict[str, Any]:
    totals = empty_totals()
    digest = hashlib.sha256()
    started = time.time()

    class HashingReader(io.RawIOBase):
        def __init__(self, raw):
            self.raw = raw
        def readable(self):
            return True
        def readinto(self, b):
            data = self.raw.read(len(b))
            if not data:
                return 0
            digest.update(data)
            b[:len(data)] = data
            return len(data)
        def close(self):
            try:
                self.raw.close()
            finally:
                super().close()

    with zf.open(info, "r") as raw:
        hashed = io.BufferedReader(HashingReader(raw), buffer_size=1 << 20)
        with io.TextIOWrapper(hashed, encoding="utf-8", errors="strict", newline="") as text:
            for conversation in iter_top_level_array(text):
                scan_conversation(conversation, totals)
    return {
        "schema": RECEIPT_SCHEMA,
        "entry": info.filename,
        "crc32": f"{info.CRC:08x}",
        "compressedBytes": info.compress_size,
        "uncompressedBytes": info.file_size,
        "contentSha256": digest.hexdigest(),
        "metrics": totals,
        "elapsedMs": int((time.time() - started) * 1000),
        "completed": True,
    }


def receipt_name(index: int, info: zipfile.ZipInfo) -> str:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", info.filename.rsplit("/", 1)[-1])
    return f"{index:04d}-{safe}.receipt.json"


def validate_receipt(receipt: Dict[str, Any], info: zipfile.ZipInfo) -> bool:
    return (
        receipt.get("schema") == RECEIPT_SCHEMA
        and receipt.get("entry") == info.filename
        and receipt.get("crc32") == f"{info.CRC:08x}"
        and int(receipt.get("uncompressedBytes", -1)) == info.file_size
        and bool(receipt.get("completed"))
        and isinstance(receipt.get("contentSha256"), str)
        and len(receipt.get("contentSha256", "")) == 64
    )


def merge_metrics(receipts: Iterable[Dict[str, Any]]) -> Dict[str, int]:
    merged: Dict[str, int] = {}
    for receipt in receipts:
        for key, value in (receipt.get("metrics") or {}).items():
            if isinstance(value, int):
                merged[key] = merged.get(key, 0) + value
    return merged


def run(archive: Path, state_dir: Path, stop_after_shards: int | None = None) -> Dict[str, Any]:
    state_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "r", allowZip64=True) as zf:
        fingerprint, shards, entry_count = archive_fingerprint(zf, archive)
        if not shards:
            raise RuntimeError("No allowlisted conversation shards found")
        manifest_path = state_dir / "scan-manifest.json"
        if manifest_path.exists():
            existing = json.loads(manifest_path.read_text())
            if existing.get("archiveFingerprint") != fingerprint:
                raise RuntimeError("ARCHIVE_IDENTITY_CHANGED: existing receipts belong to a different central-directory fingerprint")
        manifest = {
            "schema": SCHEMA,
            "archiveFingerprint": fingerprint,
            "archiveSizeBytes": archive.stat().st_size,
            "zipEntryCount": entry_count,
            "conversationShardCount": len(shards),
            "conversationShards": [i.filename for i in shards],
            "nonConversationEntriesNeverOpened": entry_count - len(shards),
            "coverageState": "INDEX_READY",
        }
        atomic_write_json(manifest_path, manifest)

        receipts: list[Dict[str, Any]] = []
        completed_this_run = 0
        for index, info in enumerate(shards):
            path = state_dir / "receipts" / receipt_name(index, info)
            receipt = None
            if path.exists():
                try:
                    candidate = json.loads(path.read_text())
                    if validate_receipt(candidate, info):
                        receipt = candidate
                except Exception:
                    receipt = None
            if receipt is None:
                receipt = scan_shard(zf, info)
                receipt["archiveFingerprint"] = fingerprint
                receipt["shardOrdinal"] = index
                receipt["receiptDigest"] = sha256_bytes(json.dumps(receipt, sort_keys=True, separators=(",", ":")).encode())
                atomic_write_json(path, receipt)
                completed_this_run += 1
            receipts.append(receipt)
            merged = merge_metrics(receipts)
            state = "BODY_RECONCILED" if len(receipts) == len(shards) else "BODY_PARTIAL"
            checkpoint = {
                **manifest,
                "coverageState": state,
                "completedShards": len(receipts),
                "remainingShards": len(shards) - len(receipts),
                "highWaterShardOrdinal": index,
                "metrics": merged,
                "receiptDigestChain": sha256_bytes("\n".join(r["receiptDigest"] for r in receipts).encode()),
                "updatedAtEpochMs": int(time.time() * 1000),
            }
            atomic_write_json(state_dir / "body-scan-state.json", checkpoint)
            if stop_after_shards is not None and completed_this_run >= stop_after_shards:
                return checkpoint
        return json.loads((state_dir / "body-scan-state.json").read_text())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("--state-dir", type=Path, required=True)
    parser.add_argument("--stop-after-shards", type=int)
    args = parser.parse_args()
    result = run(args.archive, args.state_dir, args.stop_after_shards)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
