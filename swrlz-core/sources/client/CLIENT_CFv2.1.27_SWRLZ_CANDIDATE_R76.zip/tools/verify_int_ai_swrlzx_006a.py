#!/usr/bin/env python3
from pathlib import Path
import json, sys, hashlib
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
is_server=(root/'app/src/main/java/sh/swrlz/nodehost/service/NodeRuntime.kt').is_file()
checks=[]
def ck(name,ok): checks.append((name,bool(ok)))
def txt(p): return (root/p).read_text(errors='replace') if (root/p).is_file() else ''
receipt=json.loads(txt('CHECKPOINT_RECEIPT.json'))
road=txt('docs/architecture/SWRLZX_MODEL_FORMAT_AND_STREAMING_ROADMAP_V1.md')
ck('checkpoint receipt',receipt.get('checkpoint')=='INT-AI-SWRLZX-006A')
ck('roadmap status','implemented as paired CLIENT R28 / SERVER R53 source foundation' in road)
for p in ['docs/checkpoints/INT-AI-SWRLZX-006A_CLIENT_STREAMING_READER_LIVE_CHAT.md','docs/contracts/SWRLZX_CLIENT_STREAM_STATE_MACHINE_V1.md','docs/architecture/ADR-0024_SWRLZX_CLIENT_APP_SCOPED_STREAM_RENDERING.md','docs/evidence/INT-AI-SWRLZX-006A_STATIC_VERIFICATION.md','INT-AI-SWRLZX-006A_IMPLEMENTATION_REPORT.md','INT-AI-SWRLZX-006A_VALIDATION.md']:
    ck('doc '+p,(root/p).is_file())
for p in ['INT-AI-SWRLZX-006A_STATE_MACHINE_COMPILE.txt','INT-AI-SWRLZX-006A_STATE_MACHINE_RUN.txt','INT-AI-SWRLZX-006A_RUNTIME_COMPILE.txt','INT-AI-SWRLZX-006A_RUNTIME_BEHAVIOR.txt','INT-AI-SWRLZX-006A_E2E_LATENCY_TRACE.txt','INT-AI-SWRLZX-006A_COMPOSE_RECOMPOSITION.txt','INT-AI-SWRLZX-006A_ROTATION_BACKGROUND_RECONNECT.txt','INT-AI-SWRLZX-006A_ANDROID_COMPILE_ATTEMPT.txt']:
    ck('evidence '+p,(root/p).is_file())
ck('state machine fixture','stateMachine=PASS' in txt('INT-AI-SWRLZX-006A_STATE_MACHINE_RUN.txt'))
ck('runtime fixture','runtimeBehavior=PASS cases=7' in txt('INT-AI-SWRLZX-006A_RUNTIME_BEHAVIOR.txt'))
ck('loopback trace','loopbackTrace=PASS' in txt('INT-AI-SWRLZX-006A_E2E_LATENCY_TRACE.txt') and "finalText='Streaming works live.'" in txt('INT-AI-SWRLZX-006A_E2E_LATENCY_TRACE.txt'))
ck('cadence evidence','eligibleCadencePublishes=313' in txt('INT-AI-SWRLZX-006A_COMPOSE_RECOMPOSITION.txt') and 'cadenceReductionPct=96.87' in txt('INT-AI-SWRLZX-006A_COMPOSE_RECOMPOSITION.txt'))
ck('android boundary','UnknownHostException: services.gradle.org' in txt('INT-AI-SWRLZX-006A_ANDROID_COMPILE_ATTEMPT.txt'))
if is_server:
    gradle=txt('app/build.gradle.kts')
    catalog=txt('app/src/main/java/sh/swrlz/nodehost/runtime/ServerPatchCatalog.kt')
    node=txt('app/src/main/java/sh/swrlz/nodehost/service/NodeRuntime.kt')
    proto=txt('app/src/main/java/sh/swrlz/nodehost/service/SwrlzLlmProtocol.kt')
    writer=txt('app/src/main/java/sh/swrlz/nodehost/service/SwrlzChunkedNdjsonWriter.kt')
    registry=txt('app/src/main/java/sh/swrlz/nodehost/service/SwrlzLlmStreamRegistry.kt')
    contract=txt('llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2.kt')
    ck('server version','versionCode = 176' in gradle and 'swrlzx-client-stream-r53' in gradle and 'INT-AI-SWRLZX-006A' in gradle)
    ck('server patch catalog','revision = "R53"' in catalog and 'INT-AI-SWRLZX-006A' in catalog)
    ck('preserve v2 route','isStreamingChatRoute' in node and 'writeSwrlzLlmStream' in node and '/ai/swrlz-llm/v2' in contract)
    ck('preserve chunked writer','Transfer-Encoding' in writer and 'chunked' in writer and 'output.flush()' in writer)
    ck('preserve bounded registry','MAX_ACTIVE_STREAMS' in registry and '@Synchronized' in registry)
    ck('preserve v1 route','SwrlzLlmProtocolV1.CHAT ->' in proto)
else:
    gradle=txt('android/app/build.gradle.kts')
    api=txt('android/app/src/main/java/sh/swurlz/core/net/Api.kt')
    state=txt('android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamStateMachine.kt')
    runtime=txt('android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamRuntime.kt')
    hist=txt('android/app/src/main/java/sh/swurlz/core/data/ClientChatHistoryStore.kt')
    shell=txt('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt')
    ck('client version','versionCode = 154' in gradle and 'swrlzx-client-stream-r28' in gradle and 'INT-AI-SWRLZX-006A' in gradle)
    # success path must be channel based; error/cancel/V1 may still use bodyAsText.
    start=api.find('fun swrlzLlmChatStream'); end=api.find('suspend fun swrlzLlmCancelStream',start)
    stream=api[start:end] if start>=0 and end>start else ''
    success=stream[stream.find('if (!response.status.isSuccess())'):] if stream else ''
    ck('byte channel stream','bodyAsChannel()' in stream and 'readUTF8Line' in stream and 'application/x-ndjson' in stream)
    ck('bounded event parsing','MAX_EVENT_BYTES + 1' in stream and 'toByteArray(Charsets.UTF_8).size' in stream)
    ck('wire identity checks',all(x in stream for x in ['PROTOCOL_VERSION','SCHEMA_VERSION','CONTRACT_ID','event.identity.requestId != request.requestId']))
    ck('legacy v1 retained','suspend fun swrlzLlmChat(' in api and 'SwrlzLlmProtocolV1.CHAT' in api)
    ck('exact sequence gate','event.seq == expectedSeq' in state and 'expectedSeq++' in state)
    ck('reset transient state','SwrlzLlmStreamEventTypeV2.RESET' in state and 'text = ""' in state)
    ck('routed identity stable','SWRLZ_LLM_STREAM_ROUTE_IDENTITY_DRIFT' in state)
    ck('app scoped owner','CoroutineScope(SupervisorJob() + Dispatchers.IO)' in runtime)
    ck('32ms conflated microbatch','Channel<RenderUpdate>(Channel.CONFLATED)' in runtime and 'ClientLlmRenderCadence(32L)' in runtime)
    ck('pre-delta retry only','attempt == 0 && !committedTextSeen' in runtime and 'retryRequestId' in runtime)
    ck('explicit compatibility fallback','failure.statusCode in setOf(404, 405, 501)' in runtime and 'runLegacyFallback' in runtime)
    ck('cancel route','swrlzLlmCancelStream' in runtime and 'CANCEL_ACK_TIMEOUT_MS' in runtime)
    ck('completed-only persistence','persistCompleted' in runtime and 'appendAssistantMessage' in runtime)
    ck('idempotent history','sourceRequestId' in hist and 'appendAssistantMessage' in hist)
    ck('live transient bubble','ClientLlmStreamingBubble' in shell and 'liveStream' in shell and 'ClientLlmStreamRuntime.states' in shell)
    ck('stop control','ClientLlmStreamRuntime.cancel' in shell or 'onCancelLiveStream' in shell)
failed=[n for n,o in checks if not o]
print(f"INT-AI-SWRLZX-006A focused verifier: {len(checks)-len(failed)}/{len(checks)} PASS")
for n,o in checks: print(('PASS' if o else 'FAIL')+'\t'+n)
if failed: sys.exit(1)
