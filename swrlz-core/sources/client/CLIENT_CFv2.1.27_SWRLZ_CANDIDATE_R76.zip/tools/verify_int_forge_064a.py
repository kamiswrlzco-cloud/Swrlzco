#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re, sys
from pathlib import Path

root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
server=(root/'app/src/main/java/sh/swrlz/nodehost/forge').is_dir()
component='SERVER' if server else 'CLIENT'
forge=root/('app/src/main/java/sh/swrlz/nodehost/forge' if server else 'android/app/src/main/java/sh/swurlz/core/github')
screen=root/('app/src/main/java/sh/swrlz/nodehost/forge/ServerForgeScreen.kt' if server else 'android/app/src/main/java/sh/swurlz/core/ui/screens/GitHubForgeScreen.kt')
build=root/('app/build.gradle.kts' if server else 'android/app/build.gradle.kts')
expected_vc=87 if server else 125
expected_vn='2.1.26-forge-metadata-bundle-candidate-r4' if server else '2.1.26-forge-metadata-bundle-candidate-r2'
checks=[]
def check(name,condition):
 checks.append((name,bool(condition)))
def text(p): return p.read_text(encoding='utf-8')

for name in ['ForgeMetadataBundle.kt','ForgeEvidenceBundle.kt','GitHubForgeClient.kt','ForgeAutomation.kt']:
 check(f'{name} exists',(forge/name).is_file())
check('Forge screen exists',screen.is_file())
b=text(build); check('versionCode',f'versionCode = {expected_vc}' in b); check('versionName',expected_vn in b)
m=text(forge/'ForgeMetadataBundle.kt')
for token in ['_METADATA.zip','exactly checksum + manifest','MAX_BUNDLE_BYTES','Manifest revision','versionCode > 0']:
 check('metadata '+token,token in m)
e=text(forge/'ForgeEvidenceBundle.kt')
for token in ['repositoryFiles','repo-patches/','swrlz-core/tools/ci/resolve_swrlz_source.py','expectedCheckpoint','MAX_TOTAL_DOCUMENT_BYTES']:
 check('evidence '+token,token in e)
g=text(forge/'GitHubForgeClient.kt')
for token in ['chunked-git-blobs-v2','metadata_bundle_path','metadata_bundle_sha256','validateSourcePairs','Do not mix metadata bundle and loose companions','SOURCE_PLUS_METADATA_BUNDLE_OR_COMPLETE_LEGACY_SIDECARS','ForgeEvidenceBundle.inspect(cacheFile, archive.displayName)']:
 check('client '+token,token in g)
check('metadata not generic source','!canonical.endsWith("_METADATA.ZIP")' in g)
check('evidence not generic source','!canonical.endsWith("_EVIDENCE.ZIP")' in g)
s=text(screen)
for token in ['previouslyStagedNames','knownNames','checksumReady && manifestReady','unresolvedEvidence','METADATA BUNDLE READY']:
 check('screen '+token,token in s)
check('picker does not generate partial checksum','generateChecksumReceipt(context, file)' not in s)
a=text(forge/'ForgeAutomation.kt')
for token in ['metadataBundle: DocumentFile?','metadataBundle == null && (checksum == null || manifest == null)','ForgeMetadataBundle.inspect','maxWithOrNull']:
 check('automation '+token,token in a)
resolver=root/'tools/ci/resolve_swrlz_source.py'; verifier=root/'tools/ci/verify_swrlz_package_pair.py'
check('resolver exists',resolver.is_file()); check('verifier exists',verifier.is_file())
r=text(resolver)
for token in ['chunked-git-blobs-v2','direct-bundle','direct-legacy','canonical_stem','uploaded_filename','metadata_bundle_sha256','Manifest revision']:
 check('resolver '+token,token in r)
v=text(verifier)
for token in ['--metadata','metadata-bundle-v1','manifest revision mismatch','legacy-sidecars']:
 check('verifier '+token,token in v)
for rel in ['docs/contracts/SWRLZ_SOURCE_METADATA_BUNDLE_CONTRACT_V1.md','docs/checkpoints/INT_FORGE_064A_CHECKPOINT.md','reports/INT_FORGE_064A_IMPLEMENTATION_REPORT.md','INT_FORGE_064A_CHANGED_PATHS.txt']:
 check(rel,(root/rel).is_file())
receipt=json.loads(text(root/'CHECKPOINT_RECEIPT.json'))
check('checkpoint id',receipt.get('checkpoint')=='INT-FORGE-064A')
check('component',receipt.get('component')==component)
check('no build',receipt.get('apk_build') is False and receipt.get('workflow_dispatch') is False)
if component=='CLIENT': check('client lineage disclosure',receipt.get('lineage_quality')=='FUNCTIONAL_DESCENDANT_REBASE_NOT_BYTE_EXACT_DIRECT_PARENT')
else: check('server direct parent',receipt.get('lineage_quality')=='BYTE_EXACT_DIRECT_PARENT')
failed=[name for name,ok in checks if not ok]
for name,ok in checks: print(('PASS' if ok else 'FAIL')+' '+name)
print(f'RESULT {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
 print('FAILED: '+', '.join(failed),file=sys.stderr); raise SystemExit(1)
