#!/usr/bin/env python3
from pathlib import Path
import sys
r=Path(__file__).resolve().parents[1]
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def txt(rel): return (r/rel).read_text()
build=txt('android/app/build.gradle.kts')
llm=txt('android/llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmContract.kt')
provider=txt('android/provider-contract/src/main/kotlin/sh/swrlz/provider/ProviderContract.kt')
rack=txt('android/model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt')
ui=txt('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt')
ledger=txt('android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt')
ck('CLIENT R40 / VC166 identity','versionCode = 166' in build and '2.1.27-lalm-messaging-r40' in build)
ck('131A patch/source identity','INT-AI-LALM-MESSAGING-131A' in build and 'CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R40.zip' in build)
ck('Native LALM contract fields','NATIVE_LALM' in llm and 'nativeLalmEnabled' in llm and 'nativeLalmReady' in llm)
ck('Legacy LLM contract fields retired',all(x not in llm for x in ['LEGACY_GGUF_ADAPTER','legacyGgufAdapterEnabled','legacyAdapterReady']))
ck('@lalm local tag supported','lalm|swrlie' in provider and '"lalm" in tags' in provider)
ck('GGUF compatibility field marked retired','RETIRED_RUNTIME_INT-AI-LALM-MESSAGING-131A_PROVENANCE_ONLY' in rack)
ck('Client UI says GGUF non-executable','GGUF is conversion/provenance-only and is not executable' in ui)
ck('Client UI provenance runtime role','"PROVENANCE_ONLY"' in ui)
ck('R40 ledger recorded','revision = "R40"' in ledger and 'SERVER R66' in ledger)
failed=[n for n,v in checks if not v]
for n,v in checks: print(('PASS' if v else 'FAIL')+' | '+n)
print(f'{sum(v for _,v in checks)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
