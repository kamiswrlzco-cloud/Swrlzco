#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
is_client=(ROOT/'android/app/build.gradle.kts').is_file()
checks=[]
def check(name, cond):
    checks.append((name,bool(cond)))
    print(('PASS' if cond else 'FAIL')+' | '+name)

def text(rel): return (ROOT/rel).read_text(errors='replace')
if is_client:
    build=text('android/app/build.gradle.kts')
    ui=text('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt')
    contract=text('android/model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt')
    check('CLIENT R29 versionCode 155', 'versionCode = 155' in build)
    check('CLIENT R29 versionName', '2.1.27-swrlzx-native-default-r29' in build)
    check('007A patch label', 'INT-AI-SWRLZX-007A' in build)
    check('Model Rack exposes format', 'val format: String = "UNKNOWN"' in contract)
    check('Model Rack exposes runtimeRole', 'val runtimeRole: String = "STAGED_ONLY"' in contract)
    check('SWRLZX preferred runtime wire field', 'preferredRuntimeFormat' in contract and 'DEFAULT_RUNTIME_FORMAT = "SWRLZX"' in contract)
    check('bounded GGUF window wire field', 'legacyGgufCompatibilityWindow' in contract and '007A..009A' in contract)
    check('UI calls SWRLZX native/default', 'Native SWRLZX selection' in ui and 'native SERVER SWRLZX models' in ui)
    check('UI renders actual format', '${model.format}' in ui)
    check('UI renders runtime role', 'model.runtimeRole' in ui)
    check('UI labels legacy emergency', 'Legacy emergency compatibility' in ui)
    check('old GGUF-primary category removed', 'Select SERVER GGUFs' not in ui and 'SERVER GGUF selection' not in ui)
else:
    build=text('app/build.gradle.kts')
    policy=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelSelectionPolicy.kt')
    vault=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelVault.kt')
    runtime=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieLocalRuntime.kt')
    rack=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelRack.kt')
    contract=text('model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt')
    check('SERVER R54 versionCode 177', 'versionCode = 177' in build)
    check('SERVER R54 versionName', '2.1.27-swrlzx-native-default-r54' in build)
    check('007A patch id', 'INT-AI-SWRLZX-007A' in build)
    check('native format is SWRLZX', 'NATIVE_FORMAT = "SWRLZX"' in policy)
    check('GGUF bounded 007A..009A', 'GGUF_COMPATIBILITY_WINDOW = "INT-AI-SWRLZX-007A..009A"' in policy)
    check('direct source hash lineage required', 'it.sourceSha256?.equals(selected.sha256, true) == true' in policy)
    check('native auto selection requires READY', 'it.compatibility == "READY"' in policy)
    check('native auto selection requires explicit parity evidence', 'it.nativeParityProven' in policy and 'PARITY_STATUS_KEY' in policy)
    check('unproven no-proven selection outcome', 'NO_PROVEN_RUNTIME_MODEL' in policy)
    check('vault reconciles native runtime preference', 'reconcileNativeRuntimePreference' in vault)
    check('vault uses sourceSha256 optimized lineage', 'record.model.metadata["sourceSha256"]' in vault)
    check('startup applies runtime preference', 'reconcileNativeRuntimePreference(context)' in runtime)
    check('runtime logs native migration', 'swrlzx_default_runtime_migration' in runtime)
    check('rack exposes actual format', 'format = record.model.format.uppercase()' in rack)
    check('rack exposes runtime role', 'runtimeRole = SwrlieModelSelectionPolicy.runtimeRole' in rack)
    check('rack labels legacy emergency', 'Legacy GGUF emergency runtime' in rack)
    check('wire default is SWRLZX', 'DEFAULT_RUNTIME_FORMAT = "SWRLZX"' in contract)
for rel in [
    'docs/checkpoints/INT-AI-SWRLZX-007A_GGUF_ACTIVE_RUNTIME_DEPRECATION.md',
    'docs/architecture/ADR-0025_SWRLZX_NATIVE_DEFAULT_GGUF_BOUNDED_COMPATIBILITY.md',
    'docs/evidence/INT-AI-SWRLZX-007A_REGISTRY_MIGRATION_TESTS.md',
    'docs/evidence/INT-AI-SWRLZX-007A_SIDE_BY_SIDE_ACCEPTANCE_MATRIX.md',
    'docs/evidence/INT-AI-SWRLZX-007A_ROLLBACK_DRILL.md',
    'INT-AI-SWRLZX-007A_VALIDATION.md',
]: check('doc '+rel, (ROOT/rel).is_file())
failed=[n for n,ok in checks if not ok]
print(f'RESULT | {len(checks)-len(failed)}/{len(checks)} PASS')
if failed: sys.exit(1)
