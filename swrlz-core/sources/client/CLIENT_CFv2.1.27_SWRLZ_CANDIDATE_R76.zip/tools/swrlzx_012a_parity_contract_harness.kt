package sh.swrlz.swrlzx

private fun ck(name: String, cond: Boolean) {
    check(cond) { "FAIL | $name" }
    println("PASS | $name")
}

fun main() {
    val ref = SwrlzxLalmParityReceiptV1(
        sourceGgufSha256 = SwrlzxLalmParityV1.SOURCE_GGUF_SHA256,
        targetLalmSha256 = SwrlzxLalmParityV1.TARGET_LALM_SHA256,
        targetLalmRootDigestSha256 = SwrlzxLalmParityV1.TARGET_LALM_ROOT_SHA256,
        tensorCount = SwrlzxLalmParityV1.TENSOR_COUNT,
        tensorDataSha256 = SwrlzxLalmParityV1.TENSOR_DATA_SHA256,
        tensorDataByteIdentical = true,
        tokenizerParityProven = true,
        graphParityProven = true,
        quantizerParityProven = true,
        referenceParityStatus = SwrlzxLalmParityV1.REFERENCE_PROVEN,
        referenceEvidenceId = "INT-AI-SWRLZX-012A_REFERENCE_PARITY.json",
        referenceMaxAbsLogitDiff = 0.0,
        legacyEngineParityStatus = SwrlzxLalmParityV1.LEGACY_PENDING,
    )
    ck("reference receipt validates", ref.validationErrors().isEmpty())
    ck("reference parity proven", ref.referenceParityProven())
    ck("reference receipt cannot prove production parity", !ref.productionParityProven())
    ck("canonical target binding", SwrlzxLalmParityV1.canonicalTargetMatches(ref.targetLalmSha256, ref.targetLalmRootDigestSha256))

    val forgedTarget = ref.copy(targetLalmSha256 = "0".repeat(64))
    ck("wrong target fails closed", forgedTarget.validationErrors().contains("SWRLZX_LALM_PARITY_TARGET_SHA_MISMATCH"))

    val fakeLegacy = ref.copy(legacyEngineParityStatus = SwrlzxLalmParityV1.LEGACY_PROVEN)
    ck("legacy proven without evidence fails", fakeLegacy.validationErrors().any { it.contains("LEGACY_EVIDENCE") })

    val production = ref.copy(
        legacyEngineParityStatus = SwrlzxLalmParityV1.LEGACY_PROVEN,
        legacyEngineEvidenceId = "012A-device-run-001",
        legacyRuntimeFingerprint = "llama-android-0.1.1-arm64",
        legacyDeviceFingerprint = "android-device-build-fingerprint-001",
        legacyPromptSuiteSha256 = "1".repeat(64),
    )
    ck("complete legacy evidence validates", production.validationErrors().isEmpty())
    ck("complete evidence can prove production parity", production.productionParityProven())

    val promoted = production.copy(productionPromotionPerformed = true)
    ck("012A promotion receipt rejected", promoted.validationErrors().contains("SWRLZX_012A_PRODUCTION_PROMOTION_FORBIDDEN"))
    println("RESULT | 9/9 PASS")
}
