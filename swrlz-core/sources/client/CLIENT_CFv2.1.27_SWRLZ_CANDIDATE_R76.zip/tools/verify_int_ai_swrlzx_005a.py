#!/usr/bin/env python3
from pathlib import Path
import json, re, sys, hashlib
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
is_server=(root/'app/src/main/java/sh/swrlz/nodehost/service/NodeRuntime.kt').is_file()
checks=[]
def ck(name,ok): checks.append((name,bool(ok)))
def txt(p): return (root/p).read_text(errors='replace') if (root/p).is_file() else ''
receipt=json.loads(txt('CHECKPOINT_RECEIPT.json'))
road=txt('docs/architecture/SWRLZX_MODEL_FORMAT_AND_STREAMING_ROADMAP_V1.md')
contract_path='llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2.kt' if is_server else 'android/llm-contract/src/main/kotlin/sh/swrlz/llm/SwrlzLlmStreamContractV2.kt'
contract=txt(contract_path)
ck('checkpoint receipt',receipt.get('checkpoint')=='INT-AI-SWRLZX-005A')
ck('roadmap status','implemented as paired SERVER R52 / CLIENT R27 transport foundation' in road)
for p in ['docs/checkpoints/INT-AI-SWRLZX-005A_SERVER_STREAMING_PROTOCOL.md','docs/contracts/SWRLZ_LLM_STREAM_WIRE_V2.md','docs/architecture/ADR-0023_SWRLZX_SERVER_CHUNKED_NDJSON_STREAMING.md','docs/governance/INT-AI-SWRLZX-005A_STREAM_AUTHORITY_ANALYSIS.md','INT-AI-SWRLZX-005A_IMPLEMENTATION_REPORT.md','INT-AI-SWRLZX-005A_VALIDATION.md']:
    ck('doc '+p,(root/p).is_file())
ck('v2 route','/ai/swrlz-llm/v2' in contract and 'CHAT_STREAM' in contract)
ck('event vocabulary',all(x in contract for x in ['STARTED','ROUTE','DELTA','RESET','COMPLETED','CANCELLED','FAILED']))
ck('finite transport bounds',all(x in contract for x in ['BACKPRESSURE_BUFFER_EVENTS = 8','MAX_ACTIVE_STREAMS = 4','IDLE_TIMEOUT_MS = 30_000L','MAX_STREAM_LIFETIME_MS = 120_000L','MAX_OUTPUT_TOKENS = 2_048']))
ck('safe request id','isValidRequestId' in contract and "it == '-'" in contract)
ck('contract evidence','contract=PASS' in txt('INT-AI-SWRLZX-005A_LLM_CONTRACT_COMPILE.txt'))
ck('android boundary','UnknownHostException: services.gradle.org' in txt('INT-AI-SWRLZX-005A_ANDROID_COMPILE_ATTEMPT.txt'))
if is_server:
    gradle=txt('app/build.gradle.kts'); ck('server version','versionCode = 175' in gradle and 'swrlzx-server-stream-r52' in gradle)
    writer=txt('app/src/main/java/sh/swrlz/nodehost/service/SwrlzChunkedNdjsonWriter.kt')
    node=txt('app/src/main/java/sh/swrlz/nodehost/service/NodeRuntime.kt')
    proto=txt('app/src/main/java/sh/swrlz/nodehost/service/SwrlzLlmProtocol.kt')
    rt=txt('app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzLlmRuntime.kt')
    reg=txt('app/src/main/java/sh/swrlz/nodehost/service/SwrlzLlmStreamRegistry.kt')
    ck('chunked writer','Transfer-Encoding' in writer and 'chunked' in writer and 'Content-Length' in writer and 'output.flush()' in writer)
    ck('node stream branch','isStreamingChatRoute' in node and 'writeSwrlzLlmStream' in node)
    ck('bounded channel','Channel<SwrlzLlmStreamEventV2>(SwrlzLlmStreamProtocolV2.BACKPRESSURE_BUFFER_EVENTS)' in node)
    ck('idle timeout','withTimeoutOrNull(SwrlzLlmStreamProtocolV2.IDLE_TIMEOUT_MS)' in node)
    ck('lifetime timeout','withTimeout(SwrlzLlmStreamProtocolV2.MAX_STREAM_LIFETIME_MS)' in node)
    ck('disconnect cancellation','catch (_: java.io.IOException)' in node and 'admission.session.cancel()' in node)
    ck('same auth path','openStream' in proto and 'authorize(request, repository, localConnection)' in proto)
    ck('owner cancel gate','requesterNodeId == session.ownerNodeId' in reg)
    ck('synchronized capacity','@Synchronized' in reg and 'MAX_ACTIVE_STREAMS' in reg)
    ck('committed only','is InferenceEvent.CommittedDelta' in rt and 'SwrlzLlmStreamEventTypeV2.DELTA' in rt)
    # ensure draft branches do not emit network text directly
    ck('draft not serialized','is InferenceEvent.DraftDelta -> Unit' in rt and 'is InferenceEvent.TokenGenerated -> Unit' in rt)
    ck('legacy v1 chat preserved','SwrlzLlmProtocolV1.CHAT ->' in proto and 'SwrlzLlmRuntime.chat(context, body' in proto)
    ck('writer evidence','writer=PASS' in txt('INT-AI-SWRLZX-005A_CHUNKED_WRITER.txt'))
    ck('real tcp evidence','loopback=PASS' in txt('INT-AI-SWRLZX-005A_LOOPBACK_STREAM.txt') and 'firstDeltaBeforeCompletion=true' in txt('INT-AI-SWRLZX-005A_LOOPBACK_STREAM.txt'))
    ck('registry evidence','registry=PASS' in txt('INT-AI-SWRLZX-005A_REGISTRY.txt') and 'maxActive=4' in txt('INT-AI-SWRLZX-005A_REGISTRY.txt'))
    ck('backpressure evidence','policy=PASS' in txt('INT-AI-SWRLZX-005A_BACKPRESSURE_TIMEOUT.txt'))
    ck('disconnect evidence','disconnect=PASS' in txt('INT-AI-SWRLZX-005A_DISCONNECT.txt'))
else:
    gradle=txt('android/app/build.gradle.kts'); ck('client version','versionCode = 153' in gradle and 'swrlzx-server-stream-r27' in gradle)
    api=txt('android/app/src/main/java/sh/swurlz/core/net/Api.kt')
    ck('legacy client response retained','bodyAsText()' in api)
    ck('006A boundary','bodyAsChannel()' not in api)
    ck('paired loopback evidence','loopback=PASS' in txt('INT-AI-SWRLZX-005A_LOOPBACK_STREAM.txt'))
failed=[n for n,o in checks if not o]
print(f"INT-AI-SWRLZX-005A focused verifier: {len(checks)-len(failed)}/{len(checks)} PASS")
for n,o in checks: print(('PASS' if o else 'FAIL')+'\t'+n)
if failed: sys.exit(1)
