#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def has(path, needle, label):
    text=(ROOT/path).read_text(errors='replace')
    checks.append((label, needle in text))
def test(cond,label): checks.append((label,bool(cond)))
classifier=(ROOT/'android/app/src/main/java/sh/swurlz/core/archive/ArchiveConversationClassifier.kt').read_text()
engine=(ROOT/'android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt').read_text()
index=(ROOT/'android/app/src/main/java/sh/swurlz/core/archive/ArchiveIndexStore.kt').read_text()
detector=(ROOT/'android/app/src/main/java/sh/swurlz/core/archive/ArchiveOpaqueArchiveDetector.kt').read_text()
analytics=(ROOT/'android/app/src/main/java/sh/swurlz/core/archive/ArchiveDevelopmentAnalytics.kt').read_text()
build=(ROOT/'android/app/build.gradle.kts').read_text()
ledger=(ROOT/'android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt').read_text()

test('^conversations-\\\\d{3,}\\\\.json$' in classifier,'exact conversation shard regex')
test('conversations.json' in classifier,'legacy conversations.json accepted')
test('shared_conversations.json' in classifier,'shared conversations separate classifier')
test('conversation_asset_file_names.json' in classifier,'asset filename map explicitly classified')
test('schemaValid = id.isNotBlank() && mappingSeen' in engine,'conversation schema validity requires id + mapping')
test('parsed.messageCount <= 0' in engine,'zero-message objects excluded')
test('sharedConversationReferenceCount' in engine and 'sharedConversationReferences' in engine,'shared refs surfaced separately')
test('ArchiveConversationClassifier.isMainConversationShard(path)' in index,'persistent index uses exact classifier')
test('isZipMagic' in detector and 'updateEntryType' in detector,'opaque dat mount requires content signature path')
test('assetFilenameMapCandidates' in detector and 'isArchiveMimeType' in detector,'original name/mime map consulted as hint')
test('ArchiveConversationClassifier.isZipMagic(ArchiveOpaqueArchiveDetector.readPrefix(zip, 4))' in engine,'nested virtual dat entries sniff ZIP magic')
test('DEVELOPMENT_ANALYTICS' in engine,'development analytics Archive VFS operation')
for metric in ['updateDeliveryEvents','fieldTestReports','updateToTestLatencyMs','updateToUpdateDurationMs','messagesBetweenBuilds','testsBetweenBuilds','cyclesPerDay','longestActiveSessionMs','cumulativeActiveEngineeringMs','serverRevisionVelocity','clientRevisionVelocity']:
    test(metric in analytics,f'analytics metric {metric}')
test('versionCode = 165' in build and 'analysis-lab-r39' in build,'CLIENT R39 / VC165 identity')
test('INT-ANALYSIS-LAB-130A' in ledger,'CLIENT patch ledger updated')
test((ROOT/'INT-ANALYSIS-LAB-130A_IMPLEMENTATION_REPORT.md').exists(),'implementation report present')
test((ROOT/'SWRLZ_ANALYSIS_LAB_EXPORT_ANALYTICS_V1.md').exists(),'analytics contract present')
failed=[label for label,ok in checks if not ok]
for label,ok in checks: print(('PASS' if ok else 'FAIL'), label)
print(f'{len(checks)-len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
