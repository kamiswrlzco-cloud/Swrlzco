#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name, cond): checks.append((name,bool(cond)))
def txt(rel): return (ROOT/rel).read_text(encoding='utf-8')

gradle=txt('android/app/build.gradle.kts')
client=txt('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt')
log=txt('android/app/src/main/java/sh/swurlz/core/net/ServerTransferBenchmarkLogStore.kt')
ui=txt('android/app/src/main/java/sh/swurlz/core/ui/screens/ServerTransferScreen.kt')
ledger=txt('android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt')
check('client VC136','versionCode = 136' in gradle)
check('client R10 name','2.1.27-transfer-profiler-r10' in gradle)
check('loopback address','http://127.0.0.1:8787' in client)
check('same legacy start','/forge/uploads/start' in client)
check('same legacy chunk','/forge/uploads/$uploadId/chunk' in client)
check('same legacy commit','/forge/uploads/$uploadId/commit' in client)
check('client byte diagnostics','clientChunkDiagnostics' in client and 'base64CharacterCount' in client and 'decodedByteCount' in client)
check('benchmark summary','averageRoundTripMs' in client and 'averageServerMs' in client and 'averageOutsideServerMs' in client)
check('client log schema','swyrlz-client-transfer-benchmark-v1' in log)
check('UI benchmark panel','LOCAL LEGACY TRANSFER BENCHMARK' in ui)
check('UI sizes','1 MB' in ui and '10 MB' in ui and '50 MB' in ui and '100 MB STRESS' in ui)
check('UI chunks','4 KiB' in ui and '64 KiB' in ui and '256 KiB' in ui)
check('UI view/save','VIEW CLIENT LOG' in ui and 'SAVE CLIENT LOG' in ui)
check('ledger R10','revision = "R10", versionCode = 136' in ledger)
failed=[n for n,ok in checks if not ok]
for n,ok in checks: print(('PASS' if ok else 'FAIL')+' | '+n)
print(f'RESULT {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
