#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, subprocess, tempfile, sys

root=Path(__file__).resolve().parents[1] if Path(__file__).resolve().parent.name=='tools' else Path.cwd()
component='SERVER' if (root/'app').is_dir() and (root/'swrlzx-contract').is_dir() else 'CLIENT'
contract=(root/'swrlzx-contract' if component=='SERVER' else root/'android/swrlzx-contract')
checks=[]
def ck(name,cond): checks.append((name,bool(cond)))
ck('002A checkpoint doc', (root/'docs/checkpoints/INT-AI-SWRLZX-002A_GGUF_TO_SWRLZX_CONVERSION_BRIDGE.md').is_file())
ck('mapping spec', (root/'docs/contracts/SWRLZX_GGUF_CONVERSION_MAPPING_V1.md').is_file())
ck('source fixture identity', (root/'docs/evidence/INT-AI-SWRLZX-002A_SOURCE_FIXTURE_IDENTITY.md').is_file())
ck('shared conversion contract', (contract/'src/main/kotlin/sh/swrlz/swrlzx/SwrlzxConversionContractV1.kt').is_file())
ck('shared conversion test', (contract/'src/test/kotlin/sh/swrlz/swrlzx/SwrlzxConversionContractV1Test.kt').is_file())
converter=root/'tools/swrlzx_gguf_to_swrlzx_v1.py'; fixture=root/'tools/swrlzx_002a_fixture_gen.py'
ck('converter present', converter.is_file()); ck('fixture generator present', fixture.is_file())
contract_text=(contract/'src/main/kotlin/sh/swrlz/swrlzx/SwrlzxConversionContractV1.kt').read_text(encoding='utf-8')
ck('optimized model filename exact', 'SWRLZ-LFM-OPT-001A.gguf' in contract_text)
ck('optimized model bytes exact', '229_315_680L' in contract_text)
ck('optimized model sha exact', '651cd5c40e4ef24de2ff12c2b53b257d15816ddd4346e2575e6768a6ec1d8590' in contract_text)
ck('002A forbids runtime switch', 'SWRLZX_002A_RUNTIME_SWITCH_FORBIDDEN' in contract_text)
notes=(root/'CHANGELOG.md').read_text(encoding='utf-8')[:10000]
ck('patch notes updated', 'INT-AI-SWRLZX-002A' in notes)
receipt=json.loads((root/'CHECKPOINT_RECEIPT.json').read_text())
ck('receipt checkpoint', receipt.get('checkpoint')=='INT-AI-SWRLZX-002A')
account=json.loads((root/'PATCH_ACCOUNTING_WORKFLOW_STATUS.json').read_text())
ck('accounting preserves active gguf', account.get('activeGgufRuntimeChanged') is False)
ck('accounting does not overclaim optimized conversion', account.get('exactOptimizedFixtureConverted') is False)
# Real deterministic converter execution on a controlled 8 MiB GGUF.
with tempfile.TemporaryDirectory() as td:
    td=Path(td); g=td/'fixture.gguf'; a=td/'a.swrlzx'; b=td/'b.swrlzx'; ra=td/'a.json'
    p=subprocess.run([sys.executable,str(fixture),str(g),'--tensor-mib','8'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    ck('synthetic gguf generation',p.returncode==0 and g.is_file())
    p1=subprocess.run([sys.executable,str(converter),str(g),str(a),'--model-id','swrlzx-002a-verifier','--display-name','SWRLZX 002A Verifier','--report',str(ra)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    p2=subprocess.run([sys.executable,str(converter),str(g),str(b),'--model-id','swrlzx-002a-verifier','--display-name','SWRLZX 002A Verifier'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    ck('conversion 1',p1.returncode==0 and a.is_file())
    ck('conversion 2',p2.returncode==0 and b.is_file())
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    ck('deterministic output hash',a.is_file() and b.is_file() and sha(a)==sha(b))
    report=json.loads(ra.read_text()) if ra.is_file() else {}
    ck('tensor data byte identical',report.get('tensorDataByteIdentical') is True)
    ck('runtime switch false in report',report.get('runtimeSwitchPerformed') is False)
    ck('source sha propagated',report.get('source',{}).get('sha256')==sha(g) if g.is_file() else False)
failed=[n for n,v in checks if not v]
for n,v in checks: print(('PASS' if v else 'FAIL')+' · '+n)
print(f'SUMMARY {len(checks)-len(failed)}/{len(checks)} PASS')
if failed: print('FAILED: '+', '.join(failed)); raise SystemExit(1)
