#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def need(path,*terms):
    text=(ROOT/path).read_text()
    for term in terms: checks.append((f'{path}: {term[:64]}', term in text))
    return text
build=need('android/app/build.gradle.kts','versionCode = 142','2.1.27-trust-rebind-r16','INT-TRUST-REINSTALL-119A','SWRLZ_CANDIDATE_R16.zip')
pres=need('android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt','registerAttempt(context, baseUrl, proofRecovery = false)','PROOF_REBIND_REQUIRED','registerAttempt(context, baseUrl, proofRecovery = true)','put("proofRecovery", proofRecovery)','persistRegistrationResult','canonicalNodeId')
checks.append(('recovery only follows explicit mismatch', pres.index('needsProofRecovery') < pres.index('registerAttempt(context, baseUrl, proofRecovery = true)')))
transfer=need('android/app/src/main/java/sh/swurlz/core/net/ServerForgeTransferClient.kt','proofRecoveryRequired','PROOF_REBIND_REQUIRED','ClientPresenceRegistration.register','Recovered ${if (proofRecoveryRequired) "proof binding" else "registration"}','BUSY heartbeat accepted')
checks.append(('binary path preserved','postBinaryChunkWithRetry' in transfer and 'LEGACY_BASE64_JSON' in transfer))
ledger=need('android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt','revision = "R16"','INT-TRUST-REINSTALL-119A','proofRecovery','PROOF_REBIND_REQUIRED')
receipt=json.loads((ROOT/'CHECKPOINT_RECEIPT.json').read_text()); checks += [('receipt identity',receipt['revision']=='R16' and receipt['versionCode']==142 and receipt['checkpoint']=='INT-TRUST-REINSTALL-119A'),('receipt parent R15',receipt.get('parent',{}).get('name','').endswith('_R15.zip')),('receipt sibling R38',receipt.get('sibling',{}).get('name','').endswith('_R38.zip'))]
lineage=json.loads((ROOT/'SWRLZ_PATCH_LINEAGE_INDEX_V1.json').read_text()); checks += [('lineage identity',lineage['revision']=='R16' and lineage['versionCode']==142),('parent R15',lineage.get('parent',{}).get('candidate','').endswith('_R15')),('sibling R38',lineage.get('sibling',{}).get('candidate','').endswith('_R38'))]
notes=(ROOT/'ReleaseNotes.md').read_text(); checks.append(('patch notes current',notes.startswith('# CLIENT CFv2.1.27 R16 / VC142')))
for name,ok in checks: print(('PASS' if ok else 'FAIL'),'|',name)
failed=[n for n,o in checks if not o]
print(f'SUMMARY {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
