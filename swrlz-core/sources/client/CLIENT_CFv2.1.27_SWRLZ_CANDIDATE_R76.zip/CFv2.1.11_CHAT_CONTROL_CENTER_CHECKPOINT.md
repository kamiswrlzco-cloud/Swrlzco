# CLIENT CFv2.1.11 — Chat Control Center + Response-Top Follow

Checkpoint: `INT-CHAT-037A`
Mode: source-only implementation
Parent: `CLIENT CFv2.1.10`

## Delivered

- Expanded **Settings → Chat & Commands** into a nested control center.
- Added **Conversation Flow**, **Personality & Response**, and **Privacy & Context** submenus.
- Preserved the existing Chat auto-follow switch and added a persisted follow target:
  - `Response top` (new default)
  - `Conversation bottom` (legacy behavior)
- `Response top` reserves trailing scroll space so the newest SWRLZ response can animate to the top of the conversation viewport and grow downward.
- Manual upward scrolling pauses follow; `↓ LATEST` and a new user send re-arm follow.
- Added persisted control for whether live runtime/Forge commentary automatically brings Chat forward.
- Added a CLIENT-local SWRLZ personality profile with base style, detail, warmth, energy, humor, formatting, and emoji preferences.
- Personality settings guide optional reasoning-provider responses; deterministic status/mission/Forge truth is not rewritten by personality.
- Added direct access from Chat settings to existing sharing approvals without exposing Developer-only command tooling as a required User-mode dependency.

## Preserved boundaries

No SERVER, protocol, trust, Truth Firewall, permission, mission authority, Forge authority, repository authority, accessibility automation, or offline-first behavior changed.

## Verification boundary

Static source verification only. Added model normalization tests but did not run Gradle/JUnit, APK assembly, workflow, device installation, release, or deployment.
