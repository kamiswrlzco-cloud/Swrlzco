# INT-BUBBLE-041 — Native Bubble Admin Morph

## Corrected behavior

- Retired the three-window custom overlay dock as the default/runtime bubble model.
- SWRLZ now uses one Android-managed conversation bubble.
- Normal identity is the cyan/blue SWRLZ Client dragon.
- A verified SWURLZER admin session morphs the same bubble identity to SWURVER Admin using the fusion dragon.
- The native bubble keeps the full radial UI instead of opening separate CLIENT/SERVER/FUSION activity windows.
- Legacy overlay windows are stopped and their persisted enable flag is cleared during Client and bubble startup.
- CLIENT, SERVER, and FUSION avatar resources were tightened and near-white padding was made transparent.
- Purple SWURLZER remains the remote/server identity; cyan SWRLZ remains the client identity.

## Authority rule

The fusion/admin identity is selected only when `AdminRoutePolicy.hasVerifiedSession(...)` succeeds using:

- admin mode enabled,
- encrypted admin token present,
- non-empty last verification timestamp.

A visual preference alone cannot grant the SWURVER Admin identity.
