# INT-FORGE-045 — User Interface Forge Menu

## Status
Implemented in CLIENT CFv2.0.45.

## Change
GitHub Forge is now a first-class tab in the SWRLZ new user interface rather than only a Developer/Settings destination.

The user navigation order is now:

- Core
- Chat
- Groups
- Missions
- Activity
- Forge
- Settings

The Forge tab renders the existing authenticated GitHub Forge surface directly inside the normal CLIENT shell, preserving its mass upload, workflow observer, and artifact download state.

## Compatibility
The existing Settings shortcut and `user-forge` route remain available for compatibility. Developer Mode continues to expose the original GitHub Forge route.
