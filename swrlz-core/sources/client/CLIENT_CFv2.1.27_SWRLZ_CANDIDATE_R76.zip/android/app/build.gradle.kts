import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) load(f.reader())
}

fun swrlzPropOrEnv(key: String): String =
    ((localProps[key] as String?) ?: System.getenv(key)).orEmpty().trim()

val swrlzDevKeystoreFile = swrlzPropOrEnv("SWRLZ_DEV_KEYSTORE_FILE")
val swrlzDevKeystorePassword = swrlzPropOrEnv("SWRLZ_DEV_KEYSTORE_PASSWORD")
val swrlzDevKeyAlias = swrlzPropOrEnv("SWRLZ_DEV_KEY_ALIAS")
val swrlzDevKeyPassword = swrlzPropOrEnv("SWRLZ_DEV_KEY_PASSWORD")
val swrlzDevSigningReady = swrlzDevKeystoreFile.isNotBlank() &&
    swrlzDevKeystorePassword.isNotBlank() &&
    swrlzDevKeyAlias.isNotBlank() &&
    swrlzDevKeyPassword.isNotBlank()

android {
    namespace = "sh.swurlz.core"
    compileSdk = 35

    signingConfigs {
        if (swrlzDevSigningReady) {
            create("swrlzDev") {
                storeFile = rootProject.file(swrlzDevKeystoreFile)
                storePassword = swrlzDevKeystorePassword
                keyAlias = swrlzDevKeyAlias
                keyPassword = swrlzDevKeyPassword
            }
        }
    }

    defaultConfig {
        applicationId = "sh.swurlz.core"
        minSdk = 26
        targetSdk = 34
        versionCode = 202
        versionName = "2.1.27-jar-render-theme-persona-r76"
        // Optional build-time defaults. Both can be changed later inside the app.
        val backend = (localProps["SWURLZ_BACKEND_URL"] as String?)
            ?: System.getenv("SWURLZ_BACKEND_URL")
            ?: ""
        val apiToken = (localProps["SWURLZ_API_TOKEN"] as String?)
            ?: System.getenv("SWURLZ_API_TOKEN")
            ?: ""
        val googleOAuthKeys = listOf("SWRLZ_GOOGLE_OAUTH_WEB_CLIENT_ID", "SWRLZ_GOOGLE_OAUTH_CLIENT_ID", "GOOGLE_OAUTH_WEB_CLIENT_ID")
        val googleOAuthPair = googleOAuthKeys.asSequence().map { it to swrlzPropOrEnv(it) }.firstOrNull { it.second.isNotBlank() }
        val googleOAuthClientId = googleOAuthPair?.second.orEmpty()
        val googleOAuthConfigSource = googleOAuthPair?.first.orEmpty()
        buildConfigField("String", "BACKEND_URL", "\"${backend.replace("\"", "\\\"")}\"")
        buildConfigField("String", "API_TOKEN", "\"${apiToken.replace("\"", "\\\"")}\"")
        buildConfigField("String", "SWRLZ_GOOGLE_OAUTH_CLIENT_ID", "\"${googleOAuthClientId.replace("\"", "\\\"")}\"")
        buildConfigField("String", "SWRLZ_GOOGLE_OAUTH_CONFIG_SOURCE", "\"${googleOAuthConfigSource.replace("\"", "\\\"")}\"")

        // SWRLZ build identity: every patch must carry a visible nameplate inside the app.
        buildConfigField("String", "PATCH_LABEL", "\"INT-SERVICE-WORKFLOW-DRAGON-JAR-168A\"")
        buildConfigField("String", "ROADMAP_REVISION", "\"3.0.0\"")
        buildConfigField("String", "SWRLZ_REVISION", "\"R76\"")
        buildConfigField("String", "BUILD_LINE", "\"CFv2.1.27 R76 sent-message Code Jar renderer + theme dragon persona contract\"")
        buildConfigField("String", "SOURCE_ZIP", "\"CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R76.zip\"")
        buildConfigField("String", "SWRLZ_PARENT_REVISION", "\"R75\"")
        buildConfigField("String", "SWRLZ_PARENT_SOURCE_SHA256", "\"7281126c1c14ad99682939c0ea2ab0ac2d716161534190567507baee3206c7d7\"")
        buildConfigField("String", "PATCH_NOTES", "\"INT-SERVICE-WORKFLOW-DRAGON-JAR-168A: CLIENT R76 pairs with SERVER R111; composer keeps literal [🫙]...[/🫙] editing syntax while sent/history messages are parsed into nested Code Jar UI, fixes the R75 detectLanguage regex crash that forced raw-marker fallback, tolerates Unicode marker format controls, and adds the theme dragon persona contract used by SERVER tool/conversation narration. Fresh Auto Forge/device acceptance required.\"")
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            if (swrlzDevSigningReady) signingConfig = signingConfigs.getByName("swrlzDev")
        }
        release {
            isMinifyEnabled = false
            signingConfig = if (swrlzDevSigningReady) signingConfigs.getByName("swrlzDev") else signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources.excludes += setOf(
            "/META-INF/{AL2.0,LGPL2.1}",
            "META-INF/INDEX.LIST",
            "META-INF/io.netty.versions.properties",
        )
    }
}

dependencies {
    implementation(project(":theme-contract"))
    implementation(project(":profile-contract"))
    implementation(project(":provider-contract"))
    implementation(project(":command-contract"))
    implementation(project(":model-rack-contract"))
    implementation(project(":llm-contract"))
    implementation(project(":swrlzx-contract"))

    val composeBom = platform("androidx.compose:compose-bom:2024.09.02")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.5")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.5")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.5")
    implementation("androidx.navigation:navigation-compose:2.8.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.security:security-crypto:1.0.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.credentials:credentials:1.6.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.6.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.2.0")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.1")

    implementation("io.ktor:ktor-client-core:2.3.12")
    implementation("io.ktor:ktor-client-okhttp:2.3.12")
    implementation("io.ktor:ktor-client-content-negotiation:2.3.12")
    implementation("io.ktor:ktor-serialization-kotlinx-json:2.3.12")
    implementation("io.ktor:ktor-client-websockets:2.3.12")
    testImplementation("junit:junit:4.13.2")
}
