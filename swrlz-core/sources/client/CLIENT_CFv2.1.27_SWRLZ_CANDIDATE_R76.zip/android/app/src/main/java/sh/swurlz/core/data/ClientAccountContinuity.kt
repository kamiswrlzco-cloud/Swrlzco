package sh.swurlz.core.data

import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import java.net.HttpURLConnection
import java.net.URL
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.spec.X509EncodedKeySpec
import java.security.spec.MGF1ParameterSpec
import javax.crypto.Cipher
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import java.util.UUID
import java.util.zip.GZIPOutputStream
import org.json.JSONArray
import org.json.JSONObject
import sh.swurlz.core.net.ServerEndpointRoles

/** Optional R66 account/session/history continuity. Local-only mode never requires this store. */
object ClientAccountContinuity {
    private val OAEP_SHA256_MGF1_SHA1 = OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA1, PSource.PSpecified.DEFAULT)
    data class State(
        val signedIn: Boolean,
        val accountId: String = "",
        val provider: String = "",
        val sessionExpiresAtEpochMs: Long = 0L,
        val lastSyncRevision: Long = 0L,
        val secureBackupEnabled: Boolean = false,
    )

    data class SyncResult(
        val pushed: Int,
        val skipped: Int,
        val pulled: Int,
        val revision: Long,
        val hasMore: Boolean,
    )

    private const val FILE = "swrlz_account_continuity"
    private const val KEY_ACCOUNT = "account_id"
    private const val KEY_PROVIDER = "provider"
    private const val KEY_SESSION = "session_token"
    private const val KEY_EXPIRES = "session_expires"
    private const val KEY_REVISION = "sync_revision"
    private const val KEY_INSTALLATION = "installation_id"
    private const val KEY_BACKUP = "secure_backup_enabled"

    private fun prefs(context: Context) = EncryptedSharedPreferences.create(
        FILE,
        MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
        context.applicationContext,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    fun state(context: Context): State {
        val p = prefs(context)
        val token = p.getString(KEY_SESSION, "").orEmpty()
        val expires = p.getLong(KEY_EXPIRES, 0L)
        return State(
            signedIn = token.isNotBlank() && expires > System.currentTimeMillis(),
            accountId = p.getString(KEY_ACCOUNT, "").orEmpty(),
            provider = p.getString(KEY_PROVIDER, "").orEmpty(),
            sessionExpiresAtEpochMs = expires,
            lastSyncRevision = p.getLong(KEY_REVISION, 0L),
            secureBackupEnabled = p.getBoolean(KEY_BACKUP, false),
        )
    }

    fun installationId(context: Context): String {
        val p = prefs(context)
        return p.getString(KEY_INSTALLATION, null)?.takeIf { it.isNotBlank() }
            ?: "client-install-${UUID.randomUUID()}".also { p.edit().putString(KEY_INSTALLATION, it).commit() }
    }

    fun setSecureBackupEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_BACKUP, enabled).commit()
    }

    fun signOut(context: Context, removeLocalHistory: Boolean = false) {
        prefs(context).edit()
            .remove(KEY_ACCOUNT).remove(KEY_PROVIDER).remove(KEY_SESSION).remove(KEY_EXPIRES).remove(KEY_REVISION)
            .commit()
        if (removeLocalHistory) {
            // Deliberately not automatic. This option is explicit because sign-out must never silently delete local history.
            ImportedChatHistoryStore.clearAll(context)
        }
        ClientChatHistoryStore.notifyExternalChange()
    }

    fun establishGoogleSession(context: Context, idToken: String): State {
        val base = serverBase(context)
        val nodeId = DeviceContextCollector.collect(context).deviceNodeId
        val request = JSONObject()
            .put("idToken", idToken)
            .put("nodeId", nodeId)
            .put("installationId", installationId(context))
        val response = post(base, "/v1/account/google/session", request, null)
        require(response.optBoolean("ok")) { errorMessage(response) }
        val p = prefs(context)
        check(p.edit()
            .putString(KEY_ACCOUNT, response.optString("accountId"))
            .putString(KEY_PROVIDER, response.optString("provider", "GOOGLE"))
            .putString(KEY_SESSION, response.optString("sessionToken"))
            .putLong(KEY_EXPIRES, response.optLong("expiresAtEpochMs"))
            .commit()) { "ACCOUNT_SESSION_PERSIST_FAILED" }
        return state(context)
    }

    fun syncNow(context: Context, batchSize: Int = 96): SyncResult {
        val state = state(context)
        require(state.signedIn) { "ACCOUNT_SESSION_REQUIRED" }
        val token = prefs(context).getString(KEY_SESSION, "").orEmpty()
        val base = serverBase(context)
        val envelopes = ClientChatHistoryStore.syncEnvelopes(context)
        var pushedTotal = 0
        var skippedTotal = 0
        var finalRevision = state.lastSyncRevision
        val maxRows = batchSize.coerceIn(1, 32)
        var batch = JSONArray()
        var batchBytes = 64
        fun flushBatch() {
            if (batch.length() == 0) return
            val push = post(base, "/v1/account/history/push", JSONObject().put("records", batch), token)
            require(push.optBoolean("ok")) { errorMessage(push) }
            pushedTotal += push.optInt("accepted")
            skippedTotal += push.optInt("skipped")
            finalRevision = maxOf(finalRevision, push.optLong("syncRevision", finalRevision))
            batch = JSONArray()
            batchBytes = 64
        }
        envelopes.forEach { envelope ->
            val encodedBytes = envelope.toString().toByteArray(Charsets.UTF_8).size + 2
            if (encodedBytes >= 900_000) {
                flushBatch()
                val fragment = pushFragmentedEnvelope(base, token, envelope)
                pushedTotal += fragment.optInt("accepted")
                skippedTotal += fragment.optInt("skipped")
                finalRevision = maxOf(finalRevision, fragment.optLong("syncRevision", finalRevision))
            } else {
                if (batch.length() >= maxRows || (batch.length() > 0 && batchBytes + encodedBytes > 1_300_000)) flushBatch()
                batch.put(envelope)
                batchBytes += encodedBytes
            }
        }
        flushBatch()
        HistorySyncTombstoneStoreV1.clear(context)

        var cursor = state.lastSyncRevision
        var pulled = 0
        var hasMore: Boolean
        var loops = 0
        do {
            val delta = post(base, "/v1/account/history/pull", JSONObject().put("afterRevision", cursor).put("limit", 24), token)
            require(delta.optBoolean("ok")) { errorMessage(delta) }
            val records = delta.optJSONArray("records") ?: JSONArray()
            for (i in 0 until records.length()) {
                val record = records.optJSONObject(i) ?: continue
                ClientChatHistoryStore.applySyncEnvelope(context, record)
                pulled++
            }
            cursor = delta.optLong("deliveredRevision", cursor)
            finalRevision = maxOf(finalRevision, delta.optLong("currentRevision", finalRevision))
            hasMore = delta.optBoolean("hasMore", false)
            loops++
        } while (hasMore && loops < 256)
        prefs(context).edit().putLong(KEY_REVISION, cursor).commit()
        ClientChatHistoryStore.notifyExternalChange()
        return SyncResult(pushedTotal, skippedTotal, pulled, finalRevision, hasMore)
    }

    fun backupCredentialEnvelope(context: Context, envelope: JSONObject): JSONObject {
        val state = state(context)
        require(state.signedIn && state.secureBackupEnabled) { "SECURE_CREDENTIAL_BACKUP_NOT_ENABLED" }
        val token = prefs(context).getString(KEY_SESSION, "").orEmpty()
        val response = post(serverBase(context), "/v1/account/credentials/envelope", JSONObject().put("envelope", envelope), token)
        require(response.optBoolean("ok")) { errorMessage(response) }
        return response
    }

    fun restoreCredentialEnvelope(context: Context, credentialId: String): JSONObject {
        val state = state(context)
        require(state.signedIn && state.secureBackupEnabled) { "SECURE_CREDENTIAL_BACKUP_NOT_ENABLED" }
        val token = prefs(context).getString(KEY_SESSION, "").orEmpty()
        val response = post(serverBase(context), "/v1/account/credentials/envelope/get", JSONObject().put("credentialId", credentialId), token)
        require(response.optBoolean("ok")) { errorMessage(response) }
        return response.getJSONObject("envelope")
    }


    /**
     * Opt-in Google-account recovery slot for the vault passphrase. The passphrase is encrypted to
     * the SERVER recovery public key before transport and is never stored in CLIENT preferences.
     */
    fun backupVaultRecoveryPassphrase(context: Context, passphrase: CharArray): JSONObject {
        val state = state(context)
        require(state.signedIn && state.secureBackupEnabled) { "SECURE_CREDENTIAL_BACKUP_NOT_ENABLED" }
        val token = prefs(context).getString(KEY_SESSION, "").orEmpty()
        val base = serverBase(context)
        val clear = passphrase.concatToString().toByteArray(Charsets.UTF_8)
        try {
            require(clear.size in 10..190) { "VAULT_RECOVERY_PASSPHRASE_LENGTH_INVALID" }
            val key = post(base, "/v1/account/vault/passphrase/key", JSONObject(), token)
            require(key.optBoolean("ok")) { errorMessage(key) }
            val publicBytes = Base64.decode(key.getString("publicKeyDerBase64"), Base64.DEFAULT)
            val publicKey = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(publicBytes))
            val cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding").run {
                init(Cipher.ENCRYPT_MODE, publicKey, OAEP_SHA256_MGF1_SHA1)
                doFinal(clear)
            }
            val response = post(
                base,
                "/v1/account/vault/passphrase/put",
                JSONObject()
                    .put("keyId", key.getString("keyId"))
                    .put("ciphertextBase64", Base64.encodeToString(cipher, Base64.NO_WRAP))
                    .put("confirm", true),
                token,
            )
            require(response.optBoolean("ok")) { errorMessage(response) }
            return response
        } finally {
            clear.fill(0)
        }
    }

    /** Restore only after a current Google-backed SWRLZ session. SERVER re-wraps to this one-time key. */
    fun restoreVaultRecoveryPassphrase(context: Context): CharArray {
        val state = state(context)
        require(state.signedIn && state.secureBackupEnabled) { "SECURE_CREDENTIAL_BACKUP_NOT_ENABLED" }
        val token = prefs(context).getString(KEY_SESSION, "").orEmpty()
        val pair = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val response = post(
            serverBase(context),
            "/v1/account/vault/passphrase/get",
            JSONObject()
                .put("clientPublicKeyDerBase64", Base64.encodeToString(pair.public.encoded, Base64.NO_WRAP))
                .put("confirm", true),
            token,
        )
        require(response.optBoolean("ok")) { errorMessage(response) }
        val cipher = Base64.decode(response.getString("ciphertextBase64"), Base64.DEFAULT)
        val clear = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding").run {
            init(Cipher.DECRYPT_MODE, pair.private, OAEP_SHA256_MGF1_SHA1)
            doFinal(cipher)
        }
        return try {
            require(clear.size in 10..190) { "RESTORED_VAULT_PASSPHRASE_LENGTH_INVALID" }
            clear.toString(Charsets.UTF_8).toCharArray()
        } finally {
            clear.fill(0)
        }
    }

    private fun pushFragmentedEnvelope(base: String, token: String, envelope: JSONObject): JSONObject {
        val conversationId = envelope.optString("conversationId").trim()
        require(conversationId.isNotBlank()) { "HISTORY_CONVERSATION_ID_REQUIRED" }
        val plain = envelope.toString().toByteArray(Charsets.UTF_8)
        require(plain.size <= 16_000_000) { "HISTORY_CONVERSATION_TOO_LARGE:$conversationId" }
        val compressed = ByteArrayOutputStream().use { out ->
            GZIPOutputStream(out).use { it.write(plain) }
            out.toByteArray()
        }
        val compressedSha = sha256(compressed)
        val uploadId = "hist-${sha256((conversationId + "\u001f" + compressedSha).toByteArray(Charsets.UTF_8)).take(48)}"
        val fragmentSize = 550_000
        val count = (compressed.size + fragmentSize - 1) / fragmentSize
        var final = JSONObject().put("accepted", 0).put("skipped", 0).put("syncRevision", 0L)
        for (index in 0 until count) {
            val start = index * fragmentSize
            val end = minOf(compressed.size, start + fragmentSize)
            val part = compressed.copyOfRange(start, end)
            val request = JSONObject()
                .put("uploadId", uploadId)
                .put("conversationId", conversationId)
                .put("fragmentIndex", index)
                .put("fragmentCount", count)
                .put("fragmentSha256", sha256(part))
                .put("compressedSha256", compressedSha)
                .put("fragmentBase64", Base64.encodeToString(part, Base64.NO_WRAP))
            val response = post(base, "/v1/account/history/push-fragment", request, token)
            require(response.optBoolean("ok")) { errorMessage(response) }
            final = response
        }
        require(final.optBoolean("complete")) { "HISTORY_FRAGMENT_UPLOAD_INCOMPLETE:$conversationId" }
        return final
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }

    private fun serverBase(context: Context): String {
        val config = kotlinx.coroutines.runBlocking { Prefs.coreNodeConfig(context) }
        require(config.nodeUrl.isNotBlank()) { "CORE_NODE_NOT_CONFIGURED" }
        return ServerEndpointRoles.operationalApiBase(config.nodeUrl)
    }

    private fun post(base: String, path: String, body: JSONObject, bearer: String?): JSONObject {
        val connection = (URL(base.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 7_500
            readTimeout = 30_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            if (!bearer.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $bearer")
        }
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        return runCatching { JSONObject(text) }.getOrElse {
            JSONObject().put("ok", false).put("error", JSONObject().put("code", "BAD_ACCOUNT_RESPONSE").put("message", text.take(240)))
        }
    }

    private fun errorMessage(json: JSONObject): String = json.optJSONObject("error")?.optString("message")
        ?.takeIf { it.isNotBlank() } ?: json.optString("detail", "ACCOUNT_CONTINUITY_FAILED")
}
