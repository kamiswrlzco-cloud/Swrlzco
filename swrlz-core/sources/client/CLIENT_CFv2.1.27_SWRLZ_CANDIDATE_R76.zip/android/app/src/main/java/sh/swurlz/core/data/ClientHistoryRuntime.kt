package sh.swurlz.core.data

import android.content.Context
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * App-scoped progressive chat-history hydrator.
 *
 * History screens observe this cache instead of reparsing the imported archive index every time a
 * menu is opened. The bootstrap publishes the newest headers first, then progressively exposes the
 * rest from an IO worker while the rest of the CLIENT remains interactive.
 */
object ClientHistoryRuntime {
    data class State(
        val bootstrapReady: Boolean = false,
        val loading: Boolean = false,
        val currentThreadId: String = "",
        val threads: List<ClientChatThreadSummary> = emptyList(),
        val totalThreadCount: Int = 0,
        val exposedThreadCount: Int = 0,
        val lastRefreshAtEpochMs: Long = 0L,
        val error: String = "",
    )

    private const val FIRST_PAGE = 48
    private const val BACKGROUND_PAGE = 96
    private const val PAGE_YIELD_MS = 12L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val started = AtomicBoolean(false)
    private val stateMutable = MutableStateFlow(State())
    val state: StateFlow<State> = stateMutable.asStateFlow()
    @Volatile private var refreshJob: Job? = null
    @Volatile private var appContext: Context? = null

    fun start(context: Context) {
        appContext = context.applicationContext
        if (started.compareAndSet(false, true)) refresh(force = true)
    }

    fun refresh(context: Context? = appContext, force: Boolean = false) {
        val app = context?.applicationContext ?: return
        appContext = app
        if (!force && refreshJob?.isActive == true) return
        refreshJob?.cancel()
        refreshJob = scope.launch {
            val previous = stateMutable.value
            stateMutable.value = previous.copy(loading = true, error = "")
            runCatching {
                val doc = ClientChatHistoryStore.ensure(app)
                val all = ClientChatHistoryStore.listThreads(app)
                val first = all.take(FIRST_PAGE)
                stateMutable.value = State(
                    bootstrapReady = true,
                    loading = all.size > first.size,
                    currentThreadId = doc.currentThreadId,
                    threads = first,
                    totalThreadCount = all.size,
                    exposedThreadCount = first.size,
                    lastRefreshAtEpochMs = System.currentTimeMillis(),
                )
                var exposed = first.size
                while (exposed < all.size) {
                    val next = (exposed + BACKGROUND_PAGE).coerceAtMost(all.size)
                    stateMutable.value = stateMutable.value.copy(
                        threads = all.subList(0, next).toList(),
                        loading = next < all.size,
                        exposedThreadCount = next,
                        lastRefreshAtEpochMs = System.currentTimeMillis(),
                    )
                    exposed = next
                    if (exposed < all.size) delay(PAGE_YIELD_MS)
                }
                if (all.isEmpty()) stateMutable.value = stateMutable.value.copy(loading = false)
            }.onFailure { failure ->
                stateMutable.value = stateMutable.value.copy(
                    bootstrapReady = true,
                    loading = false,
                    error = "${failure.javaClass.simpleName}: ${failure.message}".take(240),
                    lastRefreshAtEpochMs = System.currentTimeMillis(),
                )
            }
        }
    }
}
