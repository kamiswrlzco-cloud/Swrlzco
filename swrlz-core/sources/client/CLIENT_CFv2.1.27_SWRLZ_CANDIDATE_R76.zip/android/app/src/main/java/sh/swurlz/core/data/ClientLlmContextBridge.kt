package sh.swurlz.core.data

import android.content.Context
import java.time.Instant
import sh.swrlz.llm.SwrlzClientContextV1
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.PermissionHelper
import sh.swurlz.core.net.ClientNodeMessaging

/**
 * Explicit allowlist for useful CLIENT facts sent to §wyrlzer's LLM.
 * URLs, tokens, proofs, fingerprints, content, files, and installed-app data are excluded.
 */
object ClientLlmContextBridge {
    suspend fun capture(context: Context): SwrlzClientContextV1 {
        val appContext = context.applicationContext
        val device = DeviceContextCollector.collect(appContext)
        val style = Prefs.uiStyle(appContext)
        val chat = Prefs.chatSettings(appContext)
        val truth = Prefs.coreNodeTruthState(appContext)
        val mode = Prefs.interfaceMode(appContext)
        val registeredNodeId = runCatching { ClientNodeMessaging.currentNodeId(appContext) }
            .getOrDefault(device.deviceNodeId)
        val capabilities = buildList {
            add("client.chat")
            add("client.node-messaging-v2")
            add("client.core-node-check")
            add("client.themes")
            add("client.permissions.status")
            if (device.capabilities.accessibilityEnabled) add("android.accessibility")
            if (device.capabilities.overlayEnabled) add("android.overlay")
            if (device.capabilities.notificationsEnabled) add("android.notifications")
            if (mode.storageValue == "developer") add("client.developer-interface")
        }
        return SwrlzClientContextV1(
            nodeId = registeredNodeId,
            appVersionName = BuildConfig.VERSION_NAME,
            appVersionCode = BuildConfig.VERSION_CODE,
            patchLabel = BuildConfig.PATCH_LABEL,
            deviceManufacturer = device.manufacturer,
            deviceModel = device.model,
            androidRelease = device.androidVersion,
            androidSdk = device.sdk,
            accessibilityEnabled = PermissionHelper.isAccessibilityEnabled(appContext),
            overlayGranted = PermissionHelper.isOverlayGranted(appContext),
            notificationsGranted = PermissionHelper.isNotificationGranted(appContext),
            serverConfigured = truth.config.configured,
            lastServerCheckSucceeded = truth.manual.success || truth.auto.success,
            interfaceMode = mode.storageValue,
            themeId = style.themeId,
            displayMode = style.displayMode,
            chatStyle = chat.baseStyle,
            chatDetail = chat.detailLevel,
            capabilities = capabilities,
            capturedAt = Instant.now().toString(),
        ).normalized()
    }
}
