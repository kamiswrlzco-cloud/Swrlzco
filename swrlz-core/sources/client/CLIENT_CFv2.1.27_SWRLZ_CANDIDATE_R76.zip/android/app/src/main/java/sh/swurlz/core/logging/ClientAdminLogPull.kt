package sh.swurlz.core.logging

import android.content.Context
import android.util.Base64
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

/**
 * Read-only, admin-routed export surface for SWRLZ CLIENT diagnostic logs.
 *
 * MANIFEST freezes registered redaction-safe logs into an immutable short-lived snapshot. READ_CHUNK
 * reads only that snapshot by opaque ids, so diagnostic events created by the pull itself cannot
 * move EOF or invalidate the advertised SHA-256 while GPT is reconstructing a file.
 */
object ClientAdminLogPull {
    private const val MAX_CHUNK_BYTES = 192 * 1024
    private const val MAX_FILES = 128
    private const val MAX_SNAPSHOTS = 2
    private const val SNAPSHOT_TTL_MS = 30L * 60L * 1000L
    private const val SNAPSHOT_ROOT = "admin-log-snapshots"
    private const val MANIFEST_NAME = "manifest.json"

    private data class Entry(val category: String, val file: File)

    fun execute(context: Context, request: JSONObject): JSONObject {
        val args = request.optJSONObject("arguments") ?: JSONObject()
        val explicitOperation = request.optString("operation").trim().uppercase()
        val hasChunkIdentity = args.optString("snapshotId").isNotBlank() || args.optString("logId").isNotBlank()
        val operation = when {
            explicitOperation.isNotBlank() -> explicitOperation
            hasChunkIdentity -> "READ_CHUNK"
            else -> "MANIFEST"
        }
        return when (operation) {
            "MANIFEST" -> createSnapshot(context, args.optBoolean("includeHashes", true))
            "READ_CHUNK" -> readChunk(
                context = context,
                snapshotId = args.optString("snapshotId").trim(),
                logId = args.optString("logId").trim(),
                offset = args.optLong("offset", 0L).coerceAtLeast(0L),
                maxBytes = args.optInt("maxBytes", MAX_CHUNK_BYTES).coerceIn(1, MAX_CHUNK_BYTES),
            )
            else -> failure("LOG_OPERATION_UNSUPPORTED", "Unsupported CLIENT log operation: $operation")
        }
    }

    @Synchronized
    private fun createSnapshot(context: Context, includeHashes: Boolean): JSONObject {
        pruneSnapshots(context)
        val snapshotId = UUID.randomUUID().toString()
        val dir = File(snapshotRoot(context), snapshotId).apply { mkdirs() }
        val files = JSONArray()
        entries(context).forEachIndexed { index, entry ->
            val source = entry.file
            val storageName = "log-${index.toString().padStart(3, '0')}.bin"
            val frozen = File(dir, storageName)
            source.inputStream().buffered().use { input -> frozen.outputStream().buffered().use(input::copyTo) }
            val id = sha256("CLIENT|$snapshotId|${entry.category}|${source.name}|$index".toByteArray()).take(40)
            files.put(
                JSONObject()
                    .put("logId", id)
                    .put("category", entry.category)
                    .put("displayName", source.name)
                    .put("storageName", storageName)
                    .put("bytes", frozen.length())
                    .put("sourceModifiedEpochMs", source.lastModified())
                    .put("sha256", if (includeHashes) sha256(frozen) else JSONObject.NULL),
            )
        }
        val privateManifest = JSONObject()
            .put("schema", "swrlz-admin-log-snapshot-private-v1")
            .put("snapshotId", snapshotId)
            .put("source", "CLIENT")
            .put("createdAtEpochMs", System.currentTimeMillis())
            .put("files", files)
        File(dir, MANIFEST_NAME).writeText(privateManifest.toString(), Charsets.UTF_8)
        return publicManifest(privateManifest)
    }

    private fun publicManifest(privateManifest: JSONObject): JSONObject {
        val publicFiles = JSONArray()
        val files = privateManifest.optJSONArray("files") ?: JSONArray()
        repeat(files.length()) { index ->
            val item = files.optJSONObject(index) ?: return@repeat
            publicFiles.put(
                JSONObject()
                    .put("snapshotId", privateManifest.optString("snapshotId"))
                    .put("logId", item.optString("logId"))
                    .put("source", "CLIENT")
                    .put("category", item.optString("category"))
                    .put("displayName", item.optString("displayName"))
                    .put("bytes", item.optLong("bytes", 0L))
                    .put("modifiedEpochMs", item.optLong("sourceModifiedEpochMs", 0L))
                    .put("sha256", item.opt("sha256") ?: JSONObject.NULL)
                    .put("redactionState", "SOURCE_SINK_REDACTED")
                    .put("absolutePathDisclosed", false),
            )
        }
        return JSONObject()
            .put("ok", true)
            .put("schema", "swrlz-admin-log-manifest-v1")
            .put("source", "CLIENT")
            .put("snapshotId", privateManifest.optString("snapshotId"))
            .put("generatedAtEpochMs", privateManifest.optLong("createdAtEpochMs", System.currentTimeMillis()))
            .put("snapshotTtlMs", SNAPSHOT_TTL_MS)
            .put("fileCount", publicFiles.length())
            .put("files", publicFiles)
            .put("maxChunkBytes", MAX_CHUNK_BYTES)
            .put("credentialsIncluded", false)
            .put("rawPrivateChainOfThoughtIncluded", false)
            .put("note", "Frozen read-only diagnostic snapshot. Secret material remains redacted by registered SWRLZ logging boundaries.")
    }

    @Synchronized
    private fun readChunk(context: Context, snapshotId: String, logId: String, offset: Long, maxBytes: Int): JSONObject {
        pruneSnapshots(context)
        if (!validSnapshotId(snapshotId)) return failure("LOG_SNAPSHOT_ID_REQUIRED", "A valid snapshotId from MANIFEST is required")
        if (logId.isBlank()) return failure("LOG_ID_REQUIRED", "logId is required")
        val dir = File(snapshotRoot(context), snapshotId)
        val manifestFile = File(dir, MANIFEST_NAME)
        if (!manifestFile.isFile) return failure("LOG_SNAPSHOT_EXPIRED", "The CLIENT log snapshot is missing or expired")
        val manifest = runCatching { JSONObject(manifestFile.readText(Charsets.UTF_8)) }.getOrNull()
            ?: return failure("LOG_SNAPSHOT_INVALID", "The CLIENT log snapshot manifest is invalid")
        val files = manifest.optJSONArray("files") ?: JSONArray()
        var item: JSONObject? = null
        repeat(files.length()) { index -> files.optJSONObject(index)?.takeIf { it.optString("logId") == logId }?.let { item = it } }
        val selected = item ?: return failure("LOG_NOT_FOUND", "The requested CLIENT diagnostic log is not in this snapshot")
        val storageName = selected.optString("storageName")
        if (!storageName.matches(Regex("^log-[0-9]{3}\\.bin$"))) return failure("LOG_SNAPSHOT_INVALID", "Snapshot storage identity is invalid")
        val file = File(dir, storageName)
        if (!file.isFile || file.canonicalFile.parentFile != dir.canonicalFile) return failure("LOG_SNAPSHOT_INVALID", "Frozen log file is unavailable")
        val size = file.length()
        if (offset > size) return failure("LOG_OFFSET_INVALID", "offset exceeds the frozen log size")
        val count = minOf(maxBytes.toLong(), size - offset).toInt()
        val bytes = ByteArray(count)
        if (count > 0) RandomAccessFile(file, "r").use { raf -> raf.seek(offset); raf.readFully(bytes) }
        val next = offset + bytes.size
        return JSONObject()
            .put("ok", true)
            .put("schema", "swrlz-admin-log-chunk-v1")
            .put("source", "CLIENT")
            .put("snapshotId", snapshotId)
            .put("category", selected.optString("category"))
            .put("logId", logId)
            .put("displayName", selected.optString("displayName"))
            .put("offset", offset)
            .put("bytesReturned", bytes.size)
            .put("nextOffset", next)
            .put("totalBytes", size)
            .put("eof", next >= size)
            .put("chunkSha256", sha256(bytes))
            .put("dataBase64", Base64.encodeToString(bytes, Base64.NO_WRAP))
            .put("credentialsIncluded", false)
            .put("rawPrivateChainOfThoughtIncluded", false)
    }

    private fun entries(context: Context): List<Entry> {
        val app = context.applicationContext
        val roots = listOf(
            "FULL" to File(app.noBackupFilesDir, "full-logs"),
            "FORGE" to File(app.filesDir, "forge_upload_logs"),
        )
        return roots.flatMap { (category, root) ->
            root.listFiles().orEmpty().filter { it.isFile && isAllowedLogName(it.name) }.map { Entry(category, it) }
        }.sortedWith(compareBy<Entry>({ it.category }, { it.file.name })).take(MAX_FILES)
    }

    private fun snapshotRoot(context: Context): File = File(context.applicationContext.noBackupFilesDir, SNAPSHOT_ROOT).apply { mkdirs() }

    private fun pruneSnapshots(context: Context) {
        val now = System.currentTimeMillis()
        val dirs = snapshotRoot(context).listFiles().orEmpty().filter(File::isDirectory).sortedByDescending(File::lastModified)
        dirs.forEachIndexed { index, dir ->
            if (index >= MAX_SNAPSHOTS || now - dir.lastModified() > SNAPSHOT_TTL_MS) dir.deleteRecursively()
        }
    }

    private fun validSnapshotId(value: String): Boolean = value.matches(Regex("^[A-Fa-f0-9-]{20,64}$"))
    private fun isAllowedLogName(name: String): Boolean {
        val lower = name.lowercase()
        return lower.endsWith(".ndjson") || lower.endsWith(".jsonl") || lower.endsWith(".log") || lower.endsWith(".log.txt")
    }
    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) { val read = input.read(buffer); if (read <= 0) break; digest.update(buffer, 0, read) }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    private fun failure(code: String, message: String): JSONObject = JSONObject().put("ok", false).put("schema", "swrlz-admin-log-response-v1").put("error", JSONObject().put("code", code).put("message", message).put("retryable", false))
}
