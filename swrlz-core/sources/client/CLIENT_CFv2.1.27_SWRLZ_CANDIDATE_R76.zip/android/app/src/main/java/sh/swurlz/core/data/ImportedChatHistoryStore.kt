package sh.swurlz.core.data

import android.content.Context
import android.util.AtomicFile
import java.io.File
import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject

/**
 * R66 sharded store for imported conversation archives.
 *
 * Imported history is kept outside the native chat-history JSON so a 188 MiB source archive never
 * turns every ordinary chat commit into a rewrite of the whole import.  The index is small and one
 * conversation body is loaded only when that thread is opened.
 */
object ImportedChatHistoryStore {
    private const val INDEX_SCHEMA = "swrlz-imported-chat-index-v1"
    private const val THREAD_SCHEMA = "swrlz-imported-chat-thread-v1"

    data class ThreadRecord(
        val threadId: String,
        val title: String,
        val createdAtEpochMs: Long,
        val updatedAtEpochMs: Long,
        val messageCount: Int,
        val originConversationId: String,
        val sourceArchiveSha256: String,
        val archived: Boolean,
        val starred: Boolean,
        val branchNodeCount: Int,
        val hiddenNodeCount: Int,
        val attachmentRefCount: Int,
        val syncExcluded: Boolean = false,
    )

    data class ImportedThreadPayload(
        val record: ThreadRecord,
        val currentNodeId: String,
        val defaultModelSlug: String,
        val visibleMessages: JSONArray,
        val alternateBranchNodes: JSONArray,
        val hiddenNodes: JSONArray,
    )

    private fun rootDir(context: Context): File = File(context.applicationContext.filesDir, "chat/imported-v1").also { it.mkdirs() }
    private fun indexFile(context: Context): File = File(rootDir(context), "index.json")
    private fun threadDir(context: Context): File = File(rootDir(context), "threads").also { it.mkdirs() }
    private fun stagingRoot(context: Context): File = File(rootDir(context), "staging").also { it.mkdirs() }
    private fun stagingDir(context: Context, archiveSha256: String): File = File(stagingRoot(context), archiveSha256.take(64)).also { it.mkdirs() }

    fun exists(context: Context, threadId: String): Boolean = list(context).any { it.threadId == threadId }

    @Synchronized
    fun list(context: Context): List<ThreadRecord> {
        val root = readIndex(context)
        val rows = root.optJSONArray("threads") ?: JSONArray()
        return (0 until rows.length()).mapNotNull { index ->
            val item = rows.optJSONObject(index) ?: return@mapNotNull null
            val threadId = item.optString("threadId")
            if (threadId.isBlank()) return@mapNotNull null
            ThreadRecord(
                threadId = threadId,
                title = item.optString("title", "Imported chat"),
                createdAtEpochMs = item.optLong("createdAtEpochMs", 0L),
                updatedAtEpochMs = item.optLong("updatedAtEpochMs", 0L),
                messageCount = item.optInt("messageCount", 0),
                originConversationId = item.optString("originConversationId"),
                sourceArchiveSha256 = item.optString("sourceArchiveSha256"),
                archived = item.optBoolean("archived", false),
                starred = item.optBoolean("starred", false),
                branchNodeCount = item.optInt("branchNodeCount", 0),
                hiddenNodeCount = item.optInt("hiddenNodeCount", 0),
                attachmentRefCount = item.optInt("attachmentRefCount", 0),
                syncExcluded = item.optBoolean("syncExcluded", false),
            )
        }.sortedByDescending { it.updatedAtEpochMs }
    }

    /** Stage is deterministic by archive SHA. Staged bodies are invisible until commitStagedImport flips the live index. */
    @Synchronized
    fun stageBatch(context: Context, archiveSha256: String, payloads: List<ImportedThreadPayload>) {
        require(archiveSha256.matches(Regex("[a-fA-F0-9]{64}"))) { "IMPORT_ARCHIVE_SHA_INVALID" }
        val dir = stagingDir(context, archiveSha256)
        payloads.forEach { payload ->
            require(payload.record.sourceArchiveSha256.equals(archiveSha256, ignoreCase = true)) { "IMPORT_STAGE_ARCHIVE_IDENTITY_MISMATCH" }
            atomicWrite(File(dir, sha256(payload.record.threadId).take(40) + ".json"), threadJson(payload).toString())
        }
    }

    @Synchronized
    fun commitStagedImport(
        context: Context,
        archiveSha256: String,
        expectedConversationCount: Int,
        shouldCancel: () -> Boolean = { false },
        onCommitProgress: (Int, Int) -> Unit = { _, _ -> },
    ): Pair<Int, Int> {
        val dir = stagingDir(context, archiveSha256)
        val staged = dir.listFiles { file -> file.isFile && file.extension == "json" && file.name != "commit.checkpoint.json" }?.sortedBy { it.name }.orEmpty()
        require(staged.size == expectedConversationCount) { "IMPORT_STAGE_CONVERSATION_COUNT_MISMATCH:${staged.size}:$expectedConversationCount" }
        val checkpoint = File(dir, "commit.checkpoint.json")
        fun cancelCheck() {
            if (shouldCancel()) throw kotlinx.coroutines.CancellationException("OPENAI_IMPORT_CANCELLED_DURING_COMMIT")
        }

        // Keep only compact ThreadRecord metadata resident. Conversation bodies are validated and
        // copied one-at-a-time so a 2,461-thread import never expands the whole archive into heap.
        val current = list(context).associateBy { it.threadId }.toMutableMap()
        var inserted = 0
        var updated = 0
        var ordinal = 0
        staged.forEach { file ->
            cancelCheck()
            val root = JSONObject(file.readText())
            require(root.optString("sourceArchiveSha256").equals(archiveSha256, ignoreCase = true)) { "IMPORT_STAGE_SOURCE_SHA_MISMATCH" }
            require(root.optString("originType") == "OPENAI_EXPORT") { "IMPORT_STAGE_ORIGIN_INVALID" }
            require(root.optBoolean("historical", true) && !root.optBoolean("executable", false)) { "IMPORT_STAGE_EXECUTION_ISOLATION_INVALID" }
            val record = recordFromRoot(root)
            if (current.containsKey(record.threadId)) updated++ else inserted++
            current[record.threadId] = record
            atomicWrite(threadFile(context, record.threadId), root.toString())
            ordinal++
            if (ordinal == 1 || ordinal % 32 == 0 || ordinal == staged.size) {
                atomicWrite(
                    checkpoint,
                    JSONObject()
                        .put("schema", "swrlz-import-commit-checkpoint-v1")
                        .put("archiveSha256", archiveSha256)
                        .put("phase", "BODY_COPY")
                        .put("completed", ordinal)
                        .put("total", staged.size)
                        .put("updatedAtEpochMs", System.currentTimeMillis())
                        .toString(),
                )
                onCommitProgress(ordinal, staged.size)
            }
        }

        cancelCheck()
        // Atomic index replacement is the visibility commit point. Process death before this leaves
        // only invisible body orphans; retry overwrites them idempotently.
        writeIndex(context, current.values.sortedByDescending { it.updatedAtEpochMs })
        atomicWrite(
            checkpoint,
            JSONObject()
                .put("schema", "swrlz-import-commit-checkpoint-v1")
                .put("archiveSha256", archiveSha256)
                .put("phase", "SEARCH_INDEX")
                .put("completed", 0)
                .put("total", staged.size)
                .put("updatedAtEpochMs", System.currentTimeMillis())
                .toString(),
        )

        // Build FTS one conversation at a time as well. A crash here leaves imported threads visible
        // but never corrupts their history; the next idempotent import resumes/rebuilds the index.
        // Once visibility is committed, finish this bounded pass instead of honoring cancellation so
        // search cannot be left partially indexed.
        ordinal = 0
        staged.forEach { file ->
            val root = JSONObject(file.readText())
            ImportedChatSearchIndexV1.replaceThread(context, root)
            ordinal++
            if (ordinal == 1 || ordinal % 32 == 0 || ordinal == staged.size) {
                atomicWrite(
                    checkpoint,
                    JSONObject()
                        .put("schema", "swrlz-import-commit-checkpoint-v1")
                        .put("archiveSha256", archiveSha256)
                        .put("phase", "SEARCH_INDEX")
                        .put("completed", ordinal)
                        .put("total", staged.size)
                        .put("updatedAtEpochMs", System.currentTimeMillis())
                        .toString(),
                )
                onCommitProgress(ordinal, staged.size)
            }
        }
        dir.deleteRecursively()
        ClientChatHistoryStore.notifyExternalChange()
        return inserted to updated
    }

    @Synchronized
    fun discardStage(context: Context, archiveSha256: String) {
        File(stagingRoot(context), archiveSha256.take(64)).deleteRecursively()
    }

    @Synchronized
    fun upsertBatch(context: Context, payloads: List<ImportedThreadPayload>): Pair<Int, Int> {
        if (payloads.isEmpty()) return 0 to 0
        val current = list(context).associateBy { it.threadId }.toMutableMap()
        var inserted = 0
        var updated = 0
        payloads.forEach { payload ->
            val existing = current[payload.record.threadId]
            if (existing == null) inserted++ else updated++
            writeThread(context, payload)
            current[payload.record.threadId] = payload.record
        }
        writeIndex(context, current.values.sortedByDescending { it.updatedAtEpochMs })
        return inserted to updated
    }

    fun search(
        context: Context,
        query: String,
        threadId: String? = null,
        source: String? = null,
        afterEpochMs: Long? = null,
        beforeEpochMs: Long? = null,
        limit: Int = 100,
    ): List<ImportedChatSearchIndexV1.Hit> = ImportedChatSearchIndexV1.search(context, query, threadId, source, afterEpochMs, beforeEpochMs, limit)

    @Synchronized
    fun messagePage(context: Context, threadId: String, offset: Int, limit: Int = 200): List<ClientChatStoredMessage> =
        messages(context, threadId).drop(offset.coerceAtLeast(0)).take(limit.coerceIn(1, 500))

    @Synchronized
    fun messages(context: Context, threadId: String): List<ClientChatStoredMessage> {
        val root = readThread(context, threadId) ?: return emptyList()
        val array = root.optJSONArray("messages") ?: JSONArray()
        return (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            ClientChatStoredMessage(
                fromUser = item.optString("authorRole").equals("user", true) || item.optBoolean("fromUser", false),
                text = item.optString("visibleText", item.optString("text", "")),
                createdAtEpochMs = item.optLong("createdAtEpochMs", 0L),
                sourceRequestId = item.optString("sourceRequestId", ""),
                responseTotalMs = item.optLong("responseTotalMs", -1L).takeIf { it >= 0L },
                firstTextMs = item.optLong("firstTextMs", -1L).takeIf { it >= 0L },
                route = item.optString("route", if (item.optBoolean("historical", true)) "OPENAI_EXPORT" else ""),
                truthCapsuleId = item.optString("truthCapsuleId", ""),
                executionTrace = emptyList(),
            )
        }
    }

    @Synchronized
    fun saveVisibleMessages(context: Context, threadId: String, messages: List<ClientChatStoredMessage>): Boolean {
        val root = readThread(context, threadId) ?: return false
        val existing = root.optJSONArray("messages") ?: JSONArray()
        val out = JSONArray()
        messages.forEachIndexed { index, message ->
            val prior = existing.optJSONObject(index)
            val row = if (prior != null) JSONObject(prior.toString()) else JSONObject()
                .put("nodeId", "swrlz-native-${sha256("$threadId|$index|${message.createdAtEpochMs}|${message.text}").take(24)}")
                .put("originType", "SWRLZ_NATIVE")
                .put("historical", false)
                .put("executable", false)
                .put("contentType", "text")
            row.put("authorRole", if (message.fromUser) "user" else "assistant")
                .put("fromUser", message.fromUser)
                .put("visibleText", message.text)
                .put("createdAtEpochMs", message.createdAtEpochMs)
            if (message.sourceRequestId.isNotBlank()) row.put("sourceRequestId", message.sourceRequestId)
            message.responseTotalMs?.let { row.put("responseTotalMs", it) }
            message.firstTextMs?.let { row.put("firstTextMs", it) }
            if (message.route.isNotBlank()) row.put("route", message.route)
            if (message.truthCapsuleId.isNotBlank()) row.put("truthCapsuleId", message.truthCapsuleId)
            out.put(row)
        }
        root.put("messages", out)
            .put("updatedAtEpochMs", messages.maxOfOrNull { it.createdAtEpochMs } ?: root.optLong("updatedAtEpochMs"))
        atomicWrite(threadFile(context, threadId), root.toString())
        ImportedChatSearchIndexV1.replaceThread(context, root)
        updateIndexRecord(context, threadId) { old ->
            old.copy(
                updatedAtEpochMs = root.optLong("updatedAtEpochMs", old.updatedAtEpochMs),
                messageCount = out.length(),
            )
        }
        ClientChatHistoryStore.notifyExternalChange()
        return true
    }

    @Synchronized
    fun appendAssistantMessage(
        context: Context,
        threadId: String,
        text: String,
        sourceRequestId: String,
        responseTotalMs: Long?,
        firstTextMs: Long?,
        route: String,
        truthCapsuleId: String,
    ): Boolean {
        val root = readThread(context, threadId) ?: return false
        val messages = root.optJSONArray("messages") ?: JSONArray().also { root.put("messages", it) }
        if (sourceRequestId.isNotBlank()) {
            for (index in 0 until messages.length()) {
                if (messages.optJSONObject(index)?.optString("sourceRequestId") == sourceRequestId) return false
            }
        }
        val now = System.currentTimeMillis()
        val item = JSONObject()
            .put("nodeId", "swrlz-native-${sha256("$threadId|$now|$sourceRequestId").take(24)}")
            .put("originType", "SWRLZ_NATIVE")
            .put("historical", false)
            .put("executable", false)
            .put("authorRole", "assistant")
            .put("fromUser", false)
            .put("contentType", "text")
            .put("visibleText", text)
            .put("createdAtEpochMs", now)
        if (sourceRequestId.isNotBlank()) item.put("sourceRequestId", sourceRequestId)
        responseTotalMs?.let { item.put("responseTotalMs", it) }
        firstTextMs?.let { item.put("firstTextMs", it) }
        if (route.isNotBlank()) item.put("route", route)
        if (truthCapsuleId.isNotBlank()) item.put("truthCapsuleId", truthCapsuleId)
        messages.put(item)
        root.put("updatedAtEpochMs", now)
        atomicWrite(threadFile(context, threadId), root.toString())
        ImportedChatSearchIndexV1.replaceThread(context, root)
        updateIndexRecord(context, threadId) { old -> old.copy(updatedAtEpochMs = now, messageCount = messages.length()) }
        ClientChatHistoryStore.notifyExternalChange()
        return true
    }

    @Synchronized
    fun rename(context: Context, threadId: String, title: String): Boolean {
        val root = readThread(context, threadId) ?: return false
        val clean = title.trim().take(80).ifBlank { "Imported chat" }
        root.put("title", clean).put("titleOverlay", true).put("updatedAtEpochMs", System.currentTimeMillis())
        atomicWrite(threadFile(context, threadId), root.toString())
        ImportedChatSearchIndexV1.replaceThread(context, root)
        updateIndexRecord(context, threadId) { it.copy(title = clean, updatedAtEpochMs = root.optLong("updatedAtEpochMs")) }
        ClientChatHistoryStore.notifyExternalChange()
        return true
    }

    @Synchronized
    fun delete(context: Context, threadId: String, recordTombstone: Boolean = true): Boolean {
        val records = list(context)
        if (records.none { it.threadId == threadId }) return false
        threadFile(context, threadId).delete()
        ImportedChatSearchIndexV1.removeThread(context, threadId)
        if (recordTombstone) HistorySyncTombstoneStoreV1.record(context, threadId, "OPENAI_EXPORT")
        writeIndex(context, records.filterNot { it.threadId == threadId })
        ClientChatHistoryStore.notifyExternalChange()
        return true
    }


    @Synchronized
    fun syncEnvelope(context: Context, threadId: String): JSONObject? {
        val root = readThread(context, threadId) ?: return null
        if (root.optBoolean("syncExcluded", false)) return null
        val visible = root.optJSONArray("messages") ?: JSONArray()
        val branches = root.optJSONArray("alternateBranchNodes") ?: JSONArray()
        val hidden = root.optJSONArray("hiddenNodes") ?: JSONArray()
        val allNodes = JSONArray()
        for (array in listOf(visible, branches, hidden)) {
            for (i in 0 until array.length()) array.optJSONObject(i)?.let { allNodes.put(JSONObject(it.toString())) }
        }
        return JSONObject(root.toString())
            .put("conversationId", threadId)
            .put("messageNodes", allNodes)
            .put("historical", true)
            .put("executable", false)
            .put("tombstone", false)
    }

    @Synchronized
    fun applyServerEnvelope(context: Context, envelope: JSONObject): Boolean {
        val threadId = envelope.optString("conversationId").ifBlank { envelope.optString("threadId") }
        if (threadId.isBlank()) return false
        if (envelope.optBoolean("tombstone", false)) return delete(context, threadId, recordTombstone = false)
        if (envelope.optString("originType") != "OPENAI_EXPORT") return false
        val visible = envelope.optJSONArray("messages") ?: JSONArray()
        val branches = envelope.optJSONArray("alternateBranchNodes") ?: JSONArray()
        val hidden = envelope.optJSONArray("hiddenNodes") ?: JSONArray()
        val record = ThreadRecord(
            threadId = threadId,
            title = envelope.optString("title", "Imported chat"),
            createdAtEpochMs = envelope.optLong("createdAtEpochMs", 0L),
            updatedAtEpochMs = envelope.optLong("updatedAtEpochMs", 0L),
            messageCount = visible.length(),
            originConversationId = envelope.optString("originConversationId").ifBlank { threadId.removePrefix("openai:") },
            sourceArchiveSha256 = envelope.optString("sourceArchiveSha256"),
            archived = envelope.optBoolean("archived", false),
            starred = envelope.optBoolean("starred", false),
            branchNodeCount = branches.length(),
            hiddenNodeCount = hidden.length() + (0 until branches.length()).count { branches.optJSONObject(it)?.optBoolean("hidden", false) == true },
            attachmentRefCount = (0 until visible.length()).sumOf { visible.optJSONObject(it)?.optInt("attachmentRefCount", 0) ?: 0 } +
                (0 until branches.length()).sumOf { branches.optJSONObject(it)?.optInt("attachmentRefCount", 0) ?: 0 },
            syncExcluded = false,
        )
        upsertBatch(context, listOf(ImportedThreadPayload(
            record = record,
            currentNodeId = envelope.optString("currentNodeId"),
            defaultModelSlug = envelope.optString("defaultModelSlug"),
            visibleMessages = JSONArray(visible.toString()),
            alternateBranchNodes = JSONArray(branches.toString()),
            hiddenNodes = JSONArray(hidden.toString()),
        )))
        return true
    }

    @Synchronized
    fun setSyncExcluded(context: Context, threadId: String, excluded: Boolean): Boolean {
        val root = readThread(context, threadId) ?: return false
        root.put("syncExcluded", excluded).put("updatedAtEpochMs", System.currentTimeMillis())
        atomicWrite(threadFile(context, threadId), root.toString())
        updateIndexRecord(context, threadId) { it.copy(syncExcluded = excluded, updatedAtEpochMs = root.optLong("updatedAtEpochMs")) }
        ClientChatHistoryStore.notifyExternalChange()
        return true
    }

    @Synchronized
    fun clearAll(context: Context) {
        rootDir(context).deleteRecursively()
        ImportedChatSearchIndexV1.clear(context)
        ClientChatHistoryStore.notifyExternalChange()
    }

    fun branchMetadata(context: Context, threadId: String): JSONObject? = readThread(context, threadId)?.let { root ->
        JSONObject()
            .put("currentNodeId", root.optString("currentNodeId"))
            .put("alternateBranchNodes", root.optJSONArray("alternateBranchNodes") ?: JSONArray())
            .put("hiddenNodes", root.optJSONArray("hiddenNodes") ?: JSONArray())
            .put("sourceArchiveSha256", root.optString("sourceArchiveSha256"))
    }

    private fun threadJson(payload: ImportedThreadPayload): JSONObject = JSONObject()
        .put("schema", THREAD_SCHEMA)
        .put("threadId", payload.record.threadId)
        .put("title", payload.record.title)
        .put("originType", "OPENAI_EXPORT")
        .put("originConversationId", payload.record.originConversationId)
        .put("sourceArchiveSha256", payload.record.sourceArchiveSha256)
        .put("createdAtEpochMs", payload.record.createdAtEpochMs)
        .put("updatedAtEpochMs", payload.record.updatedAtEpochMs)
        .put("archived", payload.record.archived)
        .put("starred", payload.record.starred)
        .put("syncExcluded", payload.record.syncExcluded)
        .put("currentNodeId", payload.currentNodeId)
        .put("defaultModelSlug", payload.defaultModelSlug)
        .put("messages", payload.visibleMessages)
        .put("alternateBranchNodes", payload.alternateBranchNodes)
        .put("hiddenNodes", payload.hiddenNodes)
        .put("historical", true)
        .put("executable", false)

    private fun writeThread(context: Context, payload: ImportedThreadPayload) {
        val root = threadJson(payload)
        atomicWrite(threadFile(context, payload.record.threadId), root.toString())
        ImportedChatSearchIndexV1.replaceThread(context, root)
    }

    private fun recordFromRoot(root: JSONObject): ThreadRecord {
        val visible = root.optJSONArray("messages") ?: JSONArray()
        val branches = root.optJSONArray("alternateBranchNodes") ?: JSONArray()
        val hidden = root.optJSONArray("hiddenNodes") ?: JSONArray()
        return ThreadRecord(
            threadId = root.getString("threadId"),
            title = root.optString("title", "Imported chat"),
            createdAtEpochMs = root.optLong("createdAtEpochMs", 0L),
            updatedAtEpochMs = root.optLong("updatedAtEpochMs", 0L),
            messageCount = visible.length(),
            originConversationId = root.optString("originConversationId"),
            sourceArchiveSha256 = root.optString("sourceArchiveSha256"),
            archived = root.optBoolean("archived", false),
            starred = root.optBoolean("starred", false),
            branchNodeCount = branches.length(),
            hiddenNodeCount = hidden.length() + (0 until branches.length()).count { branches.optJSONObject(it)?.optBoolean("hidden", false) == true },
            attachmentRefCount = (0 until visible.length()).sumOf { visible.optJSONObject(it)?.optInt("attachmentRefCount", 0) ?: 0 } +
                (0 until branches.length()).sumOf { branches.optJSONObject(it)?.optInt("attachmentRefCount", 0) ?: 0 },
            syncExcluded = root.optBoolean("syncExcluded", false),
        )
    }

    private fun updateIndexRecord(context: Context, threadId: String, transform: (ThreadRecord) -> ThreadRecord) {
        val rows = list(context).map { if (it.threadId == threadId) transform(it) else it }
        writeIndex(context, rows)
    }

    private fun threadFile(context: Context, threadId: String): File = File(threadDir(context), sha256(threadId).take(40) + ".json")

    private fun readThread(context: Context, threadId: String): JSONObject? = runCatching {
        val file = threadFile(context, threadId)
        if (!file.exists() && !File(file.path + ".bak").exists()) return@runCatching null
        AtomicFile(file).openRead().bufferedReader().use { JSONObject(it.readText()) }
    }.getOrNull()

    private fun readIndex(context: Context): JSONObject = runCatching {
        val file = indexFile(context)
        if (!file.exists() && !File(file.path + ".bak").exists()) return@runCatching JSONObject().put("schema", INDEX_SCHEMA).put("threads", JSONArray())
        AtomicFile(file).openRead().bufferedReader().use { JSONObject(it.readText()) }
    }.getOrElse { JSONObject().put("schema", INDEX_SCHEMA).put("threads", JSONArray()) }

    private fun writeIndex(context: Context, records: Collection<ThreadRecord>) {
        val rows = JSONArray()
        records.forEach { record ->
            rows.put(JSONObject()
                .put("threadId", record.threadId)
                .put("title", record.title)
                .put("createdAtEpochMs", record.createdAtEpochMs)
                .put("updatedAtEpochMs", record.updatedAtEpochMs)
                .put("messageCount", record.messageCount)
                .put("originConversationId", record.originConversationId)
                .put("sourceArchiveSha256", record.sourceArchiveSha256)
                .put("archived", record.archived)
                .put("starred", record.starred)
                .put("branchNodeCount", record.branchNodeCount)
                .put("hiddenNodeCount", record.hiddenNodeCount)
                .put("attachmentRefCount", record.attachmentRefCount)
                .put("syncExcluded", record.syncExcluded))
        }
        atomicWrite(indexFile(context), JSONObject().put("schema", INDEX_SCHEMA).put("threads", rows).toString())
    }

    private fun atomicWrite(file: File, text: String) {
        file.parentFile?.mkdirs()
        val atomic = AtomicFile(file)
        var stream: java.io.FileOutputStream? = null
        try {
            stream = atomic.startWrite()
            stream.write(text.toByteArray(Charsets.UTF_8))
            stream.flush()
            atomic.finishWrite(stream)
        } catch (failure: Throwable) {
            stream?.let { runCatching { atomic.failWrite(it) } }
            throw failure
        }
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
