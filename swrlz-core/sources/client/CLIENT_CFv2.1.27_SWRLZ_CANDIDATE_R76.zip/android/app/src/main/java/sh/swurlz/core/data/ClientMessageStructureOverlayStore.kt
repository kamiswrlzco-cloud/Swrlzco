package sh.swurlz.core.data

import android.content.Context
import java.security.MessageDigest
import java.text.Normalizer
import org.json.JSONObject

/**
 * Durable, non-destructive structure revisions for historical/native messages.
 *
 * User-created code containers use a deliberately tiny portable wire syntax:
 * `[🫙]...[/🫙]`.  The original imported/native payload remains immutable while the effective
 * history/context view resolves the latest stored revision.  Composer messages may carry the same
 * markers directly and therefore persist naturally when the message is sent.
 */
object ClientMessageStructureOverlayStore {
    private const val PREFS = "swrlz_message_structure_overlays_v1"
    private const val QUARANTINE_PREFS = "swrlz_message_structure_overlays_quarantine_v1"
    private const val ACTIVE_SCHEMA = "swrlz-message-structure-overlay-v3"
    private const val MAX_CONTAINERS_PER_MESSAGE = 64
    const val OPEN = "[🫙]"
    const val CLOSE = "[/🫙]"
    private const val MARKER_IGNORABLE = "[\uFE0E\uFE0F\u200B\u200C\u200D\u2060]*"
    private val OPEN_VARIANT = Regex("\\[$MARKER_IGNORABLE🫙$MARKER_IGNORABLE\\]")
    private val CLOSE_VARIANT = Regex("\\[$MARKER_IGNORABLE/$MARKER_IGNORABLE🫙$MARKER_IGNORABLE\\]")

    /**
     * Normalize visually equivalent jar markers to one storage form.
     *
     * Some Android/IME/font paths can insert variation selectors or zero-width formatting around
     * emoji.  Those code points are invisible to the user but previously made an apparently exact
     * `[🫙]...[/🫙]` pair miss the rich-message parser.  Canonicalization is therefore NFC + a
     * bounded marker-only normalization; ordinary message text is otherwise left untouched.
     */
    fun canonicalizeMarkers(value: String): String {
        var normalized = Normalizer.normalize(value, Normalizer.Form.NFC)
        normalized = CLOSE_VARIANT.replace(normalized, CLOSE)
        normalized = OPEN_VARIANT.replace(normalized, OPEN)
        return normalized
    }

    /**
     * Presentation fail-safe: structural jar syntax is editor/storage data, never user-facing chat
     * text.  A malformed marker pair degrades to its content rather than leaking `[🫙]` tokens.
     */
    fun stripJarMarkersForDisplay(value: String): String = canonicalizeMarkers(value)
        .replace(OPEN, "")
        .replace(CLOSE, "")

    data class ToggleResult(
        val text: String,
        val selectionStart: Int,
        val selectionEnd: Int,
        val action: String,
    )

    private data class ContainerRange(
        val openStart: Int,
        val contentStart: Int,
        val contentEnd: Int,
        val closeEnd: Int,
    )

    fun key(threadId: String, message: ClientChatStoredMessage): String = sha256(
        "$threadId|${message.fromUser}|${message.createdAtEpochMs}|${message.sourceRequestId}|${message.text}",
    )

    fun key(threadId: String, fromUser: Boolean, createdAtEpochMs: Long, sourceRequestId: String, text: String): String =
        sha256("$threadId|$fromUser|$createdAtEpochMs|$sourceRequestId|$text")

    fun resolve(context: Context, key: String, originalText: String): String? {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(key, null) ?: return null
        return runCatching {
            val json = JSONObject(raw)
            if (json.optString("originalSha256") != sha256(originalText)) {
                quarantine(app, key, raw, "ORIGINAL_HASH_MISMATCH")
                prefs.edit().remove(key).apply()
                return@runCatching null
            }
            val schema = json.optString("schema")
            // R73 v2 overlays are conservatively quarantined once.  That release is known to crash
            // when a persisted container is re-rendered; preserving the raw overlay outside the
            // active store lets the chat recover without destroying the original message.
            if (schema != ACTIVE_SCHEMA) {
                quarantine(app, key, raw, "LEGACY_OR_UNSAFE_SCHEMA:$schema")
                prefs.edit().remove(key).apply()
                return@runCatching null
            }
            val formatted = canonicalizeMarkers(json.optString("formattedText"))
            if (!isStructurallySafe(formatted)) {
                quarantine(app, key, raw, "STRUCTURE_VALIDATION_FAILED")
                prefs.edit().remove(key).apply()
                return@runCatching null
            }
            formatted.takeIf(String::isNotBlank)
        }.getOrElse {
            quarantine(app, key, raw, "OVERLAY_PARSE_FAILED")
            prefs.edit().remove(key).apply()
            null
        }
    }

    fun put(context: Context, key: String, originalText: String, formattedText: String) {
        val canonical = canonicalizeMarkers(formattedText)
        if (canonical == originalText) {
            remove(context, key)
            return
        }
        require(isStructurallySafe(canonical)) { "CODE_CONTAINER_STRUCTURE_INVALID" }
        val payload = JSONObject()
            .put("schema", ACTIVE_SCHEMA)
            .put("originalSha256", sha256(originalText))
            .put("formattedText", canonical)
            .put("updatedAtEpochMs", System.currentTimeMillis())
            .toString()
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(key, payload).apply()
    }

    fun remove(context: Context, key: String) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(key).apply()
    }

    /** True when 🫙 can either wrap a selection or unwrap the container under/intersecting it. */
    fun canToggle(value: String, start: Int, end: Int): Boolean = runCatching {
        val text = canonicalizeMarkers(value)
        if (!isStructurallySafe(text)) return@runCatching false
        val (safeStart, safeEnd) = normalizedRange(text, start, end)
        safeStart != safeEnd || findIntersectingContainer(text, safeStart, safeEnd) != null
    }.getOrDefault(false)

    /**
     * Toggle one structural code container. A non-collapsed selection is wrapped when it does not
     * intersect an existing container. A cursor/selection anywhere inside an existing container
     * unwraps that whole container. The returned selection always refers to the returned text.
     */
    fun toggleCodeContainer(value: String, start: Int, end: Int): ToggleResult = runCatching {
        val text = canonicalizeMarkers(value)
        if (!isStructurallySafe(text)) return@runCatching ToggleResult(text, start.coerceIn(0, text.length), end.coerceIn(0, text.length), "NOOP")
        val (safeStart, safeEnd) = normalizedRange(text, start, end)
        val existing = findIntersectingContainer(text, safeStart, safeEnd)
        if (existing != null) {
            val content = text.substring(existing.contentStart, existing.contentEnd)
            val next = text.substring(0, existing.openStart) + content + text.substring(existing.closeEnd)
            val nextStart = existing.openStart.coerceAtMost(next.length)
            val nextEnd = (nextStart + content.length).coerceAtMost(next.length)
            return@runCatching ToggleResult(next, nextStart, nextEnd, "UNWRAP")
        }
        if (safeStart == safeEnd) return@runCatching ToggleResult(text, safeStart, safeEnd, "NOOP")
        if (containers(text).size >= MAX_CONTAINERS_PER_MESSAGE) return@runCatching ToggleResult(text, safeStart, safeEnd, "NOOP")
        val selected = text.substring(safeStart, safeEnd)
        val next = text.substring(0, safeStart) + OPEN + selected + CLOSE + text.substring(safeEnd)
        if (!isStructurallySafe(next)) return@runCatching ToggleResult(text, safeStart, safeEnd, "NOOP")
        val contentStart = (safeStart + OPEN.length).coerceIn(0, next.length)
        val contentEnd = (contentStart + selected.length).coerceIn(contentStart, next.length)
        ToggleResult(next, contentStart, contentEnd, "WRAP")
    }.getOrElse { ToggleResult(canonicalizeMarkers(value), start.coerceIn(0, canonicalizeMarkers(value).length), end.coerceIn(0, canonicalizeMarkers(value).length), "NOOP") }

    /** Remove the structural/manual or imported fenced code container that covers [position]. */
    fun unwrapContainerAt(value: String, position: Int): ToggleResult {
        val text = canonicalizeMarkers(value)
        val safe = position.coerceIn(0, text.length)
        findIntersectingContainer(text, safe, safe)?.let { range ->
            return toggleCodeContainer(text, range.contentStart, range.contentEnd)
        }
        val fence = findFenceAt(text, safe)
        if (fence != null) {
            val (start, contentStart, contentEnd, end) = fence
            val content = text.substring(contentStart, contentEnd).removeSuffix("\n")
            val next = text.substring(0, start) + content + text.substring(end)
            return ToggleResult(next, start, (start + content.length).coerceAtMost(next.length), "UNWRAP_FENCE")
        }
        return ToggleResult(text, safe, safe, "NOOP")
    }

    /** Convert durable editor markers into standard fenced code for LALM/tool-facing context. */
    fun toModelText(value: String): String = runCatching {
        val text = canonicalizeMarkers(value)
        if (OPEN !in text || !isStructurallySafe(text)) return@runCatching text
        val out = StringBuilder(text.length)
        var cursor = 0
        while (cursor < text.length) {
            val open = text.indexOf(OPEN, cursor)
            if (open < 0) {
                out.append(text.substring(cursor))
                break
            }
            out.append(text.substring(cursor, open))
            val contentStart = open + OPEN.length
            val close = text.indexOf(CLOSE, contentStart)
            if (close < 0) {
                out.append(text.substring(open))
                break
            }
            val code = text.substring(contentStart, close)
            val language = detectLanguage(code).takeUnless { it == "text" }.orEmpty()
            out.append("```").append(language).append('\n')
            out.append(code)
            if (!code.endsWith("\n")) out.append('\n')
            out.append("```")
            cursor = close + CLOSE.length
        }
        out.toString()
    }.getOrDefault(value)


    sealed interface DisplaySegment {
        val sourceStart: Int
        val sourceEnd: Int

        data class Text(
            val text: String,
            override val sourceStart: Int,
            override val sourceEnd: Int,
        ) : DisplaySegment

        data class Code(
            val language: String,
            val code: String,
            override val sourceStart: Int,
            override val sourceEnd: Int,
        ) : DisplaySegment
    }

    /**
     * Convert sent/history storage text into presentation segments. Structural jar markers are never
     * returned as visible Text segments. Imported fenced Markdown converges on the same Code type.
     */
    fun parseDisplaySegments(value: String): List<DisplaySegment> = runCatching {
        val text = canonicalizeMarkers(value)
        if (text.isEmpty()) return@runCatching listOf(DisplaySegment.Text("", 0, 0))
        if (!isStructurallySafe(text)) {
            val safe = stripJarMarkersForDisplay(text)
            return@runCatching listOf(DisplaySegment.Text(safe, 0, safe.length))
        }
        val out = ArrayList<DisplaySegment>()
        var cursor = 0
        while (cursor < text.length) {
            val markerStart = text.indexOf(OPEN, cursor).takeIf { it >= 0 }
            val fenceStart = text.indexOf("```", cursor).takeIf { it >= 0 }
            val nextStart = listOfNotNull(markerStart, fenceStart).minOrNull()
            if (nextStart == null) {
                out += DisplaySegment.Text(text.substring(cursor), cursor, text.length)
                break
            }
            if (nextStart > cursor) out += DisplaySegment.Text(text.substring(cursor, nextStart), cursor, nextStart)
            if (markerStart != null && markerStart == nextStart) {
                val contentStart = markerStart + OPEN.length
                val close = text.indexOf(CLOSE, contentStart)
                if (close < 0) {
                    val safe = stripJarMarkersForDisplay(text.substring(markerStart))
                    out += DisplaySegment.Text(safe, markerStart, text.length)
                    break
                }
                val end = close + CLOSE.length
                val code = text.substring(contentStart, close)
                out += DisplaySegment.Code(detectLanguage(code), code, markerStart, end)
                cursor = end
                continue
            }
            val firstLineEnd = text.indexOf('\n', nextStart + 3)
            if (firstLineEnd < 0) {
                out += DisplaySegment.Text(text.substring(nextStart), nextStart, text.length)
                break
            }
            val language = text.substring(nextStart + 3, firstLineEnd).trim().take(32).ifBlank { "code" }
            val close = text.indexOf("```", firstLineEnd + 1)
            if (close < 0) {
                out += DisplaySegment.Text(text.substring(nextStart), nextStart, text.length)
                break
            }
            val end = close + 3
            val code = text.substring(firstLineEnd + 1, close).removeSuffix("\n")
            out += DisplaySegment.Code(language, code, nextStart, end)
            cursor = end
        }
        out.ifEmpty { listOf(DisplaySegment.Text(stripJarMarkersForDisplay(text), 0, text.length)) }
    }.getOrElse {
        val safe = stripJarMarkersForDisplay(value)
        listOf(DisplaySegment.Text(safe, 0, safe.length))
    }

    fun detectLanguage(code: String): String = when {
        Regex("\\b(fun|val|var|suspend|data class|object)\\b").containsMatchIn(code) -> "kotlin"
        Regex("\\b(public|private|class|void|static)\\b").containsMatchIn(code) && ";" in code -> "java"
        Regex("(^|\\n)\\s*(\\{|\\[)|\"[A-Za-z0-9_ -]+\"\\s*:").containsMatchIn(code) -> "json"
        Regex("\\b(def|import|from|print|None|True|False)\\b").containsMatchIn(code) -> "python"
        Regex("</?[A-Za-z][^>]*>").containsMatchIn(code) -> "html"
        Regex("\\b(const|let|function|=>)\\b").containsMatchIn(code) -> "javascript"
        else -> "text"
    }

    private fun normalizedRange(value: String, start: Int, end: Int): Pair<Int, Int> {
        val a = minOf(start, end).coerceIn(0, value.length)
        val b = maxOf(start, end).coerceIn(a, value.length)
        return a to b
    }

    private fun containers(value: String): List<ContainerRange> {
        val out = ArrayList<ContainerRange>()
        var cursor = 0
        while (cursor < value.length) {
            val open = value.indexOf(OPEN, cursor)
            if (open < 0) break
            val contentStart = open + OPEN.length
            val close = value.indexOf(CLOSE, contentStart)
            if (close < 0) break
            out += ContainerRange(open, contentStart, close, close + CLOSE.length)
            cursor = close + CLOSE.length
        }
        return out
    }

    private fun findIntersectingContainer(value: String, start: Int, end: Int): ContainerRange? {
        val collapsed = start == end
        return containers(value).firstOrNull { range ->
            if (collapsed) start in range.openStart..range.closeEnd
            else start < range.closeEnd && end > range.openStart
        }
    }

    /** start, contentStart, contentEnd, end */
    private fun findFenceAt(value: String, position: Int): IntArray? {
        var cursor = 0
        while (cursor < value.length) {
            val start = value.indexOf("```", cursor)
            if (start < 0) return null
            val firstLineEnd = value.indexOf('\n', start + 3)
            if (firstLineEnd < 0) return null
            val close = value.indexOf("```", firstLineEnd + 1)
            if (close < 0) return null
            val end = close + 3
            if (position in start..end) return intArrayOf(start, firstLineEnd + 1, close, end)
            cursor = end
        }
        return null
    }

    fun isStructurallySafe(value: String): Boolean = runCatching {
        var cursor = 0
        var count = 0
        while (cursor < value.length) {
            val open = value.indexOf(OPEN, cursor)
            val strayClose = value.indexOf(CLOSE, cursor)
            if (open < 0) return@runCatching strayClose < 0
            if (strayClose in cursor until open) return@runCatching false
            val contentStart = open + OPEN.length
            val close = value.indexOf(CLOSE, contentStart)
            if (close < 0) return@runCatching false
            if (value.indexOf(OPEN, contentStart) in contentStart until close) return@runCatching false
            count += 1
            if (count > MAX_CONTAINERS_PER_MESSAGE) return@runCatching false
            cursor = close + CLOSE.length
        }
        true
    }.getOrDefault(false)

    private fun quarantine(context: Context, key: String, raw: String, reason: String) {
        runCatching {
            val payload = JSONObject()
                .put("schema", "swrlz-message-structure-overlay-quarantine-v1")
                .put("reason", reason.take(160))
                .put("quarantinedAtEpochMs", System.currentTimeMillis())
                .put("rawOverlay", raw)
                .toString()
            context.applicationContext.getSharedPreferences(QUARANTINE_PREFS, Context.MODE_PRIVATE)
                .edit().putString(key, payload).apply()
        }
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
