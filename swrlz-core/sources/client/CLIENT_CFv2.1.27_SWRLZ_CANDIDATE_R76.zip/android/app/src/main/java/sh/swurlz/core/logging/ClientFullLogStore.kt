package sh.swurlz.core.logging

import android.content.Context
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.File
import java.security.DigestOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.atomic.AtomicLong
import org.json.JSONObject
import sh.swurlz.core.BuildConfig

data class ClientLogSubmenuSpec(val key: String, val label: String)
data class ClientLogMenuSpec(val key: String, val label: String, val submenus: List<ClientLogSubmenuSpec>)

data class ClientFullLogSummary(
    val enabled: Boolean,
    val activePath: String,
    val activeBytes: Long,
    val eventCount: Long,
    val rotatedFiles: Int,
    val maxBytes: Long,
    val totalCapBytes: Long,
)

data class ClientFullLogCapture(val bytesWritten: Long, val sha256: String, val eventCount: Long)

/**
 * App-private rotating CLIENT diagnostic journal with hierarchical operator filters.
 * Master logger -> app menu -> subsystem. Unknown/future categories default enabled so new
 * instrumentation is not silently discarded before a Settings control is added.
 */
object ClientFullLogStore {
    private const val PREFS = "swrlz_full_log"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_RUNTIME_TRACE_ENABLED = "runtime_trace_enabled_v1"
    private const val MAX_ACTIVE_BYTES = 8L * 1024L * 1024L
    private const val MAX_ROTATED_FILES = 4
    private const val ACTIVE_NAME = "client-full-current.ndjson"
    private val sequence = AtomicLong(0L)

    private val menuSpecs = listOf(
        ClientLogMenuSpec("CORE", "Core", listOf(
            ClientLogSubmenuSpec("LIFECYCLE", "Lifecycle / process"),
            ClientLogSubmenuSpec("DIAGNOSTIC", "SWRLZ runtime diagnostic trace"),
        )),
        ClientLogMenuSpec("CHAT", "Chat", listOf(ClientLogSubmenuSpec("MESSAGES", "Messages / persistence"))),
        ClientLogMenuSpec("LLM", "LLM", listOf(
            ClientLogSubmenuSpec("STREAM", "Stream lifecycle"),
            ClientLogSubmenuSpec("FALLBACK", "Fallback / retry"),
            ClientLogSubmenuSpec("RUNTIME", "Runtime / routing"),
        )),
        ClientLogMenuSpec("NODES", "Nodes", listOf(
            ClientLogSubmenuSpec("REGISTRATION", "Registration / rebind"),
            ClientLogSubmenuSpec("HEARTBEAT", "Heartbeat / presence"),
            ClientLogSubmenuSpec("TRANSPORT", "HTTP transport"),
        )),
        ClientLogMenuSpec("GROUPS", "Groups", listOf(ClientLogSubmenuSpec("RUNTIME", "Group runtime"))),
        ClientLogMenuSpec("MISSIONS", "Missions", listOf(ClientLogSubmenuSpec("RUNTIME", "Mission runtime"))),
        ClientLogMenuSpec("ACTIVITY", "Activity", listOf(ClientLogSubmenuSpec("RUNTIME", "Activity events"))),
        ClientLogMenuSpec("FORGE", "Forge", listOf(
            ClientLogSubmenuSpec("UPLOADS", "Uploads"),
            ClientLogSubmenuSpec("WORKFLOWS", "Build workflows"),
            ClientLogSubmenuSpec("REPOSITORY", "Repository"),
        )),
        ClientLogMenuSpec("TOOLS", "Tools", listOf(
            ClientLogSubmenuSpec("DIRECTORY_VFS", "Directory VFS"),
            ClientLogSubmenuSpec("ARCHIVE_VFS", "Archive VFS"),
            ClientLogSubmenuSpec("RECOVERY", "Recovery"),
            ClientLogSubmenuSpec("ANALYSIS", "Deep Dig / analysis"),
            ClientLogSubmenuSpec("AUTHORITY", "Approval / authority"),
            ClientLogSubmenuSpec("NOTIFICATION", "Tool notifications"),
        )),
        ClientLogMenuSpec("SETTINGS", "Settings", listOf(ClientLogSubmenuSpec("RUNTIME", "Settings changes"))),
    )

    fun menuSpecs(): List<ClientLogMenuSpec> = menuSpecs

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
        if (enabled) append(context, "INFO", "APP", "logging_enabled", "Developer Logger enabled for CLIENT.")
    }

    fun isRuntimeTraceEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_RUNTIME_TRACE_ENABLED, false)

    fun setRuntimeTraceEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_RUNTIME_TRACE_ENABLED, enabled).apply()
        append(context, "INFO", "APP", "trace_setting_changed", "Structured CLIENT runtime diagnostic trace ${if (enabled) "enabled" else "disabled"}; credentials and private reasoning text remain excluded.", mapOf("enabled" to enabled))
    }

    fun runtimeTrace(context: Context, event: String, detail: String = "", fields: Map<String, Any?> = emptyMap()) {
        if (!isRuntimeTraceEnabled(context)) return
        append(context, "DEBUG", "APP", "trace_${event.take(72)}", detail, fields)
    }

    fun isMenuEnabled(context: Context, menu: String): Boolean =
        prefs(context).getBoolean("menu_${menu.uppercase(Locale.US)}", true)

    fun setMenuEnabled(context: Context, menu: String, enabled: Boolean) {
        prefs(context).edit().putBoolean("menu_${menu.uppercase(Locale.US)}", enabled).apply()
    }

    fun isSubmenuEnabled(context: Context, menu: String, submenu: String): Boolean =
        prefs(context).getBoolean("submenu_${menu.uppercase(Locale.US)}_${submenu.uppercase(Locale.US)}", true)

    fun setSubmenuEnabled(context: Context, menu: String, submenu: String, enabled: Boolean) {
        prefs(context).edit().putBoolean("submenu_${menu.uppercase(Locale.US)}_${submenu.uppercase(Locale.US)}", enabled).apply()
    }

    @Synchronized
    fun append(
        context: Context,
        level: String,
        category: String,
        event: String,
        detail: String = "",
        fields: Map<String, Any?> = emptyMap(),
    ) {
        val app = context.applicationContext
        if (!isEnabled(app)) return
        val menu = menuFor(category)
        val submenu = submenuFor(category, event)
        if (!isMenuEnabled(app, menu) || !isSubmenuEnabled(app, menu, submenu)) return

        val dir = directory(app)
        val active = File(dir, ACTIVE_NAME)
        val objectLine = JSONObject()
            .put("schema", "swrlz-client-full-log-v2")
            .put("sequence", nextSequence(app))
            .put("timestampEpochMs", System.currentTimeMillis())
            .put("versionName", BuildConfig.VERSION_NAME)
            .put("versionCode", BuildConfig.VERSION_CODE)
            .put("revision", BuildConfig.SWRLZ_REVISION)
            .put("level", level.uppercase(Locale.US).take(16))
            .put("menu", menu)
            .put("submenu", submenu)
            .put("category", category.uppercase(Locale.US).take(32))
            .put("event", event.take(96))
            .put("detail", redactForLog(detail).take(65_536))
        fields.forEach { (key, value) ->
            val safeKey = key.take(80)
            if (isSecretFieldName(safeKey)) {
                objectLine.put(safeKey, "REDACTED")
            } else {
                when (value) {
                    null -> objectLine.put(safeKey, JSONObject.NULL)
                    is Number, is Boolean -> objectLine.put(safeKey, value)
                    else -> objectLine.put(safeKey, redactForLog(value.toString()).take(16_384))
                }
            }
        }
        val bytes = (objectLine.toString() + "\n").toByteArray(Charsets.UTF_8)
        rotateIfNeeded(dir, active, bytes.size.toLong())
        active.appendBytes(bytes)
    }

    fun info(context: Context, category: String, event: String, detail: String = "", fields: Map<String, Any?> = emptyMap()) =
        append(context, "INFO", category, event, detail, fields)
    fun warn(context: Context, category: String, event: String, detail: String = "", fields: Map<String, Any?> = emptyMap()) =
        append(context, "WARN", category, event, detail, fields)
    fun error(context: Context, category: String, event: String, detail: String = "", fields: Map<String, Any?> = emptyMap()) =
        append(context, "ERROR", category, event, detail, fields)

    @Synchronized
    fun summary(context: Context): ClientFullLogSummary {
        val app = context.applicationContext
        val dir = directory(app)
        val active = File(dir, ACTIVE_NAME)
        return ClientFullLogSummary(
            enabled = isEnabled(app),
            activePath = active.absolutePath,
            activeBytes = if (active.isFile) active.length() else 0L,
            eventCount = maxOf(sequence.get(), readLastSequence(dir)),
            rotatedFiles = (1..MAX_ROTATED_FILES).count { File(dir, "client-full.$it.ndjson").isFile },
            maxBytes = MAX_ACTIVE_BYTES,
            totalCapBytes = MAX_ACTIVE_BYTES * (MAX_ROTATED_FILES + 1L),
        )
    }

    @Synchronized
    fun clear(context: Context) {
        val dir = directory(context.applicationContext)
        captureFilesOldestFirst(dir).forEach { if (it.exists()) it.delete() }
        sequence.set(0L)
    }

    @Synchronized
    fun capture(context: Context, destination: Uri): ClientFullLogCapture {
        val app = context.applicationContext
        val dir = directory(app)
        val digest = MessageDigest.getInstance("SHA-256")
        var written = 0L
        val output = app.contentResolver.openOutputStream(destination, "w") ?: error("Unable to open CLIENT log destination")
        DigestOutputStream(BufferedOutputStream(output), digest).use { stream ->
            val header = JSONObject()
                .put("schema", "swrlz-client-full-log-capture-v2")
                .put("capturedAtEpochMs", System.currentTimeMillis())
                .put("versionName", BuildConfig.VERSION_NAME)
                .put("versionCode", BuildConfig.VERSION_CODE)
                .put("revision", BuildConfig.SWRLZ_REVISION)
                .put("hierarchicalFilters", true)
                .put("chatContentIncluded", true)
                .put("credentialsIncluded", false)
                .put("privateReasoningIncluded", false)
                .put("structuredRuntimeTraceEnabled", isRuntimeTraceEnabled(app))
                .put("note", "Developer diagnostic ledger. Raw credentials, device proof, authorization headers, and private keys are excluded by contract.")
                .toString() + "\n"
            val headerBytes = header.toByteArray(Charsets.UTF_8)
            stream.write(headerBytes); written += headerBytes.size
            captureFilesOldestFirst(dir).filter(File::isFile).forEach { file -> file.inputStream().use { input -> written += input.copyTo(stream) } }
        }
        return ClientFullLogCapture(written, digest.digest().joinToString("") { "%02x".format(it) }, sequence.get())
    }

    fun suggestedExportName(): String = "SWRLZ_CLIENT_DEV_LOG_${timestamp()}.ndjson"

    private fun menuFor(category: String): String = when (category.uppercase(Locale.US)) {
        "APP" -> "CORE"
        "LALM" -> "LLM"
        "REGISTRATION", "PRESENCE", "HTTP" -> "NODES"
        else -> category.uppercase(Locale.US).take(32)
    }

    private fun submenuFor(category: String, event: String): String {
        val cat = category.uppercase(Locale.US)
        val ev = event.lowercase(Locale.US)
        return when (cat) {
            "APP" -> if (ev.startsWith("trace_")) "DIAGNOSTIC" else "LIFECYCLE"
            "CHAT" -> "MESSAGES"
            "REGISTRATION" -> "REGISTRATION"
            "PRESENCE" -> "HEARTBEAT"
            "HTTP" -> "TRANSPORT"
            "LALM" -> when {
                ev.startsWith("stream_") -> "STREAM"
                ev.startsWith("legacy_") || ev.contains("retry") || ev.contains("fallback") -> "FALLBACK"
                else -> "RUNTIME"
            }
            "FORGE" -> when {
                ev.contains("upload") -> "UPLOADS"
                ev.contains("workflow") || ev.contains("build") -> "WORKFLOWS"
                ev.contains("repo") -> "REPOSITORY"
                else -> "WORKFLOWS"
            }
            "TOOLS" -> when {
                ev.contains("notification") -> "NOTIFICATION"
                ev.contains("recovery") -> "RECOVERY"
                ev.contains("deep_dig") || ev.contains("analysis") -> "ANALYSIS"
                ev.contains("approval") || ev.contains("authority") || ev.contains("plan") -> "AUTHORITY"
                ev.contains("archive") -> "ARCHIVE_VFS"
                else -> "DIRECTORY_VFS"
            }
            else -> "RUNTIME"
        }
    }

    private fun isSecretFieldName(name: String): Boolean {
        val normalized = name.lowercase(Locale.US).replace("-", "_").replace(" ", "_")
        return listOf("password", "passphrase", "secret", "token", "authorization", "api_key", "apikey", "private_key", "runtime_key", "credential_blob").any(normalized::contains)
    }

    private fun redactForLog(value: String): String {
        var safe = value
        val assignments = Regex("(?i)(authorization|bearer|token|password|passphrase|secret|api[_ -]?key|private[_ -]?key|runtime[_ -]?key)\\s*[:=]\\s*([^\\s,;]+)")
        safe = safe.replace(assignments) { match -> "${match.groupValues[1]}=REDACTED" }
        safe = safe.replace(Regex("\\bsk-(?:proj-)?[A-Za-z0-9_-]{12,}\\b"), "OPENAI_KEY_REDACTED")
        safe = safe.replace(Regex("\\bgh[pousr]_[A-Za-z0-9_]{16,}\\b", RegexOption.IGNORE_CASE), "GITHUB_TOKEN_REDACTED")
        return safe
    }

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun directory(context: Context): File = File(context.noBackupFilesDir, "full-logs").apply { mkdirs() }
    private fun nextSequence(context: Context): Long {
        if (sequence.get() == 0L) sequence.compareAndSet(0L, readLastSequence(directory(context)))
        return sequence.incrementAndGet()
    }
    private fun readLastSequence(dir: File): Long = captureFilesOldestFirst(dir).asReversed().firstNotNullOfOrNull { file ->
        if (!file.isFile) null else runCatching { file.useLines { lines -> lines.lastOrNull() } }.getOrNull()
    }?.let { line -> runCatching { JSONObject(line).optLong("sequence", 0L) }.getOrDefault(0L) } ?: 0L
    private fun rotateIfNeeded(dir: File, active: File, incoming: Long) {
        if ((if (active.isFile) active.length() else 0L) + incoming < MAX_ACTIVE_BYTES) return
        for (index in MAX_ROTATED_FILES downTo 2) {
            val prev = File(dir, "client-full.${index - 1}.ndjson")
            val next = File(dir, "client-full.$index.ndjson")
            if (next.exists()) next.delete()
            if (prev.exists()) prev.renameTo(next)
        }
        val first = File(dir, "client-full.1.ndjson")
        if (first.exists()) first.delete()
        if (active.exists()) active.renameTo(first)
    }
    private fun captureFilesOldestFirst(dir: File): List<File> = buildList {
        for (index in MAX_ROTATED_FILES downTo 1) add(File(dir, "client-full.$index.ndjson"))
        add(File(dir, ACTIVE_NAME))
    }
    private fun timestamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
}
