package sh.swurlz.core.data

import android.content.Context
import android.util.AtomicFile
import sh.swurlz.core.logging.ClientFullLogStore
import sh.swrlz.llm.SwrlzLalmHistoryMessageV1
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ClientChatTraceStep(
    val key: String,
    val label: String,
    val detail: String,
    val firstSeenAtEpochMs: Long,
    val lastSeenAtEpochMs: Long,
    val eventCount: Int,
)

data class ClientChatStoredMessage(
    val fromUser: Boolean,
    val text: String,
    val createdAtEpochMs: Long,
    val sourceRequestId: String = "",
    val responseTotalMs: Long? = null,
    val firstTextMs: Long? = null,
    val route: String = "",
    val truthCapsuleId: String = "",
    val executionTrace: List<ClientChatTraceStep> = emptyList(),
)

data class ClientChatThreadSummary(
    val threadId: String,
    val title: String,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long,
    val messageCount: Int,
    val originType: String = "SWRLZ_NATIVE",
    val syncExcluded: Boolean = false,
)

data class ClientChatHistoryDocument(
    val currentThreadId: String,
    val threads: List<ClientChatThreadSummary>,
)

/**
 * CLIENT-side chat continuity store. SERVER keeps its richer Room/evidence model; this
 * store gives the CLIENT its own local thread continuity without making SERVER state
 * authoritative for CLIENT-only UI history.
 */
object ClientChatHistoryStore {
    private const val SCHEMA = "swrlz-client-chat-history-v3"
    private const val BOOTSTRAP_MESSAGE_FRAGMENT_CHARS = 160_000
    private const val DEFAULT_GREETING = "§wyrlz is ready locally. I’ll attach SERVER tools, capabilities, and conversation continuity when the link is available."
    private var lastLoggedCommitFingerprint: String? = null
    private val revisionMutable = MutableStateFlow(0L)
    val historyRevisionFlow: StateFlow<Long> = revisionMutable.asStateFlow()

    /** Signals Compose/other observers when native or imported chat history changes. */
    fun notifyExternalChange() {
        revisionMutable.value = revisionMutable.value + 1L
    }

    private fun file(context: Context): File = File(context.applicationContext.filesDir, "chat/client-chat-history.json").also {
        it.parentFile?.mkdirs()
    }

    @Synchronized
    fun ensure(context: Context): ClientChatHistoryDocument {
        val root = readRoot(context)
        val threads = root.optJSONArray("threads") ?: JSONArray()
        if (threads.length() == 0) {
            val threadId = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            val thread = JSONObject()
                .put("threadId", threadId)
                .put("title", "New chat")
                .put("createdAtEpochMs", now)
                .put("updatedAtEpochMs", now)
                .put("messages", JSONArray().put(messageJson(false, DEFAULT_GREETING, now)))
            threads.put(thread)
            root.put("threads", threads).put("currentThreadId", threadId)
            writeRoot(context, root)
        } else if (root.optString("currentThreadId").isBlank()) {
            root.put("currentThreadId", threads.optJSONObject(0)?.optString("threadId").orEmpty())
            writeRoot(context, root)
        }
        return document(root)
    }

    @Synchronized
    fun listThreads(context: Context): List<ClientChatThreadSummary> {
        val native = document(readEnsuredRoot(context)).threads
        val imported = ImportedChatHistoryStore.list(context).map { row ->
            ClientChatThreadSummary(
                threadId = row.threadId,
                title = row.title,
                createdAtEpochMs = row.createdAtEpochMs,
                updatedAtEpochMs = row.updatedAtEpochMs,
                messageCount = row.messageCount,
                originType = "OPENAI_EXPORT",
                syncExcluded = row.syncExcluded,
            )
        }
        return (native + imported).sortedByDescending { it.updatedAtEpochMs }
    }

    /** Per-thread account-sync policy. Imported history can remain local without affecting other threads. */
    @Synchronized
    fun setThreadSyncExcluded(context: Context, threadId: String, excluded: Boolean): Boolean {
        if (!ImportedChatHistoryStore.exists(context, threadId)) return false
        return ImportedChatHistoryStore.setSyncExcluded(context, threadId, excluded)
    }

    @Synchronized
    fun currentThreadId(context: Context): String = readEnsuredRoot(context).optString("currentThreadId")

    /**
     * CLIENT-local continuity used for one-time SERVER chat bootstrap.
     *
     * Native chat continuity remains available across threads, while an imported target thread is
     * hydrated explicitly and in isolation. This avoids ever walking every imported conversation
     * body merely because one historical thread is opened. User-authored structure overlays are
     * applied to the bootstrap view without mutating the immutable imported source record.
     */
    @Synchronized
    fun bootstrapMessages(context: Context, targetThreadId: String = ""): List<SwrlzLalmHistoryMessageV1> {
        val root = readEnsuredRoot(context)
        val threads = root.optJSONArray("threads") ?: JSONArray()
        val result = ArrayList<SwrlzLalmHistoryMessageV1>()
        for (threadIndex in 0 until threads.length()) {
            val thread = threads.optJSONObject(threadIndex) ?: continue
            val threadId = thread.optString("threadId").trim()
            if (threadId.isBlank()) continue
            val title = thread.optString("title", "New chat").trim().take(160)
            val messages = thread.optJSONArray("messages") ?: JSONArray()
            val untouchedFallbackOnly = messages.length() == 1 &&
                messages.optJSONObject(0)?.optBoolean("fromUser", false) != true &&
                messages.optJSONObject(0)?.optString("text", "") == DEFAULT_GREETING
            if (untouchedFallbackOnly) continue
            for (messageIndex in 0 until messages.length()) {
                val message = messages.optJSONObject(messageIndex) ?: continue
                val rawText = message.optString("text", "")
                val fromUser = message.optBoolean("fromUser", false)
                val createdAt = message.optLong("createdAtEpochMs", 0L)
                val sourceRequestId = message.optString("sourceRequestId", "")
                val overlayKey = ClientMessageStructureOverlayStore.key(
                    threadId = threadId,
                    fromUser = fromUser,
                    createdAtEpochMs = createdAt,
                    sourceRequestId = sourceRequestId,
                    text = rawText,
                )
                val effectiveText = ClientMessageStructureOverlayStore.resolve(context, overlayKey, rawText) ?: rawText
                val text = ClientMessageStructureOverlayStore.toModelText(effectiveText)
                appendBootstrapMessage(result, threadId, title, messageIndex, if (fromUser) "USER" else "ASSISTANT", text, createdAt)
            }
        }

        val target = targetThreadId.trim()
        val importedTarget = target.takeIf(String::isNotBlank)?.let { id ->
            ImportedChatHistoryStore.list(context).firstOrNull { it.threadId == id }
        }
        if (importedTarget != null) {
            val title = importedTarget.title.trim().take(160).ifBlank { "Imported chat" }
            ImportedChatHistoryStore.messages(context, target).forEachIndexed { messageIndex, message ->
                val overlayKey = ClientMessageStructureOverlayStore.key(target, message.fromUser, message.createdAtEpochMs, message.sourceRequestId, message.text)
                val effectiveText = ClientMessageStructureOverlayStore.resolve(context, overlayKey, message.text) ?: message.text
                val text = ClientMessageStructureOverlayStore.toModelText(effectiveText)
                appendBootstrapMessage(result, target, title, messageIndex, if (message.fromUser) "USER" else "ASSISTANT", text, message.createdAtEpochMs)
            }
        }
        return result
    }

    private fun appendBootstrapMessage(
        result: MutableList<SwrlzLalmHistoryMessageV1>,
        threadId: String,
        title: String,
        messageIndex: Int,
        role: String,
        text: String,
        createdAt: Long,
    ) {
        if (text.length <= BOOTSTRAP_MESSAGE_FRAGMENT_CHARS) {
            result += SwrlzLalmHistoryMessageV1(threadId, title, messageIndex * 1000, role, text, createdAt)
        } else {
            text.chunked(BOOTSTRAP_MESSAGE_FRAGMENT_CHARS).forEachIndexed { partIndex, part ->
                result += SwrlzLalmHistoryMessageV1(threadId, title, messageIndex * 1000 + partIndex, role, part, createdAt)
            }
        }
    }

    /** Replace only the untouched local fallback greeting after SERVER bootstrap succeeds. */
    @Synchronized
    fun applyOrientationGreeting(context: Context, threadId: String, greeting: String, bootstrapId: String): Boolean {
        if (ImportedChatHistoryStore.exists(context, threadId)) return false
        val clean = greeting.trim()
        if (clean.isBlank()) return false
        val root = readEnsuredRoot(context)
        val thread = findThread(root, threadId) ?: return false
        val messages = thread.optJSONArray("messages") ?: JSONArray().also { thread.put("messages", it) }
        val hasUser = (0 until messages.length()).any { index -> messages.optJSONObject(index)?.optBoolean("fromUser", false) == true }
        if (hasUser) return false
        if (messages.length() > 1) return false
        messages.remove(0)
        messages.put(messageJson(false, clean, System.currentTimeMillis(), "bootstrap:${bootstrapId.take(24)}", route = "LALM_BOOTSTRAP"))
        thread.put("updatedAtEpochMs", System.currentTimeMillis())
        writeRoot(context, root)
        ClientFullLogStore.info(context, "LALM", "orientation_greeting_applied", "SERVER bootstrap orientation greeting committed; content omitted.", mapOf("threadId" to threadId, "bootstrapId" to bootstrapId.take(16), "textChars" to clean.length))
        return true
    }

    @Synchronized
    fun messages(context: Context, threadId: String): List<ClientChatStoredMessage> {
        if (ImportedChatHistoryStore.exists(context, threadId)) return ImportedChatHistoryStore.messages(context, threadId)
        val thread = findThread(readEnsuredRoot(context), threadId) ?: return emptyList()
        val messages = thread.optJSONArray("messages") ?: JSONArray()
        return (0 until messages.length()).mapNotNull { index ->
            val item = messages.optJSONObject(index) ?: return@mapNotNull null
            ClientChatStoredMessage(
                fromUser = item.optBoolean("fromUser", false),
                text = item.optString("text", ""),
                createdAtEpochMs = item.optLong("createdAtEpochMs", 0L),
                sourceRequestId = item.optString("sourceRequestId", ""),
                responseTotalMs = item.optLong("responseTotalMs", -1L).takeIf { it >= 0L },
                firstTextMs = item.optLong("firstTextMs", -1L).takeIf { it >= 0L },
                route = item.optString("route", ""),
                truthCapsuleId = item.optString("truthCapsuleId", ""),
                executionTrace = traceFromJson(item.optJSONArray("executionTrace")),
            )
        }
    }

    @Synchronized
    fun newThread(context: Context): String {
        val root = readEnsuredRoot(context)
        val now = System.currentTimeMillis()
        val threadId = UUID.randomUUID().toString()
        val thread = JSONObject()
            .put("threadId", threadId)
            .put("title", "New chat")
            .put("createdAtEpochMs", now)
            .put("updatedAtEpochMs", now)
            .put("messages", JSONArray().put(messageJson(false, DEFAULT_GREETING, now)))
        root.optJSONArray("threads")!!.put(thread)
        root.put("currentThreadId", threadId)
        writeRoot(context, root)
        return threadId
    }

    @Synchronized
    fun selectThread(context: Context, threadId: String): Boolean {
        val root = readEnsuredRoot(context)
        if (findThread(root, threadId) == null && !ImportedChatHistoryStore.exists(context, threadId)) return false
        root.put("currentThreadId", threadId)
        writeRoot(context, root)
        return true
    }

    @Synchronized
    fun saveMessages(context: Context, threadId: String, messages: List<ClientChatStoredMessage>) {
        if (ImportedChatHistoryStore.exists(context, threadId)) {
            ImportedChatHistoryStore.saveVisibleMessages(context, threadId, messages)
            val root = readEnsuredRoot(context)
            root.put("currentThreadId", threadId)
            writeRoot(context, root)
            return
        }
        val root = readEnsuredRoot(context)
        val thread = findThread(root, threadId) ?: return
        val array = JSONArray()
        messages.forEach { message ->
            array.put(messageJson(
                message.fromUser,
                message.text,
                message.createdAtEpochMs,
                message.sourceRequestId,
                message.responseTotalMs,
                message.firstTextMs,
                message.route,
                message.truthCapsuleId,
                message.executionTrace,
            ))
        }
        val now = System.currentTimeMillis()
        thread.put("messages", array).put("updatedAtEpochMs", now)
        val currentTitle = thread.optString("title", "New chat")
        if (currentTitle == "New chat") {
            val firstUser = messages.firstOrNull { it.fromUser && it.text.isNotBlank() }?.text.orEmpty()
            if (firstUser.isNotBlank()) thread.put("title", deriveTitle(firstUser))
        }
        root.put("currentThreadId", threadId)
        writeRoot(context, root)
        messages.lastOrNull()?.let { last ->
            val fingerprint = listOf(threadId, messages.size.toString(), last.fromUser.toString(), last.createdAtEpochMs.toString(), last.sourceRequestId, last.text).joinToString("|")
            if (lastLoggedCommitFingerprint != fingerprint) {
                lastLoggedCommitFingerprint = fingerprint
                ClientFullLogStore.info(context, "CHAT", if (last.fromUser) "user_message_committed" else "chat_snapshot_saved", "CLIENT chat snapshot committed; message content omitted.", mapOf("threadId" to threadId, "fromUser" to last.fromUser, "messageCount" to messages.size, "sourceRequestId" to last.sourceRequestId, "textChars" to last.text.length, "responseTotalMs" to last.responseTotalMs, "firstTextMs" to last.firstTextMs, "route" to last.route, "truthCapsuleId" to last.truthCapsuleId))
            }
        }
    }

    /**
     * Append exactly one completed assistant response for a SERVER request. sourceRequestId makes
     * Activity recreation/re-attachment idempotent; in-progress streamed text never enters this store.
     */
    @Synchronized
    fun appendAssistantMessage(
        context: Context,
        threadId: String,
        text: String,
        sourceRequestId: String,
        responseTotalMs: Long? = null,
        firstTextMs: Long? = null,
        route: String = "",
        truthCapsuleId: String = "",
        executionTrace: List<ClientChatTraceStep> = emptyList(),
    ): Boolean {
        val committed = text
        if (committed.isBlank()) return false
        if (ImportedChatHistoryStore.exists(context, threadId)) {
            return ImportedChatHistoryStore.appendAssistantMessage(
                context = context,
                threadId = threadId,
                text = committed,
                sourceRequestId = sourceRequestId,
                responseTotalMs = responseTotalMs,
                firstTextMs = firstTextMs,
                route = route,
                truthCapsuleId = truthCapsuleId,
            )
        }
        val root = readEnsuredRoot(context)
        val thread = findThread(root, threadId) ?: return false
        val messages = thread.optJSONArray("messages") ?: JSONArray().also { thread.put("messages", it) }
        if (sourceRequestId.isNotBlank()) {
            for (index in 0 until messages.length()) {
                val existing = messages.optJSONObject(index) ?: continue
                if (existing.optString("sourceRequestId") == sourceRequestId) return false
            }
        }
        val now = System.currentTimeMillis()
        messages.put(messageJson(false, committed, now, sourceRequestId, responseTotalMs, firstTextMs, route, truthCapsuleId, executionTrace))
        thread.put("updatedAtEpochMs", now)
        root.put("currentThreadId", root.optString("currentThreadId"))
        writeRoot(context, root)
        ClientFullLogStore.info(context, "CHAT", "assistant_message_committed", "Completed assistant message committed; content omitted.", mapOf("threadId" to threadId, "sourceRequestId" to sourceRequestId, "textChars" to committed.length, "responseTotalMs" to responseTotalMs, "firstTextMs" to firstTextMs, "route" to route, "truthCapsuleId" to truthCapsuleId))
        return true
    }

    @Synchronized
    fun renameThread(context: Context, threadId: String, title: String) {
        if (ImportedChatHistoryStore.exists(context, threadId)) {
            ImportedChatHistoryStore.rename(context, threadId, title)
            return
        }
        val root = readEnsuredRoot(context)
        val thread = findThread(root, threadId) ?: return
        thread.put("title", title.trim().take(80).ifBlank { "New chat" }).put("updatedAtEpochMs", System.currentTimeMillis())
        writeRoot(context, root)
    }

    @Synchronized
    fun deleteThread(context: Context, threadId: String): String {
        if (ImportedChatHistoryStore.exists(context, threadId)) {
            ImportedChatHistoryStore.delete(context, threadId)
            val root = readEnsuredRoot(context)
            val current = root.optString("currentThreadId")
            val next = if (current == threadId) {
                listThreads(context).firstOrNull()?.threadId ?: root.optJSONArray("threads")?.optJSONObject(0)?.optString("threadId").orEmpty()
            } else current
            root.put("currentThreadId", next)
            writeRoot(context, root)
            return next
        }
        val root = readEnsuredRoot(context)
        val source = root.optJSONArray("threads") ?: JSONArray()
        val kept = JSONArray()
        for (index in 0 until source.length()) {
            val thread = source.optJSONObject(index) ?: continue
            if (thread.optString("threadId") != threadId) kept.put(thread)
        }
        root.put("threads", kept)
        if (kept.length() == 0) {
            val now = System.currentTimeMillis()
            val replacementId = UUID.randomUUID().toString()
            kept.put(
                JSONObject()
                    .put("threadId", replacementId)
                    .put("title", "New chat")
                    .put("createdAtEpochMs", now)
                    .put("updatedAtEpochMs", now)
                    .put("messages", JSONArray().put(messageJson(false, DEFAULT_GREETING, now))),
            )
            root.put("threads", kept).put("currentThreadId", replacementId)
            HistorySyncTombstoneStoreV1.record(context, threadId, "SWRLZ_NATIVE")
            writeRoot(context, root)
            return replacementId
        }
        val current = root.optString("currentThreadId")
        val next = if (current == threadId || findThread(root.put("threads", kept), current) == null) {
            kept.optJSONObject(0)?.optString("threadId").orEmpty()
        } else current
        root.put("currentThreadId", next)
        HistorySyncTombstoneStoreV1.record(context, threadId, "SWRLZ_NATIVE")
        writeRoot(context, root)
        return next
    }


    /** Canonical account-sync envelopes. Imported records remain historical/non-executable. */
    @Synchronized
    fun syncEnvelopes(context: Context): List<JSONObject> {
        val root = readEnsuredRoot(context)
        val nativeRows = mutableListOf<JSONObject>()
        val threads = root.optJSONArray("threads") ?: JSONArray()
        for (threadIndex in 0 until threads.length()) {
            val thread = threads.optJSONObject(threadIndex) ?: continue
            val threadId = thread.optString("threadId")
            if (threadId.isBlank()) continue
            val source = thread.optJSONArray("messages") ?: JSONArray()
            val nodes = JSONArray()
            var parentId: String? = null
            for (messageIndex in 0 until source.length()) {
                val message = source.optJSONObject(messageIndex) ?: continue
                val nodeId = "native-" + java.security.MessageDigest.getInstance("SHA-256")
                    .digest("$threadId|$messageIndex|${message.optLong("createdAtEpochMs")}|${message.optString("text")}".toByteArray())
                    .joinToString("") { "%02x".format(it) }.take(28)
                nodes.put(JSONObject(message.toString())
                    .put("nodeId", nodeId)
                    .put("parentNodeId", parentId ?: JSONObject.NULL)
                    .put("authorRole", if (message.optBoolean("fromUser", false)) "user" else "assistant")
                    .put("contentType", "text")
                    .put("visibleText", message.optString("text"))
                    .put("historical", false)
                    .put("executable", false))
                parentId = nodeId
            }
            nativeRows += JSONObject()
                .put("conversationId", threadId)
                .put("threadId", threadId)
                .put("title", thread.optString("title", "New chat"))
                .put("originType", "SWRLZ_NATIVE")
                .put("createdAtEpochMs", thread.optLong("createdAtEpochMs", 0L))
                .put("updatedAtEpochMs", thread.optLong("updatedAtEpochMs", 0L))
                .put("currentNodeId", parentId ?: JSONObject.NULL)
                .put("messageNodes", nodes)
                .put("historical", false)
                .put("executable", false)
                .put("tombstone", false)
        }
        val imported = ImportedChatHistoryStore.list(context).mapNotNull { ImportedChatHistoryStore.syncEnvelope(context, it.threadId) }
        val tombstones = HistorySyncTombstoneStoreV1.envelopes(context)
        return (nativeRows + imported + tombstones).sortedByDescending { it.optLong("updatedAtEpochMs", 0L) }
    }

    @Synchronized
    fun applySyncEnvelope(context: Context, envelope: JSONObject): Boolean {
        val conversationId = envelope.optString("conversationId").ifBlank { envelope.optString("threadId") }
        if (conversationId.isBlank()) return false
        if (envelope.optString("originType") == "OPENAI_EXPORT") {
            return ImportedChatHistoryStore.applyServerEnvelope(context, envelope)
        }
        val root = readEnsuredRoot(context)
        if (envelope.optBoolean("tombstone", false)) {
            val current = findThread(root, conversationId) ?: return false
            val source = root.optJSONArray("threads") ?: JSONArray()
            val kept = JSONArray()
            for (i in 0 until source.length()) {
                source.optJSONObject(i)?.takeIf { it.optString("threadId") != conversationId }?.let(kept::put)
            }
            root.put("threads", kept)
            if (root.optString("currentThreadId") == conversationId) root.put("currentThreadId", kept.optJSONObject(0)?.optString("threadId").orEmpty())
            writeRoot(context, root)
            return current.length() >= 0
        }
        val nodes = envelope.optJSONArray("messageNodes") ?: JSONArray()
        val messages = JSONArray()
        for (i in 0 until nodes.length()) {
            val node = nodes.optJSONObject(i) ?: continue
            val role = node.optString("authorRole")
            val text = node.optString("visibleText", node.optString("text"))
            if (text.isBlank()) continue
            messages.put(messageJson(
                fromUser = role.equals("user", true) || node.optBoolean("fromUser", false),
                text = text,
                createdAt = node.optLong("createdAtEpochMs", 0L),
                sourceRequestId = node.optString("sourceRequestId"),
                responseTotalMs = node.optLong("responseTotalMs", -1L).takeIf { it >= 0 },
                firstTextMs = node.optLong("firstTextMs", -1L).takeIf { it >= 0 },
                route = node.optString("route"),
                truthCapsuleId = node.optString("truthCapsuleId"),
            ))
        }
        val existing = findThread(root, conversationId)
        val incomingUpdated = envelope.optLong("updatedAtEpochMs", 0L)
        if (existing != null && existing.optLong("updatedAtEpochMs", 0L) > incomingUpdated) return false
        val row = existing ?: JSONObject().put("threadId", conversationId)
        row.put("title", envelope.optString("title", "New chat"))
            .put("createdAtEpochMs", envelope.optLong("createdAtEpochMs", System.currentTimeMillis()))
            .put("updatedAtEpochMs", incomingUpdated)
            .put("messages", messages)
        if (existing == null) (root.optJSONArray("threads") ?: JSONArray().also { root.put("threads", it) }).put(row)
        writeRoot(context, root)
        return true
    }

    private fun readEnsuredRoot(context: Context): JSONObject {
        ensure(context)
        return readRoot(context)
    }

    private fun readRoot(context: Context): JSONObject = runCatching {
        val source = file(context)
        if (!source.exists() && !File(source.path + ".bak").exists()) {
            return@runCatching JSONObject().put("schema", SCHEMA).put("threads", JSONArray())
        }
        AtomicFile(source).openRead().bufferedReader().use { JSONObject(it.readText()) }
    }.getOrElse { JSONObject().put("schema", SCHEMA).put("threads", JSONArray()) }

    private fun writeRoot(context: Context, root: JSONObject) {
        root.put("schema", SCHEMA)
        val atomic = AtomicFile(file(context))
        var stream: java.io.FileOutputStream? = null
        try {
            stream = atomic.startWrite()
            stream.write(root.toString().toByteArray(Charsets.UTF_8))
            stream.flush()
            atomic.finishWrite(stream)
            notifyExternalChange()
        } catch (failure: Throwable) {
            stream?.let { runCatching { atomic.failWrite(it) } }
            throw IllegalStateException("CLIENT_CHAT_HISTORY_COMMIT_FAILED", failure)
        }
    }

    private fun document(root: JSONObject): ClientChatHistoryDocument {
        val threads = root.optJSONArray("threads") ?: JSONArray()
        val summaries = (0 until threads.length()).mapNotNull { index ->
            val thread = threads.optJSONObject(index) ?: return@mapNotNull null
            ClientChatThreadSummary(
                threadId = thread.optString("threadId"),
                title = thread.optString("title", "New chat"),
                createdAtEpochMs = thread.optLong("createdAtEpochMs", 0L),
                updatedAtEpochMs = thread.optLong("updatedAtEpochMs", 0L),
                messageCount = thread.optJSONArray("messages")?.length() ?: 0,
            )
        }.sortedByDescending { it.updatedAtEpochMs }
        return ClientChatHistoryDocument(root.optString("currentThreadId"), summaries)
    }

    private fun findThread(root: JSONObject, threadId: String): JSONObject? {
        val threads = root.optJSONArray("threads") ?: return null
        for (index in 0 until threads.length()) {
            val thread = threads.optJSONObject(index) ?: continue
            if (thread.optString("threadId") == threadId) return thread
        }
        return null
    }

    private fun messageJson(
        fromUser: Boolean,
        text: String,
        createdAt: Long,
        sourceRequestId: String = "",
        responseTotalMs: Long? = null,
        firstTextMs: Long? = null,
        route: String = "",
        truthCapsuleId: String = "",
        executionTrace: List<ClientChatTraceStep> = emptyList(),
    ) = JSONObject()
        .put("fromUser", fromUser)
        .put("text", text)
        .put("createdAtEpochMs", createdAt)
        .apply {
            if (sourceRequestId.isNotBlank()) put("sourceRequestId", sourceRequestId)
            responseTotalMs?.let { put("responseTotalMs", it.coerceAtLeast(0L)) }
            firstTextMs?.let { put("firstTextMs", it.coerceAtLeast(0L)) }
            if (route.isNotBlank()) put("route", route.take(64))
            if (truthCapsuleId.isNotBlank()) put("truthCapsuleId", truthCapsuleId.take(96))
            if (executionTrace.isNotEmpty()) put("executionTrace", traceToJson(executionTrace))
        }

    private fun traceToJson(trace: List<ClientChatTraceStep>): JSONArray = JSONArray().also { array ->
        trace.takeLast(16).forEach { step ->
            array.put(
                JSONObject()
                    .put("key", step.key.take(48))
                    .put("label", step.label.take(120))
                    .put("detail", step.detail.take(240))
                    .put("firstSeenAtEpochMs", step.firstSeenAtEpochMs.coerceAtLeast(0L))
                    .put("lastSeenAtEpochMs", step.lastSeenAtEpochMs.coerceAtLeast(step.firstSeenAtEpochMs))
                    .put("eventCount", step.eventCount.coerceAtLeast(1)),
            )
        }
    }

    private fun traceFromJson(array: JSONArray?): List<ClientChatTraceStep> {
        if (array == null) return emptyList()
        return (0 until minOf(array.length(), 16)).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            val key = item.optString("key").trim().take(48)
            if (key.isBlank()) return@mapNotNull null
            ClientChatTraceStep(
                key = key,
                label = item.optString("label").trim().take(120),
                detail = item.optString("detail").trim().take(240),
                firstSeenAtEpochMs = item.optLong("firstSeenAtEpochMs", 0L).coerceAtLeast(0L),
                lastSeenAtEpochMs = item.optLong("lastSeenAtEpochMs", 0L).coerceAtLeast(0L),
                eventCount = item.optInt("eventCount", 1).coerceAtLeast(1),
            )
        }
    }

    private fun deriveTitle(text: String): String = text.trim().replace(Regex("\\s+"), " ").take(52).ifBlank { "New chat" }
}
