package sh.swurlz.core.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

/** R66 on-device FTS index for visible imported/current-thread text. Hidden reasoning is never indexed. */
object ImportedChatSearchIndexV1 {
    data class Hit(
        val threadId: String,
        val nodeId: String,
        val title: String,
        val visibleText: String,
        val source: String,
        val createdAtEpochMs: Long,
    )

    private class Helper(context: Context) : SQLiteOpenHelper(context, "swrlz_imported_chat_fts_v1.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE VIRTUAL TABLE imported_message_fts USING fts4(threadId, nodeId, title, visibleText, source, createdAtEpochMs)")
        }
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            db.execSQL("DROP TABLE IF EXISTS imported_message_fts")
            onCreate(db)
        }
    }

    private fun helper(context: Context) = Helper(context.applicationContext)

    fun replaceThread(context: Context, thread: JSONObject) {
        val threadId = thread.optString("threadId").ifBlank { thread.optString("conversationId") }
        if (threadId.isBlank()) return
        helper(context).writableDatabase.use { db ->
            db.beginTransaction()
            try {
                db.delete("imported_message_fts", "threadId=?", arrayOf(threadId))
                val title = thread.optString("title", "Imported chat")
                val rows = thread.optJSONArray("messages") ?: JSONArray()
                for (i in 0 until rows.length()) {
                    val row = rows.optJSONObject(i) ?: continue
                    // The index is a visible-history index. Thought/reasoning quarantine never enters it.
                    if (row.optBoolean("hidden", false) || row.optBoolean("quarantinedFromNormalChat", false)) continue
                    val text = row.optString("visibleText", row.optString("text", "")).trim()
                    if (text.isBlank()) continue
                    val values = ContentValues().apply {
                        put("threadId", threadId)
                        put("nodeId", row.optString("nodeId", row.optString("originMessageId")))
                        put("title", title)
                        put("visibleText", text)
                        put("source", row.optString("originType", if (row.optBoolean("historical", true)) "OPENAI_EXPORT" else "SWRLZ_NATIVE"))
                        put("createdAtEpochMs", row.optLong("createdAtEpochMs", 0L).toString())
                    }
                    db.insertOrThrow("imported_message_fts", null, values)
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        }
    }

    fun removeThread(context: Context, threadId: String) {
        if (threadId.isBlank()) return
        helper(context).writableDatabase.use { it.delete("imported_message_fts", "threadId=?", arrayOf(threadId)) }
    }

    fun clear(context: Context) {
        helper(context).writableDatabase.use { it.delete("imported_message_fts", null, null) }
    }

    fun search(
        context: Context,
        query: String,
        threadId: String? = null,
        source: String? = null,
        afterEpochMs: Long? = null,
        beforeEpochMs: Long? = null,
        limit: Int = 100,
    ): List<Hit> {
        val terms = query.trim().split(Regex("\\s+")).filter(String::isNotBlank).take(12)
        if (terms.isEmpty()) return emptyList()
        val ftsQuery = terms.joinToString(" AND ") { "\"${it.replace("\"", "\"\"")}\"" }
        val clauses = mutableListOf("imported_message_fts MATCH ?")
        val args = mutableListOf(ftsQuery)
        threadId?.takeIf(String::isNotBlank)?.let { clauses += "threadId=?"; args += it }
        source?.takeIf(String::isNotBlank)?.let { clauses += "source=?"; args += it }
        afterEpochMs?.let { clauses += "CAST(createdAtEpochMs AS INTEGER)>=?"; args += it.toString() }
        beforeEpochMs?.let { clauses += "CAST(createdAtEpochMs AS INTEGER)<=?"; args += it.toString() }
        val sql = "SELECT threadId,nodeId,title,visibleText,source,createdAtEpochMs FROM imported_message_fts WHERE ${clauses.joinToString(" AND ")} ORDER BY CAST(createdAtEpochMs AS INTEGER) DESC LIMIT ${limit.coerceIn(1, 500)}"
        val out = ArrayList<Hit>()
        helper(context).readableDatabase.rawQuery(sql, args.toTypedArray()).use { cursor ->
            while (cursor.moveToNext()) {
                out += Hit(
                    threadId = cursor.getString(0).orEmpty(),
                    nodeId = cursor.getString(1).orEmpty(),
                    title = cursor.getString(2).orEmpty(),
                    visibleText = cursor.getString(3).orEmpty(),
                    source = cursor.getString(4).orEmpty(),
                    createdAtEpochMs = cursor.getString(5)?.toLongOrNull() ?: 0L,
                )
            }
        }
        return out
    }
}
