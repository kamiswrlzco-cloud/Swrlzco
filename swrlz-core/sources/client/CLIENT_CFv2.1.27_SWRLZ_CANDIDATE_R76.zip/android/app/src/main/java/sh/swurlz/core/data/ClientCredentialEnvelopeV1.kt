package sh.swurlz.core.data

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import org.json.JSONObject

/**
 * Cross-reinstall credential envelope. The recovery passphrase never leaves CLIENT; SERVER receives
 * only ciphertext, salt/nonce, versioned KDF metadata and an opaque key-wrap descriptor.
 */
object ClientCredentialEnvelopeV1 {
    private const val ITERATIONS = 210_000
    private const val KEY_BITS = 256
    private val random = SecureRandom()

    fun encrypt(credentialId: String, plaintext: String, recoveryPassphrase: CharArray): JSONObject {
        require(credentialId.isNotBlank()) { "CREDENTIAL_ID_REQUIRED" }
        require(plaintext.isNotBlank()) { "CREDENTIAL_PLAINTEXT_REQUIRED" }
        require(recoveryPassphrase.size >= 12) { "RECOVERY_PASSPHRASE_TOO_SHORT" }
        val salt = ByteArray(16).also(random::nextBytes)
        val nonce = ByteArray(12).also(random::nextBytes)
        val key = derive(recoveryPassphrase, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, nonce))
        cipher.updateAAD(("swrlz-credential-envelope-v1\u001f$credentialId").toByteArray(Charsets.UTF_8))
        val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        return JSONObject()
            .put("version", 1)
            .put("credentialId", credentialId)
            .put("cipher", "AES-256-GCM")
            .put("kdf", "PBKDF2-HMAC-SHA256")
            .put("iterations", ITERATIONS)
            .put("salt", b64(salt))
            .put("nonce", b64(nonce))
            .put("ciphertext", b64(ciphertext))
            .put("keyWrap", "USER_RECOVERY_PASSPHRASE_V1")
    }

    fun decrypt(envelope: JSONObject, recoveryPassphrase: CharArray): String {
        require(envelope.optInt("version") == 1) { "CREDENTIAL_ENVELOPE_VERSION_UNSUPPORTED" }
        require(envelope.optString("cipher") == "AES-256-GCM") { "CREDENTIAL_ENVELOPE_CIPHER_UNSUPPORTED" }
        require(envelope.optString("kdf") == "PBKDF2-HMAC-SHA256") { "CREDENTIAL_ENVELOPE_KDF_UNSUPPORTED" }
        val id = envelope.optString("credentialId")
        val salt = unb64(envelope.getString("salt"))
        val nonce = unb64(envelope.getString("nonce"))
        val ciphertext = unb64(envelope.getString("ciphertext"))
        val key = derive(recoveryPassphrase, salt, envelope.optInt("iterations", ITERATIONS))
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, nonce))
        cipher.updateAAD(("swrlz-credential-envelope-v1\u001f$id").toByteArray(Charsets.UTF_8))
        return String(cipher.doFinal(ciphertext), Charsets.UTF_8)
    }

    private fun derive(passphrase: CharArray, salt: ByteArray, iterations: Int = ITERATIONS): SecretKeySpec {
        val spec = PBEKeySpec(passphrase, salt, iterations.coerceIn(100_000, 1_000_000), KEY_BITS)
        return try {
            val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            SecretKeySpec(bytes, "AES")
        } finally {
            spec.clearPassword()
        }
    }

    private fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)
    private fun unb64(value: String): ByteArray = Base64.decode(value, Base64.NO_WRAP)
}
