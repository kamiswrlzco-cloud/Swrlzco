package sh.swurlz.core.tools

import android.content.Context
import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject
import sh.swurlz.core.archive.ArchiveSourceStore
import sh.swurlz.core.directory.DirectoryGrantStore

/**
 * R66 canonical preflight compiler for routed CLIENT tool work.
 *
 * Backend exceptions are no longer the discovery protocol for required fields.  The compiler first
 * resolves safe local values, verifies capability/grant readiness, bundles every unresolved operand
 * into one result, and assigns a deterministic fingerprint/idempotency key before consequential
 * execution reaches a VFS engine.
 */
object ToolRequestCompilerV1 {
    data class Contract(
        val schema: String,
        val operation: String,
        val requiredCapability: String,
        val requiredInputs: Set<String>,
        val mutationClass: String,
        val preserveSource: Boolean = false,
    )

    data class Result(
        val executable: Boolean,
        val request: JSONObject,
        val contract: Contract?,
        val fingerprint: String,
        val resolved: Map<String, String>,
        val missing: List<String>,
        val blockers: List<String>,
    ) {
        fun errorJson(): JSONObject = JSONObject()
            .put("ok", false)
            .put("schema", "swrlz-tool-preflight-v1")
            .put("code", if (blockers.isNotEmpty()) "TOOL_PREFLIGHT_BLOCKED" else "TOOL_PREFLIGHT_INPUT_REQUIRED")
            .put("message", if (blockers.isNotEmpty()) "Tool preflight found capability/authority blockers." else "Tool preflight needs the bundled unresolved inputs before execution.")
            .put("preflightFingerprint", fingerprint)
            .put("missingInputs", JSONArray(missing))
            .put("blockers", JSONArray(blockers))
            .put("resolved", JSONObject(resolved))
            .put("operation", contract?.operation ?: request.optString("operation"))
            .put("requiredCapability", contract?.requiredCapability ?: JSONObject.NULL)
            .put("mutationClass", contract?.mutationClass ?: "UNKNOWN")
    }

    fun compile(context: Context, sourceRequest: JSONObject, routedCapability: String): Result {
        val request = JSONObject(sourceRequest.toString())
        val schema = request.optString("schema").trim()
        val operation = request.optString("operation").trim().uppercase()
        val contract = contract(schema, operation)
            ?: return Result(false, request, null, fingerprint(request), emptyMap(), emptyList(), listOf("TOOL_CONTRACT_NOT_REGISTERED:$schema:$operation"))
        val args = request.optJSONObject("arguments") ?: JSONObject().also { request.put("arguments", it) }
        val resolved = linkedMapOf<String, String>()
        val missing = linkedSetOf<String>()
        val blockers = linkedSetOf<String>()

        if (routedCapability.isBlank()) blockers += "REQUESTED_CAPABILITY_MISSING"
        else if (routedCapability != contract.requiredCapability) blockers += "CAPABILITY_MISMATCH:${contract.requiredCapability}:$routedCapability"

        when (schema) {
            "swrlz-archive-query-v1" -> resolveArchive(context, request, args, contract, resolved, missing, blockers)
            "swrlz-directory-query-v1" -> resolveDirectory(context, request, args, contract, resolved, missing, blockers)
            "swrlz-log-query-v1" -> Unit
        }

        contract.requiredInputs.forEach { key ->
            if (!hasValue(request, args, key)) missing += key
        }
        if (contract.preserveSource && !args.has("preserveSource")) {
            args.put("preserveSource", true)
            resolved["preserveSource"] = "true(default)"
        }

        var fp = fingerprint(request)
        if (contract.mutationClass != "READ_ONLY" && args.optString("idempotencyKey").isBlank()) {
            args.put("idempotencyKey", "preflight-${fp.take(32)}")
            resolved["idempotencyKey"] = "preflight-${fp.take(32)}"
            fp = fingerprint(request)
        }
        request.put("preflight", JSONObject()
            .put("schema", "swrlz-tool-preflight-v1")
            .put("fingerprint", fp)
            .put("compiledAtEpochMs", System.currentTimeMillis())
            .put("mutationClass", contract.mutationClass)
            .put("requiredCapability", contract.requiredCapability)
            .put("preserveSource", contract.preserveSource))

        return Result(
            executable = missing.isEmpty() && blockers.isEmpty(),
            request = request,
            contract = contract,
            fingerprint = fp,
            resolved = resolved,
            missing = missing.toList(),
            blockers = blockers.toList(),
        )
    }

    private fun resolveArchive(
        context: Context,
        request: JSONObject,
        args: JSONObject,
        contract: Contract,
        resolved: MutableMap<String, String>,
        missing: MutableSet<String>,
        blockers: MutableSet<String>,
    ) {
        var archiveId = request.optString("archiveId").trim()
        if (archiveId.isBlank()) {
            val sources = ArchiveSourceStore.list(context).filter { ArchiveSourceStore.effectiveAuthority(context, it).readable }
            if (sources.size == 1) {
                archiveId = sources.single().archiveId
                request.put("archiveId", archiveId)
                resolved["archiveId"] = "$archiveId(single-readable-source)"
            } else missing += "archiveId"
        }
        if (archiveId.isNotBlank()) {
            val source = ArchiveSourceStore.find(context, archiveId)
            if (source == null) blockers += "ARCHIVE_NOT_REGISTERED:$archiveId"
            else {
                val authority = ArchiveSourceStore.effectiveAuthority(context, source)
                if (!authority.readable) blockers += "ARCHIVE_READ_AUTHORITY_UNAVAILABLE:$archiveId"
                if (contract.requiredCapability == "archive.write" && !authority.writeAllowed) blockers += "ARCHIVE_WRITE_AUTHORITY_UNAVAILABLE:$archiveId"
            }
        }

        if (contract.operation == "REPACK_SELECTED") {
            var destinationGrantId = args.optString("destinationGrantId").trim()
            if (destinationGrantId.isBlank()) {
                val default = DirectoryGrantStore.defaultGrant(context)
                val authority = default?.let { DirectoryGrantStore.effectiveAuthority(context, it) }
                if (default != null && authority?.writable == true) {
                    destinationGrantId = default.grantId
                    args.put("destinationGrantId", destinationGrantId)
                    resolved["destinationGrantId"] = "$destinationGrantId(default-writable-grant)"
                } else {
                    val writable = allDirectoryGrants(context).filter { DirectoryGrantStore.effectiveAuthority(context, it).writable }
                    if (writable.size == 1) {
                        destinationGrantId = writable.single().grantId
                        args.put("destinationGrantId", destinationGrantId)
                        resolved["destinationGrantId"] = "$destinationGrantId(single-writable-grant)"
                    }
                }
            }
            if (destinationGrantId.isNotBlank()) {
                val grant = DirectoryGrantStore.find(context, destinationGrantId)
                if (grant == null) blockers += "DESTINATION_GRANT_NOT_FOUND:$destinationGrantId"
                else if (!DirectoryGrantStore.effectiveAuthority(context, grant).writable) blockers += "DESTINATION_GRANT_NOT_WRITABLE:$destinationGrantId"
            }
        }
    }

    private fun resolveDirectory(
        context: Context,
        request: JSONObject,
        args: JSONObject,
        contract: Contract,
        resolved: MutableMap<String, String>,
        missing: MutableSet<String>,
        blockers: MutableSet<String>,
    ) {
        var grantId = request.optString("grantId").trim()
        if (grantId.isBlank()) {
            val default = DirectoryGrantStore.defaultGrant(context)
            if (default != null) {
                val authority = DirectoryGrantStore.effectiveAuthority(context, default)
                val eligible = if (contract.requiredCapability == "directory.write") authority.writable else authority.readable
                if (eligible) {
                    grantId = default.grantId
                    request.put("grantId", grantId)
                    resolved["grantId"] = "$grantId(default-eligible-grant)"
                }
            }
        }
        if (grantId.isBlank()) {
            val eligible = allDirectoryGrants(context).filter { grant ->
                val authority = DirectoryGrantStore.effectiveAuthority(context, grant)
                if (contract.requiredCapability == "directory.write") authority.writable else authority.readable
            }
            if (eligible.size == 1) {
                grantId = eligible.single().grantId
                request.put("grantId", grantId)
                resolved["grantId"] = "$grantId(single-eligible-grant)"
            } else missing += "grantId"
        }
        if (grantId.isNotBlank()) {
            val grant = DirectoryGrantStore.find(context, grantId)
            if (grant == null) blockers += "DIRECTORY_GRANT_NOT_FOUND:$grantId"
            else {
                val authority = DirectoryGrantStore.effectiveAuthority(context, grant)
                if (!authority.readable) blockers += "DIRECTORY_READ_AUTHORITY_UNAVAILABLE:$grantId"
                if (contract.requiredCapability == "directory.write" && !authority.writable) blockers += "DIRECTORY_WRITE_AUTHORITY_UNAVAILABLE:$grantId"
            }
        }
    }

    private fun allDirectoryGrants(context: Context): List<DirectoryGrantStore.Grant> = buildList {
        DirectoryGrantStore.builtInDownloadsGrant(context)?.let(::add)
        DirectoryGrantStore.builtInAppPrivateGrant(context)?.let(::add)
        addAll(DirectoryGrantStore.list(context))
    }.distinctBy { it.grantId }

    private fun contract(schema: String, operation: String): Contract? = when (schema) {
        "swrlz-log-query-v1" -> {
            val required = when (operation) {
                "READ_CHUNK" -> setOf("snapshotId", "logId")
                "MANIFEST" -> emptySet()
                else -> return null
            }
            Contract(schema, operation, "logs.read", required, "READ_ONLY")
        }
        "swrlz-archive-query-v1" -> {
            val writeOps = setOf("WRITE_TEXT", "MKDIR", "COPY", "MOVE", "RENAME", "DELETE", "REPACK")
            val mutation = when {
                operation == "REPACK_SELECTED" -> "OUTPUT_MUTATION"
                operation in writeOps -> "CONSEQUENTIAL"
                else -> "READ_ONLY"
            }
            val required = linkedSetOf("archiveId")
            when (operation) {
                "READ", "IDENTIFY_ENTRY" -> required += "entryPath"
                "GET_CONVERSATION", "RECONSTRUCT_CONVERSATION" -> required += "conversationId"
                "WRITE_TEXT" -> required += setOf("path", "text")
                "MKDIR", "DELETE" -> required += "path"
                "COPY", "MOVE", "RENAME" -> required += setOf("sourcePath", "destinationPath")
                "REPACK_SELECTED" -> required += setOf("includePaths", "destinationGrantId", "destinationPath")
            }
            Contract(
                schema = schema,
                operation = operation,
                requiredCapability = if (operation in writeOps) "archive.write" else "archive.read",
                requiredInputs = required,
                mutationClass = mutation,
                preserveSource = operation == "REPACK_SELECTED",
            )
        }
        "swrlz-directory-query-v1" -> {
            val writeOps = setOf("WRITE", "APPEND_TEXT", "ALLOCATE", "MKDIR", "COPY", "MOVE", "DELETE", "DELETE_COMPLETE", "RECOVERY_RESTORE", "RECOVERY_PURGE")
            val required = linkedSetOf("grantId")
            when (operation) {
                "READ", "WRITE", "APPEND_TEXT", "ALLOCATE", "MKDIR", "DELETE", "DELETE_COMPLETE" -> required += "path"
                "COPY", "MOVE" -> required += setOf("sourcePath", "destinationPath")
                "RECOVERY_RESTORE" -> required += setOf("recoveryId", "destinationPath")
                "RECOVERY_PURGE" -> required += "recoveryId"
                "SEARCH", "ANALYZE" -> required += "query"
            }
            Contract(
                schema = schema,
                operation = operation,
                requiredCapability = when {
                    operation == "RECOVERY_SCAN" -> "directory.recovery.read"
                    operation in writeOps -> "directory.write"
                    else -> "directory.read"
                },
                requiredInputs = required,
                mutationClass = if (operation in writeOps) "CONSEQUENTIAL" else "READ_ONLY",
            )
        }
        else -> null
    }

    private fun hasValue(request: JSONObject, args: JSONObject, key: String): Boolean {
        if (key == "archiveId" || key == "grantId") return request.optString(key).isNotBlank()
        val value = args.opt(key) ?: return false
        return when (value) {
            is String -> value.isNotBlank()
            is JSONArray -> value.length() > 0
            JSONObject.NULL -> false
            else -> true
        }
    }

    private fun fingerprint(root: JSONObject): String {
        val canonical = canonical(root, excludedKeys = setOf("preflight", "idempotencyKey", "compiledAtEpochMs"))
        return MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    private fun canonical(value: Any?, excludedKeys: Set<String>): String = when (value) {
        null, JSONObject.NULL -> "null"
        is JSONObject -> value.keys().asSequence().toList().sorted().filterNot(excludedKeys::contains).joinToString(prefix = "{", postfix = "}") { key ->
            JSONObject.quote(key) + ":" + canonical(value.opt(key), excludedKeys)
        }
        is JSONArray -> (0 until value.length()).joinToString(prefix = "[", postfix = "]") { index -> canonical(value.opt(index), excludedKeys) }
        is Number, is Boolean -> value.toString()
        else -> JSONObject.quote(value.toString())
    }
}
