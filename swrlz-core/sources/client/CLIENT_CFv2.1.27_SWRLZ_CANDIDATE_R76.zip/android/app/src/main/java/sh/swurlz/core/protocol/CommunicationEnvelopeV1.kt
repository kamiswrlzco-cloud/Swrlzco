package sh.swurlz.core.protocol

import kotlinx.serialization.Serializable

@Serializable enum class CommunicationRequestType { CHAT, MISSION, COMMAND, TOOL, APPROVAL, PROVIDER }
@Serializable enum class CommunicationRoute { LOCAL, ONLINE, HYBRID, FALLBACK }
@Serializable enum class CommunicationStatus { CREATED, RECEIVED, COMPLETED, REJECTED, FAILED }
@Serializable enum class InterfaceProjection { USER, DEVELOPER }

@Serializable
data class CommunicationEndpoint(
    val component: String,
    val deviceId: String? = null,
    val provider: String? = null,
    val interfaceMode: InterfaceProjection? = null,
)

@Serializable
data class CommunicationEnvelopeV1(
    val messageId: String,
    val correlationId: String,
    val conversationId: String,
    val missionId: String? = null,
    val eventId: String,
    val source: CommunicationEndpoint,
    val destination: CommunicationEndpoint,
    val requestType: CommunicationRequestType,
    val route: CommunicationRoute,
    val createdAtEpochMs: Long,
    val receivedAtEpochMs: Long? = null,
    val completedAtEpochMs: Long? = null,
    val status: CommunicationStatus = CommunicationStatus.CREATED,
    val errorCategory: String? = null,
    val latencyMs: Long? = null,
    val retryCount: Int = 0,
    val payloadSummary: String = "",
) {
    init {
        require(messageId.isNotBlank() && correlationId.isNotBlank() && conversationId.isNotBlank() && eventId.isNotBlank())
        require(missionId == null || missionId.isNotBlank())
        require(retryCount >= 0)
        require(payloadSummary.length <= 256)
    }
}

sealed interface ConversationRouteDecision {
    data object OrdinaryChat : ConversationRouteDecision
    data class ExistingMission(val missionId: String) : ConversationRouteDecision
    data class ApprovalRequired(val conversationId: String) : ConversationRouteDecision
    data class Rejected(val reason: String) : ConversationRouteDecision
}

object ConversationRouterFoundation {
    fun classify(envelope: CommunicationEnvelopeV1, promoteConversationToMission: Boolean = false, explicitApproval: Boolean = false): ConversationRouteDecision = when {
        envelope.requestType == CommunicationRequestType.CHAT && !promoteConversationToMission -> ConversationRouteDecision.OrdinaryChat
        envelope.requestType == CommunicationRequestType.CHAT && promoteConversationToMission && !explicitApproval -> ConversationRouteDecision.ApprovalRequired(envelope.conversationId)
        envelope.requestType == CommunicationRequestType.CHAT && promoteConversationToMission && explicitApproval && envelope.missionId != null -> ConversationRouteDecision.ExistingMission(envelope.missionId)
        envelope.requestType == CommunicationRequestType.MISSION && envelope.missionId != null -> ConversationRouteDecision.ExistingMission(envelope.missionId)
        envelope.requestType == CommunicationRequestType.MISSION -> ConversationRouteDecision.Rejected("missionId is required for mission traffic")
        else -> ConversationRouteDecision.Rejected("request type is outside conversation routing")
    }
}
