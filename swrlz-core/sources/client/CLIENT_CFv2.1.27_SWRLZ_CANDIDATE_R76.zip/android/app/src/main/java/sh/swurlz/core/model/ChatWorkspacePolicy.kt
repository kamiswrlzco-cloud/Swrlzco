package sh.swurlz.core.model

/**
 * Pure layout policy for the conversation workspace.
 * Presentation only: it cannot change provider authority, mission state, trust, or approvals.
 */
data class ChatWorkspaceLayout(
    val showOnboarding: Boolean,
    val showBottomNavigation: Boolean,
    val showSecondaryTelemetry: Boolean,
    val showProviderCompactBar: Boolean,
    val composerMaxLines: Int,
)

object ChatWorkspacePolicy {
    fun resolve(
        imeVisible: Boolean,
        hasUserConversation: Boolean,
        providerStatusEnabled: Boolean,
    ): ChatWorkspaceLayout = ChatWorkspaceLayout(
        showOnboarding = !imeVisible && !hasUserConversation,
        showBottomNavigation = !imeVisible,
        showSecondaryTelemetry = !imeVisible && !hasUserConversation,
        showProviderCompactBar = providerStatusEnabled,
        composerMaxLines = if (imeVisible) 4 else 5,
    )
}
