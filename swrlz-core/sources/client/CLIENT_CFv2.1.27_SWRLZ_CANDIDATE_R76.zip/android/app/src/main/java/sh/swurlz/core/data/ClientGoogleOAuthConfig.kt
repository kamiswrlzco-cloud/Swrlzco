package sh.swurlz.core.data

import android.content.Context
import sh.swurlz.core.BuildConfig

/** Public Google OAuth web-client configuration. Client IDs are identifiers, not secrets. */
object ClientGoogleOAuthConfig {
    private const val PREFS = "swrlz_google_oauth_config_v1"
    private const val KEY_OVERRIDE = "web_client_id_override"

    fun resolve(context: Context): String {
        val override = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_OVERRIDE, "").orEmpty().trim()
        return override.ifBlank { BuildConfig.SWRLZ_GOOGLE_OAUTH_CLIENT_ID.trim() }
    }

    fun source(context: Context): String {
        val override = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_OVERRIDE, "").orEmpty().trim()
        return if (override.isNotBlank()) "RUNTIME_OVERRIDE" else BuildConfig.SWRLZ_GOOGLE_OAUTH_CONFIG_SOURCE.ifBlank { "UNCONFIGURED" }
    }

    fun setOverride(context: Context, value: String) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_OVERRIDE, value.trim()).apply()
    }

    fun clearOverride(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_OVERRIDE).apply()
    }
}
