package sh.swurlz.core.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

/** Stores provider secrets outside ordinary DataStore preferences using Android Keystore-backed encryption. */
object SecretStore {
    private const val FILE = "swurlz_secrets"
    private const val KEY_MENTOR_TOKEN = "mentor_api_token"
    private const val KEY_CORE_NODE_TOKEN = "core_node_pairing_token"
    private const val KEY_RELAY_GROUP_KEY = "relay_group_key"
    private const val KEY_RELAY_DEVICE_KEY = "relay_device_key"
    private const val KEY_ADMIN_SESSION_TOKEN = "admin_session_token"
    private const val KEY_GITHUB_TOKEN = "github_forge_token"
    private const val KEY_GITHUB_REFRESH_TOKEN = "github_forge_refresh_token"
    private const val KEY_GITHUB_ACCESS_EXPIRES_AT = "github_forge_access_expires_at"
    private const val KEY_GITHUB_REFRESH_EXPIRES_AT = "github_forge_refresh_expires_at"
    private const val KEY_GITHUB_OAUTH_CLIENT_ID = "github_oauth_client_id"

    private fun prefs(ctx: Context) = EncryptedSharedPreferences.create(
        FILE,
        MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
        ctx,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    fun mentorToken(ctx: Context): String = prefs(ctx).getString(KEY_MENTOR_TOKEN, "").orEmpty()

    fun setMentorToken(ctx: Context, token: String) {
        prefs(ctx).edit().putString(KEY_MENTOR_TOKEN, token.trim()).apply()
    }

    fun coreNodeToken(ctx: Context): String = prefs(ctx).getString(KEY_CORE_NODE_TOKEN, "").orEmpty()

    fun setCoreNodeToken(ctx: Context, token: String) {
        prefs(ctx).edit().putString(KEY_CORE_NODE_TOKEN, token.trim()).apply()
    }

    fun relayGroupKey(ctx: Context): String = prefs(ctx).getString(KEY_RELAY_GROUP_KEY, "").orEmpty()

    fun setRelayGroupKey(ctx: Context, key: String) {
        prefs(ctx).edit().putString(KEY_RELAY_GROUP_KEY, key.trim()).apply()
    }

    fun relayDeviceKey(ctx: Context): String = prefs(ctx).getString(KEY_RELAY_DEVICE_KEY, "").orEmpty()

    fun setRelayDeviceKey(ctx: Context, key: String) {
        prefs(ctx).edit().putString(KEY_RELAY_DEVICE_KEY, key.trim()).apply()
    }

    fun adminSessionToken(ctx: Context): String = prefs(ctx).getString(KEY_ADMIN_SESSION_TOKEN, "").orEmpty()

    fun setAdminSessionToken(ctx: Context, token: String) {
        prefs(ctx).edit().putString(KEY_ADMIN_SESSION_TOKEN, token.trim()).apply()
    }

    fun githubToken(ctx: Context): String = prefs(ctx.applicationContext).getString(KEY_GITHUB_TOKEN, "").orEmpty()

    fun githubRefreshToken(ctx: Context): String = prefs(ctx.applicationContext).getString(KEY_GITHUB_REFRESH_TOKEN, "").orEmpty()

    fun githubAccessExpiresAt(ctx: Context): Long = prefs(ctx.applicationContext).getLong(KEY_GITHUB_ACCESS_EXPIRES_AT, 0L)

    fun githubRefreshExpiresAt(ctx: Context): Long = prefs(ctx.applicationContext).getLong(KEY_GITHUB_REFRESH_EXPIRES_AT, 0L)

    fun githubOAuthClientId(ctx: Context): String = prefs(ctx.applicationContext).getString(KEY_GITHUB_OAUTH_CLIENT_ID, "").orEmpty()

    fun setGithubOAuthClientId(ctx: Context, clientId: String) {
        check(prefs(ctx.applicationContext).edit().putString(KEY_GITHUB_OAUTH_CLIENT_ID, clientId.trim()).commit()) { "Unable to persist GitHub OAuth client ID." }
    }

    fun setGithubCredential(
        ctx: Context,
        token: String,
        refreshToken: String = "",
        expiresInSeconds: Int? = null,
        refreshTokenExpiresInSeconds: Int? = null,
    ) {
        val now = System.currentTimeMillis()
        val accessExpiresAt = expiresInSeconds?.takeIf { it > 0 }?.let { now + it * 1000L } ?: 0L
        val refreshExpiresAt = refreshTokenExpiresInSeconds?.takeIf { it > 0 }?.let { now + it * 1000L } ?: 0L
        check(
            prefs(ctx.applicationContext).edit()
                .putString(KEY_GITHUB_TOKEN, token.trim())
                .putString(KEY_GITHUB_REFRESH_TOKEN, refreshToken.trim())
                .putLong(KEY_GITHUB_ACCESS_EXPIRES_AT, accessExpiresAt)
                .putLong(KEY_GITHUB_REFRESH_EXPIRES_AT, refreshExpiresAt)
                .commit(),
        ) { "Unable to persist GitHub credential lifecycle." }
    }

    fun setGithubToken(ctx: Context, token: String) {
        setGithubCredential(ctx, token)
    }

    fun forgetGithubToken(ctx: Context) {
        prefs(ctx.applicationContext).edit()
            .remove(KEY_GITHUB_TOKEN)
            .remove(KEY_GITHUB_REFRESH_TOKEN)
            .remove(KEY_GITHUB_ACCESS_EXPIRES_AT)
            .remove(KEY_GITHUB_REFRESH_EXPIRES_AT)
            .commit()
    }

    fun forgetGithubOAuthClientId(ctx: Context) {
        prefs(ctx).edit().remove(KEY_GITHUB_OAUTH_CLIENT_ID).apply()
    }


    fun forgetAdminSessionToken(ctx: Context) {
        prefs(ctx).edit().remove(KEY_ADMIN_SESSION_TOKEN).apply()
    }
}
