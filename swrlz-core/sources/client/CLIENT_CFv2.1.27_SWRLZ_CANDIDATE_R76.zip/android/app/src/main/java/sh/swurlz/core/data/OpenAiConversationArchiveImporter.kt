package sh.swurlz.core.data

import android.content.Context
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.zip.ZipInputStream
import kotlinx.coroutines.CancellationException
import org.json.JSONArray
import org.json.JSONObject
import sh.swurlz.core.logging.ClientFullLogStore

/** First-class conversations-only ChatGPT export importer introduced in CLIENT R66. */
object OpenAiConversationArchiveImporter {
    data class Analysis(
        val sha256: String,
        val shardCount: Int,
        val conversationCount: Int,
        val messageNodeCount: Int,
        val currentPathNodeCount: Int,
        val alternateBranchNodeCount: Int,
        val conversationsWithBranches: Int,
        val textMessageCount: Int,
        val multimodalMessageCount: Int,
        val hiddenThoughtCount: Int,
        val reasoningRecapCount: Int,
        val attachmentRefCount: Int,
        val millisecondTimestampCount: Int,
        val uncompressedJsonBytes: Long,
    )

    data class ImportResult(
        val analysis: Analysis,
        val insertedThreads: Int,
        val updatedThreads: Int,
        val visibleMessages: Int,
        val alternateNodesPreserved: Int,
        val hiddenNodesQuarantined: Int,
    )

    private val shardPattern = Regex("(^|/)conversations(?:-\\d{3,})?\\.json$", RegexOption.IGNORE_CASE)

    fun analyze(context: Context, uri: Uri): Analysis {
        val sha = sha256(context, uri)
        var shardCount = 0
        var conversations = 0
        var nodes = 0
        var currentNodes = 0
        var alternateNodes = 0
        var branchConversations = 0
        var text = 0
        var multimodal = 0
        var thoughts = 0
        var recaps = 0
        var attachmentRefs = 0
        var millis = 0
        var jsonBytes = 0L
        openZip(context, uri) { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val name = entry.name.replace('\\', '/')
                if (entry.isDirectory || !shardPattern.containsMatchIn(name)) continue
                shardCount++
                val bytes = readEntry(zip)
                jsonBytes += bytes.size
                val array = JSONArray(bytes.toString(Charsets.UTF_8))
                for (i in 0 until array.length()) {
                    val conversation = array.optJSONObject(i) ?: continue
                    conversations++
                    val mapping = conversation.optJSONObject("mapping") ?: JSONObject()
                    val currentPath = currentPathIds(conversation)
                    val currentSet = currentPath.toHashSet()
                    var conversationMessageNodes = 0
                    var conversationCurrentMessages = 0
                    var conversationAlternateMessages = 0
                    val childCounts = HashMap<String, Int>()
                    val keys = mapping.keys()
                    while (keys.hasNext()) {
                        val nodeId = keys.next()
                        val node = mapping.optJSONObject(nodeId) ?: continue
                        val parent = node.optString("parent")
                        if (parent.isNotBlank()) childCounts[parent] = (childCounts[parent] ?: 0) + 1
                        val message = node.optJSONObject("message") ?: continue
                        conversationMessageNodes++
                        if (nodeId in currentSet) conversationCurrentMessages++ else conversationAlternateMessages++
                        when (message.optJSONObject("content")?.optString("content_type")) {
                            "text" -> text++
                            "multimodal_text" -> multimodal++
                            "thoughts" -> thoughts++
                            "reasoning_recap" -> recaps++
                        }
                        attachmentRefs += countMessageAttachmentRefs(message)
                        val rawTime = message.opt("create_time")
                        if (rawTime is Number && rawTime.toDouble() >= 1_000_000_000_000.0) millis++
                    }
                    nodes += conversationMessageNodes
                    currentNodes += conversationCurrentMessages
                    alternateNodes += conversationAlternateMessages
                    if (childCounts.values.any { it > 1 }) branchConversations++
                }
            }
        }
        require(shardCount > 0) { "OPENAI_CONVERSATION_SHARDS_NOT_FOUND" }
        return Analysis(sha, shardCount, conversations, nodes, currentNodes, alternateNodes, branchConversations, text, multimodal, thoughts, recaps, attachmentRefs, millis, jsonBytes)
    }

    fun import(
        context: Context,
        uri: Uri,
        analysis: Analysis = analyze(context, uri),
        syncExcluded: Boolean = false,
        shouldCancel: () -> Boolean = { false },
        onShardProgress: (Int, Int) -> Unit = { _, _ -> },
    ): ImportResult {
        require(sha256(context, uri).equals(analysis.sha256, ignoreCase = true)) { "OPENAI_ARCHIVE_CHANGED_AFTER_ANALYSIS" }
        val estimatedWorkingBytes = maxOf(64L * 1024L * 1024L, analysis.uncompressedJsonBytes * 3L)
        require(context.applicationContext.filesDir.usableSpace > estimatedWorkingBytes) {
            "OPENAI_IMPORT_LOCAL_STORAGE_INSUFFICIENT:need=$estimatedWorkingBytes:free=${context.applicationContext.filesDir.usableSpace}"
        }
        fun checkCancelled() {
            if (shouldCancel()) {
                ImportedChatHistoryStore.discardStage(context, analysis.sha256)
                throw CancellationException("OPENAI_IMPORT_CANCELLED_CLEAN_ROLLBACK")
            }
        }
        checkCancelled()
        var inserted = 0
        var updated = 0
        var visibleCount = 0
        var branchCount = 0
        var hiddenCount = 0
        var parsedShards = 0
        openZip(context, uri) { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val name = entry.name.replace('\\', '/')
                if (entry.isDirectory || !shardPattern.containsMatchIn(name)) continue
                checkCancelled()
                parsedShards++
                val bytes = readEntry(zip)
                val array = JSONArray(bytes.toString(Charsets.UTF_8))
                val batch = ArrayList<ImportedChatHistoryStore.ImportedThreadPayload>(array.length())
                for (i in 0 until array.length()) {
                    val conversation = array.optJSONObject(i) ?: continue
                    val payload = toPayload(conversation, analysis.sha256, name, syncExcluded)
                    visibleCount += payload.visibleMessages.length()
                    branchCount += payload.alternateBranchNodes.length()
                    hiddenCount += payload.hiddenNodes.length()
                    batch += payload
                }
                ImportedChatHistoryStore.stageBatch(context, analysis.sha256, batch)
                checkCancelled()
                onShardProgress(parsedShards, analysis.shardCount)
                ClientFullLogStore.info(
                    context,
                    "CHAT",
                    "conversation_import_shard_staged",
                    "OpenAI conversation shard staged; it is not visible until the archive-wide validation/commit point.",
                    mapOf("shard" to name, "shardOrdinal" to parsedShards, "shardCount" to analysis.shardCount, "conversations" to batch.size, "sourceArchiveSha256" to analysis.sha256),
                )
            }
        }
        require(parsedShards == analysis.shardCount) { "OPENAI_IMPORT_SHARD_COUNT_CHANGED:$parsedShards:${analysis.shardCount}" }
        checkCancelled()
        val committed = ImportedChatHistoryStore.commitStagedImport(
            context,
            analysis.sha256,
            analysis.conversationCount,
            shouldCancel = shouldCancel,
        )
        inserted = committed.first
        updated = committed.second
        ClientChatHistoryStore.notifyExternalChange()
        ClientFullLogStore.info(
            context,
            "CHAT",
            "conversation_import_completed",
            "Conversation archive import completed with historical execution isolation armed.",
            mapOf(
                "sourceArchiveSha256" to analysis.sha256,
                "shards" to parsedShards,
                "insertedThreads" to inserted,
                "updatedThreads" to updated,
                "visibleMessages" to visibleCount,
                "alternateNodes" to branchCount,
                "hiddenNodes" to hiddenCount,
            ),
        )
        return ImportResult(analysis, inserted, updated, visibleCount, branchCount, hiddenCount)
    }

    private fun toPayload(conversation: JSONObject, archiveSha: String, shardName: String, syncExcluded: Boolean): ImportedChatHistoryStore.ImportedThreadPayload {
        val originId = conversation.optString("conversation_id").ifBlank { conversation.optString("id") }
        require(originId.isNotBlank()) { "OPENAI_CONVERSATION_ID_REQUIRED" }
        val threadId = "openai:$originId"
        val mapping = conversation.optJSONObject("mapping") ?: JSONObject()
        val currentIds = currentPathIds(conversation)
        val currentSet = currentIds.toHashSet()
        val visible = JSONArray()
        val branches = JSONArray()
        val hidden = JSONArray()
        var attachmentRefs = 0
        var hiddenNodeCount = 0

        currentIds.forEach { nodeId ->
            val node = mapping.optJSONObject(nodeId) ?: return@forEach
            val message = node.optJSONObject("message") ?: return@forEach
            val content = message.optJSONObject("content") ?: JSONObject()
            val contentType = content.optString("content_type", "text")
            if (contentType in setOf("thoughts", "reasoning_recap")) {
                hidden.put(hiddenNode(nodeId, node, message, contentType, shardName))
                hiddenNodeCount++
                return@forEach
            }
            val rendered = renderVisibleContent(content)
            val metadataRefs = countMessageAttachmentRefs(message)
            attachmentRefs += metadataRefs
            if (rendered.first.isBlank() && rendered.second == 0 && metadataRefs == 0) return@forEach
            visible.put(visibleNode(nodeId, node, message, contentType, rendered.first, archiveSha, shardName, metadataRefs, conversation.optString("default_model_slug")))
        }

        val keys = mapping.keys()
        while (keys.hasNext()) {
            val nodeId = keys.next()
            if (nodeId in currentSet) continue
            val node = mapping.optJSONObject(nodeId) ?: continue
            val message = node.optJSONObject("message") ?: continue
            val content = message.optJSONObject("content") ?: JSONObject()
            val contentType = content.optString("content_type", "text")
            val rendered = renderVisibleContent(content)
            val metadataRefs = countMessageAttachmentRefs(message)
            attachmentRefs += metadataRefs
            val branch = JSONObject()
                .put("nodeId", nodeId)
                .put("parentNodeId", node.optString("parent"))
                .put("originMessageId", message.optString("id", nodeId))
                .put("authorRole", message.optJSONObject("author")?.optString("role").orEmpty())
                .put("contentType", contentType)
                .put("createdAtEpochMs", normalizeTimestamp(message.opt("create_time")))
                .put("historical", true)
                .put("executable", false)
                .put("hidden", contentType in setOf("thoughts", "reasoning_recap"))
                .put("attachmentRefCount", metadataRefs)
            if (contentType !in setOf("thoughts", "reasoning_recap")) branch.put("visibleText", rendered.first)
            branches.put(branch)
            if (contentType in setOf("thoughts", "reasoning_recap")) hiddenNodeCount++
        }

        val createAt = normalizeTimestamp(conversation.opt("create_time"))
        val updateAt = normalizeTimestamp(conversation.opt("update_time")).takeIf { it > 0L } ?: createAt
        val record = ImportedChatHistoryStore.ThreadRecord(
            threadId = threadId,
            title = conversation.optString("title", "Imported chat").trim().take(160).ifBlank { "Imported chat" },
            createdAtEpochMs = createAt,
            updatedAtEpochMs = updateAt,
            messageCount = visible.length(),
            originConversationId = originId,
            sourceArchiveSha256 = archiveSha,
            archived = conversation.optBoolean("is_archived", false),
            starred = conversation.optBoolean("is_starred", false),
            branchNodeCount = branches.length(),
            hiddenNodeCount = hiddenNodeCount,
            attachmentRefCount = attachmentRefs,
            syncExcluded = syncExcluded,
        )
        return ImportedChatHistoryStore.ImportedThreadPayload(
            record = record,
            currentNodeId = conversation.optString("current_node"),
            defaultModelSlug = conversation.optString("default_model_slug"),
            visibleMessages = visible,
            alternateBranchNodes = branches,
            hiddenNodes = hidden,
        )
    }

    private fun visibleNode(
        nodeId: String,
        node: JSONObject,
        message: JSONObject,
        contentType: String,
        text: String,
        archiveSha: String,
        shardName: String,
        attachmentRefs: Int,
        defaultModelSlug: String,
    ): JSONObject {
        val role = message.optJSONObject("author")?.optString("role").orEmpty()
        val modelSlug = message.optJSONObject("metadata")?.optString("model_slug").orEmpty().ifBlank { defaultModelSlug }
        return JSONObject()
            .put("nodeId", nodeId)
            .put("parentNodeId", node.optString("parent"))
            .put("originMessageId", message.optString("id", nodeId))
            .put("originType", "OPENAI_EXPORT")
            .put("sourceArchiveSha256", archiveSha)
            .put("sourceShard", shardName)
            .put("authorRole", role)
            .put("fromUser", role.equals("user", true))
            .put("contentType", contentType)
            .put("visibleText", text)
            .put("createdAtEpochMs", normalizeTimestamp(message.opt("create_time")))
            .put("modelSlug", modelSlug)
            .put("historical", true)
            .put("executable", false)
            .put("attachmentRefCount", attachmentRefs)
    }

    private fun hiddenNode(nodeId: String, node: JSONObject, message: JSONObject, contentType: String, shardName: String): JSONObject = JSONObject()
        .put("nodeId", nodeId)
        .put("parentNodeId", node.optString("parent"))
        .put("originMessageId", message.optString("id", nodeId))
        .put("authorRole", message.optJSONObject("author")?.optString("role").orEmpty())
        .put("contentType", contentType)
        .put("createdAtEpochMs", normalizeTimestamp(message.opt("create_time")))
        .put("sourceShard", shardName)
        .put("historical", true)
        .put("executable", false)
        .put("quarantinedFromNormalChat", true)

    private fun renderVisibleContent(content: JSONObject): Pair<String, Int> {
        val type = content.optString("content_type", "text")
        val parts = content.optJSONArray("parts") ?: JSONArray()
        val text = ArrayList<String>()
        var attachments = 0
        for (i in 0 until parts.length()) {
            when (val part = parts.opt(i)) {
                is String -> if (part.isNotBlank()) text += part
                is JSONObject -> {
                    val ct = part.optString("content_type")
                    val transcript = part.optString("text")
                    if (transcript.isNotBlank() && ct.contains("transcription", true)) text += transcript
                    val pointerLike = ct.contains("asset", true) || part.has("asset_pointer") || part.has("audio_asset_pointer") || ct.contains("audio_video", true)
                    if (pointerLike) {
                        attachments++
                        val label = when {
                            ct.contains("image", true) -> "Image"
                            ct.contains("audio", true) -> "Audio"
                            ct.contains("video", true) -> "Video"
                            else -> "Media"
                        }
                        text += "[$label attachment unavailable in conversations-only import]"
                    }
                }
            }
        }
        if (type == "text" && text.isEmpty()) {
            // Some exports contain a scalar text field instead of parts.
            content.optString("text").takeIf { it.isNotBlank() }?.let(text::add)
        }
        return text.joinToString("\n").trim() to attachments
    }

    private fun countMessageAttachmentRefs(message: JSONObject): Int {
        val attachments = message.optJSONObject("metadata")?.optJSONArray("attachments") ?: return 0
        return attachments.length()
    }

    private fun currentPathIds(conversation: JSONObject): List<String> {
        val mapping = conversation.optJSONObject("mapping") ?: return emptyList()
        var cursor = conversation.optString("current_node")
        val reversed = ArrayList<String>()
        val seen = HashSet<String>()
        while (cursor.isNotBlank() && seen.add(cursor)) {
            val node = mapping.optJSONObject(cursor) ?: break
            reversed += cursor
            cursor = node.optString("parent")
        }
        reversed.reverse()
        return reversed
    }

    private fun normalizeTimestamp(value: Any?): Long {
        val number = value as? Number ?: return 0L
        val raw = number.toDouble()
        if (!raw.isFinite() || raw <= 0.0) return 0L
        return if (raw >= 1_000_000_000_000.0) raw.toLong() else (raw * 1000.0).toLong()
    }

    private fun sha256(context: Context, uri: Uri): String {
        val digest = MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        } ?: error("OPENAI_ARCHIVE_OPEN_FAILED")
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private inline fun openZip(context: Context, uri: Uri, block: (ZipInputStream) -> Unit) {
        val raw = context.contentResolver.openInputStream(uri) ?: error("OPENAI_ARCHIVE_OPEN_FAILED")
        ZipInputStream(raw.buffered()).use(block)
    }

    private fun readEntry(zip: ZipInputStream): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(64 * 1024)
        var total = 0L
        while (true) {
            val count = zip.read(buffer)
            if (count < 0) break
            total += count
            require(total <= MAX_SHARD_BYTES) { "OPENAI_CONVERSATION_SHARD_TOO_LARGE" }
            out.write(buffer, 0, count)
        }
        return out.toByteArray()
    }

    private const val MAX_SHARD_BYTES = 64L * 1024L * 1024L
}
