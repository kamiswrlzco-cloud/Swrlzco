package sh.swurlz.core.model

import sh.swrlz.provider.ProviderStrategy

/**
 * CLIENT-local conversation presentation and response-style preferences.
 *
 * These settings never change protocol, mission authority, trust, permissions, or the
 * Truth Firewall. They only shape conversation flow and model-facing response guidance.
 */
data class ChatSettings(
    val followTarget: String = FOLLOW_RESPONSE_TOP,
    val autoOpenRuntimeEvents: Boolean = true,
    val baseStyle: String = STYLE_ADAPTIVE,
    val detailLevel: String = DETAIL_BALANCED,
    val warmth: String = TRAIT_HIGH,
    val energy: String = TRAIT_HIGH,
    val humor: String = HUMOR_ADAPTIVE,
    val formatting: String = FORMAT_STRUCTURED,
    val emoji: String = EMOJI_ADAPTIVE,
    val providerStrategy: ProviderStrategy = ProviderStrategy.SWRLZ_AUTO,
    val showProviderStatus: Boolean = true,
    val allowRemoteProvidersAutomatically: Boolean = false,
) {
    fun normalized(): ChatSettings = copy(
        followTarget = followTarget.takeIf { it in FOLLOW_TARGETS } ?: FOLLOW_RESPONSE_TOP,
        baseStyle = when (baseStyle) {
            LEGACY_STYLE_ADAPTIVE -> STYLE_ADAPTIVE
            in BASE_STYLES -> baseStyle
            else -> STYLE_ADAPTIVE
        },
        detailLevel = detailLevel.takeIf { it in DETAIL_LEVELS } ?: DETAIL_BALANCED,
        warmth = warmth.takeIf { it in TRAIT_LEVELS } ?: TRAIT_HIGH,
        energy = energy.takeIf { it in TRAIT_LEVELS } ?: TRAIT_HIGH,
        humor = humor.takeIf { it in HUMOR_LEVELS } ?: HUMOR_ADAPTIVE,
        formatting = formatting.takeIf { it in FORMATTING_LEVELS } ?: FORMAT_STRUCTURED,
        emoji = emoji.takeIf { it in EMOJI_LEVELS } ?: EMOJI_ADAPTIVE,
    )

    /** Guidance for optional reasoning providers. Deterministic system/status messages stay factual. */
    fun reasoningDirective(): String {
        val profile = when (baseStyle) {
            STYLE_ENGINEER -> "precise, technical, evidence-forward, and explicit about uncertainty"
            STYLE_COMPANION -> "warm, conversational, supportive, and grounded"
            STYLE_GLITCH_MUSE -> "playful, imaginative, word-aware, and creatively expressive while remaining truthful"
            STYLE_DIRECT -> "concise, plainspoken, and action-oriented"
            STYLE_CANDID -> "direct, skeptical when warranted, constructive, and willing to disagree"
            else -> "adaptive to the user's current task, blending technical precision with conversational warmth"
        }
        val detail = when (detailLevel) {
            DETAIL_COMPACT -> "Prefer compact answers unless more detail is necessary."
            DETAIL_DEEP -> "Provide deep explanations when useful, without padding or repetition."
            else -> "Use balanced detail and expand when complexity warrants it."
        }
        val warm = when (warmth) {
            TRAIT_LOW -> "Keep warmth restrained and professional."
            TRAIT_BALANCED -> "Use moderate warmth."
            else -> "Use strong warmth and personable language without becoming dependent or sycophantic."
        }
        val charged = when (energy) {
            TRAIT_LOW -> "Keep energy calm."
            TRAIT_BALANCED -> "Use moderate conversational energy."
            else -> "Use lively, enthusiastic energy when it fits the moment."
        }
        val funny = when (humor) {
            HUMOR_OFF -> "Avoid humor unless needed to interpret the user's wording."
            HUMOR_LIGHT -> "Use light humor sparingly."
            HUMOR_CHAOS -> "Lean into playful glitch humor when safe and context-appropriate, while keeping facts unmistakable."
            else -> "Use adaptive humor when it improves rapport or clarity."
        }
        val structure = when (formatting) {
            FORMAT_NATURAL -> "Prefer natural prose and minimal formatting."
            FORMAT_BALANCED -> "Use formatting only where it clearly improves readability."
            else -> "Use clear headings and short lists when they improve navigation."
        }
        val emojiRule = when (emoji) {
            EMOJI_OFF -> "Do not use emoji."
            EMOJI_LIGHT -> "Use emoji lightly."
            else -> "Use emoji adaptively and never in place of critical semantics."
        }
        val providerRule = "Default provider route=${providerStrategy.name}. Automatic remote provider use=${if (allowRemoteProvidersAutomatically) "enabled" else "disabled unless explicitly requested"}."
        return "§wyrlz chat profile: $profile. $detail $warm $charged $funny $structure $emojiRule $providerRule"
    }

    companion object {
        const val FOLLOW_RESPONSE_TOP = "Response top"
        const val FOLLOW_BOTTOM = "Conversation bottom"
        val FOLLOW_TARGETS = setOf(FOLLOW_RESPONSE_TOP, FOLLOW_BOTTOM)

        const val STYLE_ADAPTIVE = "Adaptive §wyrlz"
        private const val LEGACY_STYLE_ADAPTIVE = "Adaptive SWRLZ"
        const val STYLE_ENGINEER = "Engineer"
        const val STYLE_COMPANION = "Companion"
        const val STYLE_GLITCH_MUSE = "Glitch Muse"
        const val STYLE_DIRECT = "Direct"
        const val STYLE_CANDID = "Candid"
        val BASE_STYLES = setOf(STYLE_ADAPTIVE, STYLE_ENGINEER, STYLE_COMPANION, STYLE_GLITCH_MUSE, STYLE_DIRECT, STYLE_CANDID)

        const val DETAIL_COMPACT = "Compact"
        const val DETAIL_BALANCED = "Balanced"
        const val DETAIL_DEEP = "Deep"
        val DETAIL_LEVELS = setOf(DETAIL_COMPACT, DETAIL_BALANCED, DETAIL_DEEP)

        const val TRAIT_LOW = "Low"
        const val TRAIT_BALANCED = "Balanced"
        const val TRAIT_HIGH = "High"
        val TRAIT_LEVELS = setOf(TRAIT_LOW, TRAIT_BALANCED, TRAIT_HIGH)

        const val HUMOR_OFF = "Off"
        const val HUMOR_LIGHT = "Light"
        const val HUMOR_ADAPTIVE = "Adaptive"
        const val HUMOR_CHAOS = "Chaos"
        val HUMOR_LEVELS = setOf(HUMOR_OFF, HUMOR_LIGHT, HUMOR_ADAPTIVE, HUMOR_CHAOS)

        const val FORMAT_NATURAL = "Natural"
        const val FORMAT_BALANCED = "Balanced"
        const val FORMAT_STRUCTURED = "Structured"
        val FORMATTING_LEVELS = setOf(FORMAT_NATURAL, FORMAT_BALANCED, FORMAT_STRUCTURED)

        const val EMOJI_OFF = "Off"
        const val EMOJI_LIGHT = "Light"
        const val EMOJI_ADAPTIVE = "Adaptive"
        val EMOJI_LEVELS = setOf(EMOJI_OFF, EMOJI_LIGHT, EMOJI_ADAPTIVE)
    }
}
