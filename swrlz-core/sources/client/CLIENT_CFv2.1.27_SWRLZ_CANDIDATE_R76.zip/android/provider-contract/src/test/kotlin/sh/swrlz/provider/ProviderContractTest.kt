package sh.swrlz.provider

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProviderContractTest {
    @Test fun tagsRouteDeterministically() {
        assertEquals(ProviderStrategy.OPENAI, ProviderTagParser.resolve("@gpt review this").strategy)
        assertEquals(ProviderStrategy.GEMINI, ProviderTagParser.resolve("@gemini review this").strategy)
        assertEquals(ProviderStrategy.COUNCIL, ProviderTagParser.resolve("@gpt @gemini review this").strategy)
        assertEquals(ProviderStrategy.COMPARE, ProviderTagParser.resolve("@compare review this").strategy)
        assertEquals(ProviderStrategy.LOCAL_ONLY, ProviderTagParser.resolve("@local review this").strategy)
        assertEquals(ProviderStrategy.LOCAL_ONLY, ProviderTagParser.resolve("@lalm review this").strategy)
    }

    @Test fun tagsAreRemovedFromProviderPrompt() {
        val resolved = ProviderTagParser.resolve("@gpt @gemini analyze source")
        assertEquals("analyze source", resolved.cleanedPrompt)
        assertTrue(resolved.explicit)
        assertFalse(resolved.cleanedPrompt.contains("@"))
    }
}
