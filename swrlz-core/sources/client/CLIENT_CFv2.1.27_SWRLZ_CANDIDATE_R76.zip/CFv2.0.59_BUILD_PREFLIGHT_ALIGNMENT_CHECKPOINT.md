# CLIENT CFv2.0.59 — Build Preflight Alignment

**Recorded:** 2026-07-24  
**Status:** Source/static and package verification complete; GitHub compilation and device acceptance pending.

## Finding

The CLIENT root build applied the Kotlin 2.0 Compose Compiler Gradle plugin while the Kotlin Android and Kotlin serialization plugins remained on 1.9.24. The Compose compiler plugin is a Kotlin 2.0+ configuration and should use the same version as the Kotlin plugin.

## Repair

The root plugin set is aligned at 2.0.0:

```kotlin
id("org.jetbrains.kotlin.android") version "2.0.0" apply false
id("org.jetbrains.kotlin.plugin.compose") version "2.0.0" apply false
id("org.jetbrains.kotlin.plugin.serialization") version "2.0.0" apply false
```

No protocol, upload, connector, bubble-authority, or Theme Armor behavior is changed.

## Package identity

```text
Package: CLIENT_CFv2.0.59_SWRLZ.zip
versionCode: 86
versionName: 2.0.59-build-preflight-alignment-v1
```

The authoritative digest is supplied in the sibling external `CLIENT_CFv2.0.59_SWRLZ.sha256` receipt.

## Verification boundary

- XML resources parse successfully.
- Image resources verify successfully.
- package declarations match source paths.
- referenced local resources resolve.
- no explicit incompatible Compose `foundation.layout.weight` import exists.
- the final ZIP must pass compressed-data testing and match its external SHA receipt.
- GitHub Actions remains the authoritative Android compilation gate.
