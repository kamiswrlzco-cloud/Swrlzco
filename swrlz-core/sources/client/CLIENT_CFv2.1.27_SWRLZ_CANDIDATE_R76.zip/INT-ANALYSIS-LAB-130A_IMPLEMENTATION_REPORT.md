# INT-ANALYSIS-LAB-130A — Analysis Lab Export Intelligence

## Source handoff

Implements the three parked improvements from `SWRLZ_Analysis_Lab_Parked_Updates.docx` (August 12, 2026):

1. conversation corpus classifier cleanup;
2. nested opaque `.dat` archive detection;
3. timestamp/development-cycle analytics.

The operating boundary remains local-first, bounded-query, and provenance-preserving. The outer export and attachment payloads remain on the owning CLIENT unless the user separately authorizes a transfer.

## 1. Conversation corpus classifier cleanup

Main conversation candidates are now limited to:

- `conversations.json`; or
- a basename matching `^conversations-\d{3,}\.json$`.

`conversation_asset_file_names.json` is never treated as a conversation shard. Parsed conversation objects must contain a nonblank conversation ID and an object-shaped `mapping`; zero-message objects are excluded from the main message-bearing catalog. `shared_conversations.json` is handled on a separate reference-only path and surfaced separately from real message-bearing conversations.

This prevents metadata files from generating `conversation-unknown` records and prevents shared metadata references from inflating the real-thread count.

## 2. Nested opaque `.dat` archive detection

A `.dat` extension alone never grants archive semantics. The CLIENT:

- locates bounded `.dat` candidates from the compact Archive Index;
- consults `conversation_asset_file_names.json` filename/MIME metadata when available to prioritize probes;
- requires ZIP PK magic (`PK\x03\x04`, `PK\x05\x06`, or `PK\x07\x08`) before changing an opaque entry to type `archive`;
- updates the local index so `TREE`, `LIST`, nested `!` paths, and `INFO.nestedArchivesDetected` can see the detected archive;
- performs the same four-byte magic check inline during the non-seekable sequential compatibility scan;
- rechecks opaque entries encountered inside already-mounted nested ZIPs.

Mapped filenames/MIME types are hints only. Content signature remains authoritative.

## 3. Timestamp / development-cycle analytics

CLIENT adds Archive VFS operation `DEVELOPMENT_ANALYTICS`. SERVER exposes it as read-only MCP tool `swrlz_archive_development_analytics` and routes the bounded request to the archive-owning CLIENT under the existing `archive.read` capability.

Returned metrics include:

- update-delivery event count;
- distinct SERVER and CLIENT revision counts;
- field-test and issue-report counts;
- average/median/min/max update-to-test latency;
- average/median/min/max update-to-update duration;
- messages and tests between builds;
- completed update→test cycles per day;
- active engineering session count;
- longest active session;
- cumulative active engineering time;
- SERVER and CLIENT revision velocity;
- up to 100 provenance-bearing update→test cycle evidence rows.

The event classifier is explicit in every result. It does not infer hidden intent. Update delivery requires an assistant message containing a canonical `SERVER_..._CANDIDATE_R<n>.zip` or `CLIENT_..._CANDIDATE_R<n>.zip` filename; field-test/issue/diagnosis categories use documented bounded lexical indicators.

## Bounds

- maximum 5,000 conversation objects per analytics request;
- maximum 250,000 messages per analytics request;
- maximum 5,000 collected messages / 2,000,000 collected text characters from one conversation;
- 512 KiB existing Archive VFS tunnel-response ceiling remains unchanged;
- session gap is caller-selectable from 5–360 minutes (default 60);
- cycles-per-day grouping accepts a fixed UTC offset from -840 to +840 minutes; evidence timestamps remain UTC ISO values.

## SERVER / CLIENT pairing

- SERVER: R65 / VC188
- CLIENT: R39 / VC165
- Checkpoint: `INT-ANALYSIS-LAB-130A`

R65/R39 preserve R64/R38 native LALM bounded activation/probing behavior, the LM_HEAD capability repair, persistent Archive Index behavior, Truth Firewall authority, and existing trust/approval gates.
