# INT-OBSERVABILITY-RECONNECT-LALM-132A — CLIENT R41 implementation report

Parent: CLIENT R40 SHA-256 `65e2bfd00f1630a56d41e91d28eaf3e7e182fd3921b8516480a21c977066d288`
Paired SERVER: R68 / VC191.

## Scope
1. Adds a rotating app-private CLIENT NDJSON full diagnostic ledger plus Settings toggle/export. It logs application lifecycle, chat/stream state, registration/rebind/heartbeat, provider/LALM routing and errors. Chat text is intentionally included; raw credentials/device proofs/auth headers/private keys are forbidden.
2. Repairs in-place-update reconnect: on process start, persisted `ONLINE` is changed to `RECONCILING` until a fresh SERVER heartbeat proves the session. A valid session restarts heartbeat + ArchiveNodeRuntime; conclusive NOT_REGISTERED/proof-rebind/proof-mismatch responses trigger registration repair. Ambiguous network failure retains enrollment and reports DEGRADED rather than inventing a new node.
3. Heartbeat loop self-heals lost enrollment without uninstall/reinstall, while explicit manual disconnect preserves `autoReconnectSuppressed=true`.
4. Adds detailed LALM stream start/cancel/retry/terminal/failure/fallback logs and chat-history commit logs.
5. Provider snapshot presentation now marks successful remote status as SERVER-owned and recognizes canonical `lalm` alongside the historical `swrlie` alias, preventing false SERVER-offline / NO SERVER MODEL presentation after the provider rename.

No model execution authority, SERVER authority, trust/admin conflation, or automatic consequential action is added to CLIENT.
