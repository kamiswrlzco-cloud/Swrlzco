# CLIENT CFv2.1.7 — Theme Progress Compose Scope Repair Checkpoint

Checkpoint: `INT-THEME-035B`  
Status: source repair complete; follow-up build/device verification pending  
Parent: `CLIENT_CFv2.1.6_SWRLZ.zip` / SHA-256 `bed74b9e4c85e180c2a709f5a48dece3e1abb0e3a9cdab948d80888077aafb94`  
Android identity: versionCode `105`, versionName `2.1.7-theme-progress-compose-scope-repair-v1`

## Evidence
Workflow run `30216145763` verified the CFv2.1.6 CLIENT source/checksum and passed six resolver tests. Kotlin compilation then failed at `ThemedProgress.kt:175` and `:190` because `maxWidth` was requested through nested implicit Compose receivers.

## Repair
The enclosing `BoxWithConstraints.maxWidth` is captured once as `availableWidth`; both nested progress-fill `Image` modifiers use `Modifier.width(availableWidth)`. No ThemePack contract, asset, semantic-state truth rule, reduced-motion rule, protocol, trust, mission authority, permission, Forge authority, or offline-first behavior changed.

## Verification boundary
Static verification only. Gradle compilation, unit/instrumentation execution, APK/AAB assembly, device verification, GitHub publication, commit, push, release, deployment, and installation are not run or claimed.
