# INT-CLIENT-BUILD-COMPAT-160A — CLIENT R67 Patch Notes

**Parent:** R66 → **Current:** R67 (VC193)  
**Paired SERVER:** R101 unchanged  
**Parent source SHA-256:** `25cb8ad577807fbb33bf90e7da4883834f8c0911ffe5007f22c4954342fa4553`

## Failure diagnosed
APK Router accepted the R66 Forge pointer, resolved the canonical source, verified the strict two-member metadata bundle, and marked the source build-eligible. Gradle then failed `:app:checkDebugAarMetadata` because:
- Credential Manager 1.6.0 requires compileSdk 35+.
- Credential Manager 1.6.0 requires AGP 8.6.0+.
- its resolved AndroidX Core 1.15.0 dependency also requires compileSdk 35+.
- R66 was still compileSdk 34 / AGP 8.5.2.

## Repair
- `android/build.gradle.kts`: AGP 8.5.2 → 8.6.1.
- `android/app/build.gradle.kts`: compileSdk 34 → 35.
- targetSdk remains 34 to avoid bundling an unrelated runtime-behavior migration into this build fix.
- Gradle wrapper remains 8.7, compatible with AGP 8.6.
- Credential Manager remains 1.6.0; no rollback to deprecated GoogleSignInClient.
- Version identity advanced to R67 / VC193 / `INT-CLIENT-BUILD-COMPAT-160A`.

## Preservation
All R66 feature and safety work remains in place. SERVER R101 already built successfully and is not revised.

## Acceptance
A fresh APK Router CLIENT build is required before claiming APK/install/device success.
