# SWRLZ-Core 2.4 Command Inbox Patch Report

## Identity

- App version: `0.2.4-command-inbox`
- Version code: `10`
- Patch: `2.4-COMMAND-INBOX`
- Roadmap revision: `2.4`
- Source ZIP: `SWRLZ_CORE_2.4_COMMAND_INBOX_SOURCE.zip`

## Included fixes from the 2.3 status-truth pass

- Fixed the Home screen `Local Core Node bridge` row that wrapped into broken fragments on narrow displays.
- Reworked system status rows into a responsive stacked layout for long status values.
- Added stricter Core Node success validation: `/status` must return valid JSON with `ok=true`, node identity, and server version before the app marks the node reachable.
- Setup now reports auto-check state honestly instead of saying configured/not tested after a saved URL check has already occurred.
- Core/admin request failures now show clean user-facing messages instead of Kotlin stack traces.

## New 2.4 command inbox features

- Added `Cmds` tab.
- Added command inbox screen for pending command polling.
- Added admin command creation for safe test commands.
- Added command acknowledge/reject/complete test loop.
- Added Core Node API methods for:
  - `GET /commands/pending`
  - `GET /admin/commands/all`
  - `POST /admin/commands/create`
  - `POST /commands/{id}/ack`
  - `POST /commands/{id}/result`

## Safety stance

This patch only adds the first safe command queue loop. It does not perform dangerous or autonomous device actions. Commands are visible, manually acknowledged, and manually completed during testing.

