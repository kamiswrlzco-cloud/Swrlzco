# SWRLZ-Core Latest Setup Guide — 2.2 Admin + How-To + Info

## Current app identity

```text
v0.2.2-admin-howto-info · code 9
Patch: 2.2-ADMIN-HOWTO-INFO
Roadmap: 2.2
```

## Build from Codespaces

```bash
sha256sum -c SWRLZ_CORE_2.2_ADMIN_HOWTO_INFO_SHA256.txt
bash scripts/install_android_sdk_and_build.sh
```

Then download the APK bundle from `APK_DOWNLOAD`.

## Install/update on Android

Open the APK and install/update. Confirm Home displays:

```text
v0.2.2-admin-howto-info · code 9
```

## Connect to same-phone Core Node

Run Termux server on the same phone and use:

```text
http://127.0.0.1:8787
```

## Connect to two-phone Core Node

Run Termux server on the second phone and use the printed LAN URL:

```text
http://192.168.x.x:8787
```

## New menus

- `Core` — Core Node admin/status/settings/log helpers.
- `How To` — update and setup instructions.
- `Info` — app legend explaining every menu and status color.
