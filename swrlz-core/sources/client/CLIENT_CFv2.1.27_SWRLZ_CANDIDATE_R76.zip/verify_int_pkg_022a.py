from pathlib import Path
root=Path(__file__).parent
g=(root/'android/app/build.gradle.kts').read_text()
wf=(root/'.github/workflows/build-apk.yml').read_text()
checks={
 'versionCode 42':'versionCode = 42' in g,
 'versionName':'cfv2.0.11-int-pkg-022a' in g,
 'workflow artifact':'CLIENT_CFv2.0.11_SWRLZ_DEBUG.apk' in wf,
}
for k,v in checks.items(): print(f'{k}: {"PASS" if v else "FAIL"}')
raise SystemExit(0 if all(checks.values()) else 1)
