# INT-AI-SWRLZX-013A — CLIENT R38 Validation

- Focused source/identity/probing-UX checks are included in the paired 29/29 assertion run.
- Chat now resolves the SERVER `swrlie` provider's selected discovered model while health is `PROBING` and renders `<model> · PROBING` before Model Rack selection is committed.
- `NO SERVER MODEL` remains the fallback only when neither a selected Model Rack model nor a probing SWRLIE model exists.
- R37 Archive Index implementation and streaming behavior are preserved.
- Android Gradle wrapper acquisition was attempted; DNS resolution for `services.gradle.org` failed before project compilation. No APK/build claim is made here.
