# INT-REGISTRATION-HOTPATH-124A — CLIENT R20 validation

- Focused source verifier: **18/18 PASS**.
- Registration request contains identity/proof/capabilities but no archive advertisement.
- Registration response budget is 5 seconds with one idempotent retry on `SocketTimeoutException`; heartbeat budget is 2.5 seconds.
- First heartbeat is immediate and carries Archive VFS advertisements.
- Archive advertisement no longer opens SAF archive documents; persisted read permission is used as the cheap presence signal.
- Android Gradle compile was attempted but wrapper download failed before Kotlin compilation with `UnknownHostException: services.gradle.org`. GitHub Actions remains compile/sign acceptance.
