# INT-AI-SWRLZX-011A — Operator / Quantizer Reference Matrix

| Surface | Production implementation | Evidence in 011A | Status |
|---|---|---|---|
| RMSNorm | `SwrlzxLalmMathV1.rmsNorm` | deterministic Kotlin primitive fixture | PASS |
| RoPE | `SwrlzxLalmMathV1.ropeHead` | position-zero identity + energy preservation fixture | PASS (reference fixture) |
| Gated MLP | `SwrlzxLalmMathV1.gatedMlp` | deterministic SiLU gate/up/down fixture | PASS (reference fixture) |
| Short convolution state | `SwrlzxLfmConvStateV1` | recurrent-state and owner-isolation fixture | PASS (reference fixture) |
| Tensor K/V paging | `SwrlzxTensorKvCacheV1` | paging and cross-owner rejection fixture | PASS |
| GQA causal attention | native graph `GQA_ATTENTION` | source/shape/state verification + component fixtures | SOURCE IMPLEMENTED; full-model parity OPEN |
| Sampling | `SwrlzxLalmSamplerV1` | deterministic seeded fixture | PASS |
| BF16 | `SwrlzxLalmQuantV1.decodeBf16` | deterministic row fixture | PASS |
| Q4_K | `SwrlzxLalmQuantV1.decodeQ4K` | 32 independent random GGML-layout blocks / 8,192 values | PASS |
| Q6_K | `SwrlzxLalmQuantV1.decodeQ6K` | 32 independent random GGML-layout blocks / 8,192 values | PASS |
| GGML BPE byte codec | `SwrlzxGgmlBpeV1` / `SwrlzxGpt2ByteCodecV1` | UTF-8 round-trip, merge, special-token, Unicode-byte fixtures | PASS (reference fixture) |
| Exact `lfm2` pre-tokenizer | same tokenizer path + real metadata | requires real source/corpus comparison | OPEN 012A |
| Full canonical LALM logits/tokens | `SwrlzxNativeEngine` | exact converted real model required | OPEN 012A |

## Tolerance policy

Reference primitive fixtures are exact where the expected value is algebraic/discrete. Quantizer comparison uses independent GGML-layout formulas with `3e-6` relative/absolute float tolerance for host float conversion. Full model numerical tolerance is **not defined by 011A**; 012A must define and justify it before `swrlzxParityStatus=PROVEN` can be recorded.
