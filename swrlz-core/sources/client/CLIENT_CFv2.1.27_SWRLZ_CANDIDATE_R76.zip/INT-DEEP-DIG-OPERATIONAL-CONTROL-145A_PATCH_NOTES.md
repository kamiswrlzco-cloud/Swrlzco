# INT-DEEP-DIG-OPERATIONAL-CONTROL-145A — CLIENT R54

## Deep Dig / forensic analysis
- Adds `CORPUS_AGGREGATE` for one-pass user/assistant/corpus totals: messages, characters, words, lexical tokens, transparent estimated model tokens, and estimated 160-character SMS segments.
- Adds seedless `NEOLOGISM_ANALYZE`: recurrence, first/last evidence, role counts, mutual user↔assistant adoption, root normalization, bounded near-root clustering, stylization/morphology evidence, probable-typo/review/intentional classifications.
- Optimizes FUZZY matching by preparing each message once and comparing short seeds to bounded message tokens instead of whole-body edit similarity.
- Normalizes `YYYY-MM-DD`, epoch-ms, and accidental epoch-second date bounds explicitly.

## Operational control / safety
- Directory and Archive VFS gain read-only `MUTATION_PLAN` evidence plus approval hashes re-derived from live target/source state immediately before destructive execution.
- Large/protected archive replacement is marked double-verification class. Directory destructive planning fails closed when a complete bounded inventory cannot be established.
- Adds bounded provider-native `APPEND_TEXT` with expected-size/SHA guards, idempotency receipt, canonical provider path and exact length verification. Unsafe implicit whole-file fallback is refused.
- CLIENT emits redacted observable tool lifecycle notifications and adds TOOLS logger categories for VFS, analysis and authority.

## Evidence boundary
Source/static candidate only. Gradle wrapper distribution was unavailable in this sandbox, so Android compilation/APK/device acceptance is not claimed.
