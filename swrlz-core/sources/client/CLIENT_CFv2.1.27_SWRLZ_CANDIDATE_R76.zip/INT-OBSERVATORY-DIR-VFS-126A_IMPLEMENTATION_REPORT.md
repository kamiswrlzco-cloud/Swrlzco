# INT-OBSERVATORY-DIR-VFS-126A Implementation Report

## Goal
Repair live recovered-identity transfer gating, make Observatory index real node-protocol conversations, and add a locally authorized Selective Directory VFS for bounded analysis/file operations with honest deleted-file recovery.

## SERVER R46
- Proof-bound reinstall lineage can remain identity CONFIRMED while rebind/trust reapproval stays independently enforced.
- Observatory now reacts to node message/reply activity and group links and synthesizes NODE_PROTOCOL conversations/history with provenance.
- Opaque directory grant registry receives heartbeat advertisements off the response hot path.
- MCP catalog expands from 33 to 47 tools, adding 14 directory tools.
- Directory reads require TRUSTED proof-bound target; writes require local grant write authority and explicit MCP consequential confirmation.

## CLIENT R22
- User-selected SAF tree grants remain local and default read-only.
- Directory VFS supports bounded browse/list/read/search/structural analysis and confirmed mutations inside a single grant.
- Recovery scan/restore covers Android-visible trash/remnants only; raw block carving remains unavailable without future privileged capability.
- Background worker requires exact directory control-plane capability and keeps 512 KiB response ceiling.

## Non-claims
No APK compile/install, GitHub workflow, raw deleted-block recovery, or device/tunnel acceptance is claimed by source implementation alone.
