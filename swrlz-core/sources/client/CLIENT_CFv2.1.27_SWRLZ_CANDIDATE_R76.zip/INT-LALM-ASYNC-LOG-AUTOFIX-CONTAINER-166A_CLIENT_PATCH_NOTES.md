# INT-LALM-ASYNC-LOG-AUTOFIX-CONTAINER-166A — CLIENT R74 PATCH NOTES

## 🫙 recovery and hardening
- R73 v2/unknown structure overlays are quarantined out of the active store on first resolution. The raw overlay is retained separately, while the chat falls back to immutable original content so previously poisoned chats can open.
- New v3 jar overlays require balanced non-nested `[🫙]...[/🫙]` structure, clamp stale selection indexes, cap container count, and fail safe without mutation.
- Rich rendering falls back to plain text on parser/structure failure. Code payloads use bounded full-width wrapping instead of an unbounded horizontal measurement path.
- Composer and historical-message selection toggles remain persistent and non-destructive.

## LALM timeout repair
- Long local LALM requests now use SERVER R109 asynchronous provider-reason jobs with short bounded control requests and status polling, honoring the LALM budget instead of the global 60-second HTTP request ceiling.
- Pre-R109 direct endpoint fallback remains only for an explicit 404 from the async submit route.

## swrlz_logs READ_CHUNK
- Routed canonical/generic log requests preserve or infer READ_CHUNK whenever snapshot/log identity is present.
- READ_CHUNK preflight requires snapshotId + logId; malformed chunk requests cannot silently become MANIFEST.

## Google account boundary
- Existing OAuth public Web Client ID configuration plumbing remains intact. No OAuth ID/secret is invented; live Google/Auth0 account linking still requires the real external configuration.

## Evidence boundary
- Local Gradle probe is blocked before compilation because `services.gradle.org` is unavailable in this environment. No APK/device success is claimed.
