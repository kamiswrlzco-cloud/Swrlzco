# CLIENT CFv2.1.0 — Autonomous Update Loop Foundation

**Recorded:** 2026-07-25
**Baseline:** CLIENT CFv2.0.72
**SERVER compatibility reference:** SERVER CFv2.0.49 debug artifact supplied; SERVER source was not supplied in this pass.

## Implemented

- `UPDATE` chat intent for explicit CLIENT/SERVER update requests containing a source ZIP/version.
- Exact Downloads lookup for requested source ZIP and exact sibling `.sha256`; no fuzzy filename guessing.
- Local ZIP/SHA validation before repository mutation.
- Reuse of the existing Chat Forge pipeline for upload, commit confirmation, workflow correlation, human-readable chat milestones, log analysis, and cancellation.
- Autonomous workflow watch loop with conservative retry only for transient failure classes.
- Artifact download, APK extraction, local SHA-256 verification, and Android install handoff via FileProvider.
- Durable CLIENT `UpdateHandoff` record so a same-package update can resume verification after relaunch.
- SERVER update handoff keeps CLIENT as the surviving orchestrator; post-install reconnect/version verification remains the next runtime integration step.
- Forge failure analyzer now recognizes stale `Missing manifest` verifier failures as workflow-contract mismatch rather than automatically blaming valid source bytes.

## Safety / authority boundaries

- Android package installer remains authoritative; CFv2.1.0 opens the install handoff and does not bypass platform approval.
- Source ZIP/SHA integrity remains fail-closed.
- No automatic architectural/code rewrite is attempted from ambiguous logs. Deterministic local repairs and future Swurver/provider repair escalation must preserve source lineage and patch evidence.
- Existing Forge STOP/cancel controls remain authoritative throughout the loop.

## Acceptance gate

1. Compile CLIENT CFv2.1.0 in GitHub Actions.
2. Place an exact CLIENT or SERVER source ZIP and sibling SHA in Downloads.
3. In Chat, issue `Update SERVER using <exact ZIP name>` (or CLIENT).
4. Verify local pair validation, Forge upload narration, commit-bound workflow discovery, and success/failure narration.
5. On failure, verify log analysis is surfaced and no duplicate source commit is created during transient refresh retry.
6. On success, verify artifact download, APK extraction, SHA calculation, and Android install prompt.
7. For CLIENT, complete in-place install and relaunch; verify the durable handoff is consumed only after expected version continuity is satisfied.
8. For SERVER, complete install then validate reconnect/version/capability checks once SERVER source/runtime hook is added.
