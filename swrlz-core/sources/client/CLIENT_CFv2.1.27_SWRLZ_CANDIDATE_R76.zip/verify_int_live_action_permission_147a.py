#!/usr/bin/env python3
from pathlib import Path
import json, re, sys, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
checks=[]
def check(name, cond): checks.append((name,bool(cond)))
def text(rel): return (ROOT/rel).read_text(errors='replace')
notifier=text('android/app/src/main/java/sh/swurlz/core/notification/ToolActionNotifier.kt')
status=text('android/app/src/main/java/sh/swurlz/core/notification/ClientStatusNotification.kt')
svc=text('android/app/src/main/java/sh/swurlz/core/service/ClientStatusService.kt')
shell=text('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt')
perm=text('android/app/src/main/java/sh/swurlz/core/ui/screens/PermissionsScreen.kt')
grant=text('android/app/src/main/java/sh/swurlz/core/directory/DirectoryGrantStore.kt')
engine=text('android/app/src/main/java/sh/swurlz/core/directory/DirectoryVfsEngine.kt')
main=text('android/app/src/main/java/sh/swurlz/core/MainActivity.kt')
build=text('android/app/build.gradle.kts')
check('version r56', 'versionCode = 182' in build and '2.1.27-live-action-storage-permissions-r56' in build and 'SWRLZ_REVISION' in build and 'R56' in build and 'INT-LIVE-ACTION-PERMISSION-UX-147A' in build)
check('action stateflow', 'MutableStateFlow<ActionSnapshot?>' in notifier and 'val latest: StateFlow<ActionSnapshot?>' in notifier)
check('three surfaces', all(x in notifier for x in ['STATUS_STREAM','ANDROID_EVENTS','CHAT_BUBBLE']))
check('verbosity enforced across surfaces', 'shouldExposeToSurfaces' in notifier and 'Verbosity.OFF' in notifier)
check('bubble mirror', 'ClientBubbleController.publish' in notifier)
check('status live action', 'Live action ↻' in status and 'ToolActionNotifier.shouldExposeToSurfaces' in status)
check('service observes action state', 'ToolActionNotifier.latest' in svc)
check('settings surface toggles', all(x in shell for x in ['Live action roll','Separate tool notifications','Tool actions in bubble','Tool action detail']))
check('directory analysis toggle', 'Directory analysis' in shell and 'DIRECTORY_ANALYSIS_DISABLED' in engine)
check('default downloads grant', 'SET DEFAULT ANDROID DOWNLOADS DIRECTORY' in shell and 'recommendedDownloadsInitialUri' in grant)
check('default grant is read-only fallback', 'defaultGrantId' in engine and 'operation in setOf("INFO", "TREE", "LIST", "READ", "SEARCH", "ANALYZE")' in engine)
check('mutations require explicit grant', 'grantId' in engine and 'defaultGrantId' in engine)
check('permission centre directory access', 'Downloads / Directory Access' in perm and 'All Files Special Access' in perm)
check('permission centre wording updated', 'Permission and storage grants live here.' in perm)
check('all files settings helper', 'ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION' in main)
# JSON/XML corpus health
json_bad=[]
for p in ROOT.rglob('*.json'):
    try: json.loads(p.read_text(errors='strict'))
    except Exception as e: json_bad.append((str(p.relative_to(ROOT)),str(e)))
check('all json valid', not json_bad)
xml_bad=[]
for p in list((ROOT/'android/app/src/main').rglob('*.xml')):
    try: ET.parse(p)
    except Exception as e: xml_bad.append((str(p.relative_to(ROOT)),str(e)))
check('android xml valid', not xml_bad)
# Very lightweight lexical sanity for modified Kotlin files
mods=[notifier,status,svc,shell,perm,grant,engine,main]
check('no merge conflict markers', not any(('<<<<<<<' in x or '>>>>>>>' in x or '=======' in x) for x in mods))
for n,c in checks: print(('PASS' if c else 'FAIL'),n)
print(f'RESULT {sum(c for _,c in checks)}/{len(checks)}')
if json_bad: print('JSON_BAD',json_bad[:5])
if xml_bad: print('XML_BAD',xml_bad[:5])
sys.exit(0 if all(c for _,c in checks) else 1)
