# INT-OBSERVATORY-DIR-VFS-126A CLIENT validation

- Focused source verifier: **26/26 PASS**.
- Kotlin stub compile of `DirectoryGrantStore.kt` + `DirectoryVfsEngine.kt`: PASS.
- Local Android Gradle: blocked before Kotlin compilation by `services.gradle.org` DNS unavailability.
- Source manifest and ZIP integrity are generated/checked during sealing; GitHub Actions remains compile/stable-sign acceptance.
- Recovery boundary: MediaStore/trash/remnant inspection is best-effort and grant-scoped; raw deleted-block carving is explicitly unavailable on stock Android without a future privileged helper.
