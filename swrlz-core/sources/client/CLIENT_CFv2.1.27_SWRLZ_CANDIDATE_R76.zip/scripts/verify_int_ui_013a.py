from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
checks={
'android/app/build.gradle.kts':['versionCode = 35','cfv2.0.4-int-ui-013a'],
'android/app/src/main/java/sh/swurlz/core/MainActivity.kt':['openRoute("user-perms")','UserFeatureShell("Node Trust"','!currentRoute.startsWith("user-")'],
'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt':['ClientTab.Activity','Actionable operator events only'],
'android/app/src/main/AndroidManifest.xml':['android:roundIcon="@mipmap/ic_launcher_round"'],
}
errors=[]
for rel, needles in checks.items():
 p=root/rel
 if not p.exists(): errors.append(f'missing {rel}'); continue
 text=p.read_text()
 for n in needles:
  if n not in text: errors.append(f'{rel}: missing {n}')
main=(root/'android/app/src/main/java/sh/swurlz/core/MainActivity.kt').read_text()
for forbidden in ['switchInterface(ClientInterfaceMode.Developer, "perms")','switchInterface(ClientInterfaceMode.Developer, "discovery")','switchInterface(ClientInterfaceMode.Developer, "core")','switchInterface(ClientInterfaceMode.Developer, "style")','switchInterface(ClientInterfaceMode.Developer, "setup")']:
 if forbidden in main: errors.append(f'forbidden User→Developer route remains: {forbidden}')
icon=root/'android/app/src/main/res/drawable-nodpi/swrlz_glitch_dragon_launcher.png'
if not icon.exists() or icon.stat().st_size<100000: errors.append('launcher identity missing')
if errors:
 print('CLIENT INT-UI-013A VERIFY FAIL'); print('\n'.join('- '+x for x in errors)); sys.exit(1)
print('CLIENT INT-UI-013A VERIFY PASS')
