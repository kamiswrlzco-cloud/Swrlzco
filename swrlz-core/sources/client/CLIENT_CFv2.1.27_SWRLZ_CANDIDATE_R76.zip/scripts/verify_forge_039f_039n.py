#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parents[1]
errors = []

forge = (root / "android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt").read_text(encoding="utf-8")
settings = (root / "android/app/src/main/java/sh/swurlz/core/ui/client/ForgeSettingsControls.kt").read_text(encoding="utf-8")
screen = (root / "android/app/src/main/java/sh/swurlz/core/ui/screens/GitHubForgeScreen.kt").read_text(encoding="utf-8")
chat = (root / "android/app/src/main/java/sh/swurlz/core/github/ChatForgeCoordinator.kt").read_text(encoding="utf-8")

required = {
    "optional checksum default": "requireChecksum: Boolean = false",
    "optional manifest default": "requireManifest: Boolean = false",
    "AUTO transport": "enum class SourceTransportMode { AUTO, DIRECT, CHUNKED }",
    "current bounded chunk threshold": "SOURCE_CHUNK_THRESHOLD_BYTES = 4L * 1024L * 1024L",
    "transport manifest": 'transport: String = "chunked-git-blobs-v1"',
    "resume cache": 'getSharedPreferences("forge_chunk_resume_blobs"',
}
for label, token in required.items():
    if token not in forge:
        errors.append(f"missing {label}: {token}")

if 'listOf("AUTO", "DIRECT", "CHUNKED")' not in settings:
    errors.append("Forge settings do not expose AUTO/DIRECT/CHUNKED")
if "sourceTransportMode = sourceTransportMode" not in screen:
    errors.append("Forge screen does not pass selected transport mode")
if "sourceTransportMode = transportMode" not in chat:
    errors.append("Chat Forge does not pass selected transport mode")
if "validateSourcePairs(context, current.files)" not in chat:
    errors.append("Chat Forge does not validate supplied optional evidence")

patch_ci = root / "repo-patches/INT-FORGE-039F-039N/swrlz-core/tools/ci"
result = subprocess.run([sys.executable, str(patch_ci / "test_resolve_swrlz_source.py")], cwd=patch_ci, text=True, capture_output=True)
if result.returncode != 0:
    errors.append("repository resolver regression tests failed:\n" + result.stdout + result.stderr)

if errors:
    for error in errors:
        print("FAIL:", error)
    raise SystemExit(1)

print("PASS: INT-FORGE-039F+039N source/regression precheck")
