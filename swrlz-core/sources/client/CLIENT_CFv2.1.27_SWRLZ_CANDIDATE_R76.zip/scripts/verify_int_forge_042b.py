#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
errors=[]
def need(path, token, label):
    text=(root/path).read_text(encoding="utf-8")
    if token not in text: errors.append(f"{label}: missing {token}")
need("android/app/build.gradle.kts", "versionCode = 122", "CLIENT VC122")
need("android/app/build.gradle.kts", 'versionName = "2.1.24-forge-transport-v2-candidate-r1"', "CLIENT version")
need("android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt", "@Composable\nprivate fun ChatSettingsChoiceGroup", "Compose repair")
forge="android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt"
for token,label in [
("SOURCE_CHUNK_SIZE_BYTES = 4 * 1024 * 1024","4 MiB chunks"),
("enum class SourceTransportMode { AUTO, DIRECT, CHUNKED }","transport modes"),
("CHUNK_RESUME_VERIFIED","verified resume"),
("BLOB_RETRY","blob retry diagnostics"),
("failure.statusCode in setOf(401, 408, 425, 429, 500, 502, 503, 504)","transient retry set"),
("authReprobe","401 auth reprobe"),
("retryAfterSeconds","Retry-After support"),
("rateLimited","rate limit semantics"),
]: need(forge,token,label)
need("android/app/src/main/java/sh/swurlz/core/github/ForgeChunkTransport.kt", "DEFAULT_CHUNK_SIZE_BYTES: Int = 4 * 1024 * 1024", "chunk planner")
if errors:
    [print("FAIL:",e) for e in errors]
    raise SystemExit(1)
print("PASS: INT-FORGE-042B CLIENT static gates")
