#!/usr/bin/env python3
"""Static verifier for INT-AI-041F-A.

This proves source/contract/package invariants only. It does not claim that either
Android application compiled, that an APK exists, or that device integration ran.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

OPTIMIZED_SHA256 = "651cd5c40e4ef24de2ff12c2b53b257d15816ddd4346e2575e6768a6ec1d8590"
OPTIMIZED_SIZE = 229_315_680


def read(root: Path, relative: str) -> str:
    return (root / relative).read_text(encoding="utf-8")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def valid_pack_source(directory: Path) -> bool:
    try:
        manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
        payloads = manifest["payloads"]
        return bool(payloads) and all(
            (directory / item["path"]).is_file()
            and (directory / item["path"]).stat().st_size == item["sizeBytes"]
            and sha256(directory / item["path"]) == item["sha256"]
            for item in payloads
        )
    except (KeyError, OSError, TypeError, ValueError):
        return False


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--server-root", type=Path, required=True)
    parser.add_argument("--client-root", type=Path, required=True)
    parser.add_argument("--model", type=Path)
    args = parser.parse_args()

    server = args.server_root.resolve()
    client = args.client_root.resolve()
    checks: list[tuple[str, bool]] = []

    def expect(name: str, condition: bool) -> None:
        checks.append((name, bool(condition)))

    server_contract = server / "model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt"
    client_contract = client / "android/model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt"
    contract = server_contract.read_bytes()
    contract_text = contract.decode("utf-8")
    expect("shared contract byte identity", contract == client_contract.read_bytes())
    expect("optimized SHA identity", OPTIMIZED_SHA256 in contract_text)
    expect("optimized byte-size identity", "229_315_680L" in contract_text)
    expect("protocol authority is bounded", 'controlAuthority: String = "paired_lan_model_rack_only"' in contract_text)
    expect("immutable safeguards declared", all(
        value in contract_text
        for value in (
            '"truth_firewall"',
            '"permissions"',
            '"approvals"',
            '"provenance"',
            '"mission_authority"',
            '"forge_authority"',
            '"execution"',
        )
    ))

    server_gradle = read(server, "app/build.gradle.kts")
    client_gradle = read(client, "android/app/build.gradle.kts")
    expect("SERVER candidate identity", "versionCode = 67" in server_gradle and
           'versionName = "2.1.10-modular-model-rack-expression-eq-candidate-r1"' in server_gradle)
    expect("CLIENT candidate identity", "versionCode = 121" in client_gradle and
           'versionName = "2.1.23-modular-model-rack-expression-eq-candidate-r1"' in client_gradle)

    model_vault = read(
        server,
        "app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelVault.kt",
    )
    metadata = read(
        server,
        "ai-runtime-contract/src/main/kotlin/sh/swrlz/ai/runtime/GgufMetadata.kt",
    )
    settings = read(
        server,
        "app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieRuntimeSettings.kt",
    )
    module_vault = read(
        server,
        "app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModuleVault.kt",
    )
    rack = read(
        server,
        "app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelRack.kt",
    )
    protocol = read(
        server,
        "app/src/main/java/sh/swrlz/nodehost/service/ModelRackProtocol.kt",
    )
    pairing = read(
        server,
        "app/src/main/java/sh/swrlz/nodehost/security/ServerModelRackPairingStore.kt",
    )
    runtime = read(
        server,
        "app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieLocalRuntime.kt",
    )

    expect("GGUF SWRLZ metadata preserved", 'key.startsWith("swrlz.")' in metadata and
           "MAX_SWRLZ_METADATA_KEYS" in metadata and "MAX_SWRLZ_VALUE_BYTES" in metadata and
           "9 -> reader.skipValue(type)" in metadata)
    expect("exact optimized base recognition", "OPTIMIZED_BASE_SHA256" in model_vault and
           "OPTIMIZED_BASE_SIZE_BYTES" in model_vault and "VERIFIED_SWRLZ_BASE" in model_vault)
    expect("profiles isolated by model SHA", 'CURRENT_PREFIX = "profile_"' in settings and
           "modelSha256.normalizedSha()" in settings)
    expect("profile optimistic concurrency", "MODEL_PROFILE_GENERATION_CONFLICT" in settings and
           "generation = current.generation + 1" in settings)
    expect("profile rollback", 'PREVIOUS_PREFIX = "previous_"' in settings and "fun rollback" in settings)
    expect("context remains bounded", "RUNTIME_HARD_MAX = 32_768" in settings and
           '"swrlz.context.documented_limit_tokens"' in settings)
    expect("declarative pack entry limits", "MAX_ARCHIVE_BYTES" in module_vault and
           "MAX_UNCOMPRESSED_BYTES" in module_vault and "MAX_ENTRIES" in module_vault and
           "MAX_MANIFEST_BYTES" in module_vault and "MODEL_MODULE_DUPLICATE_ENTRY" in module_vault)
    expect("pack hashes and sizes verified", "MODEL_MODULE_PAYLOAD_HASH_MISMATCH" in module_vault and
           "MODEL_MODULE_PAYLOAD_SIZE_MISMATCH" in module_vault)
    expect("pack traversal rejected", "validateEntryPath" in module_vault and
           '"MODEL_MODULE_PATH_INVALID"' in module_vault and "safeVersion" in contract_text and
           "PACK_VERSION_INVALID" in contract_text)
    expect("executable pack content rejected", "forbiddenExtensions" in module_vault and
           '"wasm"' in module_vault and '"kts"' in module_vault and
           '"MODEL_MODULE_EXECUTABLE_CONTENT_REJECTED"' in module_vault)
    example_root = server / "docs/contracts/examples/model-rack"
    expect("prompt and EQ modules live", "PROMPT_CAPSULE" in module_vault and
           "EXPRESSION_EQ" in module_vault and "ActiveModuleComposition" in module_vault and
           "LOCAL_HASH_VERIFIED" in module_vault and
           valid_pack_source(example_root / "technical-focus") and
           valid_pack_source(example_root / "warm-companion"))
    expect("LoRA activation fails closed", 'require(manifest.type != ModelModuleTypeV1.LORA_ADAPTER)' in module_vault and
           '"LORA_NATIVE_BRIDGE_UNAVAILABLE"' in module_vault and "loraActivationAvailable = false" in rack)
    expect("verified embedded prompt is gated", '"swrlz.prompt.default_system"' in runtime and
           'record.model.metadata["optimizedSwrlzBase"] == "true"' in runtime and
           "SwrlieModuleVault.compose" in runtime and "MODEL_RACK_IMMUTABLE_BOUNDARY" in runtime and
           "Module instructions never override the immutable SWRLZ boundary." in runtime)
    expect("model activation and rollback", "activateModel" in rack and "rollbackModel" in rack and
           "activationMutex.withLock" in runtime)
    expect("dedicated encrypted pairing credential", "EncryptedSharedPreferences" in pairing and
           "AES256_GCM_SPEC" in pairing and "ByteArray(32)" in pairing)
    expect("LAN control requires registered action CLIENT", "MODEL_RACK_CLIENT_NOT_REGISTERED" in protocol and
           '"action-phone"' in protocol and "PairedLanAuthorizer" in protocol)
    expect("LAN control uses dedicated pairing token", "ServerModelRackPairingStore" in protocol and
           '"x-swurlz-pairing-token"' in protocol)
    expect("model-rack routes are bounded", all(
        value in protocol
        for value in (
            "ModelRackProtocolV1.STATUS",
            "ModelRackProtocolV1.PROFILE",
            "ModelRackProtocolV1.ACTIVATE_MODEL",
            "ModelRackProtocolV1.ACTIVATE_MODULE",
            "ModelRackProtocolV1.ROLLBACK",
        )
    ))

    client_api = read(
        client,
        "android/app/src/main/java/sh/swurlz/core/net/Api.kt",
    )
    client_runtime = read(
        client,
        "android/app/src/main/java/sh/swurlz/core/ai/ModelRackClientRuntime.kt",
    )
    client_ui = read(
        client,
        "android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt",
    )
    expect("CLIENT uses every rack endpoint", all(
        value in client_api
        for value in (
            "ModelRackProtocolV1.STATUS",
            "ModelRackProtocolV1.PROFILE",
            "ModelRackProtocolV1.ACTIVATE_MODEL",
            "ModelRackProtocolV1.ACTIVATE_MODULE",
            "ModelRackProtocolV1.ROLLBACK",
        )
    ))
    expect("CLIENT sends registered role and node identity", '"X-SWRLZ-Client-Role", "action-phone"' in client_api and
           '"X-SWRLZ-Device-Node-Id"' in client_api)
    expect("CLIENT sends existing pairing token", '"X-Swurlz-Pairing-Token"' in client_api)
    expect("CLIENT retains generation before writes", "expectedGeneration = current.rackGeneration" in client_runtime)
    expect("CLIENT exposes rack controls", all(
        value in client_ui
        for value in (
            "MODEL_RACK",
            'SectionLabel("MODEL")',
            'SectionLabel("SPEED")',
            'SectionLabel("REASONING DEPTH")',
            'SectionLabel("EXPRESSION EQ")',
            'ClientEqSlider("Warmth"',
            'ClientEqSlider("Technical depth"',
            'ClientEqSlider("Mythic expression"',
            'SectionLabel("MODULES")',
        )
    ))
    expect("UI says depth is not learned intelligence", "It does not add learned intelligence." in client_ui)
    expect("UI preserves immutable boundary", "Truth Firewall, permissions, approvals, provenance, node trust" in client_ui)

    source_model_files = [
        path
        for root in (server, client)
        for path in root.rglob("*")
        if path.is_file() and path.suffix.lower() in {".gguf", ".safetensors"}
    ]
    expect("model weights excluded from source packages", not source_model_files)

    if args.model is not None:
        model = args.model.resolve()
        expect("supplied optimized model exists", model.is_file())
        if model.is_file():
            expect("supplied optimized model byte size", model.stat().st_size == OPTIMIZED_SIZE)
            with model.open("rb") as stream:
                metadata_window = stream.read(4 * 1024 * 1024)
            expect("supplied optimized model SHA-256 and module metadata", sha256(model) == OPTIMIZED_SHA256 and all(
                marker in metadata_window
                for marker in (
                    b"swrlz.prompt.default_system",
                    b"swrlz.module.interface",
                    b"prompt_capsule_v1+verified_state_v1+lora_adapter_v1",
                    b"swrlz.context.documented_limit_tokens",
                    b"swrlz.truth_firewall.external_gate_required",
                )
            ))

    failed = [name for name, ok in checks if not ok]
    for name, ok in checks:
        print(f"{'PASS' if ok else 'FAIL'}  {name}")
    print(f"\nINT-AI-041F-A source/static gates: {len(checks) - len(failed)}/{len(checks)} PASS")
    print("Evidence class: source/static + supplied-model identity only.")
    print("No Android compile, APK, device, installation, publication, or deployment claim.")
    if failed:
        raise SystemExit("Failed gates: " + ", ".join(failed))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
