#!/usr/bin/env python3
"""
Validate a SWRLZ build request file or supplied request fields.

This is intentionally source-level and command-testable. It validates the request
shape, short naming conventions, source/SHA path relationship, and optional file existence.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import re
import sys

REQUIRED_KEYS = {"source_zip", "sha_file", "release_name", "commit_release_artifacts"}


def parse_request(path: Path) -> dict:
    data = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise ValueError(f"invalid line without '=': {raw}")
        k, v = line.split("=", 1)
        data[k.strip()] = v.strip()
    return data


def validate(data: dict, root: Path, allow_missing: bool) -> list[str]:
    messages = []
    missing = sorted(REQUIRED_KEYS - set(data))
    if missing:
        messages.append(f"FAIL missing required keys: {missing}")

    source = data.get("source_zip", "")
    sha = data.get("sha_file", "")
    release = data.get("release_name", "")

    if not re.search(r"/SRC_|^SRC_", source):
        messages.append(f"FAIL source_zip should use SRC_ short naming: {source}")
    if not re.search(r"/SHA_|^SHA_", sha):
        messages.append(f"FAIL sha_file should use SHA_ short naming: {sha}")
    if not re.match(r"^(APK_|[0-9A-Za-z_.-]+)", release):
        messages.append(f"FAIL release_name has invalid characters: {release}")
    if data.get("commit_release_artifacts") not in {"true", "false"}:
        messages.append("FAIL commit_release_artifacts must be true or false")

    if source and sha:
        src_stem = Path(source).name.removeprefix("SRC_").removesuffix(".zip")
        sha_stem = Path(sha).name.removeprefix("SHA_").removesuffix(".txt")
        if src_stem != sha_stem:
            messages.append(f"FAIL source/SHA stem mismatch: {src_stem} != {sha_stem}")

    if not allow_missing:
        for key in ("source_zip", "sha_file"):
            p = root / data.get(key, "")
            if not p.exists():
                messages.append(f"FAIL {key} does not exist: {p}")

    if not messages:
        messages.append("PASS build request validation")
    return messages


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--file", help="Build request file to validate")
    parser.add_argument("--root", default=".", help="Repository root for existence checks")
    parser.add_argument("--allow-missing", action="store_true", help="Validate shape/naming without requiring files to exist")
    args = parser.parse_args()

    if not args.file:
        print("FAIL --file is required", file=sys.stderr)
        return 2

    root = Path(args.root).resolve()
    data = parse_request(root / args.file)
    messages = validate(data, root, args.allow_missing)
    for msg in messages:
        print(msg)
    return 0 if not any(m.startswith("FAIL") for m in messages) else 1


if __name__ == "__main__":
    raise SystemExit(main())
