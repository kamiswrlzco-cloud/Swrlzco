#!/usr/bin/env python3
"""SWRLZ compile-sensitive Compose opt-in precheck.

This is a narrow regression gate, not a Kotlin compiler replacement. It catches
known experimental Compose API calls in top-level functions when the required
OptIn annotation is missing from that function or the file.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

KNOWN_CALLS = {
    "ModalBottomSheet": "ExperimentalMaterial3Api",
}

FUN_RE = re.compile(r"\bfun\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(")


def has_file_optin(lines: list[str], annotation: str) -> bool:
    needle = f"@file:OptIn({annotation}::class)"
    return any(needle in line.replace(" ", "") for line in lines[:80])


def enclosing_function(lines: list[str], call_index: int) -> tuple[int, str] | None:
    for idx in range(call_index, -1, -1):
        m = FUN_RE.search(lines[idx])
        if m:
            return idx, m.group(1)
    return None


def function_has_optin(lines: list[str], fun_index: int, annotation: str) -> bool:
    # Walk upward through the annotation/comment/blank prelude attached to this function.
    start = max(0, fun_index - 12)
    prelude = "\n".join(lines[start:fun_index]).replace(" ", "")
    return f"@OptIn({annotation}::class)" in prelude


def scan_text(text: str, label: str = "<memory>") -> list[str]:
    lines = text.splitlines()
    failures: list[str] = []
    for call, annotation in KNOWN_CALLS.items():
        if has_file_optin(lines, annotation):
            continue
        call_re = re.compile(rf"\b{re.escape(call)}\s*\(")
        for idx, line in enumerate(lines):
            if not call_re.search(line):
                continue
            owner = enclosing_function(lines, idx)
            if owner is None:
                failures.append(f"{label}:{idx+1}: {call} has no enclosing function and no file-level {annotation} opt-in")
                continue
            fun_idx, fun_name = owner
            if not function_has_optin(lines, fun_idx, annotation):
                failures.append(
                    f"{label}:{idx+1}: {call} in {fun_name}() requires @OptIn({annotation}::class)"
                )
    return failures


def self_test() -> None:
    bad = """
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
@Composable
fun Bad() {
    ModalBottomSheet(onDismissRequest = {}) { }
}
"""
    good = """
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Good() {
    ModalBottomSheet(onDismissRequest = {}) { }
}
"""
    bad_failures = scan_text(bad, "bad.kt")
    good_failures = scan_text(good, "good.kt")
    if len(bad_failures) != 1 or good_failures:
        raise SystemExit(f"self-test failed: bad={bad_failures!r} good={good_failures!r}")
    print("compose opt-in gate self-test: PASS")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", help="Kotlin source root to scan")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        if not args.root:
            return 0
    if not args.root:
        parser.error("root is required unless --self-test is used")
    root = Path(args.root)
    failures: list[str] = []
    for path in sorted(root.rglob("*.kt")):
        failures.extend(scan_text(path.read_text(errors="replace"), str(path)))
    if failures:
        print("compose experimental opt-in gate: FAIL", file=sys.stderr)
        for failure in failures:
            print(f"- {failure}", file=sys.stderr)
        return 1
    print(f"compose experimental opt-in gate: PASS ({root})")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
