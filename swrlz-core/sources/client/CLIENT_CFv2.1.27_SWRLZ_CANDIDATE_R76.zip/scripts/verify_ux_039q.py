#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
shell = (root / 'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt').read_text()
ledger_ui = (root / 'android/app/src/main/java/sh/swurlz/core/ui/client/UpdateLedgerDialog.kt').read_text()
ledger = (root / 'android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt').read_text()
identity = (root / 'android/app/src/main/java/sh/swurlz/core/identity/ThemeIdentityManager.kt').read_text()
bubble = (root / 'android/app/src/main/java/sh/swurlz/core/bubble/ClientBubbleController.kt').read_text()
commands = (root / 'android/command-contract/src/main/kotlin/sh/swrlz/command/CommandCatalog.kt').read_text()
build = (root / 'android/app/build.gradle.kts').read_text()
packs = (root / 'android/theme-contract/src/main/kotlin/sh/swrlz/theme/BuiltInThemePacks.kt').read_text()

checks = {
    'topbar opens update ledger': 'onOpenUpdates = { showUpdateLedger = true }' in shell,
    'kapanion is ledger control': '.clickable(onClick = onOpenUpdates)' in shell,
    'ledger left rail exists': '.width(118.dp)' in ledger_ui and 'UpdateRailItem' in ledger_ui,
    'ledger asks swrlz': 'ASK SWRLZ ABOUT THIS UPDATE' in ledger_ui,
    'ledger latest summary action': 'LATEST UPDATE SUMMARY' in ledger_ui,
    'local patch query intercept': 'UpdateLedgerCatalog.answer(goal)' in shell,
    'latest catalog entry 039Q': 'checkpoint = "INT-UX-039Q"' in ledger,
    'update command latest': 'id = "updates.latest"' in commands,
    'update command ask': 'id = "updates.ask"' in commands,
    'update command compare': 'id = "updates.compare"' in commands,
    'settings root activity submenu': 'ClientActivityNotificationSettingsScreen(' in shell,
    'activity messages bubble': 'MESSAGES_BUBBLE("Messages & Bubble"' in shell,
    'theme category renamed': 'THEME("Theme & Interface"' in shell,
    'legacy root brain category removed': 'BRAIN("Brain & AI", "SERVER provider mesh' not in shell,
    'chat brain page exists': 'BRAIN("Brain & AI", "Local SWRLZ reasoning' in shell,
    'providers parent is brain': 'ClientChatSettingsPage.PROVIDERS, ClientChatSettingsPage.PROFILES -> ClientChatSettingsPage.BRAIN' in shell,
    'settings hardware back': 'BackHandler(enabled = active != ClientSettingsSection.ROOT)' in shell,
    'chat nested hardware back': 'if (page == ClientChatSettingsPage.ROOT) onBack() else pageName = parentPage(page).name' in shell,
    'activity nested hardware back': 'if (page == ClientActivitySettingsPage.ROOT) onBack() else pageName = ClientActivitySettingsPage.ROOT.name' in shell,
    'top tab back to core': 'BackHandler(enabled = selectedTab != ClientTab.Core)' in shell,
    'complementary client color': 'else -> palette.secondary' in identity,
    'server role color': '"server" -> palette.tertiary' in identity,
    'bubble bitmap role tint': 'fun roleBubbleBitmap' in identity and 'PorterDuff.Mode.SRC_ATOP' in identity,
    'system bubble consumes themed bitmap': 'ThemeIdentityManager.clientBubbleBitmap(context)' in bubble,
    'system badge truth boundary': 'Android/SystemUI may still add its own launcher/app badge' in identity,
    'candidate version code 120': 'versionCode = 120' in build,
    'candidate version name 2.1.22 r1': '2.1.22-update-ledger-settings-theme-identity-candidate-r1' in build,
    'candidate source zip 2.1.22 r1': 'CLIENT_CFv2.1.22_SWRLZ_CANDIDATE_R1.zip' in build,
    'rescue selectable theme boundary preserved': 'val all: List<ThemePack> = listOf(\n        glitchDragonGlass,\n    )' in packs,
}
failed = [name for name, ok in checks.items() if not ok]
if failed:
    print('INT-UX-039Q static checks: FAIL')
    for name in failed:
        print(' -', name)
    raise SystemExit(1)
print(f'INT-UX-039Q static checks: PASS ({len(checks)}/{len(checks)})')
