#!/usr/bin/env python3
from pathlib import Path
import hashlib
import sys

ROOT = Path(__file__).resolve().parents[1]

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

checks=[]
def check(name, cond): checks.append((name, bool(cond)))
contract = (ROOT / 'android/model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt').read_text()
api = (ROOT / 'android/app/src/main/java/sh/swurlz/core/net/Api.kt').read_text()
ui = (ROOT / 'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt').read_text()
ledger = (ROOT / 'android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt').read_text()
build = (ROOT / 'android/app/build.gradle.kts').read_text()

secret = (ROOT / 'android/app/src/main/java/sh/swurlz/core/data/SecretStore.kt').read_text()
commands = (ROOT / 'android/command-contract/src/main/kotlin/sh/swrlz/command/CommandCatalog.kt').read_text()
provider_runtime = (ROOT / 'android/app/src/main/java/sh/swurlz/core/ai/ProviderClientRuntime.kt').read_text()
intent_router = (ROOT / 'android/app/src/main/java/sh/swurlz/core/ai/SwrlzIntentRouter.kt').read_text()
profile_store = (ROOT / 'android/app/src/main/java/sh/swurlz/core/profile/ClientProfileStore.kt').read_text()
contract_doc = ROOT / 'docs/contracts/SWRLZ_BEHAVIOR_SHARD_CONTRACT_V1.md'
schema_doc = ROOT / 'docs/contracts/SWRLZ_BEHAVIOR_SHARD_V1.schema.json'
check('version', 'versionCode = 123' in build and '2.1.25-behavior-shard-v1-candidate-r1' in build)
check('protocol-v2', 'object ModelRackProtocolV2' in contract and 'PROTOCOL_VERSION = 2' in contract)
check('behavior-enum', 'BEHAVIOR_SHARD' in contract)
check('behavior-contract', 'BEHAVIOR_RUNTIME_CONTRACT = "behavior_shard_v1"' in contract)
check('api-v2', 'ModelRackProtocolV2.STATUS' in api and 'ModelRackProtocolV1.STATUS' not in api)
check('ui-awareness', 'Behavior Shard V1 packs are supported' in ui and '0–2 per turn' in ui)
check('ledger', 'checkpoint = "INT-AI-041F-C2"' in ledger and 'version = "2.1.25"' in ledger)
check('frozen-contract-copy', contract_doc.is_file() and sha(contract_doc) == '534b94e2cd6a7c0ea444bb134b65438a07dbfa386022d861d31fc4fa5c57eef8')
check('frozen-schema-copy', schema_doc.is_file() and sha(schema_doc) == 'dcf64406b347f6e3c0eda8ea3b8722b412962465e4856fef80613ef7da3fe5f9')
check('gemini-direct-runtime-removed', not (ROOT / 'android/app/src/main/java/sh/swurlz/core/ai/GeminiClient.kt').exists() and not (ROOT / 'android/app/src/main/java/sh/swurlz/core/ai/GeminiMissionPlanner.kt').exists())
check('gemini-secret-removed', 'KEY_GEMINI' not in secret and 'geminiApiKey' not in secret and 'Gemini' not in secret)
check('remote-brand-commands-hidden', all(token not in commands for token in ['ai.gpt', 'ai.gemini', 'ai.council', 'ai.compare', 'ai.probe', 'files.client.gpt', 'files.combo.council']))
check('remote-brand-ui-hidden', all(token not in ui for token in ['GPT provider profile', 'Gemini provider profile', 'COUNCIL CHAT', 'PROBE ALL', 'Optional GPT, Gemini']))
check('source-analysis-does-not-auto-pick-gpt', all(token not in provider_runtime for token in ['"gpt" in lower', '"openai" in lower', '"chatgpt" in lower']))
check('system-state-brand-keywords-removed', all(token not in intent_router for token in ['"gemini" in t', '"gpt" in t', '"openai" in t']))
check('gemini-profile-routing-disabled', '"gemini" -> document.assignments.geminiProviderProfileId' not in profile_store)
check('legacy-provider-wire-tombstone-preserved', 'GEMINI' in (ROOT / 'android/provider-contract/src/main/kotlin/sh/swrlz/provider/ProviderContract.kt').read_text())
failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL')+' '+n)
print(f'RESULT {len(checks)-len(failed)}/{len(checks)}')
sys.exit(1 if failed else 0)
