#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
files = {
    "network": root / "android/app/src/main/java/sh/swurlz/core/ui/screens/NetworkDiscoveryScreen.kt",
    "manifest": root / "android/app/src/main/AndroidManifest.xml",
    "gradle": root / "android/app/build.gradle.kts",
    "backup": root / "android/app/src/main/res/xml/backup_rules.xml",
    "extract": root / "android/app/src/main/res/xml/data_extraction_rules.xml",
}
missing = [name for name, path in files.items() if not path.exists()]
if missing:
    raise SystemExit(f"Missing files: {missing}")
network = files["network"].read_text(encoding="utf-8")
manifest = files["manifest"].read_text(encoding="utf-8")
gradle = files["gradle"].read_text(encoding="utf-8")
backup = files["backup"].read_text(encoding="utf-8")
extract = files["extract"].read_text(encoding="utf-8")
checks = {
    "cf7 identity": "2.7.6-CF7-NETPULSE-LIVE-ADMIN" in gradle,
    "source identity": "SRC_CF7_276_NETPULSE.zip" in gradle,
    "auto refresh persisted": "KEY_AUTO_REFRESH" in network and "saveAutoRefreshEnabled" in network,
    "refresh interval persisted": "KEY_REFRESH_INTERVAL_MS" in network and "nextRefreshInterval" in network,
    "active-tab-only loop": "Switching tabs disposes this screen" in network and "while (isActive)" in network,
    "live dashboard": "LIVE SERVER DASHBOARD" in network,
    "admin hidden notice": "Admin controls hidden" in network,
    "admin devices endpoint": "/admin/devices" in network,
    "admin queues endpoint": "/admin/queues" in network,
    "admin ledger endpoint": "/admin/ledger" in network,
    "group create endpoint": "/groups/create" in network,
    "device force offline": "force-offline" in network,
    "settings backup enabled": 'android:allowBackup="true"' in manifest,
    "full backup rules": 'android:fullBackupContent="@xml/backup_rules"' in manifest,
    "backup excludes secrets": "swurlz_secrets.xml" in backup and "swurlz_secrets.xml" in extract,
}
failed = [name for name, ok in checks.items() if not ok]
print("CF7_NETPULSE_CHECKS")
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'} {name}")
if failed:
    raise SystemExit("Failed: " + ", ".join(failed))
print("RESULT PASS")
