#!/usr/bin/env python3
"""
SWRLZ-Core Engine Test Helpers.

Pure Python, stdlib-only command-testable logic for SWRLZ source handoffs.
These helpers are intentionally Android-free so registry, queue, approval,
workaround, packet, and lineage rules can be simulated before APK build/install.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Tuple

ALLOWED_STATES = {
    "queued",
    "running",
    "paused",
    "waiting",
    "rerouted",
    "completed",
    "failed",
    "archived",
    "ghosted",
    "blocked",
}

ALLOWED_TRANSITIONS = {
    "queued": {"running", "paused", "blocked", "waiting", "archived"},
    "running": {"paused", "waiting", "completed", "failed", "rerouted"},
    "paused": {"running", "waiting", "archived", "failed"},
    "waiting": {"running", "rerouted", "failed", "archived"},
    "blocked": {"rerouted", "failed", "waiting", "archived"},
    "rerouted": {"running", "completed", "failed", "archived"},
    "completed": {"archived"},
    "failed": {"archived"},
    "archived": set(),
    "ghosted": {"archived"},
}

REQUIRED_PACKET_FIELDS = {
    "packet_id",
    "packet_type",
    "mission_id",
    "source_device_id",
    "target_device_id",
    "state",
    "created_at",
}


def stable_device_key(device: Dict[str, Any]) -> str:
    """Return a deterministic registry key from non-volatile device identity fields."""
    anchor = device.get("stable_anchor") or device.get("hardware_fingerprint") or device.get("device_id")
    model = device.get("model", "unknown")
    owner = device.get("owner", "unknown")
    return f"{owner}:{model}:{anchor}".lower().replace(" ", "-")


def validate_device_registry(devices: List[Dict[str, Any]]) -> Tuple[bool, List[str]]:
    messages: List[str] = []
    ids = [d.get("device_id") for d in devices]
    missing = [i for i, x in enumerate(ids) if not x]
    if missing:
        messages.append(f"FAIL device registry: missing device_id indexes={missing}")

    duplicates = sorted({x for x in ids if x and ids.count(x) > 1})
    if duplicates:
        messages.append(f"FAIL device registry: duplicate device_id values={duplicates}")

    active = {d.get("device_id") for d in devices if d.get("status") == "active"}
    for d in devices:
        status = d.get("status")
        if status in {"ghost", "retired", "legacy"}:
            if d.get("active") is not False:
                messages.append(f"FAIL lineage: {d.get('device_id')} status={status} must have active=false")
            link = d.get("linkedActiveDeviceId")
            if not link or link not in active:
                messages.append(f"FAIL lineage: {d.get('device_id')} must link to active device, got={link}")

    keys = {}
    for d in devices:
        k = stable_device_key(d)
        keys.setdefault(k, []).append(d.get("device_id"))
    potential_dupes = {k: v for k, v in keys.items() if len(v) > 1}
    if potential_dupes:
        messages.append(f"PASS duplicate detection candidate keys={potential_dupes}")
    else:
        messages.append("PASS duplicate detection: no duplicate stable keys in fixture")

    if not any(d.get("status") in {"ghost", "retired", "legacy"} for d in devices):
        messages.append("FAIL lineage: fixture does not include ghost/retired/legacy case")

    ok = not any(m.startswith("FAIL") for m in messages)
    if ok:
        messages.insert(0, "PASS device registry and ghost lineage validation")
    return ok, messages


def validate_state_transitions(missions: List[Dict[str, Any]]) -> Tuple[bool, List[str]]:
    messages: List[str] = []
    for mission in missions:
        mid = mission.get("mission_id", "<missing>")
        states = mission.get("state_history", [])
        if not states:
            messages.append(f"FAIL mission {mid}: missing state_history")
            continue
        for s in states:
            if s not in ALLOWED_STATES:
                messages.append(f"FAIL mission {mid}: unknown state={s}")
        for prev, nxt in zip(states, states[1:]):
            if nxt not in ALLOWED_TRANSITIONS.get(prev, set()):
                messages.append(f"FAIL mission {mid}: invalid transition {prev}->{nxt}")
        final = mission.get("state")
        if final and final != states[-1]:
            messages.append(f"FAIL mission {mid}: final state={final} does not match last history={states[-1]}")
    ok = not any(m.startswith("FAIL") for m in messages)
    if ok:
        messages.insert(0, "PASS mission queue state transition validation")
    return ok, messages


def route_approval(packet: Dict[str, Any], approval: Dict[str, Any]) -> Dict[str, Any]:
    """Simulate an approval router decision for one packet."""
    risk = packet.get("risk", "unknown")
    policy = approval.get("policy", "manual")
    outcome = approval.get("outcome", "requires-user-input")

    if outcome == "deny":
        return {"decision": "denied", "next_state": "blocked"}
    if outcome == "approve":
        return {"decision": "approved", "next_state": "running"}
    if outcome == "timeout":
        return {"decision": "timeout", "next_state": "waiting"}
    if policy == "auto_approve_safe" and risk == "safe":
        return {"decision": "auto-approved-safe", "next_state": "running"}
    return {"decision": "requires-user-input", "next_state": "waiting"}


def validate_approval_router(packets: List[Dict[str, Any]], approvals: List[Dict[str, Any]]) -> Tuple[bool, List[str]]:
    messages: List[str] = []
    by_packet = {a.get("packet_id"): a for a in approvals}
    expected = {
        "pkt-safe-auto": "auto-approved-safe",
        "pkt-denied": "denied",
        "pkt-timeout": "timeout",
        "pkt-manual": "requires-user-input",
    }
    for pkt in packets:
        pid = pkt.get("packet_id")
        if pid not in by_packet:
            continue
        decision = route_approval(pkt, by_packet[pid])
        if pid in expected and decision["decision"] != expected[pid]:
            messages.append(f"FAIL approval {pid}: expected {expected[pid]}, got {decision['decision']}")
        else:
            messages.append(f"PASS approval {pid}: {decision['decision']} -> {decision['next_state']}")
    ok = not any(m.startswith("FAIL") for m in messages)
    if ok:
        messages.insert(0, "PASS approval router simulation")
    return ok, messages


def choose_workaround(routes: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Return the first safe/approved fallback after a blocked or warning primary route."""
    for route in routes:
        if route.get("role") == "primary" and route.get("status") == "available":
            return route
    for route in routes:
        if route.get("role") == "fallback" and route.get("status") == "available" and route.get("risk") in {"safe", "warning"}:
            if route.get("approval") in {"preapproved", "auto_approve_safe", "approved"}:
                return route
    return {"route_id": None, "status": "no-safe-route-found"}


def validate_workaround_cycling(scenarios: List[Dict[str, Any]]) -> Tuple[bool, List[str]]:
    messages: List[str] = []
    for scenario in scenarios:
        sid = scenario.get("scenario_id", "<missing>")
        chosen = choose_workaround(scenario.get("routes", []))
        expected = scenario.get("expected_route_id")
        if chosen.get("route_id") != expected:
            messages.append(f"FAIL workaround {sid}: expected {expected}, got {chosen.get('route_id')}")
        else:
            messages.append(f"PASS workaround {sid}: chose {expected}")
    ok = not any(m.startswith("FAIL") for m in messages)
    if ok:
        messages.insert(0, "PASS workaround cycling simulation")
    return ok, messages


def validate_packets(packets: List[Dict[str, Any]]) -> Tuple[bool, List[str]]:
    messages: List[str] = []
    seen = set()
    for pkt in packets:
        pid = pkt.get("packet_id", "<missing>")
        missing = sorted(REQUIRED_PACKET_FIELDS - set(pkt.keys()))
        if missing:
            messages.append(f"FAIL packet {pid}: missing fields={missing}")
        if pid in seen:
            messages.append(f"FAIL packet {pid}: duplicate packet_id")
        seen.add(pid)
        if pkt.get("state") not in ALLOWED_STATES:
            messages.append(f"FAIL packet {pid}: invalid state={pkt.get('state')}")
    ok = not any(m.startswith("FAIL") for m in messages)
    if ok:
        messages.insert(0, "PASS packet format validation")
    return ok, messages
