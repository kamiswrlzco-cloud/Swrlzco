#!/usr/bin/env python3
"""CF6 source-level simulation for boot auto-connect and permission refresh decisions."""
from __future__ import annotations

from dataclasses import dataclass


def normalize_base_url(value: str) -> str:
    value = value.strip().rstrip("/")
    if not value:
        return ""
    if value.startswith(("http://", "https://")):
        return value
    return "http://" + value


def subnet_candidates(ipv4: str, port: int = 8787, include_loopback: bool = False) -> list[str]:
    parts = ipv4.split(".")
    if len(parts) != 4:
        return []
    try:
        nums = [int(p) for p in parts]
    except ValueError:
        return []
    if any(n < 0 or n > 255 for n in nums):
        return []
    prefix = ".".join(parts[:3])
    if prefix == "127.0.0" and not include_loopback:
        return []
    return [f"http://{prefix}.{i}:{port}" for i in range(1, 255)]


def candidate_urls(saved: str, last_good: str, device_ips: list[str]) -> list[str]:
    raw = [normalize_base_url(saved), normalize_base_url(last_good)]
    out: list[str] = []
    for item in raw:
        if item and item not in out:
            out.append(item)
    for ip in device_ips:
        for item in subnet_candidates(ip):
            if item not in out:
                out.append(item)
    for item in ["http://127.0.0.1:8787", "http://localhost:8787", "http://10.0.2.2:8787"]:
        if item not in out:
            out.append(item)
    return out


@dataclass
class PermissionSnapshot:
    accessibility: bool
    overlay: bool


def recompute_permission_board(before: PermissionSnapshot, after: PermissionSnapshot) -> PermissionSnapshot:
    # CF6 rule: never trust only the permission just opened; recompute the full board.
    return PermissionSnapshot(accessibility=after.accessibility, overlay=after.overlay)


def test_loopback_not_swept_by_default() -> None:
    assert subnet_candidates("127.0.0.1") == []
    assert len(subnet_candidates("127.0.0.1", include_loopback=True)) == 254


def test_device_subnet_sweep() -> None:
    candidates = candidate_urls("", "", ["10.24.230.55"])
    assert "http://10.24.230.1:8787" in candidates
    assert "http://10.24.230.254:8787" in candidates
    assert "http://127.0.0.2:8787" not in candidates


def test_saved_and_last_good_first() -> None:
    candidates = candidate_urls("http://10.24.230.21:8787", "http://192.168.1.77:8787", ["10.24.230.55"])
    assert candidates[0] == "http://10.24.230.21:8787"
    assert candidates[1] == "http://192.168.1.77:8787"


def test_permission_board_recomputed_after_second_return() -> None:
    before = PermissionSnapshot(accessibility=True, overlay=False)
    after = PermissionSnapshot(accessibility=True, overlay=True)
    board = recompute_permission_board(before, after)
    assert board.accessibility is True
    assert board.overlay is True


def main() -> int:
    tests = [
        test_loopback_not_swept_by_default,
        test_device_subnet_sweep,
        test_saved_and_last_good_first,
        test_permission_board_recomputed_after_second_return,
    ]
    for test in tests:
        test()
        print(f"PASS {test.__name__}")
    print("CF6 boot-sync simulation: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
