#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "android/command-contract/src/main/kotlin/sh/swrlz/command/CommandCatalog.kt"
UI = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/client/ChatCommandCenter.kt"
CHAT = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt"
GRADLE = ROOT / "android/app/build.gradle.kts"

checks = []

def require(path: Path, needle: str, label: str) -> None:
    text = path.read_text(encoding="utf-8")
    ok = needle in text
    checks.append((label, ok))
    if not ok:
        raise SystemExit(f"FAIL: {label}: missing {needle!r} in {path}")

require(GRADLE, "versionCode = 119", "CLIENT versionCode 119")
require(GRADLE, 'versionName = "2.1.21-command-palette-parent-child-cursor-follow-candidate-r2"', "R2 versionName")
require(GRADLE, 'SOURCE_ZIP", "\\\"CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R2.zip\\\"', "R2 SOURCE_ZIP identity")

for needle, label in [
    ("fun canonicalPrefix", "structured prefix helper"),
    ("fun syntaxDisplay", "instruction grammar display"),
    ("fun insertionPrompt", "structured insertion helper"),
    ("parseStructuredPrompt", "parenthesized command parser"),
    ('id = "files.scan"', "generic file scan action"),
    ('id = "files.organize"', "generic file organize action"),
    ('id = "files.duplicates"', "generic duplicate action"),
    ('id = "files.undo"', "generic undo action"),
    ('id = "files.keep-organized"', "generic Keep Organized action"),
    ("availability = CommandAvailability.PLANNED", "039M planned truth state"),
    ('add("/" + pathSegments(command).joinToString(" "))', "legacy slash compatibility"),
]:
    require(CATALOG, needle, label)

for needle, label in [
    ('Text("/parent → (child) → instructions"', "clear grammar heading"),
    ("SwrlzCommandCatalog.syntaxDisplay(leaf)", "leaf syntax in command list"),
    ("SwrlzCommandCatalog.insertionPrompt(leaf)", "quick-menu structured insertion"),
    ("SwrlzCommandCatalog.insertionPrompt(command)", "full-palette structured insertion"),
    ("Selecting a command inserts /parent (child)", "authority/caret explanation"),
]:
    require(UI, needle, label)

for needle, label in [
    ("TextFieldValue(draft, selection = TextRange(draft.length))", "composer initializes caret at end"),
    ("composerValue = TextFieldValue(draft, selection = TextRange(draft.length))", "external insertion caret at end"),
    ("val responseTopReserve = if (followTarget == ChatSettings.FOLLOW_RESPONSE_TOP) maxHeight else 10.dp", "full response-top trailing extent"),
    ("listState.firstVisibleItemIndex != target || listState.firstVisibleItemScrollOffset != 0", "response-top exact-anchor verification"),
    ("listState.scrollToItem(target, 0)", "response-top zero-offset correction"),
]:
    require(CHAT, needle, label)

ui_text = UI.read_text(encoding="utf-8")
for forbidden in ["dispatchGesture(", "commitRepository", "deleteDocument(", "providerClient.execute("]:
    if forbidden in ui_text:
        raise SystemExit(f"FAIL: command palette unexpectedly contains direct side effect marker {forbidden}")
    checks.append((f"no direct side effect marker {forbidden}", True))

print(f"INT-CMD-039P-R2 static checks: PASS ({len(checks)}/{len(checks)})")
