# INT-AI-SWRLZX-002A — Validation Boundary

## Proven locally

- Focused source/checkpoint verifier: **22/22 PASS** on SERVER R49 and CLIENT R24 source trees.
- Shared Kotlin conversion/provenance contract compiles in a bounded pure-Kotlin harness and its contract runner reports **PASS**.
- Python 002A converter output is accepted by the production Kotlin `SwrlzxBinaryCodecV1.inspectFile` implementation: **cross-language interop PASS**.
- Negative coverage rejects a truncated GGUF, bad GGUF magic and corrupted SWRLZX output: **3/3 PASS**.
- Deterministic synthetic conversion was repeated at 4 MiB, 64 MiB and 128 MiB tensor payload sizes; every repeated pair produced the same SWRLZX SHA-256.
- The synthetic converter runs used a fixed 1 MiB copy/hash buffer and process max-RSS stayed essentially flat across 4–128 MiB payloads (~115.8 MiB process RSS in this environment); this is evidence that tensor payload size is not being mirrored as a whole-model RAM buffer, not a claim that total converter memory is 1 MiB.
- An 8 MiB reconciliation fixture converted 3/3 tensor descriptors, verified every source/output tensor span hash, preserved the source SHA-256 and copied the full tensor-data region byte-for-byte.
- SWRLZX section digests, content-root digest and SXI1 integrity table verify after conversion.
- The conversion report explicitly records `runtimeSwitchPerformed=false`; active GGUF runtime source remains unchanged by this checkpoint.

## Build attempt

A bounded Gradle test invocation was attempted on both source candidates. SERVER Gradle 8.9 and CLIENT Gradle 8.7 wrapper bootstrap both stopped at `services.gradle.org` with `UnknownHostException` before project compilation. Android/Gradle compile success is therefore **not claimed** by this local evidence set.

## Not yet proven / checkpoint exit evidence still pending

- Direct conversion of the exact live `SWRLZ-LFM-OPT-001A.gguf` (229,315,680 bytes / expected SHA-256 `651cd5c40e4ef24de2ff12c2b53b257d15816ddd4346e2575e6768a6ec1d8590`). The node advertises that model, but the Archive VFS route intentionally does not transfer arbitrary binary model bytes into this analysis environment.
- Therefore the exact optimized-model tensor count/shape/type reconciliation and repeat output hash remain pending direct-byte/device execution.
- Device throughput, thermal behavior and peak memory under the real 229 MB source model remain pending.
- Native SWRLZX tensor execution/generation parity belongs to 003A and later; native response streaming is not claimed by 002A.
