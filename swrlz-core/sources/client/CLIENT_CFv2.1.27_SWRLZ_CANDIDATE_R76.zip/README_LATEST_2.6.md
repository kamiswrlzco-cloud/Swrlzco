# SWRLZ-Core 2.6 — Bridge Truth + Command Hardening

## Identity

- Version name: `0.2.6-bridge-truth`
- Version code: `12`
- Patch label: `2.6-BRIDGE-TRUTH`
- Roadmap revision: `2.6`
- Source ZIP: `SWRLZ_CORE_2.6_BRIDGE_TRUTH_SOURCE.zip`

## What changed

- Home status layout changed to stacked cards so long Core Node values cannot crush labels vertically.
- Core Node status now separates:
  - configured URL
  - last manual test
  - last auto-check
  - reachable proof
- Green Core Node status only appears after `/status` returns `ok=true`, node identity, and server version.
- Setup screen explains bridge truth directly.
- Server identity details display after successful status: server, version, patch, roadmap, local URL, LAN URLs.
- Command cards now show lifecycle details and timestamps.
- Command card buttons are lifecycle-gated:
  - pending: ACK / REJECT
  - accepted: COMPLETE / REJECT
  - completed/rejected/failed: read-only
- How To and Info screens updated for Local Node Server 0.6 process controls.

## Safety laws preserved

- No invisible patches.
- No mystery APKs.
- No paid runtime dependency required for local bridge testing.
- Admin password field stays masked.
- Core Node and Mentor backend remain separate.
