# SWRLZ-Core 2.7.2 — Signal Polish

Signal Polish is a UI/relay refinement patch on top of 2.7.1 Relay Radar.

## Identity

- Version: `0.2.7.2-signal-polish`
- Code: `15`
- Patch: `2.7.2-SIGNAL-POLISH`
- Roadmap: `2.7.2`
- Source ZIP: `SWRLZ_CORE_2.7.2_SIGNAL_POLISH_SOURCE.zip`

## Main changes

- Added **Style / Options** screen.
- Added saved UI settings: theme pack, display mode, animation level, text size, card density.
- Preserved **Original Core** as the default night-style theme.
- Added starter presets: **Original Core**, **Pharaoh Gold**, and **Glitch Teal**.
- Added **Dark / Sunlight** display-mode preference.
- Added animated selected-tab state with stronger glow/underline.
- Increased global contrast for text and borders.
- Added **Node Heartbeat / Auto Presence** setting.
- App now ensures a stable local device identity exists instead of forcing manual Device ID entry first.
- Radar can run **AUTO REGISTER / HEARTBEAT**, which attempts group join/register plus check-in.
- Radar now exposes Node Heartbeat toggle beside auto-refresh.
- Manual setup remains available as advanced fallback for recovery/custom IDs.

## What still requires setup

Auto Presence only checks in automatically after these are present:

1. Core Node URL saved.
2. Group ID saved.
3. Group key saved.
4. Device identity/key available.

If group info is missing, SWRLZ creates the local device identity but skips network check-in until group settings are provided.

## Test targets

- Confirm Home/Core identity shows `0.2.7.2-signal-polish · code 15`.
- Open Style tab; switch theme/display/animation/text/card settings.
- Confirm selected tab has stronger active-state glow.
- Confirm Radar auto-generates device identity after launch.
- With Core Node URL + group saved, tap `AUTO REGISTER / HEARTBEAT`.
- Confirm `/presence/summary` shows device online.
- Confirm two phones show as two devices if they use different device IDs.
- Confirm queue lifecycle still works: queued → displayed → acknowledged → completed.

## Build note

Use Java 17 in Codespaces/GitHub builds.
