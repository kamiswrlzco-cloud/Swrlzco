# INT-FIX-078A — Forge Metadata Contract Repair

## Scope
Source-only successor of `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R3` for CLIENT package-pair compatibility.

## Defect corrected
The prior metadata manifest described the source under an `archive` object. The Forge strict metadata reader requires a canonical `sourceZip` object or legacy top-level `zip`. This caused: `Manifest is missing sourceZip.filename or zip.`

## Canonical metadata contract
The matching metadata bundle for `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R4.zip` contains exactly:

- `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R4.sha256`
- `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R4.manifest.json`

The manifest now provides:

- `component`
- `versionCode`
- `revision`
- `verified: true`
- `sourceZip.filename`
- `sourceZip.sha256`
- `sourceZip.sizeBytes`
- legacy-compatible top-level `zip`, `sha256`, and `size_bytes`

## Forge auto-selection compatibility
The source ZIP and metadata bundle share the exact canonical stem `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R4`. This allows Forge source-archive selection to automatically locate and stage `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R4_METADATA.zip` as its evidence companion.

## Preserved boundaries
No runtime feature behavior, Android application ID, protocol contract, Truth Firewall rule, offline-first rule, architecture, workflow, build, installation, promotion, release, or deployment action was changed or performed.

## Verification
The final source checksum, byte size, manifest fields, checksum target, metadata member count, canonical filenames, and Forge parser requirements were checked after packaging.
