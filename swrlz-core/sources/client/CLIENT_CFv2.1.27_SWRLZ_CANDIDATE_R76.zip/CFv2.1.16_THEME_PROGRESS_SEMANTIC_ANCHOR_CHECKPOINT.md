# INT-THEME-039C — Theme Progress Semantic Anchor Calibration

Prepared: 2026-07-27  
Target: CLIENT  
Parent: CLIENT CFv2.1.15 / versionCode 113 / `2.1.15-theme-ignition-family-completion-v1`
Successor: CLIENT CFv2.1.16 / versionCode 114 / `2.1.16-theme-progress-semantic-anchor-v1`
Evidence class: source/static

## Runtime defect evidence

An installed older CLIENT VC108 Forge screen showed a determinate 100% operation whose ornate Jester progress presentation did not terminate at the right green emerald. The installed version is older than the source parent, but the screenshot remains valid defect evidence: inspection of current CFv2.1.15 confirmed the same underlying geometry was still present and therefore was not assumed fixed by version advancement.

## Root cause

`ThemedProgressBar` contained Jester-specific fractional frame insets. The right inset was 12.5% of outer width, making the semantic track end 87.5%, short of the visible green emerald centered near 89.5%. The head formula used `(trackWidth - headWidth) * progress`, which keeps the head fully inside the track but changes the effective semantic point from the head's left edge at 0% to its right edge at 100%. Fill/mask truth and head visual truth therefore did not share one invariant anchor.

## Repair

- Replaced the inline Jester-only geometry branch with a reusable theme-aware `ThemeProgressGeometry` resolver.
- Jester geometry: start 20.5%, end 89.5%, top 30%, bottom 75% of the outer component.
- Jester 100% now terminates at the center of the right green emerald landmark.
- Progress-head center is the semantic anchor and follows `trackWidth * progress`; clipping contains overflow at track boundaries.
- Fill, active clip, highlight window, and head all derive from the same resolved track.
- Other themes retain their existing declarative dp geometry unless/until visual calibration is evidenced.

## Shared-contract discipline

ThemePack manifest v1 and `theme-contract` sources are intentionally unchanged in this CLIENT-only checkpoint. The generic runtime resolver provides the cross-theme mechanism without breaking CLIENT/SERVER byte parity. Promotion of normalized progress landmarks into the shared manifest requires a later paired CLIENT+SERVER contract checkpoint.

## Non-goals

No SERVER source change, protocol change, provider change, Forge authority change, build, APK, workflow, GitHub write, release, deployment, or installation is claimed.
