# CLIENT CFv2.0.68 — Chat Forge Orchestrator

## Implemented
- SWRLZ intent routing separates conversation, questions, quick actions, Forge work, and missions.
- Casual chat no longer automatically starts a mission.
- `open settings` is handled as a deterministic Android quick action.
- Gemini is used as a private reasoning consultant for chat/questions, not as the SWRLZ identity or direct device executor.
- Added chat-native Forge workflow backed by the existing Forge/GitHub service APIs.
- Chat can request/validate a fine-grained GitHub token using a password field; the token is stored by the existing encrypted SecretStore/GitHubConnectionStore.
- SHA pairing can be accepted/declined from chat.
- Android file picker can stage source ZIP/SHA files from chat.
- Upload confirmation, validation, upload progress, transaction status, workflow discovery/watch, artifact discovery, artifact download, and first-use artifact folder selection are surfaced in a compact chat card.
- The selected artifact folder is persisted as a SAF tree URI for later Forge chat downloads.
- Workflow cards are filtered by the commit SHA produced by the chat Forge transaction.

## Architecture
Chat calls `ChatForgeCoordinator`, which delegates to the same `GitHubForgeClient`, credential store, upload log, build watch, and runtime state used by Forge. It does not simulate taps on the Forge screen.
