# ADR-0030 — LALM Reference Runtime Before Optimization

## Status

Accepted for `INT-AI-SWRLZX-011A` source implementation.

## Decision

Implement the first complete LALM-specific execution semantics as an auditable CPU/reference path behind the existing `LocalInferenceEngine`/SWRLZX graph boundary before introducing architecture-specific SIMD, GPU, NPU, persistent-prefix-KV, or speculative acceleration.

## Rationale

The critical risk at this stage is silent semantic drift, not insufficient throughput. A small, readable reference implementation gives later optimized kernels a fixed comparison target for tensor layout, quantization, RoPE, short-convolution recurrence, grouped attention, tokenizer behavior, sampling, cancellation and streaming authority.

## Consequences

- The reference implementation may be slower than an optimized backend.
- Optional accelerators remain disabled until they can demonstrate parity against this path.
- The streaming Truth Firewall remains downstream of model decode; this ADR changes no authority boundary.
- Exact source-model and Android performance claims remain deferred to 012A/013A.
- GGUF remains the bounded emergency rollback until 014A promotion criteria are met.
