# SWRLZ-CORE 1.3 ContextCollectors Build Hotfix Report

**Patch label:** 1.3 Build Mesh — ContextCollectors Compile Hotfix  
**Scope:** Minimal Android compile fix based on known-good `0.1.4` vs known-bad `0.1.5` comparison.  
**Status:** Source patched; APK build still needs Codespaces validation.

## Reported failure

Codespaces AI compared `0.1.4` and `0.1.5` and found that `0.1.5` introduced `android/app/src/main/java/sh/swurlz/core/data/ContextCollectors.kt`.

The reported failing references were:

```text
packageInfo?.requestedPermissions.orEmpty()
packageInfo?.requestedPermissionsFlags.orEmpty()
PackageManager.REQUESTED_PERMISSION_GRANTED
```

## Root cause

The new app-permission collection code used nullable array handling and the permission-granted flag in a way that did not compile in the current Android/Kotlin build environment.

- `requestedPermissionsFlags` is an `IntArray?`; using `.orEmpty()` here can fail because primitive arrays do not have the same nullable `orEmpty()` behavior as regular collections in this environment.
- `REQUESTED_PERMISSION_GRANTED` belongs to `android.content.pm.PackageInfo`, not `PackageManager`.

## Minimal fix applied

In `ContextCollectors.kt`, the permission collection block was changed to:

```kotlin
val requested = packageInfo?.requestedPermissions?.toList().orEmpty()
val flags = packageInfo?.requestedPermissionsFlags ?: IntArray(0)
val permissions = requested.take(60).mapIndexed { index, name ->
    val granted = ((flags.getOrNull(index) ?: 0) and android.content.pm.PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
    AppPermissionState(name = name.substringAfterLast('.'), granted = granted)
}
```

## Why this is safe

- The patch only changes permission flag parsing.
- No mission execution logic, allowlist logic, token storage, or accessibility actions were changed.
- If permission flags are missing, the app now safely treats them as an empty `IntArray` instead of crashing or failing compile.

## Next validation target

Run from the extracted source folder:

```bash
bash scripts/install_android_sdk_and_build.sh
```

Expected result:

- Gradle should move past the previous `ContextCollectors.kt` unresolved-reference error.
- If another compile error appears, capture the failing task, file path, line number, and last 80 log lines.
