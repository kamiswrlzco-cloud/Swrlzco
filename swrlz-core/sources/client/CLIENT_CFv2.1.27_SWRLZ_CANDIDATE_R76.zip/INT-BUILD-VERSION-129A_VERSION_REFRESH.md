# INT-BUILD-VERSION-129A — CLIENT R37 / VC163

## Purpose
Provide a clean canonical successor to R36 for APK Router/source selection without changing runtime behavior.

## Identity
- Candidate: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R37`
- Version code: `163`
- Version name: `2.1.27-archive-index-r37`
- Parent: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R36.zip`
- Parent SHA-256: `29486724b8f55455e8829da44f5c2c7b6a808772c2dd789aa4c2a3b0f0f1b051`
- Paired SERVER: `SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R63` / VC186

## Scope
Version/package identity only. R36 runtime behavior is intentionally unchanged.
