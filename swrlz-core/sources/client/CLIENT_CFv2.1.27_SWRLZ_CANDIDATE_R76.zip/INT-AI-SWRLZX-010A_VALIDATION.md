# INT-AI-SWRLZX-010A — Validation Boundary

## Passing evidence

| Area | Result |
|---|---|
| SERVER focused source checks | 41/41 PASS |
| CLIENT focused source checks | 37/37 PASS |
| LALM identity/receipt Kotlin harness | 8/8 PASS |
| Model Rack LALM/LFM Kotlin harness | 6/6 PASS |
| LALM selection-policy Kotlin harness | 4/4 PASS |
| 002A default converter deterministic regression | PASS |
| exact-size 229,315,680-byte synthetic conversion, pass 1 vs pass 2 | identical SHA-256 `6bc00eb75b53e0ece83804f541f75a9ab78dbf50fb7aeceae4147746560766de` |
| exact-size synthetic source rejected by canonical 010A gate | PASS: `LALM_010A_SOURCE_SHA256_MISMATCH` |
| canonical target absent after failed exact-source gate | PASS |
| 009A advanced runtime regression | 65/65 PASS |
| shared LALM Kotlin contract CLIENT/SERVER | byte-identical |
| shared converter CLIENT/SERVER | byte-identical |
| shared two-pass bring-up runner CLIENT/SERVER | byte-identical |
| shared Model Rack contract CLIENT/SERVER | byte-identical |

## Shared contract hashes

- `SwrlzxLalmIdentityV1.kt`: `c6e6138d00433899a238f00cf5fbfcc4a2e4778c60a37c7b9efd5cf4d3087ee3`
- `swrlzx_gguf_to_swrlzx_v1.py`: `17a6438cb83c4b4da285e0fe4018e1313636e0024e84e352a37658c6bb9dc91a`
- `swrlzx_lalm_010a_bringup.py`: `0a72c93dfe833d89e6e91b6c88a698bafdee22a7d5a09cc93b565c2d3e8c94cf`
- `ModelRackContract.kt`: `f56266ffea1afa3de59a976c8257efac79c08fb63be5500a69fdcf2f18855de5`

## Android build attempt

Both SERVER and CLIENT Gradle wrappers attempted to fetch their pinned Gradle distributions. DNS resolution for `services.gradle.org` failed before project compilation. This checkpoint therefore makes no Android compile, APK, install, device, thermal, LAN, or deployment claim.

## Open acceptance gates

1. Directly access/recompute the exact pinned GGUF source bytes.
2. Run 010A two-pass conversion on those exact bytes and record the canonical LALM target SHA/root digest.
3. Complete the LFM2-derived native operator/tokenizer/quantizer path (011A).
4. Prove GGUF ↔ LALM numerical/token/generation parity (012A).
5. Pass real Android/LAN/thermal acceptance (013A).
6. Explicitly promote LALM and retire GGUF from normal runtime only after all prior gates pass (014A).
