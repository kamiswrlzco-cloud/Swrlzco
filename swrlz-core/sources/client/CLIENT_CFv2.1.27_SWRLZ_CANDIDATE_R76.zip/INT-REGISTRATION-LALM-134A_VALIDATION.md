# INT-REGISTRATION-LALM-134A — CLIENT R44 validation

- Candidate revision: `R44`
- versionCode: `170`
- versionName: `2.1.27-registration-lalm-r44`
- Checkpoint: `INT-REGISTRATION-LALM-134A`
- JSON corpus: `37/37 valid`
- Source-manifest target entries: `1117` (all files except `SOURCE_MANIFEST.sha256`)
- Android build/sign acceptance: **PENDING APK Router**

## Focused static gates

- PASS — R44 / VC170 BuildConfig identity and persistent revision footer.
- PASS — bounded loopback-first process reconciliation with configured-LAN fallback.
- PASS — explicit proof_rebind_begin/proof_rebind_end telemetry.
- PASS — duplicate CLIENT chat diagnostic suppression.
- PASS — no explicit androidx.compose.foundation.layout.weight imports.

## Evidence boundary

Kotlin lexical delimiter balance passed on all changed Kotlin files. A full Android compile is not claimed by source preparation; GitHub APK Router remains the authoritative Android compiler/signing gate. No install, promotion, release, deployment, or production-parity claim is made.
