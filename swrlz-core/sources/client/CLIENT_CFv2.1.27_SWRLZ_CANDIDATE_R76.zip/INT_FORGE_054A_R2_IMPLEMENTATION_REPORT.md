# INT-FORGE-054A-R2 — CLIENT Implementation Report

Component: **CLIENT**  
Candidate: `CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R1`  
Version code: `124`  
Version name: `2.1.26-forge-parity-chat-settings-candidate-r1`  
Parent source: `CLIENT_CFv2.1.25_SWRLZ_CANDIDATE_R1.zip`  
Parent SHA-256: `6ce26560dab4113d06bb1360c260dcc087fc2fa8b583f1583ada2bfe3688f5b2`

## Approved scope implemented

- shared Forge target modes: `ASK`, `CLIENT`, `SERVER`, `BOTH`, `FILES`;
- user-initiated `BUILD LATEST VERIFIED` conveyor for CLIENT/SERVER/BOTH;
- manifest/component/versionCode/SHA-based newest-source verification;
- selectable persisted SAF folder routing for root/source/artifact/log/model/mod/evidence lanes;
- success artifact auto-download default ON and failure-log auto-download default ON;
- persistent append-only Forge build ledger with distinct built/downloaded/install-pending states;
- existing manual staging, source guard, credential lifecycle, repository routing and build watching preserved;
- machine-readable patch/checkpoint lineage index added;
- CLIENT/SERVER parity contract documented.

### CLIENT catch-up

- adds app-private CLIENT chat-thread continuity and history controls;
- adds a paired-SERVER model selector directly in CLIENT Chat while keeping model authority on SERVER;
- preserves Missions and legacy Dev Mode;
- intentionally does not duplicate SERVER-owned inference evidence/model residency/runtime authority.


## Truth / authority boundary

The lineage index and release notes are navigation/self-history aids. They do not supersede canonical source ZIP bytes, SHA-256 receipts, accepted contracts, implementation files, or accepted build/device evidence.

## Not claimed

- no Android Gradle compilation;
- no APK build;
- no GitHub write, commit, push or workflow dispatch from this workspace;
- no release, deployment or installation;
- no automatic APK installation;
- no GGUF/model/SWRLZMOD content change;
- no OpenAI/Grok export processing.

## Validation boundary

Static verifier: **75/75 PASS** (`tools/verify_int_forge_054a_r2.py`).

This candidate is packaged as **source-only**. Static source gates, manifest/checksum gates and archive-integrity checks are recorded in the external checkpoint evidence package. Device acceptance remains pending an explicitly authorized/user-run build and test.
