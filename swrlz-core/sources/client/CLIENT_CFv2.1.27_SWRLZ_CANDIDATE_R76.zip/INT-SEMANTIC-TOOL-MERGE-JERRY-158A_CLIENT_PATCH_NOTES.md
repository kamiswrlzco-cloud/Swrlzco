# INT-SEMANTIC-TOOL-MERGE-JERRY-158A — CLIENT Patch Notes

## R65 / VC191

- Preserved all CLIENT R64 routed tool-executor normalization and exact-plan destructive safety.
- Added explicit awaiting-clarification state for SERVER semantic clarification phases.
- Added visible `SELF-PRESERVATION BLOCKED` and `UNDERSTOOD · NOT EXECUTABLE` status labels for the Jerry boundary.
- Clarification-completed turns now display `§WYRLZ · NEEDS DETAIL` rather than ordinary COMPLETE.
- Added UI copy clarifying that a clarification response supplies missing meaning only and is not action approval.
- No new transport event schema was introduced; existing V2 stream phase transport is reused.
- No APK/install/device/deployment/promotion claim is made by this source candidate.
