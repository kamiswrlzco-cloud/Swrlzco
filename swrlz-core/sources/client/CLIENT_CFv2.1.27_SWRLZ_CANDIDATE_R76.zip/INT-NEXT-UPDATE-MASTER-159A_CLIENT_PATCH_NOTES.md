# INT-NEXT-UPDATE-MASTER-159A — CLIENT R66 Patch Notes

**Parent:** R65 → **Current:** R66 (VC192)  
**Paired SERVER:** R101 (VC224)

### Added
- `ToolRequestCompilerV1` preflight contracts and archive/directory pre-execution resolution.
- OpenAI conversations-only importer with archive analysis, staging/rollback, branch reconstruction, timestamp normalization, provenance, and hidden-reasoning isolation.
- Imported history store integrated with the existing thread list, paging, FTS, continuation, sync exclusion, and tombstones.
- Account/history continuity with revision sync, fragmented oversized uploads, local-only behavior, and reinstall restoration support.
- Android Credential Manager Google sign-in path using Google ID tokens.
- Encrypted client credential envelopes with explicit recovery-key wrapping.

### Changed
- Archive runtime now consumes preflight-compiled requests before backend execution.
- Chat history list now represents native + imported thread sources while keeping imported messages historical/non-executable.
- Settings/account UI now exposes local-only, sign-in-later, import/sync modes, per-thread sync exclusion, and cancelable import.
- Build/patch identity advanced to R66 / VC192 / `INT-NEXT-UPDATE-MASTER-159A`.

### Preserved
- Imported history cannot authorize or dispatch a present tool mission merely by being loaded.
- Local-only SWRLZ remains fully usable without Google sign-in or server history upload.
- External canonical SWRLZ-LALM model/container unchanged.

### Validation
- Fresh successor source/archive verifier: **48/48 PASS**.
- Android compile/device execution remains pending because the Gradle wrapper could not fetch Gradle 8.7 in this environment.
