# INT-TRANSFER-STREAM-117A — CLIENT R14 implementation report

## Trigger

The same-phone loopback benchmark on `127.0.0.1:8787` could time out at `/forge/uploads/start` before a first payload chunk, including a 1 MiB test, while Google Drive and GitHub transfers showed substantially healthier throughput.

## CLIENT changes

1. A proof-bound BUSY heartbeat is performed before generic, benchmark, and verified source-pair transfer creation. The existing heartbeat uses 1500 ms connect/read bounds, so stale presence now recovers or fails fast instead of waiting for the 60 s upload request timeout.
2. Generic file transfer keeps R13's single local staging/hash pass, negotiates SERVER binary capability, then prefers raw binary chunks (256 KiB advertised preference) with resumable offsets and bounded retries.
3. Canonical source+metadata transactions prefer `/v1/transfers/chunks/write-binary` and send raw bytes plus exact chunk SHA-256 headers; 404/405 against an older SERVER falls back to the established Base64 verified-transfer route.
4. Public transfer entry points execute on `Dispatchers.IO`; files remain bounded/chunked rather than loaded as a whole-file byte array.
5. The UI benchmark is now `LOCAL STREAM TRANSFER BENCHMARK` and reports transport-aware NDJSON evidence for `/start → raw binary chunks → commit` over localhost.

## Compatibility and authority

Legacy Base64 remains fallback. CLIENT does not gain Forge approve/dispatch/build/deploy/install authority; SERVER remains authoritative for verification and consequential actions.

## Evidence boundary

Source/static checks are local. Android compilation was attempted, but Gradle 8.7 could not be downloaded because this workspace has no network route to `services.gradle.org`; no successful APK/device claim is made. Parent R13 source SHA-256: `e2cba3996cd45c123e7b90e09d005f2b36504373a3a8a60dbc9e906e054a64c1`. Paired SERVER: R36 / VC159.
