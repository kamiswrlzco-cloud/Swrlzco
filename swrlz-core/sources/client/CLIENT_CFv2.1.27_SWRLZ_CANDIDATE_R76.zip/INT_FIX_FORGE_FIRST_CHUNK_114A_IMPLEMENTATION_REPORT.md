# INT-FIX-FORGE-FIRST-CHUNK-114A — CLIENT R13 Implementation

- Baseline: CLIENT R12 / VC138.
- Successor: CLIENT R13 / VC139 `2.1.27-forge-first-chunk-r13`.
- Device evidence: upload `forge-upload-cfa7a730-8ba9-4993-bd67-812352552d39` opened for 15,184,394 bytes but SERVER recorded 0 received bytes / 0 chunks.
- Generic uploads now stage the selected content URI into app-private cache and hash the staged bytes before `/forge/uploads/start`; the transfer no longer depends on reopening the document provider after SERVER has created a session.
- Generic chunk size is 64 KiB, keeping base64 JSON requests substantially below the previous 256 KiB raw / ~350 KiB encoded request size.
- Each chunk uses up to three bounded retries with one idempotency identity. If a response is lost but SERVER reports `nextOffset == offset + decodedBytes`, CLIENT treats that chunk as already accepted.
- Fatal post-start failures issue a best-effort authenticated `/forge/uploads/{uploadId}/abort`; R33 compatibility is preserved because failure of the optional abort is ignored.
- Staged cache files are deleted in `finally`.
- No GitHub workflow, Actions-secret, signing, deployment, or install changes are included in this app-side checkpoint.
- Authoritative Android compilation remains the next GitHub build.
