# INT-AI-SWRLZX-004A — Validation Boundary

## Proven in this source checkpoint

- shared `swrlzx.stream.v1` contract is present in both candidates;
- production Kotlin reference executor emits token steps incrementally;
- production Kotlin native engine emits multiple `TokenGenerated`/`DraftDelta` events before `Completed`;
- cancellation requested after the first draft is observed before a second decode/draft and yields `Cancelled` without `Completed` in the fixture;
- strict incremental BYTE_UTF8 decoding reconstructs a three-byte `€` code point and rejects truncated input;
- production streaming Truth Firewall suppresses draft/token events, emits multiple committed deltas for a safe long response, preserves exact reconstruction, and emits a reset on adversarial output;
- existing whole-response Truth Firewall remains authoritative and the streaming gate does not grant model authority;
- source manifests, checkpoint receipt, lineage, patch notes, and paired documentation are updated.

## Evidence that is fixture/local only

- cancellation wall-clock latency from the deterministic reference fixture;
- first-token / first-commit timing measured on the build environment;
- reference CPU executor throughput.

These values are architectural regression evidence, not Android phone performance claims.

## Still unproven

- exact optimized 229 MB GGUF→SWRLZX conversion on the node-local model bytes;
- complete LFM2 native operator/tokenizer/quantizer execution;
- target Android RAM/thermal/performance behavior;
- production cancellation latency on long LFM2 decode steps;
- SERVER HTTP streaming, disconnect cleanup, LAN backpressure, CLIENT stream parsing, and Compose rendering;
- APK build/install, GitHub workflow acceptance, promotion, deployment, or release.
