# CLIENT CFv2.1.4 — Forge + Repository Console

Version code: `102`  
Version name: `2.1.4-forge-repository-console-v1`

## Scope

This additive patch turns Forge into an action console and adds a separate repository workspace while keeping persistent Forge configuration in Settings.

## Forge mode

- Two-mode header: **FORGE** / **REPOSITORY**.
- Live GitHub Actions discovery from the configured repository.
- Searchable workflow list.
- Workflow YAML inspection for `workflow_dispatch.inputs`.
- Dynamic boolean, choice, and text dispatch controls.
- Manual workflow dispatch by selected ref without touching source files.
- Existing run observer retained with cancel and re-run actions.
- Workflow auto-refresh and history depth are now Settings-owned preferences.
- Source routing, checksum matching, source guard, generic ZIP expansion, token-name, and repository target configuration remain under Settings → Forge.

## Repository mode

- Branch-aware repository list view with branch discovery and branch creation.
- Current-directory search and root/up navigation.
- Create UTF-8 text files and edit existing text files.
- Create folder markers with `.gitkeep`.
- Upload files into the current repository directory.
- Download repository blobs through Android document save UI.
- Multi-select repository files.
- Atomic multi-file move and delete operations through Git tree commits.
- Single-file move supports full destination path, including rename.
- Destructive delete confirmation enumerates exact paths before commit.

## Forge transaction behavior

An upload whose staged blobs already match the current branch is now a successful verified no-op instead of an exception. Forge records `TRANSACTION_NOOP`, verifies staged paths against expected blob SHAs, returns the current commit, and does not wait for a nonexistent push-triggered workflow unless an explicit workflow dispatch occurred.

## Verification state

- Kotlin source was checked for parser-level syntax errors using the available local Kotlin compiler; no parser errors were detected in the modified Forge files.
- Full Android/Gradle compilation is **not claimed**. The execution environment does not have the required Gradle distribution cached and cannot resolve `services.gradle.org`.
- Device/runtime verification is **not claimed** until a GitHub Actions or device build succeeds.
