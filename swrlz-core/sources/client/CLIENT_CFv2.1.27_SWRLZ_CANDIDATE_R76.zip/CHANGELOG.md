# INT-SERVICE-WORKFLOW-DRAGON-JAR-168A — CLIENT R76 / VC202 PATCH NOTES

## Code 🫙 send/render boundary repair
- Composer behavior now matches the operator contract exactly: selecting text and pressing 🫙 visibly inserts editable `[🫙]...[/🫙]` serialization in the input field.
- After SEND/history persistence, the same serialization is parsed into a real nested Code 🫙 UI segment inside the message bubble; raw jar markers are not normal sent-message presentation.
- Fixes the concrete R75 root cause: `detectLanguage()` contained an invalid Kotlin regex (`Unclosed character class`) which threw during rich parsing; the renderer caught that exception and fell back to raw serialized text.
- Marker canonicalization tolerates variation selectors and zero-width format characters around jar tokens, supports multiple containers, converges fenced Markdown onto the same code segment, and strips structural markers on malformed-display fallback rather than leaking them into chat.
- Historical/imported/user/assistant/LALM messages continue using the same non-destructive presentation model over immutable original provenance.

## Dragon theme/persona contract
- Mirrors the SERVER shared theme-persona contract so theme identity can provide the baseline dragon presentation personality while custom node/user profile instructions layer on top later.
- Default built-in theme resolves to `ANCIENT_DRAGON`; variant themes carry their own presentation-only persona metadata.
- CLIENT theme/persona metadata never alters tool schemas, truth, trust, authority, confirmation, or execution semantics.

## Preservation / validation boundary
- R75 execution ownership, group/trust presentation, active-GGUF exclusion, Forge behavior, and SERVER_LOCAL pairing remain preserved.
- Canonical `SWRLZ-LALM-001A.§wyrlzx` remains external and unmodified.
- Actual CLIENT jar parser source passes a dedicated Kotlin harness including the exact leaked-marker screenshot sentence and malformed/Unicode cases.
- Local Gradle compilation cannot start because this workspace cannot resolve `services.gradle.org`; fresh Auto Forge/APK/device evidence remains required.

---

# INT-TRUST-LALM-FORGE-RICH-167A — CLIENT R75 / VC201 PATCH NOTES

## Rich Code 🫙
- `[🫙]...[/🫙]` remains durable internal serialization only. Normal chat renders the contained range as a nested code-container card inside the surrounding message.
- Fenced Markdown and jar serialization converge on the same rich renderer with language label, monospace body, `COPY`, and `🫙 REMOVE`.
- The composer visually hides storage markers while preserving correct selection mapping and durable wrap/unwrap state.
- Historical/imported USER/assistant/LALM structure edits remain non-destructive overlays over immutable original content; malformed/legacy structures fall back safely.

## Execution ownership
- CLIENT protocol handling accepts only explicit `CLIENT_LOCAL` jobs.
- The old Android→SERVER `/providers/reason` relay is removed from CLIENT_LOCAL. Until a true on-device executor exists, CLIENT_LOCAL ACKs then fails closed with `CLIENT_LOCAL_EXECUTOR_NOT_CONFIGURED`.
- SERVER-owned canonical §wyrlzx inference uses SERVER R110 `SERVER_LOCAL` and therefore does not depend on Android selection/trust.

## Model/UI
- Active CLIENT model inventory hides GGUF/provenance-only entries. Historical update-ledger evidence remains readable but does not create runtime execution authority.
- Pairs with SERVER R110 group-scoped trust, direct SERVER_LOCAL execution, correlation diagnostics, canonical §wyrlzx auto-selection/background preload, and tile-scoped Auto Fix successor loop.

## Boundary
- Model bytes remain external; `SWRLZ-LALM-001A.§wyrlzx` is not bundled or mutated.
- Fresh Android compile/APK/device acceptance is not claimed by this source package.

---

# CLIENT R74 / VC200 — INT-LALM-ASYNC-LOG-AUTOFIX-CONTAINER-166A

Poisoned R73 jar-overlay recovery/quarantine, hardened v3 jar rendering/selection, READ_CHUNK routing repair, and async local LALM provider polling.

# CLIENT R73 — Durable 🫙 Message Containers + Paired Conversational LALM
Checkpoint: `INT-LALM-CHAT-OBSERVATORY-164A` · VC199 · `2.1.27-lalm-chat-containers-r73`

- Replaces the R72 crash-prone secondary code-structure editor with a single portable structural syntax: `[🫙]selected text[/🫙]`.
- Composer 🫙 acts directly on the current `TextFieldValue`: non-empty selection wraps exactly that range; cursor/selection anywhere touching an existing container unwraps that whole container.
- Historical/imported/user/assistant/LALM plain-text segments are selectable in-place. Pressing the message 🫙 control persists a non-destructive effective-text overlay and immediately recomposes the message; original provenance stays recoverable.
- Rendered containers expose `🫙 REMOVE` plus COPY-content-only. Legacy/imported fenced Markdown continues to render and can be unwrapped through the same control path.
- Adds unit coverage for exact wrapping, inside-container unwrapping, intersection unwrapping, and imported fenced-code unwrapping.
- Preserves R72 progressive history/cache behavior, direct newest-message thread opening, wide timestamped chat, admin Observatory mirror, Google configuration path, and the device-proven GPT↔Android LALM transport.
- Pairs with SERVER R107, which repairs conversational generation selection, same-device bootstrap authorization, native provider health reporting, and LALM Observatory readability.
- Fresh R73 compile/APK/device acceptance remains external Auto Forge evidence and is not claimed by this source checkpoint.

## R71 / VC197 — INT-RUNTIME-STREAM-OBSERVATORY-163A

- App-scoped IO history runtime publishes recent thread headers first, keeps the cache alive across menu changes, and progressively exposes older headers without repeating a cold history load on every HISTORY press.
- Existing threads initialize the lazy chat list directly at the newest message instead of visibly animating through the entire historical timeline.
- Chat messages use near-full usable width, retain per-message timestamps, parse fenced Markdown code into 🫙 code containers, and provide copy-code-only controls.
- Users can select a range in the composer or an existing/historical message and convert it into a code container. Historical/imported records keep immutable original provenance; the structured presentation is a removable local overlay.
- The AI fallback/bootstrap path resolves those structure overlays so selected code is represented as fenced code/data rather than silently flattened.
- CLIENT Observatory is visible only while SERVER reports this node as ACTIVE `SWRLZ_ADMIN_OPERATOR`, TRUSTED and BOUND. The app-scoped Observatory runtime continues hydrating node, thread and SERVER-log state while menus change.
- Google OAuth web client ID can come from compatible build aliases or a user-entered public identifier in Account & Sync. Local-only operation remains supported.
- R70/R69 GPT→Android LALM transport behavior and R68 bounded archive/account safeguards are preserved.
- Fresh R71 Android compile/install/device validation is external Auto Forge evidence and is not claimed by this source checkpoint.


# Changelog

## R72 / VC198 — INT-RUNTIME-STREAM-OBSERVATORY-COMPILE-163B
- CLIENT-only compile successor to R71; SERVER R106 remains unchanged.
- Fixes the R71 `ChatBubble(threadId, message)` live-stream call mismatch.
- Gives `SettingLine` a default empty trailing composable for read-only Observatory rows.
- Preserves all R71 runtime/history/rich-chat/code-container/admin-Observatory behavior; APK/device acceptance awaits fresh Auto Forge evidence.

## CFv2.1.27 CLIENT R65 — INT-SEMANTIC-TOOL-MERGE-JERRY-158A
- Pairs with SERVER R100 and preserves all R64 routed tool-executor normalization.
- Maps semantic clarification phases into a visible WAITING FOR CLARIFICATION state and labels terminal clarification questions as NEEDS DETAIL.
- Surfaces Jerry/self-preservation operational states without promoting them into tool execution.
- Clarification remains meaning-only; approval/execution remains separate.
- APK/install/device success remains unclaimed pending external build/device evidence.

# 2.1.27 Tool Executor Bridge — R64

- `versionCode`: `190`
- `versionName`: `2.1.27-tool-executor-schema-observatory-r64`
- Generic allowlisted TOOL/MISSION envelopes are normalized into canonical Archive/Directory/Log VFS requests instead of disappearing after durable inbox cursor advancement.
- `swrlz_archive_repack` normalizes to `REPACK_SELECTED` for the local conversation-only ZIP workflow.
- Unsupported routed tool envelopes return explicit correlated error evidence.
- R63 Forge live inbox auto-selection and exact-plan destructive safety remain preserved.
- Android APK/device acceptance remains separate evidence.

# 2.1.27 Exact Filename + App-Private Directory Toggle — R59

- `versionCode`: `185`
- `versionName`: `2.1.27-approval-private-root-r59`
- File-backed Directory VFS creation now preserves the exact requested leaf filename; `SWRLZ_TEST_1MB.bin` no longer intentionally passes through MIME-based extension synthesis that could create `.bin.bin`.
- Adds an OFF-by-default `CLIENT App-Private Data` toggle in Archives & Data and Permission Centre. It exposes only this app's own sandbox (`/data/user/0/sh.swurlz.core`) as opaque grant `client-app-private`.
- Android sandbox truth is explicit: the whole `/data/user/0` tree and other apps' private directories remain inaccessible to a normal non-root app.
- App-private access is READ-ONLY, recovery-disabled, never auto-defaulted, and marked as a sensitive scope in CLIENT advertisements.
- R58 Downloads actual-write advertisement, exact-plan destructive approval, recovery semantics, Deep Dig, and durability work remain preserved.
- Device acceptance remains pending until APK Router/device testing.

# 2.1.27 Fixable Issues Phase 1 — R58

- `versionCode`: `184`
- `versionName`: `2.1.27-fixable-issues-phase1-r58`
- Built-in Android Downloads now advertises actual filesystem write authority only when enabled + All Files + root `canWrite()` are all true; exact-plan destructive approval remains mandatory and recovery remains disabled.
- Downloads authority changes trigger immediate best-effort SERVER re-advertisement instead of waiting only for the next heartbeat.
- Adds per-shard resumable conversation-only archive research receipts with `INDEX_READY` / `BODY_PARTIAL` / `BODY_RECONCILED` coverage truth and hostile 25-boundary resume tests.
- Adds AtomicFile-backed active LALM stream recovery journal; process death preserves partial committed presentation separately and never promotes it to completed history.
- CLIENT chat-history snapshots now use AtomicFile commit/backup recovery. Whole-history write amplification remains a separate P1 migration item.
- Failed/cancelled streamed text is labeled `PARTIAL COMMITTED PREFIX · NOT A COMPLETED TURN`.
- Source/harness checkpoint only; Android compile/APK/device acceptance remains separate.

# 2.1.27 Downloads Toggle + Routing Repair — R57

- `versionCode`: `183`
- `versionName`: `2.1.27-downloads-toggle-routing-r57`
- Android Downloads is now a built-in read-only Directory VFS authority toggle instead of an impossible Download-root SAF picker.
- When enabled and Android All Files special access is ready, `android-downloads` becomes the default for read-only list/tree/read/search/analyze operations only.
- Built-in Downloads never grants remote write/recovery authority; custom SAF grants remain available for other folders.
- Canonical path containment protects the direct-file Downloads backend from escaping its root.
- R56 live status-card/bubble/Android notification surfaces and destructive-safety contracts remain preserved.

# 2.1.27 Live Action + Storage Permission UX — R56

- `versionCode`: `182`
- `versionName`: `2.1.27-live-action-storage-permissions-r56`
- Persistent CLIENT foreground status notification now consumes the live tool-action state and rolls the latest bounded action/state/detail directly in the top status card.
- Tool-action visibility surfaces are independently controllable: persistent status stream, separate Android action notifications, and conversation-bubble action updates.
- Tool-action verbosity is enforced across every action surface; routine OFF is global while safety-critical approval/failure states remain eligible to surface.
- Activity & Notifications owns action visibility/bubble controls; Theme remains presentation-only.
- Directory analysis/content-search can be disabled locally without revoking direct scoped directory grants.
- A locally selected default analysis directory can satisfy omitted `grantId` only for read-only Directory VFS operations; mutations still require explicit grant identity.
- Added a Downloads-focused scoped SAF picker to first-run Permissions and Archives & Data settings.
- Permission Centre now owns scoped Downloads/directory onboarding plus optional All Files special access, so storage authority is visible during setup and later review.
- Default directory identity is advertised without exposing the raw Android tree URI.

# INT-DEEP-DIG-OPERATIONAL-CONTROL-145A — CLIENT CFv2.1.27 R54 · VC180

- `versionName`: `2.1.27-deep-dig-control-r54`
- Parent: CLIENT R53 SHA-256 `c63df10f663af89fb2cd369c5d089d224f660ace963749d099276c52a2eef8ad`.
- Pair: SERVER R85 / VC208.
- Adds one-pass `CORPUS_AGGREGATE` role/corpus totals for messages, characters, words, lexical tokens, estimated model tokens and 160-character SMS equivalents.
- Adds seedless `NEOLOGISM_ANALYZE` with root/stylization/edit-near clustering, recurrence, first/last evidence and user↔assistant mutual-adoption evidence; strong labels require creative morphology/family evidence.
- Optimizes single-word FUZZY search by preparing messages once and comparing against token vocabulary rather than whole-body edit distance; date bounds accept YYYY-MM-DD and normalize accidental epoch seconds.
- Directory/Archive VFS adds exact live mutation-plan hash approval; bounded destructive inventory fails closed if it cannot be fully verified. Directory adds safe idempotent `APPEND_TEXT`.
- Adds CLIENT tool-action notifications and TOOLS logger controls without exposing hidden reasoning or secrets.
- Source/static candidate only. Gradle compilation was blocked before toolchain execution because the wrapper distribution host is unavailable in this sandbox; no APK/install/device/deployment/promotion claim.

# INT-TUNNEL-LALM-NODE-ADMIN-144A — CLIENT CFv2.1.27 R53 · VC179

- `versionName`: `2.1.27-observation-freshness-r53`
- Pairs with SERVER R83.
- Adds the paired safe V2 execution-state vocabulary for permission preflight, capability discovery, state validation, mutation-triggered revalidation, and result verification.
- Preserves R52 Deep Dig corpus search/aggregation/timeline/concept-lineage/thread reconstruction.
- Hidden reasoning remains excluded; the added trace is operational telemetry only.
- Evidence boundary: source/static only; no APK/device/deployment claim.

# INT-DEEP-DIG-ANALYSIS-FABRIC-143A — CLIENT CFv2.1.27 R52 · VC178

- `versionName`: `2.1.27-deep-dig-r52`
- Parent: CLIENT R51 SHA-256 `6c7bda0ca55deae9448c01c2a9c9fc7d8829810e192b4cba3bdab491e4726338`
- Pair: SERVER R81 / VC204.
- Archive VFS gains bounded GPT-export Deep Dig operations: exact/regex/fuzzy/transparent lexical-semantic message search, aggregation, timeline, concept-lineage evidence, messageId/parentId thread reconstruction and magic-byte entry identification.
- Filters are message-grounded where possible: role, recorded model slug, date range, title, conversation ID, message length and per-message attachment presence; results retain snippets and archive/conversation/message provenance.
- Aggregation separates matching messages from unique message IDs/conversations/days and groups by role/month/conversation with first/last occurrence evidence.
- Transparent evidence profiles surface candidate support/concern/encouragement/disagreement/correction/humor/creative/technical/identity/persona/preference/promise/unresolved-task evidence without asserting psychological or relational conclusions.
- Existing persistent ArchiveIndexStore reuse is complemented by a bounded query-result cache keyed to the archive/index/query fingerprint; this is not mislabeled as a full FTS/vector index.
- R51 directory allocation and transactional mutable Archive VFS are preserved. Source/static checkpoint only; Gradle 8.7 download was blocked before compilation by `UnknownHostException`. No APK/install/deployment/promotion claim.

# INT-LALM-CAPABILITY-FABRIC-142A — CLIENT CFv2.1.27 R51 · VC177

- `versionName`: `2.1.27-capability-fabric-r51`
- Parent: CLIENT R50 SHA-256 `bd87ba3d35a3337fc50d4e087b59c250c20e9549fbe092b510f405f5af15461a`
- Pair: SERVER R80 / VC203.
- Adds write-aware Archive VFS selection and transactional top-level ZIP mutation: WRITE_TEXT, MKDIR, COPY, MOVE, RENAME, DELETE and REPACK with structural/SHA verification plus rollback protection. Nested archive-in-archive mutation fails closed; nested reads remain supported.
- Adds bounded Directory VFS `ALLOCATE` up to 4 GiB with sparse-seek or zero-fill execution and exact resulting-size verification, avoiding unnecessary tunnel transfer for large local test files.
- CLIENT presence now advertises `archive.write` separately from `archive.read`; archive and directory mutation remain local-grant + capability + explicit-consequential-confirmation gated.
- Preserves R50 semantic orchestration, schema-2 operational stream, evidence gating and STOP/retry quiescence.
- Source/static checkpoint only; no APK/install/device/deployment/promotion claim.

# INT-LALM-TOOL-ORCHESTRATION-141A — CLIENT CFv2.1.27 R50 · VC176

- `versionName`: `2.1.27-tool-orchestration-r50`
- Parent: CLIENT R49 SHA-256 `78eb12adc0780bedbcf8a75963bd91e15e7020470ec31bffdb0c653c662e44f9`
- Pair: SERVER R79 / VC202.
- Routes actionable Forge/GitHub and File Analysis Lab language through the typed SERVER tool-control path while preserving bare Forge UI navigation.
- Protocol V2 schema 2 adds safe STATUS telemetry for suite/operation/capability/risk/plan/execution/evidence/answer state; hidden reasoning remains excluded.
- Tool-plan UI distinguishes review, waiting-for-executor, evidence-ready and rejected states; `NOT_REQUIRED` confirmation never implies execution.
- STOP/retry/replacement uses bounded SERVER cancellation-drain coordination to prevent stale native ownership from becoming an immediate retry `LALM_BUSY` race.
- Deterministic capability-catalog answers can complete without native decode.
- Source/static checkpoint only; no APK/install/device/workflow/deployment/promotion claim.

# INT-LALM-SESSION-BOOTSTRAP-139A — CLIENT CFv2.1.27 R49 · VC175

- `versionName`: `2.1.27-lalm-session-bootstrap-r49`
- Parent: CLIENT R48 SHA-256 `5604f603ef3ffe71777052b24e3271800ca2ede3885c331a6e67daa5b0d62aee`
- Pair: SERVER R77 / VC200
- New/first-activated chat threads upload the complete CLIENT-local node chat history once through bounded `/chat/bootstrap` chunks; untouched local placeholder greetings are excluded from history truth.
- After SERVER readiness, the opening fallback greeting is replaced only if the thread is still untouched, using the fact-grounded SERVER orientation greeting.
- Normal bootstrapped LALM turns send `history=[]` and omit repeated `clientContext`; bootstrap failure preserves the previous bounded last-12-turn history and CLIENT-context request path.
- V1 compatibility fallback now carries `threadId` and `ingress` so SERVER-side session continuity survives stream-route fallback.
- Gradle wrapper distribution was unavailable in this sandbox, so compilation did not start. No APK, install, device, workflow, deployment, or production-promotion result is claimed.

# INT-LALM-EXECUTION-TRACE-138A — CLIENT CFv2.1.27 R48 · VC174

- `versionName`: `2.1.27-lalm-execution-trace-r48`
- Pair: SERVER R76 / VC199
- Chat now renders safe operational LALM state transitions before/during committed text streaming instead of a single ambiguous CONNECTING state.
- Normalized lifecycle includes request analysis, Truth/Memory/context readiness, action-plan review, model readiness, PREFILL, first token, generation, reset/fallback, and terminal states.
- On completion, execution telemetry collapses into the assistant message as an expandable `Worked for …` summary and persists in CLIENT local history schema v3.
- Protocol V2/schema 1 remains unchanged; labels are operational telemetry only and never expose hidden reasoning, draft deltas, prompt text, or chain-of-thought.
- Source/static checkpoint only. No APK, install, device, workflow, deployment, or production-promotion claim is made here.

# INT-LALM-INTERACTIVE-MEMORY-137A — CLIENT CFv2.1.27 R47 · VC173

Pairs with SERVER R75. CLIENT keeps one protocol-2/schema-1 LALM stream, accepts content-free heartbeat phases during bounded reference-CPU work, preserves first-token/first-text/start-to-finish timing, and renders opaque memory decisions plus explicit plan-scoped tool review outside assistant-authored content.

- `versionName`: `2.1.27-lalm-interactive-memory-r47`
- Reference-CPU prefill/generation no longer terminates with `LALM_REFERENCE_CPU_INTERACTIVE_GUARD` on the paired V2 route.
- Memory IDs/content-safe decisions and tool plan/result correlation are additive safe-default fields; older schema-1 payloads still decode.
- `APPROVE PLAN` records approval only. The UI explicitly says that approval is not invocation or success; a separate capability-authorized executor must record result evidence.
- CLIENT logs every validated stream event and terminal/decision outcome without prompt or assistant content.
- No APK build, install, device test, workflow, deployment, executor run, or production promotion is claimed.

# INT-LALM-STREAM-TRUTH-136A — CLIENT CFv2.1.27 R46 · VC172

Pairs with SERVER R74. CLIENT now consumes one additive protocol-2/schema-1 LALM stream for direct and generated answers, supplies thread/ingress context, renders operational phases outside assistant content, and shows/persists start-to-finish plus first-text timing. Event logs correlate endpoint, request, thread, sequence, route, Truth Capsule ID, and timing without recording prompt or response content.

The V1 completed route remains an older-SERVER compatibility fallback. No APK, Android compile, install, device, workflow, release, deployment, or production-promotion result is claimed; Gradle verification was blocked before compilation because Gradle 8.7 was uncached and its distribution host was unreachable.

# INT-LALM-ROUTING-RUNTIME-135A — CLIENT CFv2.1.27 R45 · VC171

- candidate: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R45`
- parent: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R44` · SHA-256 `cf945429cfbb3e6f2c2890407848047b2cb33ab9c76b04124221ca94fdc05223`
- sibling: `SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R73`
- versionName: `2.1.27-lalm-routing-r45`
- checkpoint: `INT-LALM-ROUTING-RUNTIME-135A`

## Live SERVER route repair

- The SERVER endpoint proven healthy by process reconciliation is now the operational endpoint for Core, Chat and LALM APIs while its heartbeat remains fresh and ONLINE.
- The configured Core Node URL remains the durable preference and fallback; the runtime override is not persisted as a silent configuration rewrite.
- LALM stream startup records `stream_endpoint_resolved` with request/thread correlation so future transport failures show the exact route actually used.
- This repairs the field condition where registration/heartbeat succeeded over `127.0.0.1:8787` but Chat still opened its stream against a stale LAN address such as `192.168.1.181:8787`.

## Evidence boundary

CLIENT R44 already built successfully in workflow `31747287191`. R45 changes CLIENT routing behavior and therefore requires a new authoritative APK Router build. No installation, promotion or deployment is claimed by source preparation.

# INT-REGISTRATION-LALM-134A — CLIENT CFv2.1.27 R44 · VC170

- candidate: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R44`
- parent: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R43` · SHA-256 `f75003c06f2cfe905b61323f3fabed1ea4713cd061ea8d00b54cc802be7d3c8c`
- sibling: `SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R71`
- versionName: `2.1.27-registration-lalm-r44`
- checkpoint: `INT-REGISTRATION-LALM-134A`

## Changes

- Startup registration reconciliation now performs a bounded local loopback probe before falling back to the configured LAN endpoint. A co-resident SWRLZ SERVER that answers with a valid SWRLZ registration/heartbeat response is selected for the session.
- `PROOF_REBIND_REQUIRED` / `PROOF_MISMATCH` recovery now emits distinct `proof_rebind_begin` and `proof_rebind_end` diagnostic evidence with protocol code, status, elapsed time and canonical node identity.
- Duplicate CLIENT chat snapshot saves are de-duplicated at the diagnostic layer so one logical message commit does not appear twice merely because Compose/state persistence called `saveMessages` twice.
- R43 hierarchical Developer Logger controls and the persistent `CLIENT · CFv2.1.27 · R44 / VC170` revision footer are preserved.

## Evidence boundary

The change is prepared from R43 source. Android compilation/signing remains the APK Router acceptance gate. No installation, promotion or deployment is claimed by source preparation.

# INT-DEVLOGGER-FORGE-133A — CLIENT CFv2.1.27 R43 · VC169

- candidate: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R43`
- checkpoint: `INT-DEVLOGGER-FORGE-133A`
- versionCode: `169`
- direct parent: CLIENT R42 / SHA `60a602529905ab30435a7668c7a6fe999c673ed0b81e31a955ac9da74baffc28`
- sibling prepared with this feature update: SERVER R70
- changes: hierarchical Developer Logger master/menu/submenu switches; bounded rotating log clear/export controls; visible CLIENT revision in the persistent footer; stale direct-build workflow identity refreshed.
- preserved: R42 registration reconciliation, LALM stream diagnostics, archive/analysis behavior, Truth Firewall and approval boundaries.
- Android build: pending authoritative APK Router rebuild.

## CLIENT R42 — INT-FIX-CLIENT-LOGGER-COMPOSE-132B

Authoritative APK Router workflow `31732692488` reached `:app:compileDebugKotlin` and exposed one CLIENT-only compile blocker in the new full-log Settings panel: the explicit `androidx.compose.foundation.layout.weight` import resolved to an internal `RowColumnParentData` helper in this Compose toolchain. R42 removes that import and preserves the R41 observability, registration continuity, LALM diagnostics, and SERVER R68 pairing unchanged. SERVER is intentionally not incremented.

## CLIENT R41 — INT-OBSERVABILITY-RECONNECT-LALM-132A

Full-pair update paired with SERVER R68. Adds an app-private rotating NDJSON full diagnostic log with Settings export, detailed chat/LALM stream events, and registration/rebind/heartbeat traces. Repairs in-place update reconnect by reconciling persisted enrollment on process start rather than trusting a stale `ONLINE` preference after the process-local heartbeat job has died; the heartbeat loop can also re-register after conclusive registration-loss responses. Provider status now recognizes canonical `lalm` SERVER identity and avoids false `NO SERVER MODEL`/SERVER-offline presentation caused by the R67 provider rename. Explicit manual disconnect remains authoritative and no raw device proof or credential is written to logs.

## CLIENT R39 — INT-ANALYSIS-LAB-130A

Pairs with SERVER R65. Implements all three parked Analysis Lab export improvements: exact conversation shard classification (`conversations.json` / `conversations-\d{3,}.json`), separate `shared_conversations.json` references, exclusion of `conversation_asset_file_names.json`, ZIP-magic mounting of opaque `.dat` attachments with filename/MIME metadata used only as hints, and bounded provenance-preserving development-cycle analytics. R38 LALM PROBING UX, persistent Archive Index, streaming and safety gates are preserved. Android APK Router/device acceptance remains pending.

## CLIENT R38 — INT-AI-SWRLZX-013A

Adds truthful native-model probing UX: when SERVER reports the SWRLIE/LALM provider as PROBING before Model Rack selection is committed, Chat shows the discovered LALM model with `PROBING` instead of incorrectly saying `NO SERVER MODEL`. Preserves R37 Archive Index behavior and streaming client runtime. Paired with SERVER R64 / VC187.

## CLIENT R37 — INT-BUILD-VERSION-129A

Version-only canonical refresh of R36. Advances CLIENT to R37 / VC163 with a clean canonical source filename while preserving the R36 persistent Archive VFS index, FD-native ZIP/ZIP64 seek, direct indexed entry reads, LALM contracts, and all runtime behavior unchanged. Paired with SERVER R63 / VC186.

## CLIENT R36 — INT-ARCHIVE-INDEX-128A

Fixes the giant-archive Archive VFS timeout path exposed by the 6.25 GiB `§wyrlzx.zip` export. CLIENT now builds one persistent SQLite outer-archive catalog in the background, advertises `BUILDING/READY/FAILED/STALE` index state, and serves root `INFO/TREE/LIST` plus conversation-candidate discovery from the local catalog instead of rescanning the source ZIP on every tunnel request.

A new pure-Kotlin ZIP/ZIP64 central-directory parser reads the granted SAF file descriptor directly, bypassing the fragile `/proc/self/fd -> ZipFile` reopen path. Seekable providers record each entry's local-header offset so `READ`/conversation operations can jump directly to the requested entry and inflate only its compressed bytes. Non-seekable providers fall back to one background sequential indexing pass; request threads return retryable `ARCHIVE_INDEX_BUILDING` rather than spending the 300-second tunnel window walking gigabytes. Nested archives remain bounded/on-demand after the outer catalog is READY.

Focused JVM regression evidence passes ZIP64 entry-count parsing (66,001+ entries) and direct DEFLATE seek/read. Core Archive VFS Kotlin compiles against Android/API stubs. Full Android Gradle compilation could not start because the wrapper distribution host is unavailable in this environment; authoritative APK/workflow/device acceptance remains pending. SERVER R61 is the paired sibling and adds fail-fast routing from the CLIENT-advertised archive index state while leaving archive bytes on the CLIENT.

## CLIENT R35 — INT-AI-SWRLZX-012B

Repairs the authoritative GitHub Kotlin compile blockers exposed after 012A: Ktor stream cleanup now supplies the required cancel cause argument, and suspend CLIENT-context capture now executes inside the existing coroutine before stream start. SERVER R60 pairs with the explicit serializer repair. LALM parity semantics and production gates are unchanged; authoritative Android rebuild is pending.


## CLIENT R34 — INT-AI-SWRLZX-012A

Exact canonical GGUF↔LALM format/tensor/tokenizer/reference numerical parity is proven on real pinned bytes. `swrlzx.lalm.parity.v1` now requires structured legacy-engine/device evidence before production parity can be marked. Android/device promotion remains pending.
# INT-AI-SWRLZX-011A — CLIENT R33 / VC159

R33 pairs with SERVER R58 on the first-party LALM native architecture reference execution foundation. CLIENT carries the byte-identical runtime/operator contracts and 011A conversion/bring-up evidence so Model Rack and future parity surfaces share the same semantics, but CLIENT does not gain model-execution or promotion authority. Exact canonical model execution/tokenizer parity, GGUF↔LALM parity, Android performance and production promotion remain open.

# INT-AI-SWRLZX-010A — CLIENT R32 / VC158

R32 pairs with SERVER R57 on the canonical **LALM (Local Adaptive Language Model)** native identity and exact-source bring-up gate. CLIENT carries the byte-identical identity/conversion/Model Rack contracts, exposes native LALM versus source LFM provenance, and displays source-ready / target-present / parity-proven / selected bring-up state. No CLIENT model-execution authority, automatic promotion, or fabricated canonical target hash is introduced.

# INT-AI-SWRLZX-009A — CLIENT R31 / VC157

R31 pairs the checkpoint-9 advanced-runtime contract/status surface with SERVER R56. It exposes enabled paged/prefix capabilities and explicit fallbacks without moving target-model or Truth Firewall authority onto CLIENT.

# INT-AI-SWRLZX-008A — CLIENT R30 / VC156

R30 pairs with SERVER R55 on immutable SWRLZX model evolution. CLIENT carries the byte-identical evolution contract and V3 paired-LAN control routes, can inspect logical active/known-good identities and candidate stages, and exposes request helpers for registration, evaluation, explicit promotion and rollback. Training completion never promotes a candidate, hidden reasoning cannot be training truth, and unknown/unimplemented overlay application remains fail-closed. Exact optimized LFM2 Android parity/deployment remains open.

# INT-AI-SWRLZX-007A — CLIENT R29 / VC155

R29 pairs with SERVER R54 on SWRLZX native-default Model Rack migration. CLIENT now receives model `format` and `runtimeRole`, presents SWRLZX as the native/default contract, labels GGUF as bounded legacy emergency compatibility, and preserves explicit rollback/activation controls. The exact optimized 229 MB SWRLZX model/device parity gate remains open.

# INT-AI-SWRLZX-006A — CLIENT R28 / VC154

R28 completes the CLIENT side of live SWRLZX response streaming. Successful V2 chat responses are parsed incrementally through Ktor `bodyAsChannel()`/bounded NDJSON lines and applied to an exact sequence/identity state machine. An application-scoped stream runtime exposes microbatched 32 ms `StateFlow` snapshots to a transient Compose assistant bubble, handles RESET/cancel/failure/reconnect semantics, and persists assistant text only after terminal COMPLETED.

The existing V1 completed-response call remains as an explicit 404/405/501 compatibility fallback. One automatic retry is allowed only before committed text; post-delta replay is fail-closed until a resume-offset contract exists. SERVER R53 preserves R52 transport behavior and pairs the 006A lineage. Android device/LAN/process-death acceptance remains pending.

# INT-AI-SWRLZX-005A — CLIENT R27 / VC153

R27 pairs with SERVER R52 and carries the byte-identical `swrlz_llm_stream_v2` contract, wire/authority/ADR documentation, and transport evidence boundary. SERVER R52 can now flush committed model deltas over authenticated chunked NDJSON with bounded backpressure, cancellation and disconnect cleanup.

CLIENT network consumption is intentionally unchanged in 005A: the existing completed-response path remains the compatibility behavior. `bodyAsChannel()` parsing, stream state and live Compose rendering belong to 006A.

# INT-AI-SWRLZX-004A — CLIENT R26 / VC152

Checkpoint 004A adds the first native SWRLZX token-streaming foundation. The native reference executor/engine now emits token and draft events incrementally, uses strict cross-token UTF-8 assembly, and supports decode-boundary cancellation. A deterministic streaming Truth Firewall holds a bounded tail and is the only layer allowed to produce presentation-safe `CommittedDelta`; rejected drafts emit `Reset(regenerate=true)`.

This candidate does **not** yet stream over SERVER HTTP or render live CLIENT chat. Those remain 005A/006A. GGUF remains the compatibility fallback and optimized-LFM2/device acceptance remains open.

# INT-AI-SWRLZX-003A — CLIENT R25 / VC151

CLIENT R25 directly succeeds R24 SHA-256 `aee8af624f4e348cf6bbb0ef9958da81846b5288f172c049feb17b173c54aa76` and pairs with SERVER R50. It carries the byte-matched SWRLZX runtime/graph/tokenizer/quantizer contracts, checkpoint documents and verification tooling needed to understand the SERVER native-runtime state without moving model execution authority onto CLIENT.

Streaming transport/UI remains checkpoint 005A/006A work; CLIENT R25 does not claim local native model execution.

# CLIENT CFv2.1.27 R24 / VC150 — INT-AI-SWRLZX-002A

R24 pairs with SERVER R49 on the deterministic GGUF → SWRLZX conversion bridge. It carries the byte-identical shared conversion/provenance contract, exact optimized-source identity, conversion mapping documentation and verification tooling so future CLIENT inspection/stream negotiation sees the same source-to-container lineage as SERVER.

The CLIENT does **not** switch its chat/runtime path to SWRLZX in 002A. Native model execution begins only after checkpoint 003A parity evidence.

# CLIENT CFv2.1.27 R23 / VC149 — INT-AI-SWRLZX-001A

## Native SWRLZX container foundation

R23 pairs with SERVER R48 to establish the shared first-party `.§wyrlzx`/`.swrlzx` model-container contract. The CLIENT does not run or convert the model yet; it receives the same parser/schema contract now so future model inspection, streaming capability negotiation and runtime status use one exact file definition on both sides.

- Adds byte-identical `swrlzx-contract` core/metadata sources shared with SERVER R48.
- Defines authoritative SWRLZX magic, fixed V1 header/TOC, required manifest/tensor-directory/lineage/integrity sections and reserved stream/runtime section IDs.
- Adds section SHA-256, deterministic root digest, alignment/non-overlap/bounds checks and architecture-neutral tensor descriptors.
- Adds the staged roadmap through GGUF conversion, native inference, incremental Truth Firewall streaming, SERVER transport, CLIENT live rendering, GGUF deprecation and immutable model-generation evolution.
- Preserves R22 Selective Directory VFS, Archive VFS, Forge transfer and all existing trust/permission/Truth Firewall boundaries.
- No GGUF conversion, neural inference change, live response streaming, APK/device acceptance, model training or deployment is claimed by 001A.

# CLIENT CFv2.1.27 R22 / VC148 — INT-OBSERVATORY-DIR-VFS-126A

## Selective Directory VFS + bounded recovery

R22 pairs with SERVER R46 and preserves the R21 forensic baseline. A new **Archives & Data → Selective Directory VFS** section lets the user grant exact Android directory trees without exposing their SAF URI/device path to SERVER or ChatGPT.

- Grants start READ-ONLY. Write and deleted-file-recovery authority are separate local toggles and are revoked immediately when the grant is removed.
- Background protocol-2 worker now accepts fail-closed `swrlz-directory-query-v1` operations only with the exact requested `directory.read`, `directory.write`, or `directory.recovery.read` capability.
- Supports bounded info/tree/list/read/search and whole-directory structural analysis, plus confirmed create/write/mkdir/copy/move/delete operations trapped inside the selected grant. `..`, absolute/escaping paths, cross-grant operations and root deletion are rejected.
- Copy/move are bounded to 5,000 entries / 256 MiB per operation; text writes are bounded to 4 MiB; remote responses remain <=512 KiB.
- Recovery scan can inspect Android MediaStore trash records scoped to the selected external-storage tree and trash/temp/orphan-like remnants already visible inside the grant. Restore is best-effort into the same grant. Raw deleted flash/block recovery is explicitly unavailable on stock Android due to sandbox/FBE/TRIM boundaries unless a future privileged helper is enabled.
- Registration/heartbeat advertise only opaque grant ID/name/readiness/write/recovery bits; local URIs stay local. R19 Archive VFS and R21 Forge hardening remain intact.

## Validation boundary

Source/static validation is recorded in this candidate. GitHub Actions remains the compile/stable-sign gate if Gradle dependency bootstrap is unavailable. Device/tunnel acceptance is pending.

# INT-FORENSIC-REPAIR-125A

CLIENT R21 / VC147 forensic hardening pass. Repairs stale runtime identity, content-binds Forge pending transactions, rejects transaction-marker reconciliation unless staged paths verify exactly, revalidates repository mutation preconditions across branch races, retries automated Forge once after OAuth refresh, and replaces large GitHub Actions artifact/log ByteArrays with bounded file-backed streaming and APK extraction. R20 registration/Archive VFS behavior is preserved.

# INT-REGISTRATION-HOTPATH-124A

# R20 — Registration Hot-Path Isolation

Live R19 device evidence showed discovery reachable while enrollment timed out. R20 makes connection establishment independent of Archive VFS readiness.

- Registration sends identity/proof/capabilities only; archive advertisements begin on the immediate heartbeat after registration.
- Registration read timeout increases from 1.5 s to a bounded 5 s; heartbeat uses 2.5 s.
- Archive presence no longer opens every SAF document on each heartbeat. Persisted URI read permission is the cheap readiness signal; actual Archive VFS query opens remain authoritative.
- The first heartbeat is immediate, then the existing 10 s cadence continues.
- R19 Archive VFS engine, nested ZIP/ZIP64 reads, streaming conversation parser, R18 MAX/AUTO transfer behavior, proof recovery and Truth Firewall are preserved.

Paired SERVER: R44 / VC167.

# CLIENT CFv2.1.27 R19 / VC145 — INT-ARCHIVE-VFS-123A

R19 turns CLIENT into a local Archive VFS node. Large ZIP/ZIP64 exports remain on-device and can be progressively mapped/read through bounded SERVER/ChatGPT queries without uploading or extracting the entire archive.

## Changes
- Adds **Archives & Data** settings with Android document-picker registration and persistable read access; local document URIs are never advertised.
- Advertises only opaque `archiveId`, name, size, format/readiness and index status during registration/heartbeat.
- Adds a background protocol-2 archive query worker using `archive.read` / `archive.vfs.v1`, durable inbox cursors and correlated replies.
- Adds generic Archive VFS ZIP/ZIP64 info/tree/list/direct-read operations with nested `!` paths and cursor pagination.
- Adds streaming `JsonReader` conversation catalog and per-conversation retrieval for OpenAI-style exports without loading giant JSON arrays into memory.
- Enforces 512 KiB response ceiling, 256 KiB text windows, bounded message/tree counts, provenance and machine-readable errors.

## Validation boundary
The archive engine deliberately does not perform full archive extraction or 7 GB transfer. GitHub Actions remains the APK compile/sign gate; large-export acceptance is pending device testing.

# CLIENT CFv2.1.27 R17 / VC143 — INT-STREAM-BOOTSTRAP-120A

## One-body binary stream + localhost/tunnel benchmark parity

R17 pairs with SERVER R39 after R38/R16 live tests passed 1/10/100 MiB and isolated request-per-chunk overhead as the dominant remaining cost. The 100 MiB / 256 KiB test completed 400 chunks at ~1.01 MiB/s with average RTT 220.70 ms, while SERVER work averaged only 25.71 ms.

- Generic staged-file uploads prefer SERVER-advertised `DEVICE_BINARY_STREAM_V2`: one `application/octet-stream` request carries the remaining file from a bounded file reader instead of creating a whole-file byte array or issuing hundreds of HTTP requests.
- The loopback benchmark now uses one payload HTTP request when R39 streaming is available. The 4/64/256 KiB selector becomes the CLIENT writer buffer size; older SERVER builds retain binary-chunk/Base64 fallback.
- Benchmark summaries record transport, payload request count, CLIENT buffer count, stream/request RTT, SERVER time, outside-SERVER time, fsync count, presence timing and `/start` timing so localhost and tunnel/plugin acceptance can be compared directly.
- Streaming requests receive a long bounded wall-clock budget while retaining a 120-second idle socket timeout, avoiding the generic 60-second request cutoff for legitimate large/tunnel transfers.
- R16 proof-aware heartbeat/rebind recovery, SERVER trust/admin authority, staged SHA verification, resumable fallback, offline-first behavior and Truth Firewall boundaries remain preserved.
- Parent: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R16` SHA-256 `2b3ffffc804c32b580d4b07d3c9b9f5d9f7498fb0f6ddef8ed16f8a5e7b69645`. Paired SERVER: R39 / VC162.
- Local Android compilation was attempted but could not begin because `services.gradle.org` is unreachable in this environment. GitHub Actions remains the compile/sign gate; tunnel speed acceptance remains external.

---

# CLIENT CFv2.1.27 R16 / VC142 — INT-TRUST-REINSTALL-119A

## Reinstall proof rebind + canonical node recovery

R16 pairs with SERVER R38 after R15/R37 evidence isolated a stale proof binding: heartbeat was fast, but Forge `/start` failed `PROOF_NOT_BOUND` and Core remained `NOT_ENROLLED / REGISTRATION_FAILED / DISCOVERY_ONLY`.

- Normal registration remains fail-closed; CLIENT attempts `proofRecovery=true` only after SERVER explicitly returns `PROOF_REBIND_REQUIRED` (or legacy `PROOF_MISMATCH`).
- The retry reuses the stable device recovery binding and current installation ID, then stores SERVER's canonical node ID on success.
- Transfer preflight recognizes proof-rebind-required state, performs the controlled registration recovery once, retries BUSY heartbeat, and only then proceeds to `/forge/uploads/start`.
- R15 timed/exportable benchmark diagnostics and R14 raw-binary streaming are preserved.
- SERVER remains authoritative for accepting the rebind and suspending/reapproving any prior admin authority.

# CLIENT CFv2.1.27 R15 / VC141 — INT-TRANSFER-PRESENCE-118A

## Timed presence recovery + zero-chunk diagnostics

R15 pairs with SERVER R37 after the matched R14/R36 localhost test still failed before transferring a single chunk.

- Heartbeat responses retain HTTP status, SERVER protocol code, and elapsed milliseconds.
- Transfer preflight automatically re-registers only when SERVER explicitly returns `NOT_REGISTERED`, then retries the BUSY heartbeat once; transport/auth/admin failures remain fail-closed and visible.
- Loopback NDJSON begins before presence preflight, so failures before `/forge/uploads/start` now leave a viewable/exportable CLIENT log.
- Benchmark results expose presence, registration-recovery and `/start` timing plus the exact failure stage.
- Benchmark status is isolated from generic/source-pair picker status so unrelated selection messages no longer overwrite the actual loopback failure.
- R14 raw-binary streaming, verified-transfer binary path, Dispatchers.IO boundaries, SHA verification, resumability and Base64 fallback are preserved.

# CLIENT CFv2.1.27 R14 / VC140 — INT-TRANSFER-STREAM-117A

- Replaces the preferred same-device CLIENT→SERVER payload path with authenticated raw-binary chunks while retaining the R13 JSON/Base64 route as compatibility fallback for older SERVER builds.
- Sends a proof-bound BUSY heartbeat before generic, loopback-benchmark, and canonical source-pair transfers so a stale presence lease fails or recovers in ~1.5 s instead of letting `/forge/uploads/start` sit until the 60 s request timeout.
- Generic uploads continue to stage once and hash once, then use SERVER-advertised binary chunk capability/path and resumable offsets; bounded retries preserve idempotent lost-response reconciliation.
- Canonical source+metadata transactions prefer `/v1/transfers/chunks/write-binary` with raw bytes and exact per-chunk SHA-256; 404/405 against an older SERVER transparently falls back to the verified Base64 route.
- Public transfer entry points and blocking content/file work are constrained to `Dispatchers.IO`; large files remain chunked/streamed rather than loaded into one whole-file byte array.
- Forge → SERVER benchmark is relabeled `LOCAL STREAM TRANSFER BENCHMARK` and measures `/start → raw binary chunks → commit` on `127.0.0.1:8787`, with transport-aware NDJSON evidence.
- Preserves R13 staging/retry/abort behavior, SERVER verification authority, explicit Forge approval/dispatch boundaries, offline-first behavior, Truth Firewall, and stable-signing workflow expectations.
- Parent source: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R13` SHA-256 `e2cba3996cd45c123e7b90e09d005f2b36504373a3a8a60dbc9e906e054a64c1`. Paired SERVER: R36 / VC159.
- Source/static candidate; Android compile was attempted locally but the Gradle 8.7 distribution could not be fetched in this offline workspace. APK/device acceptance remains the next GDrive→Forge/GitHub test.

---

# CLIENT CFv2.1.27 R9 — INT-FIX-TRANSFER-FORGE-096A

- Adds a `⇅ SERVER` Forge mode for registered CLIENT→SERVER transfers.
- Adds arbitrary-file resumable upload through SERVER `/forge/uploads/*` with CLIENT node proof and SHA verification.
- Adds canonical CLIENT/SERVER source ZIP + matching `_METADATA.zip` prevalidation and SERVER verified-transfer submission.
- Adds approval-gated Auto Forge STAGE requests after SERVER verifies the pair.
- Advertises transfer/stage capabilities but deliberately excludes `forge.auto.approve` and `forge.auto.dispatch`.
- Preserves offline-first behavior, Truth Firewall, identity/trust and protocol discipline.
- Source/static checkpoint only; no APK build/install, workflow dispatch, release or deployment.

---

# INT-FORGE-081A — Dragon Master Workshop and conveyor repair

- repaired malformed ForgeConveyorStateStore Kotlin braces;
- documented §wyrlz / §wyrlix / §wyrver identity roles;
- added Workshop Presence, Invitation Invocations, Dragon Master Theme Zero, §wyrlish, Heat, voice, Theme Anchors, Chronicle, and roadmap boundaries;
- preserved offline-first behavior, Truth Firewall, lineage, approval gates, and compatibility identifiers;
- no APK/build/install/release/deploy claim.

# CLIENT CFv2.1.27 Candidate R5 — Adaptive Forge Project Conveyor Foundation (2026-08-05)

- Adds the adaptive Forge Project Target and operating-mode contracts.
- Adds resumable approval-aware conveyor stages and need-based file-analysis specialist routing.
- Adds fact/inference/projection/recommendation findings, Architecture Genome snapshots, persistent local conveyor state, and thresholded Council review/event models.
- Preserves existing Forge transport, package identity, compatibility identifiers, offline-first behavior, Truth Firewall, and approval boundaries.
- Source/static foundation only; no build, notification dispatch, workflow, GitHub write, install, promotion, release, or deployment is claimed.

# CFv2.1.27 R2 — Forge Progress Truth (2026-08-05)

- Shows byte transfer, GitHub blob acceptance, repository finalization, and completion as separate phases.
- Prevents a 100% byte-send display from being interpreted as a completed repository transaction.
- Preserves 4 MiB resumable source chunking.

# INT-AI-074A — CLIENT CFv2.1.27 R1 / VC132

- Adds the byte-identical shared §wyrlz LLM protocol V1 contract.
- Routes default/explicit-local Chat to the paired §wyrlz LLM on §wyrlzer.
- Adds registered-node and encrypted device-proof headers to Core Node calls used by the new proof-bound route.
- Adds a strict CLIENT context allowlist: build identity, device/Android model, permission booleans, Core Node check state, interface/theme/chat preferences, and declared capabilities.
- Excludes URLs, pairing material, device proofs, credentials, message/file/clipboard content, fingerprints, and installed-app lists.
- Sends recent bounded Chat turns and the existing user response directive without changing mission/Forge/tool authority.
- Preserves explicit remote-provider routing and approval policy; local failure never silently becomes remote use.
- Applies visible `§wyrlz` identity to the app label and primary Chat/startup surfaces while retaining compatibility-sensitive ASCII identifiers.
- Advances Android source identity to VC132 / `2.1.27-swrlz-llm-client-bridge-r1`.
- Source/static candidate only; no Android compile, APK, device acceptance, workflow, GitHub write, promotion, release, deployment, or installation is claimed.

---

# INT-FIX-060C — CLIENT CFv2.1.26 R8 / VC131

- Pinned security-crypto 1.0.0 compatibility repair for encrypted device proof.
- Preserved protocol-2 messaging and proof semantics.
- Source-only; no APK build, install, GitHub write, promotion, release, or deployment.

# CFv2.1.24 R1 — INT-FORGE-042B

- Forge Transport V2: 4 MiB protected-source chunks, bounded transient per-blob retries, 401 auth/repository reprobe, verified resume, richer diagnostics.
- Repairs missing `@Composable` on `ChatSettingsChoiceGroup` from the CFv2.1.23 R1 build failure.

# CLIENT CFv2.1.23 — Modular Model Rack + Expression EQ Candidate R1

Checkpoint: `INT-AI-041F-A-R8`

- Parent is immutable CLIENT CFv2.1.22 R1, source ZIP SHA `49284e9a57d30a2b37912c32ac9a85fbb333d4a6ed620687c855469363d0ecd5`.
- Advances Android candidate identity to versionCode `121` / versionName `2.1.23-modular-model-rack-expression-eq-candidate-r1`.
- Adds Brain & AI → Model Rack & Expression EQ with SERVER GGUF selection, Speed, truthful Reasoning Depth, context/output and nine EQ sliders.
- Adds module state/toggles plus profile/model rollback.
- Sends generation-checked requests through the existing registered Core Node identity, action-phone role and pairing token; SERVER remains authoritative.
- Displays exact optimized-base recognition and the immutable Truth Firewall/permission/approval/provenance/trust/mission/Forge/execution boundary.
- Paired static/model-identity verification passes `36/36`; Android compilation did not begin because Gradle 8.7 was unavailable.
- No GGUF bytes, APK/device/install/GitHub/workflow/promotion/publication/release/deployment result is included or claimed.

---

# CLIENT CFv2.1.22 — Update Ledger + Settings/Theme Identity Candidate R1

Checkpoint: `INT-UX-039Q`

- Parent: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R2.zip` at SHA-256 `c4eb68554bc3c5bf95a0599c42da782ad3b948331cab3b08229eb73c3a9b089b`.
- Advances Android identity to versionCode `120` / versionName `2.1.22-update-ledger-settings-theme-identity-candidate-r1`.
- Header Kapanion opens a local evidence-aware Update Ledger with version rail and detailed notes.
- Chat can locally summarize latest notes, answer version-specific patch questions, and compare updates; `/updates (latest|ask|compare)` is registered.
- CLIENT tabs and nested Settings pages now consume Back only while there is an application level to pop.
- Settings nests Brain & AI under Chat & Commands and Messages & Bubble under Activity & Notifications.
- SWRLZ-owned bubble/shortcut artwork gains complementary role tinting while launcher identity remains unchanged.
- Android/SystemUI-added app badges remain system-owned; full multi-theme rescue restoration is deferred.
- INT-CMD-039P-R3 and INT-FILE-039M execution are not included.
- Source/static candidate only; no APK/workflow/GitHub promotion/release/deployment/install claimed.

---

# CLIENT CFv2.1.21 — Parent/Child Command Grammar + Chat Anchor Candidate R2

Checkpoint: `INT-CMD-039P-R2`

- Parent: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R1.zip`.
- Keeps versionCode `119` and advances immutable candidate identity/versionName to `2.1.21-command-palette-parent-child-cursor-follow-candidate-r2`.
- Makes `/parent (child) [instructions]` the preferred visible Chat command grammar.
- Rebuilds palette hierarchy around action/subcommand meaning rather than raw dotted-ID order; shared actions expose a selector only when required.
- Registers generic `/files (scan)`, `/files (organize)`, `/files (duplicates)`, `/files (undo)`, and `/files (keep-organized)` prefixes while keeping 039M backing capabilities truthfully `PLANNED`.
- Preserves legacy tokenized command forms as resolver/search aliases.
- Command insertion now uses structured command text and the composer explicitly places the cursor at the end of externally inserted text.
- Response-top following now reserves a full conversation viewport of trailing scroll space and reasserts a zero-offset item anchor after animation, fixing short responses that previously stopped slightly below the top.
- Source/static verification only in this checkpoint; no APK/workflow/GitHub promotion/release/deployment/install claimed.

---

# CLIENT CFv2.1.21 — Hierarchical Chat Command Palette Candidate R1

Checkpoint: `INT-CMD-039P`

- Advances Android identity to versionCode `119` / versionName `2.1.21-command-palette-hierarchy-capability-registry-candidate-r1`.
- Upgrades the existing Chat Command Center from flat command discovery to data-driven category → subcommand navigation.
- Adds canonical slash syntax such as `/forge client latest` plus typed exact resolution and ranked suggestions.
- Adds visible approval/availability metadata, local pins/recents, and Chat-context recommendations.
- Preserves insert-for-review semantics; the palette does not become a parallel capability executor.
- Registers approved 039M organizer vocabulary as `PLANNED` only.
- Marks commercial-provider entries configuration-required/sensitive without enabling them.
- Source/static validation passes; Android compile-only attempt was blocked before compilation because Gradle 8.7 was unavailable and services.gradle.org was unreachable.
- No APK/workflow/GitHub promotion/release/deployment/install claimed.

---

# CLIENT CFv2.1.20 — Forge Chunked Transport + Optional Evidence Candidate R1

Checkpoint: `INT-FORGE-039F + INT-FORGE-039N`

- Adds AUTO/DIRECT/CHUNKED protected-source transport.
- AUTO/CHUNKED use deterministic 8 MiB parts with per-chunk and whole-ZIP SHA-256.
- Adds retry reuse of already-created chunk Git blobs.
- Makes source ZIP the only required build input; checksum/manifest are optional evidence.
- Supplied conflicting evidence still blocks.
- Packages an unapplied repository CI patch for verified runner-temp reassembly.
- Android compile/build remains pending.

---

# CLIENT CFv2.1.19 — Adaptive Chat Workspace (candidate)

**Candidate v2 compile-evidence repair:** workflow `30306467282` reached `compileDebugKotlin` and exposed a missing `ExperimentalMaterial3Api` opt-in on the new provider-mesh bottom sheet. Candidate v2 adds the narrow opt-in plus a compile-sensitive Compose opt-in regression gate. Promotion remains blocked until the Android build is green.

Checkpoint: `INT-CHAT-039I`

- Conversation-first Chat layout with IME-aware chrome collapse.
- Compact/expandable Reasoning Mesh.
- Compact ThemePack/Kapanion composer and Command Center entry.
- Existing response-top follow preserved.
- Pure policy acceptance tests pass locally.
- Full Android compile/build is still required before Promotion Gate completion.

---

# CLIENT CFv2.1.18 — Forge Rescue Profile-Store Compile Repair

Checkpoint: `INT-FIX-039G`

- Repairs the `ClientProfileStore.resolveClientToServer` provider-profile expression that blocked `compileDebugKotlin` in workflow `30302109949`.
- Changes the incorrect function-symbol nullable access `providerProfileId?.let` to the declared `providerId?.let`.
- Audits SERVER CFv2.1.7 profile-store Kotlin; the corresponding SERVER paths are already correct, so SERVER remains unchanged.
- Preserves the CFv2.1.17 default-theme Forge rescue payload and GitHub credential/write-preflight repair.
- Source/static verification only; successful compilation remains pending the next authorized build/workflow.

---

# CLIENT CFv2.1.17 — Forge Rescue / Default-Theme Bootstrap

Checkpoint: `INT-FORGE-039E`

This source-only rescue successor is intentionally transport-light. It preserves the current CLIENT code lineage while exposing only the canonical default `Glitch Dragon Glass` ThemePack at runtime and removing optional ThemePack/ignition payloads from the package so the Forge uploader repair can itself be transported through older CLIENT builds.

## Forge repair

- Preflight now proves authentication, repository read, and `Contents: write` before a large transfer by creating a tiny unreferenced Git blob. The probe does not modify a branch/tree/file.
- A 401 during a later repository operation is no longer automatically interpreted as proof that the credential is revoked. Forge re-probes authentication and preserves the credential when the re-probe succeeds.
- 422 `input was too large` is classified as a transport-size failure, not an authentication failure.
- Sanitized GitHub request ID / accepted-permission evidence is included when supplied by GitHub.

## Temporary bootstrap theme boundary

- Runtime registry selectable set: `Glitch Dragon Glass` only.
- Alternate launcher aliases are removed from the bootstrap Android manifest.
- Optional theme progress, ignition, launcher, Kapanion, and legacy alternate identity artwork is omitted.
- The full declarative ThemePack definitions remain in source lineage for restoration; this bootstrap edition is not a design rollback.
- ThemePack authority/trust/protocol/mission semantics are unchanged.

## Evidence boundary

Source/static/package verification only. No Gradle build, APK, device acceptance, GitHub upload, workflow, commit, push, release, deployment, or installation is claimed.

---

# CLIENT CFv2.1.16 — Theme Progress Semantic Anchor Calibration

- Generalizes progress-track calibration through one ThemePack-aware runtime geometry resolver instead of a Jester-specific layout branch.
- Calibrates Jester Glitch Dragon's truthful 100% endpoint to the center of the right green emerald landmark (`89.5%` of outer frame width).
- Aligns the progress-head semantic center to the same determinate/indeterminate boundary used by fill and active clipping.
- Preserves existing ThemePack manifest v1 and CLIENT/SERVER shared-contract bytes; uncalibrated themes retain their declared dp geometry.
- Applies the Documentation Gate and records the older VC108 screenshot as valid defect evidence while repairing the current CFv2.1.15 lineage.
- Source-only; build/APK/workflow/device/repository publication/release/deployment/install success is not claimed.

---

# CLIENT CFv2.1.15 — Theme Ignition Family Completion

- Verifies the supplied ignition resource pack at SHA-256 `fc5e41188e429cf5b088f8da47ead713ba0e39849b75e79e6f5011e532d58c3c` and revalidates every entry in its root manifest.
- Preserves the existing Jester Glitch Dragon reference ignition.
- Adds complete eight-stage ignition assets to Dragon Kamileon, Jade, Frost, Crystal Cyber, and Inferno.
- Generalizes the runtime ignition renderer name from Jester-specific to theme-generic without changing readiness or timeline semantics.
- Extends ThemePack tests so all six supplied ignition families must declare all eight semantic startup roles.
- Updates runtime asset catalog, architecture docs, asset provenance, release notes, engineering log, source package note, and documentation impact set.
- Source-only; build/APK/workflow/device/repository publication/release/deployment/install success is not claimed.

---

# CLIENT CFv2.1.14 — Command Center + Package-Aware Forge

- Adds a theme-aware Chat Command Center with categorized search, favorites, and quick natural-language insertion.
- Adds CLIENT / SERVER / BOTH / FILES Forge targeting.
- Auto-resolves canonical SHA-256 and manifest companions for protected source ZIPs, with mismatch/blocking verification.
- Routes CLIENT and SERVER package units to their canonical source lanes and supports one transactional combo staging job when enabled.
- Adds package automation settings and destination previews; defaults preserve safe automatic pairing/routing.
- Establishes the standing Documentation Gate and records the full documentation impact set.
- Source-only; no build/APK/workflow/GitHub write/release/deployment/provider-call result is claimed.

---

# CLIENT CFv2.1.13 — Provider Mesh + Profile Library

- Adds shared provider-contract v1 and per-message `@gpt`, `@gemini`, `@both`/Council, Compare, and Local routing.
- Adds provider status/model controls to Chat and Chat Settings while preserving SWRLZ identity.
- Adds canonical latest CLIENT/SERVER source-analysis dispatch through SERVER sanitization.
- Adds STABLE/TEST/DRAFT profile lifecycle, favorites, duplication, and quick assignment/switching.
- Keeps automatic remote provider use off by default and does not add CLIENT OpenAI secret storage.
- Source-only; provider calls/build/APK/device/workflow/release are not claimed.

---

# CLIENT CFv2.1.12 — Distributed Profile Architecture

- Adds byte-aligned CLIENT/SERVER `profile-contract` v1.
- Adds CLIENT-local profile registry and assignments.
- Adds Chat & Commands → Profiles & Routing.
- Adds custom inherited endpoint/link/provider profiles.
- Applies the resolved Gemini provider profile to the existing private reasoning path.
- Preserves CFv2.1.11 chat flow/personality and all authority boundaries.

---

# CLIENT CFv2.1.11 — Chat Control Center + Response-Top Follow

- Expands Settings → Chat & Commands into Conversation Flow, Personality & Response, and Privacy & Context submenus.
- Adds persisted response-top vs legacy conversation-bottom follow targeting; response-top is the new default.
- Reserves trailing list extent so a new SWRLZ response can animate to the top of the viewport and grow downward.
- Manual upward scrolling detaches follow; ↓ LATEST and sending a new message re-arm it.
- Adds a persisted choice for whether runtime/Forge commentary automatically brings Chat forward.
- Adds SWRLZ-native base style, detail, warmth, energy, humor, formatting, and emoji preferences.
- Applies the profile to optional reasoning-provider prompts while preserving deterministic status/safety semantics.
- Adds normalization unit-test source for ChatSettings.
- Advances Android identity to versionCode `109` / versionName `2.1.11-chat-control-center-v1`.
- No SERVER, protocol, trust, Truth Firewall, permission, mission authority, Forge authority, repository authority, or offline-first change.
- Source-only checkpoint; build/APK/workflow/device/release/deployment/install success is not claimed.

---

# CLIENT CFv2.1.10 — Progress Layering + Clipping Repair

- Uses real-device CFv2.1.9 evidence to correct Jester progress containment.
- Enforces an artwork-calibrated Jester inner track so fill no longer begins beneath the large dragon cap or extends into the frame borders.
- Keeps ambient energy as a low-alpha full-track underlay.
- Reveals the full-width fill texture through the determinate/indeterminate active window instead of compressing texture geometry.
- Clips particles and highlight to the active progress window so motion does not stream past the progress head.
- Keeps the decorative frame above all streaming/fill layers and preserves truthful determinate, indeterminate, paused, reduced-motion, and terminal semantics.
- Advances Android identity to versionCode `108` / versionName `2.1.10-progress-layering-clipping-repair-v1`.
- Does not modify SERVER, ThemePack contract/assets, protocol, trust, permissions, missions, Forge authority, local/remote distinctions, or offline-first behavior.
- Source-only checkpoint; build, APK, workflow, repository publication, release, deployment, installation, and final device acceptance are not claimed.

---

# CLIENT CFv2.1.9 — Package Pair Repair

- Records failed Source Package Integrity run `30222384992` and APK Router run `30222384996`.
- Both workflows selected the correct CFv2.1.8 ZIP and checksum, then stopped before compilation because the sidecar manifest omitted the canonical `zip`, `size_bytes`, and `verified` fields.
- Preserves CFv2.1.8 theme, launcher, startup, progress, Kapanion, accessibility, protocol, trust, mission, Forge, and offline-first behavior.
- Advances Android identity to versionCode `107` / versionName `2.1.9-package-pair-repair-v1`.
- Reissues the immutable source package under `INT-THEME-035D` with a verifier-compatible manifest and preserved failed-lineage evidence.

---

# CLIENT CFv2.1.8 — Theme Chrome + Runtime Visual Repair

- Replaced the base Glitch Dragon launcher’s legacy foreground across application, adaptive, round, and density resources.
- Added declarative theme chrome motifs, semantic background/Kapanion/voice-core roles, bounded alpha/edge settings, and progress track geometry.
- Completed distinct identity mappings for all selectable CLIENT themes; Teal Serpent remains explicitly partial and uses its own emblem.
- Replaced the hard-coded Glitch Dragon shell art with selected ThemePack backgrounds, Kapanions, motif fields, border ornaments, shapes, and motion.
- Added selected Kapanions to the header, tap-to-speak core, companion rail, assistant chat bubbles, and live preview.
- Clipped progress fill/head/ambient/particles/highlight to one calibrated track and retained truthful determinate, indeterminate, paused, and terminal semantics.
- Staged Jester Core Ignition core states and bounded its spark/radial/particle/shockwave/residual effects.
- Advanced Android identity to versionCode `106` / versionName `2.1.8-theme-chrome-runtime-repair-v1`.
- No SERVER, protocol, trust, mission, permission, Forge authority, build, APK, workflow, release, or deployment change is claimed.

---

# CLIENT CFv2.1.7 — Theme Progress Compose Scope Repair

- Records GitHub Actions run `30216145763`: resolver tests passed 6/6, CLIENT source/checksum verification passed, then Kotlin compilation failed at `ThemedProgress.kt:175` and `:190` because nested `Box` scopes could not implicitly resolve `BoxWithConstraints.maxWidth`.
- Captures the outer width as `availableWidth` and uses it for both nested fill images.
- Preserves ThemePack contracts/assets, truthful semantic progress, reduced motion, protocol, trust, missions, permissions, Forge, and offline-first behavior.
- Advances Android identity to versionCode `105` / versionName `2.1.7-theme-progress-compose-scope-repair-v1`.
- Static verification passed; new Gradle/APK/device verification remains pending separate authorization.

---

# CLIENT CFv2.1.6 — ThemePack Engine

- Added one byte-identical declarative ThemePack contract shared with SERVER.
- Preserved six legacy Theme Armor identities and added seven asset-derived built-ins.
- Added independent stable-ID persistence, staged settings preview, launcher/Kapanion identity, Jester Core Ignition, and semantic layered progress.
- Added reduced-motion, TalkBack, truthful indeterminate/terminal state, and bounded WebP asset handling.
- Added manifest v1 validation and reserved custom-theme UI without exposing an unsupported importer.
- Advanced Android identity to versionCode 104 / versionName `2.1.6-theme-pack-engine-v1`.
- Static source integrity passed; Gradle/APK/device/GitHub verification remains pending.

---

# CFv2.1.4 — Forge + Repository Console

- Split Forge into FORGE and REPOSITORY action modes.
- Added live GitHub Actions discovery, dispatch input forms, manual run, cancel, and re-run.
- Added branch-aware repository browser with create/edit/upload/download and atomic move/rename/delete.
- Moved persistent Forge preferences to Settings → Forge.
- Changed identical repository uploads from failure to verified successful no-op.

# CFv2.1.3 — Settings Control Center

- Searchable domain-based Settings hub.
- Mission-start approval policy with Always ask dialog enforcement.
- Chat auto-follow preference with scroll-detach and ↓ LATEST recovery.
- Settings entry points for Core/connection, Chat, Missions, Activity, Forge, Interface/Bubble, Brain/AI, Privacy/Security, and Developer/Diagnostics.

# CFv2.1.2 — Repository Bootstrap Forge

- Default Forge routing moved to `kamiswrlzco-cloud/Swrlzco` + `swrlz-core/...` lanes.
- Added repository-root ZIP expansion with optional outer-ZIP removal.
- Added chat bootstrap intent and chat expansion/removal toggles.
- Added Forge repository tools: browse, read/write text, delete file with confirmation, and create branch.
- Added archive path/size safety gates before repository expansion.

# CLIENT CFv2.0.69 — Chat + Mission Runtime Cohesion

- Grounded Gemini/GitHub/accessibility status queries in authoritative runtime state.
- Added contextual mission handoff for follow-up requests such as “do that as a mission.”
- Added Gemini-backed structured mission planning when Online Mentor is absent.
- Mission completion can return to CLIENT and publish gathered results into Chat.
- Added Forge chat milestone narration and first-class cancellation state/control.
- Added animated complementary-color dragon companion/status rail foundation.

## 2.0.66
- Snapshot-bound accessibility targets with fail-closed live-node validation.

# CLIENT CFv2.0.64 — Credential Lifecycle and Upload Preflight

- Added token normalization and exact credential preflight before source streaming.
- Added GitHub App access/refresh token lifecycle persistence and refresh.
- Added one refresh-and-retry path for a 401 during transfer.
- Retires explicitly rejected credentials instead of reusing them.
- Preserves CFv2.0.63 generated checksum receipts, launcher/theme identity, and Forge reliability.

---

## CFv2.0.63 — Generated checksum receipt

- Generates and stages an exact `<base>.sha256` receipt when Android withholds sibling URI access.
- Eliminates the normal-path `LOCATE SHA-256` requirement.
- Retains independent repository-side digest verification.
- Advances Android identity to versionCode 90 / versionName `2.0.63-generated-checksum-receipt-v1`.

## CFv2.0.62 — Manual token validation state repair

- Separates unverified fine-grained token text from the active validated runtime token.
- Prevents the token-entry form from disappearing after the first typed character.
- Stops automatic validation from running against partial manual input.
- Saves and publishes a token only after GitHub `/user` validation succeeds.
- Keeps invalid input editable without replacing the active session.
- Advances Android identity to versionCode 89 / versionName `2.0.62-manual-token-validation-state-v1`.

## CFv2.0.61 — Automatic same-directory checksum resolution

- Preserves the device-verified repeated-upload and upload-success notification behavior.
- Derives the exact `<base>.sha256` name from a selected `<base>.zip`.
- Adds provider-safe lookup through direct document IDs, parent child enumeration, and Android 10+ MediaStore relative directories.
- Stops opening a second file browser automatically when a provider denies sibling access.
- Adds an explicit `LOCATE SHA-256` fallback beside unmatched staged ZIPs.
- Advances Android identity to versionCode 88 / versionName `2.0.61-automatic-sibling-checksum-v1`.

## CFv2.0.60 — Theme connector continuity and collapsible Forge panels

- Records successful GitHub compilation of CLIENT CFv2.0.58.
- Prevents a launcher/theme task refresh from presenting a false disconnected GitHub account while the saved Keystore token is validating.
- Hides redundant OAuth/device-code controls whenever a saved token exists.
- Keeps temporary verification failure non-destructive.
- Makes Repository Target and Source Package Matching collapsible and persists their state.
- Advances Android identity to versionCode 87 / versionName `2.0.60-theme-connector-collapse-v1`.

## CFv2.0.59 — Build preflight alignment

- Aligned `org.jetbrains.kotlin.android`, `org.jetbrains.kotlin.plugin.serialization`, and `org.jetbrains.kotlin.plugin.compose` at version `2.0.0`.
- Preserved the CFv2.0.58 Forge log repair, CLIENT actor evidence, Dragon Kamileon Theme Armor, connector continuity, and bubble/main version surfaces.
- Advanced Android identity to versionCode 86 / versionName `2.0.59-build-preflight-alignment-v1`.
- Package/static verification complete; GitHub compilation and device acceptance remain pending.

## CFv2.0.58 — Dragon Kamileon and Forge log build repair

- Fixed the CFv2.0.57 `ForgeUploadLogStore` unresolved SharedPreferences receiver.
- Added `SWRLZ-Forge-Actor: CLIENT` to atomic Forge commits and `forge_actor` to diagnostics.
- Added selectable Dragon Kamileon Theme Armor with iridescent interface tokens.
- Added dedicated Kamileon launcher, adaptive, CLIENT, SERVER-context, and fusion bubble assets.
- Advanced Android identity to versionCode 85 / versionName `2.0.58-kamileon-theme-forge-log-buildfix-v1`.

## CFv2.0.57 — Forge live logs and durable GitHub connection

- Added a redacted append-only Forge upload log from source selection through terminal outcome.
- Added live/latest upload-log export during staging, active transfer, retry, failure, and success.
- Logged SHA matching, ZIP/pair validation, transfer checkpoints, blobs, trees, commits, branch confirmation, uploaded-path verification, workflow discovery, and exceptions.
- Persisted OAuth client ID, repository target, connected login, and auto-connect intent outside the Keystore secret file.
- Added secure-transport-gated Android backup/device-transfer restoration that re-imports the GitHub token into the fresh install's Keystore and validates it before reconnecting.
- Added an approval dialog before disconnecting and clearing connector identity/restore state.
- Advanced Android identity to versionCode 84 / versionName `2.0.57-forge-live-logs-connector-restore-v1`.

## CLIENT CFv2.0.56 — Forge observer, themed identity, version footer, and build repair

- Fixed `ForgeBuildWatchStore` compilation by applying `takeLast` to a list rather than a Set.
- Added immediate post-upload workflow discovery and 2-second active polling.
- Added active-first workflow display with configurable completed history and duplicate-card collapse.
- Added CLIENT CF/versionCode footers to main User and Developer interfaces.
- Rebuilt theme launcher assets from the current crystal-dragon art and synchronized all bubble roles with Theme Armor.
- Advanced Android identity to versionCode 83 / versionName `2.0.56-forge-observer-identity-footer-buildfix-v1`.

# Changelog

## CLIENT CFv2.0.55 — Forge repeat-upload truth, event notifications, and same-location SHA matching

- Added a fresh UUID correlation identity to every upload attempt, including validation failures.
- Snapshot staged files at commit press so later UI selection changes cannot mutate an active transaction.
- Upload blobs first, resolve the latest branch head afterward, and retry non-fast-forward branch races up to three times.
- Reject no-op trees explicitly instead of replaying a false success animation.
- Confirm the target branch points to the new commit and verify every uploaded repository path resolves to the expected blob SHA before clearing staging.
- Separate repository-upload success from workflow-dispatch failure; a dispatch error can no longer erase a verified commit result.
- Added Android and CLIENT-bubble events for upload success/failure, workflow-dispatch failure, and artifact-build success/failure.
- Persist up to twelve pending commit watches so later CLIENT/SERVER uploads do not replace earlier build notifications.
- Added background build-result polling to the existing CLIENT status service while notification status is enabled.
- Added a compact latest Forge-event banner inside the CLIENT bubble interface.
- Removed the separate source-folder tree grant from checksum matching.
- Added best-effort exact sibling lookup from the selected ZIP URI with a same-location document-picker fallback when Android blocks direct sibling access.
- Advanced Android identity to versionCode 82 / versionName `2.0.55-forge-repeat-notifications-sibling-v1`.

# CLIENT CFv2.0.53

- Added the first separate SWRLZ CLIENT bubble interface overhaul.
- Replaced the default light Material panel with the saved SWRLZ theme and a compact crystal cockpit.
- Added full navigation labels, icons, responsive crystal tiles, truthful CLIENT/SERVER-link status, and an Open Full Client action.
- Kept CLIENT identity independent instead of visually morphing into SWURVER when a SERVER session exists.
- Added an always-visible `CLIENT · CFv2.0.53` footer derived from `BuildConfig.VERSION_NAME`.
- Corrected stale Android/source identity fields inherited by the CFv2.0.52 archive.
- Reserved the fusion interface for a later pass after CLIENT and SERVER surfaces are accepted.
- Advanced Android identity to versionCode 80 / versionName `2.0.53-client-bubble-interface-v1`.

# CLIENT CFv2.0.52

- Added authoritative Forge phase projection in the CLIENT top bar.
- Added persisted Source ZIP Content Guard with pre-network APK/artifact rejection and source-structure heuristics.
- Preserved exact ZIP/SHA-256 validation and truthful phase-based workflow reporting.

# CLIENT CFv2.0.41 — Native Bubble Admin Morph

## CFv2.0.52
- Removed six unused CLIENT launcher/fusion resource artifacts.
- Preserved all launcher identity resources still referenced by aliases and ThemeIdentityManager.
- Added a conservative resource audit utility and checkpoint documentation.
- Advanced CLIENT build identity to versionCode 79.


- Replaced the experimental three-overlay dock with one Android-managed conversation bubble.
- Corrected identity mapping: SWRLZ Client = cyan/blue; SWURLZER Server = purple; authenticated fusion = SWURVER.
- Added verified-admin-driven bubble identity morphing.
- Prevented bubble taps from spawning separate CLIENT/SERVER/FUSION activity windows.
- Removed excess light padding from bubble avatar resources.

# CLIENT CFv2.0.40

- Added GitHub Forge mass routing for CLIENT and SERVER source packages.
- Added workflow-run observation and Actions artifact download/save support.
- Preserved encrypted GitHub authentication and atomic multi-file commits.

# Changelog

## CFv2.0.32 — Bubble build correction
- Corrected `LocusId` to use the public `android.content.LocusId` API.
- Removed the incompatible explicit Compose `weight` import from the Client bubble activity.
- Advanced Android `versionCode` to 61.
- Added `docs/implementation/INT_CHAT_032D_BUBBLE_BUILD_CORRECTION.md`.

## CFv2.0.31 — Persistent Client notification surface

- Added `ClientStatusService` so Client status remains available outside `MainActivity`.
- Added live notification updates for server connection, endpoint, mission, session evidence, and theme.
- Added a notification-permission guard before foreground startup.
- Introduced a fresh status channel ID to recover from retained legacy channel configuration.
- Kept the Client status notification separate from the Floating Dragon conversation bubble.
- Added `docs/implementation/INT_NOTIFY_034B_PERSISTENT_CLIENT_STATUS_SERVICE.md`.

## CFv2.0.30 — Client status notification recovery

- Requests Android 13+ notification permission on first launch when missing.
- Adds notification permission state and recovery controls to the Permission Centre.
- Republishes the persistent Client status notification after permission approval.
- Keeps server connection, endpoint, mission, and theme details in the expanded notification.
- Documents notification-channel and user-controlled permission limitations.

## CLIENT CFv2.0.30 — Client notification status recovery

- Restored the persistent Client status notification using a fresh Android notification channel.
- Raised the status channel from low to default importance while retaining update-only alert behavior.
- Added an Android 13+ notification permission guard.
- Decoupled the Client status widget from the Floating Dragon bubble lifecycle.
- Added `INT_NOTIFY_034A_CLIENT_STATUS_NOTIFICATION_RECOVERY.md`.

## Unreleased

- Added themed Floating Dragon bubble UI and hardened Android conversation registration.
- Bubble settings now register the conversation before opening system settings.

## Permission priority, live node status, and explicit bubble controls

- Moved the sideloaded-app restricted-settings guide to the top of the Client Permission Centre.
- Added authoritative online/offline/registered node totals to the Server notification.
- Added explicit Client server-connection evidence to its notification.
- Added manual Floating Dragon launch and Android bubble-settings controls.
- Connected the Client telemetry side puck and strip to Floating Dragon.
- Corrected the Server bubble namespace and connected it to live runtime/node state.
- Documented the release in ADR-0022 and INT-UX-033A.

## Floating Dragon bubble release

## Floating Dragon build correction

- Corrected AndroidX conversation Person and IconCompat usage.
- Corrected client permission-route compilation.
- Removed fragile server generated-class dependencies from the bubble feature.


- Added Android-native conversation bubbles for compact SWRLZ chat and mission/server status.
- Added dedicated resizeable bubble activities and long-lived conversation shortcuts.
- Preserved full-app authority for sensitive actions.
- Documented phased chat transport boundaries in ADR-0021.

# Changelog

## INT-UX-031A

- Moved Accept All to the client first-mission acknowledgement screen.
- Restored the Android permission centre workflow.
- Added default-on, theme-aware client/server notification status widgets.
- Preserved Android's mandatory server foreground-service notification.

# CLIENT CFv2.0.23 (2026-07-23)

- Protocol v2 device continuity registration.
- Raw ANDROID_ID removed from registration payload.
- Canonical SERVER node ID retained for subsequent presence calls.

# CLIENT CFv2.0.22 — INT-UI-028D

- Added a SERVER-authoritative group overview to the Core session card.
- Shows group role plus online-versus-active device counts.
- Supports zero, one, and multiple group memberships with truthful unavailable states.
- Added tap-through navigation to the dedicated Groups workspace.
- Advanced Android identity to versionCode 51 and versionName `0.2.7.26-cfv2.0.22-int-ui-028d`.
- Source-only package; no build or runtime verification performed.

# CLIENT CFv2.0.18 — INT-FIX-026E

- Replaced the invalid `tokens.status.error` reference with canonical `tokens.status.danger`.
- Advanced Android identity to `versionCode` 47 and `versionName` `0.2.7.22-cfv2.0.18-int-fix-026e`.
- Recorded the CLIENT CFv2.0.17 GitHub compilation failure and the user-reported SERVER CFv2.0.17 build success.
- Preserved all group, heartbeat, trust, identity, offline-first, lineage, and Truth Firewall behavior.
- Source-only package; compilation and runtime verification were not run.

# CLIENT CFv2.0.17 — INT-FIX-026C

- Repaired SERVER group-list dispatch.
- Added canonical role, membership-state, leader, and member-count data.
- Added live roster retrieval and readable CLIENT synchronization errors.
- Prevented failed group requests from being labeled synchronized.

# INT-UX-026A — Navigation and Groups Workspace

- Added horizontally swipeable bottom navigation.
- Added a dedicated Groups destination.
- Added richer group creation, join, inspection, synchronization, and assignment UI while preserving SERVER authority.
- Advanced package identity to CFv2.0.16.
- No APK build or runtime verification was performed.

# CLIENT CFv2.0.15

- Completed visible group-management dialogs, lists, assignment controls, and immediate post-mutation refresh.
- Corrected prior foundation-only UI claims.

# Changelog

## CLIENT CFv2.0.14
### Added
- SERVER-authoritative heartbeat lease metadata and tolerant liveness states.
- Repository checkpoint, ADR, and protocol-history documentation.
- Visible group controls on CLIENT / node detail and Mission Council foundations on SERVER as applicable.

### Changed
- Administrative disconnect now prevents silent immediate reconnection.
- Connection status progresses through delayed and unavailable states before inferred disconnection.

### Preserved
- Offline-first behavior, Truth Firewall, identity lineage, trust gates, SERVER canonical group ownership, and protocol v1 compatibility.

## CLIENT CFv2.0.19 — INT-FIX-027D

- Sanitized nested SERVER discovery errors in the Groups workspace.
- Preserved raw response payloads for developer diagnostics while removing raw JSON from user-facing status text.
- Classified unsupported Groups routes as a CLIENT/SERVER compatibility condition.
- Disabled group creation and join submission until authoritative group synchronization succeeds.
- Confirmed SERVER CFv2.0.17 already exposes the canonical `/v1/groups/*` route set; no SERVER source change was required.
## CFv2.0.24
- Installable-update version bump, permission onboarding, and guided Accept All flow.
## CLIENT CFv2.0.38 — GitHub Forge
- Added More → GitHub Forge for multi-file Android document selection.
- Added atomic Git Data API commits that bypass the 25 MiB website uploader.
- Added encrypted fine-grained GitHub token storage.
- Added optional workflow_dispatch after a successful commit.


## CLIENT CFv2.0.39 — GitHub Device Authorization

- Added GitHub browser sign-in through the OAuth Device Authorization Flow.
- Added encrypted OAuth Client ID and access-token persistence.
- Added connected-account verification through `GET /user`.
- Added disconnect and manual fine-grained-token fallback controls.
- GitHub Forge upload controls remain locked until authentication succeeds.
- Multi-file atomic commit and optional workflow dispatch remain preserved.

## CLIENT CFv2.0.65 — Finish-Line Cohesion
- Added canonical handling for Android download-copy suffixes such as ` (1)`.
- Added Forge directly to the CLIENT bubble.
- Synchronized GitHub credential state between full CLIENT and bubble surfaces.
- Preserved content-based source validation and canonical ZIP/SHA repository pairing.

## CLIENT CFv2.0.70 — Forge Chat Diagnostics
- Added `Upload from Forge officially Swurlzed!` after confirmed repository upload.
- Added workflow-start and workflow-success chat announcements scoped to the upload commit SHA.
- Added redaction-safe upload-log analysis on Forge failures.
- Added workflow job/step + GitHub log archive analysis on workflow failures.
- Added evidence / likely-cause / recommended-next-step separation to failure feedback.
- Routed Forge milestone narration through the shared ChatRuntimeBus while retaining high-frequency progress inside the live Forge card.
- Advanced Android identity to `versionCode` 96 and `versionName` `2.0.70-forge-chat-diagnostics-v1`.
- GitHub Android compilation and device acceptance remain authoritative release gates.

## CLIENT CFv2.0.71 — Forge STOP Build Fix
- Repaired the CFv2.0.70 Kotlin compilation failure in `ClientShellScreen.kt` by using the canonical `tokens.status.danger` field for the STOP FORGE control.
- Preserved CFv2.0.70 Forge chat diagnostics, upload/workflow narration, cancellation semantics, failure analysis, Gemini/provider routing, mission/chat bridge, and companion work unchanged.
- Advanced Android identity to `versionCode` 97 and `versionName` `2.0.71-forge-stop-buildfix-v1`.
- GitHub Android compilation and device acceptance remain authoritative release gates.


## CLIENT CFv2.0.72 — 2026-07-25
- Mission stop/pause/resume intents are handled locally before Gemini.
- Added Volume Up + Volume Down hold-to-pause safety chord.
- Added Mission HUD STOP control and automatic execution-time collapse.
- Bubble-launched missions collapse the expanded bubble before device execution.
- Fixed chat dragon companion rendering and retained complementary theme treatment.
- Added context-aware Gemini connection offer and secure key entry dialog.
## INT-FORGE-064B-CLIENT-R4 — CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R4

- Adds project-root package discovery and genuine CLIENT/SERVER/BOTH auto-detection.
- Selects the newest valid source package by verified versionCode/revision and rejects equal-rank hash conflicts.
- Supports two-file metadata pairs and three-file legacy triples.
- Stages matching checkpoint evidence and performs scan-stage-upload from one explicit action.
- Reconciles transient GitHub 5xx outcomes and reuses unresolved transaction IDs to prevent duplicate commits.
- Gives authoritative workflow success precedence over stale local failure presentation.
- Advances CLIENT to VC127. Source-only; Android workflow compilation is pending.

## CLIENT CFv2.1.27 Candidate R3 — INT-DOC-077A
- Reconciled current continuity against CLIENT R2 and SERVER R4 parent baselines.
- Added standardized §wyrlz Checkpoint Documentation skill and approval-gate response structure.
- Preserved runtime source and Android identity unchanged; source-only documentation successor.

## CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R4 — INT-FIX-078A
- Repairs the metadata manifest contract for Forge strict parsing and automatic source/archive companion selection.
- Adds canonical `sourceZip.filename`, `sourceZip.sha256`, and `sourceZip.sizeBytes` fields with required component, versionCode, revision, and verified identity.
- Keeps runtime and Android identity unchanged; source-only package successor.


## INT-FORGE-082A

- Added duplicate-aware Forge source routing and exact component workflow dispatch.
- Removed unrelated-run fallback from component build monitoring.
- Preserved source-only, approval-gated, offline-first, Truth Firewall, and lineage boundaries.

## CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R13 — INT-FIX-FORGE-FIRST-CHUNK-114A

- Repairs a device-observed generic Forge upload stall where SERVER created the upload session but received `0` bytes and `0` chunks.
- Stages the selected content URI once into app-private cache before opening the SERVER session and computes SHA-256 from those staged bytes.
- Reduces generic JSON/base64 chunks from 256 KiB to 64 KiB and adds three bounded attempts per chunk with lost-acknowledgement `nextOffset` reconciliation.
- Adds best-effort authenticated upload abort on fatal post-start failures; SERVER R33 compatibility is preserved when that route is unavailable.
- Deletes temporary staged bytes on all completion/failure paths.
- Advances CLIENT Android identity to versionCode `139` and versionName `2.1.27-forge-first-chunk-r13`.
- GitHub workflow/signing infrastructure is intentionally outside this checkpoint.

## CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R61 — INT-ARCHIVE-REPACK-DEBUG-ADMIN-LOG-152B

- Adds exact selected-entry archive repack into a new verified destination ZIP while preserving the source archive unchanged.
- Adds opt-in full SWRLZ runtime diagnostic tracing with centralized credential redaction and no unrestricted private reasoning capture.
- Adds read-only `logs.read` CLIENT capability and `swrlz-log-query-v1` execution in the reserved safety lane.
- Admin tunnel log export exposes only registered diagnostic stores through opaque IDs and 192 KiB verified chunks; absolute app-private paths remain hidden.
- Advances CLIENT identity to VC187 / `2.1.27-selected-repack-debug-admin-log-pull-r61`.

## CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R63 — INT-FORGE-LIVE-INBOX-AUTOSELECT-154A

- Repairs stale Forge auto-selection when newer CLIENT/SERVER source + metadata bundles arrive in Downloads while Forge remains composed or resumes from ChatGPT.
- Adds a lightweight 2-second Downloads candidate fingerprint watcher; package bodies are not re-hashed unless the candidate set changes.
- Keeps full uncached SHA-256 revalidation immediately before upload.
- Blocks silent fallback to an older revision when a newer-looking source is present but fails metadata/hash verification; the rejection reason is surfaced to the operator.
- Preserves R62 LALM fair-queue/stress lifecycle behavior and all R61 archive/log capabilities.
- Advances CLIENT identity to VC189 / `2.1.27-forge-live-inbox-autoselect-r63`.
