# INT-AI-SWRLZX-010A — LALM Real-Model Bring-Up Implementation Report

## Result

Checkpoint 010A establishes **LALM = Local Adaptive Language Model** as the canonical SWRLZ-native model-family identity without renaming or erasing the upstream/source **LFM/LFM2.5** provenance.

Canonical target identity:

- model ID: `swrlz-lalm-001a`
- display name: `SWRLZ-LALM-001A`
- branded artifact: `SWRLZ-LALM-001A.§wyrlzx`
- machine-safe alias: `SWRLZ-LALM-001A.swrlzx`
- identity contract: `swrlzx.lalm.identity.v1`

Pinned source identity:

- source artifact: `SWRLZ-LFM-OPT-001A.gguf`
- source family: `LFM`
- source architecture: `lfm2` / `LFM2.5`
- source size: `229315680` bytes
- source SHA-256: `651cd5c40e4ef24de2ff12c2b53b257d15816ddd4346e2575e6768a6ec1d8590`

## Implemented

1. Added a shared Kotlin LALM identity + bring-up receipt contract.
2. Extended the bounded 002A GGUF converter with an opt-in `--lalm-010a` profile.
3. The 010A profile fails closed unless source filename, byte size, SHA-256 and `lfm2` architecture all match the pinned source contract.
4. The canonical model ID/display name cannot be overridden in 010A mode.
5. Added a deterministic two-pass `swrlzx_lalm_010a_bringup.py` runner. A canonical target is committed only when both target SHA-256 values match and tensor data remains byte-identical to the source GGUF tensor-data region.
6. Bring-up receipts always record `productionPromotionPerformed=false`, `runtimeSwitchPerformed=false` and native execution parity `PENDING` at this checkpoint.
7. Model Vault rejects partial/spoofed claims of the canonical LALM identity unless manifest + lineage preserve the pinned source contract.
8. Model selection prefers LALM among already-proven native candidates but does not relax READY/parity/evolution-selection gates.
9. Model-folder discovery prefers branded LALM, then machine-safe LALM, then the exact source GGUF.
10. Added read-only LALM bring-up phases: SOURCE_MISSING → SOURCE_READY → TARGET_IMPORTED → TARGET_PARITY_PROVEN → TARGET_SELECTED.
11. Model Rack and CLIENT/SERVER UI now distinguish native LALM identity from LFM source provenance.
12. GGUF emergency compatibility is explicitly bounded through 014A while physical conversion/parity/device/promotion gates are completed.
13. Extended the SWRLZX roadmap with Phase-II checkpoints 010A–014A.

## Verification

- SERVER focused verifier: `41/41 PASS`.
- CLIENT focused verifier: `37/37 PASS`.
- LALM Kotlin identity/receipt harness: `8/8 PASS`.
- Model Rack Kotlin identity harness: `6/6 PASS`.
- selection-policy Kotlin harness: `4/4 PASS`.
- default 002A converter regression: deterministic PASS.
- exact-size 229,315,680-byte synthetic preflight: deterministic generic conversion PASS twice; 010A exact-source gate correctly rejects wrong SHA; no canonical target is left behind.
- 009A advanced-runtime regression: `65/65 PASS`.
- Android Gradle project compilation was attempted but wrapper acquisition failed on `UnknownHostException: services.gradle.org` before project compilation.

## Exact-live-model boundary

The real 229 MB GGUF bytes were not mounted in this workspace. The connected SWRLZ node previously advertised the expected source filename and byte count, but the current connector path was unavailable and does not provide arbitrary raw binary model bytes through Archive VFS.

Therefore 010A **does not claim**:

- a freshly recomputed real-source SHA from the live bytes;
- a generated canonical `SWRLZ-LALM-001A.§wyrlzx` SHA-256;
- complete native LFM2 execution parity;
- Android APK/device acceptance;
- production promotion or deployment.

The source/runtime is now prepared to perform those checks without inventing evidence when the exact source bytes are directly available.
