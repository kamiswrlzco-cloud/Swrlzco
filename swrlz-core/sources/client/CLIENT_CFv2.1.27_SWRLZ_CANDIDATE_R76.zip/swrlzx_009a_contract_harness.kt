package sh.swrlz.nodehost.ai.local

import kotlin.random.Random
import sh.swrlz.swrlzx.SwrlzxAdvancedCapabilityV1
import sh.swrlz.swrlzx.SwrlzxAdvancedRuntimeCapabilitiesV1
import sh.swrlz.swrlzx.SwrlzxAdvancedRuntimeContractV1
import sh.swrlz.swrlzx.SwrlzxAdvancedRuntimeNegotiatorV1
import sh.swrlz.swrlzx.SwrlzxAdvancedRuntimeRequestV1
import sh.swrlz.swrlzx.SwrlzxFallbackModeV1
import sh.swrlz.swrlzx.SwrlzxSpeculativeContractV1

private fun sha(seed: String) = java.security.MessageDigest.getInstance("SHA-256")
    .digest(seed.toByteArray()).joinToString("") { "%02x".format(it) }

fun main() {
    var checks = 0
    fun pass(name: String, condition: Boolean) {
        check(condition) { "FAIL:$name" }
        checks++
        println("PASS | $name")
    }

    val root = sha("root")
    val logical = sha("logical")
    val tokens = IntArray(1024) { it % 251 }
    val p1 = SwrlzxAdvancedRuntimeContractV1.prefixIdentity(root, logical, "swrlzx.tokenizer.v1", "swrlzx.advanced-runtime.v1", tokens)
    val p2 = SwrlzxAdvancedRuntimeContractV1.prefixIdentity(root, logical, "swrlzx.tokenizer.v1", "swrlzx.advanced-runtime.v1", tokens.copyOf())
    pass("prefix identity deterministic", p1 == p2)
    tokens[800]++
    val p3 = SwrlzxAdvancedRuntimeContractV1.prefixIdentity(root, logical, "swrlzx.tokenizer.v1", "swrlzx.advanced-runtime.v1", tokens)
    pass("prefix identity token bound", p1 != p3)
    pass("prefix identity logical model bound", p1 != SwrlzxAdvancedRuntimeContractV1.prefixIdentity(root, sha("logical2"), "swrlzx.tokenizer.v1", "swrlzx.advanced-runtime.v1", IntArray(1024) { it % 251 }))

    val sig0 = SwrlzxAdvancedRuntimeContractV1.signatureSemanticDigest(1, 0, 0, root, listOf(1 to 0, 4 to 0))
    val sigMinor = SwrlzxAdvancedRuntimeContractV1.signatureSemanticDigest(1, 1, 0, root, listOf(1 to 0, 4 to 0))
    val sigFlags = SwrlzxAdvancedRuntimeContractV1.signatureSemanticDigest(1, 0, 1, root, listOf(1 to 0, 4 to 0))
    val sigSectionFlags = SwrlzxAdvancedRuntimeContractV1.signatureSemanticDigest(1, 0, 0, root, listOf(1 to 1, 4 to 0))
    pass("signature binding covers minor", sig0 != sigMinor)
    pass("signature binding covers header flags", sig0 != sigFlags)
    pass("signature binding covers semantic section flags", sig0 != sigSectionFlags)

    val caps = SwrlzxAdvancedRuntimeStateV1.capabilities
    val request = SwrlzxAdvancedRuntimeRequestV1(
        preferredCapabilities = setOf(
            SwrlzxAdvancedCapabilityV1.PAGED_KV,
            SwrlzxAdvancedCapabilityV1.PREFIX_REUSE,
            SwrlzxAdvancedCapabilityV1.SPECULATIVE_DECODE,
            SwrlzxAdvancedCapabilityV1.ACCELERATOR_BACKEND,
        ),
        targetLogicalModelSha256 = logical,
    )
    val plan = SwrlzxAdvancedRuntimeNegotiatorV1.negotiate(request, caps)
    pass("default advanced plan compatible", plan.compatible)
    pass("paged KV enabled", SwrlzxAdvancedCapabilityV1.PAGED_KV in plan.enabledCapabilities)
    pass("prefix reuse enabled", SwrlzxAdvancedCapabilityV1.PREFIX_REUSE in plan.enabledCapabilities)
    pass("speculative unavailable uses target-only", SwrlzxFallbackModeV1.TARGET_ONLY in plan.fallbackModes)
    pass("accelerator unavailable uses CPU", SwrlzxFallbackModeV1.CPU_REFERENCE in plan.fallbackModes)
    pass("authority unchanged", plan.targetModelAuthoritative && plan.outputAuthorityUnchanged)

    val hard = request.copy(requiredCapabilities = setOf(SwrlzxAdvancedCapabilityV1.SPECULATIVE_DECODE))
    val hardPlan = SwrlzxAdvancedRuntimeNegotiatorV1.negotiate(hard, caps)
    pass("missing required speculation fails closed", !hardPlan.compatible && SwrlzxFallbackModeV1.FAIL_CLOSED_REQUIRED_CAPABILITY in hardPlan.fallbackModes)

    val kv = SwrlzxPagedTokenKvV1(root, logical, "request-A", maxTokens = 4096, pageTokens = 128)
    repeat(1000) { kv.append("request-A", it) }
    pass("paged KV exact page count", kv.pageCount == 8)
    pass("paged KV bounded slots", kv.allocatedTokenSlots == 1024)
    pass("paged KV exact snapshot", kv.snapshot("request-A") == (0 until 1000).toList())
    val ownerRejected = runCatching { kv.snapshot("request-B") }.isFailure
    pass("paged KV cross-owner rejected", ownerRejected)

    val cache = SwrlzxPrefixTokenCacheV1(maxEntries = 8, maxTotalTokens = 2048)
    val promptKey = SwrlzxAdvancedRuntimeContractV1.promptTokenizationIdentity(root, logical, "swrlzx.tokenizer.v1", "swrlzx.advanced-runtime.v1", "system+prompt".toByteArray())
    val promptTokens = IntArray(512) { it % 127 }
    cache.put(promptKey, promptTokens)
    pass("prompt token cache hit exact", cache.get(promptKey)?.tokenIds?.contentEquals(promptTokens) == true)
    repeat(20) { i -> cache.put(sha("key-$i"), IntArray(128) { i }) }
    pass("prompt token cache entry bound", cache.entryCount() <= 8)
    pass("prompt token cache token bound", cache.cachedTokens() <= 2048)

    val rnd = Random(0x009A)
    var exactRuns = 0
    var accepted = 0L
    var drafted = 0L
    repeat(5000) { run ->
        val target = IntArray(16) { rnd.nextInt(0, 32000) }
        val draft = target.copyOf()
        repeat(draft.size) { i -> if (rnd.nextInt(100) >= 84) draft[i] = (draft[i] + 1 + run) % 32000 }
        val v = SwrlzxSpeculativeContractV1.verify(target, draft)
        val emitted = v.targetVerifiedTokens.toIntArray()
        val expectedLen = minOf(target.size, v.acceptedDraftTokens + if (v.correctionTokenId != null) 1 else 0)
        check(emitted.contentEquals(target.copyOfRange(0, expectedLen))) { "SWRLZX_SPEC_TARGET_MISMATCH:$run" }
        exactRuns++
        accepted += v.acceptedDraftTokens
        drafted += draft.size
    }
    pass("5000 speculative blocks target-exact", exactRuns == 5000)
    val acceptance = if (drafted == 0L) 0.0 else accepted.toDouble() / drafted
    pass("speculative fixture has useful draft acceptance", acceptance > 0.20)

    // 10k owner-isolation stress with independent caches.
    var isolationFailures = 0
    repeat(10_000) { i ->
        val q = SwrlzxPagedTokenKvV1(root, logical, "owner-$i", 256, 64)
        q.append("owner-$i", i)
        if (runCatching { q.snapshot("other-$i") }.isSuccess) isolationFailures++
    }
    pass("10000/10000 owner isolation", isolationFailures == 0)

    println("METRIC | speculativeDraftAcceptance=${"%.6f".format(acceptance)}")
    println("METRIC | pagedKv1000TokensPages=${kv.pageCount}")
    println("METRIC | pagedKv1000TokensAllocatedSlots=${kv.allocatedTokenSlots}")
    println("RESULT | $checks/$checks PASS")
}
