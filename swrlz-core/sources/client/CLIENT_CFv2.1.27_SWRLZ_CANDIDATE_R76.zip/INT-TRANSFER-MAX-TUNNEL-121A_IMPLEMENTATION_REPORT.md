# INT-TRANSFER-MAX-TUNNEL-121A — CLIENT R18 implementation report

## Accepted live evidence

Matched SERVER R39 + CLIENT R17 moved 100 MiB through `DEVICE_BINARY_STREAM_V2` in one payload request. The completed benchmark recorded 21,141 ms end-to-end at 4,959,916 B/s (~4.73 MiB/s overall), with the streaming request itself taking 17,764.06 ms. That is about 4.7x faster overall than the prior R38/R16 request-per-chunk 100 MiB run (~98.7 s / ~1.01 MiB/s).

## MAX/AUTO benchmark controls

R18 expands the local loopback stream writer from the old 4/64/256 KiB debug choices to 256 KiB, 512 KiB, 1 MiB, 2 MiB, 4 MiB, AUTO, and MAX. AUTO resolves by payload size: 512 KiB for small payloads, 1 MiB at 10 MiB, 2 MiB at 50 MiB, and 4 MiB at 100 MiB. MAX always resolves to 4 MiB.

Streaming-v2 still uses one payload HTTP request. If a peer lacks streaming-v2, the existing compatibility path is retained and capped at 512 KiB chunks.

## Evidence repair and richer timing

R18 reads the authoritative SERVER field `incrementalSha256Verified`. The prior R17 log read `incrementalShaVerified`, so its `false` value was a key-name mismatch rather than a failed stream hash. Benchmark summaries now include resolved buffer size, SERVER read count, SERVER fsync milliseconds, checkpoint milliseconds, sync count, request timing, and explicit stream SHA state.

Generic staged-file streaming now accepts SERVER-advertised stream buffers up to 4 MiB while still reading from disk and writing to Ktor's channel incrementally rather than allocating the whole file.

## Tunnel comparison target

R18 pairs with SERVER R40, which adds persistent native HTTPS-pull buffer controls and transport timing in tunnel settings. The next acceptance can therefore run the same 1/10/50/100 MiB progression locally and through the ChatGPT/plugin tunnel without requiring Google Drive as the heavy-byte path.

## Validation boundary

Android Gradle compilation was attempted but did not start because this environment could not resolve `services.gradle.org`. GitHub Actions remains the compile/sign gate. No R40/R18 MAX or tunnel/plugin speed result is claimed by source packaging.
