# INT-REGISTRATION-LALM-134A — CLIENT CFv2.1.27 R44 · VC170

- candidate: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R44`
- parent: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R43` · SHA-256 `f75003c06f2cfe905b61323f3fabed1ea4713cd061ea8d00b54cc802be7d3c8c`
- sibling: `SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R71`
- versionName: `2.1.27-registration-lalm-r44`
- checkpoint: `INT-REGISTRATION-LALM-134A`

## Changes

- Startup registration reconciliation now performs a bounded local loopback probe before falling back to the configured LAN endpoint. A co-resident SWRLZ SERVER that answers with a valid SWRLZ registration/heartbeat response is selected for the session.
- `PROOF_REBIND_REQUIRED` / `PROOF_MISMATCH` recovery now emits distinct `proof_rebind_begin` and `proof_rebind_end` diagnostic evidence with protocol code, status, elapsed time and canonical node identity.
- Duplicate CLIENT chat snapshot saves are de-duplicated at the diagnostic layer so one logical message commit does not appear twice merely because Compose/state persistence called `saveMessages` twice.
- R43 hierarchical Developer Logger controls and the persistent `CLIENT · CFv2.1.27 · R44 / VC170` revision footer are preserved.

## Evidence boundary

The change is prepared from R43 source. Android compilation/signing remains the APK Router acceptance gate. No installation, promotion or deployment is claimed by source preparation.


## Runtime evidence source

Correlated CLIENT/SERVER full logs captured 2026-08-13 showed stale LAN reconciliation, `PROOF_REBIND_REQUIRED`, repeated recovery timeouts, eventual canonical-node registration, stable heartbeats, and duplicate CLIENT chat logging.
