# INT-TRANSFER-MAX-TUNNEL-121A validation — CLIENT R18

- Focused CLIENT source verifier: **33/33 PASS**.
- Paired SERVER focused verifier: **40/40 PASS**.
- Accepted parent device evidence: R39/R17 moved 100 MiB over `DEVICE_BINARY_STREAM_V2` in one payload request; 21,141 ms end-to-end at 4,959,916 B/s overall.
- R18 adds AUTO/MAX benchmarking through 4 MiB, explicit 256 KiB/512 KiB/1/2/4 MiB choices, richer SERVER read/fsync/checkpoint evidence, and corrected `incrementalSha256Verified` handling.
- Compatibility fallback remains bounded to the established chunk lane for older SERVER peers.
- Android Gradle compilation was attempted but **blocked before compilation** because `services.gradle.org` could not be resolved in this environment. No APK/build success is claimed here.
- GitHub Actions compile + stable-signing and matched-device localhost/tunnel tests remain acceptance gates.
