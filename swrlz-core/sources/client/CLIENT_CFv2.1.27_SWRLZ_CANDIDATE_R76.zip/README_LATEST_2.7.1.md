# SWRLZ-Core 2.7.1 — Relay Radar

Relay Radar is the first UI cockpit cleanup pass after Two-Phone Sigil.

## Purpose

Turn raw relay/debug controls into a cleaner operator display:

- server-pulled groups and devices
- green/yellow/red status cards
- tap-to-select group/device targets
- ready-to-send checklist
- quick command buttons
- offline queue packet inbox
- manual setup folded behind a toggle
- admin controls folded behind a toggle
- raw JSON debug output folded behind a toggle

## App identity

- Version: `0.2.7.1-relay-radar`
- Version code: `14`
- Patch: `2.7.1-RELAY-RADAR`
- Roadmap: `2.7.1`

## Matching server

Recommended server: `local-node-server-0.7.1-presence-index`.

Relay Radar can still use older 0.7 routes for core packet flows, but the clean radar list works best with `/presence/summary` from server 0.7.1.

## Main test path

1. Start Local Node Server 0.7.1.
2. Set Local Core Node URL in app.
3. Open `Radar` tab.
4. Tap `REFRESH RADAR`.
5. If no group/device data appears, open `Manual setup / raw IDs`.
6. Enter group/device fields.
7. Create group, then join/register device.
8. Tap `CHECK-IN THIS DEVICE`.
9. Tap `REFRESH RADAR` again.
10. Tap a device card to select it.
11. Send `PING` or `SHOW_MESSAGE`.
12. Pull offline queue and handle packet cards.

## Safety

Relay Radar is still command-card only. Nothing executes invisibly. Offline packets display as cards first.
