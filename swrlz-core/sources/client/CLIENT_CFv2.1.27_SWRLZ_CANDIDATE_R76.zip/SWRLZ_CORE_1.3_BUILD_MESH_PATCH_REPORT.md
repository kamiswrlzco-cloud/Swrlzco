# SWRLZ-CORE 1.3 Build Mesh Patch Report

## Purpose

This source refresh integrates the roadmap update for:

- Build Provenance / Phone-First Cloud Build
- Dual-Phone Core Node Bridge
- Moto 5G Core Phone / Action Phone architecture

It also adds a preliminary Codespaces Android SDK bootstrap script so phone-first builds can become closer to one command.

## Source changes

### Roadmap

- Updated `SWRLZ_CORE_MASTER_ROADMAP.md` to revision 1.3.
- Added `0.1.6a — Build Provenance and Phone-First Cloud Build`.
- Added `0.2.1a — Dual-Phone Core Node Bridge`.
- Added Immediate Build Target and Immediate Architecture Target sections.

### Documentation

- Added `docs/SWRLZ_CORE_ROADMAP_UPDATE_1.3_BUILD_AND_DUAL_PHONE_CORE.md`.
- Added `docs/BUILD_PROVENANCE_REQUEST.md`.
- Added `docs/DUAL_PHONE_CORE_NODE_PLAN.md`.
- Updated `BUILD_APK_FROM_SOURCE_ZIP.md` with the new bootstrap build flow.
- Updated `README.md` to mention `scripts/install_android_sdk_and_build.sh`.

### Scripts

- Added `scripts/install_android_sdk_and_build.sh`.
- Updated `scripts/build_android_debug_bundle.sh` to emit `APK_DOWNLOAD/BUILD_PROVENANCE_REPORT.md` and include it in the APK download bundle.

## Validation performed in this environment

- Bash syntax check passed for:
  - `scripts/install_android_sdk_and_build.sh`
  - `scripts/build_android_debug_bundle.sh`
- Source ZIP creation and integrity check passed.

## Not validated here

- Android APK compilation was not run in this environment because Android SDK is not mounted here.
- The new SDK bootstrap script still needs to be tested in Codespaces.

## Notes

The bootstrap script is intentionally conservative. It installs/verifies Android SDK tooling and then delegates to the APK builder. It does not edit app source code; the APK builder only writes `android/local.properties`.
