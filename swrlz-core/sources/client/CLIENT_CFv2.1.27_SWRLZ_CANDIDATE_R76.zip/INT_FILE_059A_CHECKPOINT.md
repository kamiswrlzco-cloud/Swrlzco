# INT-FILE-059A — Forge File Lab + Archive Cartographer Foundation

Status: SOURCE CANDIDATE
Component: CLIENT
Candidate target: CFv2.1.27 / VC125
Parent: CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R1.zip

## Accepted scope implemented
- Mirrors the shared SERVER Forge File Lab baseline in CLIENT.
- Read-only file SHA-256 inspection and ZIP inventory/structural map.
- Entry path/type search plus bounded text-content search and bounded text preview.
- Selective ZIP entry extraction without bulk extraction of the archive.
- Staged text editing in app-private storage; explicit commit writes a new revised archive and lineage manifest.
- Byte-exact binary split with ~500 MiB default part size, per-part hashes, manifest, and hash-verified recombination.
- Logical ~500 MiB ZIP shard generation with entry provenance and logical recombination metadata.
- SAF-configurable File Lab working/output/shard directory lanes; Downloads fallback where platform MediaStore supports it.
- Map export for later deterministic SWRLZ evidence retrieval/LLM context packaging.

## Preserved boundaries
- CLIENT Missions, legacy Dev Mode, and CLIENT-specific surfaces remain intact.
- SERVER-only inference/model/evidence authority is not copied into CLIENT.
- Original source files/archives are never opened for write by File Lab.
- No automatic AI write commit.
- No OpenAI-export semantic mining or memory ingestion.
- No model/GGUF/SWRLZMOD changes.
- No GitHub write, workflow dispatch, APK build, promotion, release, deployment, or installation.

## Validation claim
Static/source validation only. Android Gradle compilation and device acceptance are not claimed by this checkpoint.
