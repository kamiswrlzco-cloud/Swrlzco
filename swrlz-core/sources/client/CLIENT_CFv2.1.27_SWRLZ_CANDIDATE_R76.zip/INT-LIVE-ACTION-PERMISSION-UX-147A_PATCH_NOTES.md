# INT-LIVE-ACTION-PERMISSION-UX-147A — CLIENT CFv2.1.27 R56 · VC182

- `versionName`: `2.1.27-live-action-storage-permissions-r56`
- Parent: CLIENT R55 SHA-256 `ef9b116db29666b31d7eef587af7b48a7b408b71cae730df0843653bd28b429c`.
- Persistent CLIENT notification card consumes live action state; separate Android tool notifications and right-side bubble mirroring are independently toggleable.
- Notification verbosity applies to every surface while preserving safety-critical approval/failure visibility.
- Permission Centre and Archives & Data add scoped Downloads/default-directory onboarding plus a Directory Analysis master switch; mutating operations still require explicit grant identity.
- R55 recovery, concurrency, append, Deep Dig and destructive-safety behavior is preserved; 54/54 preservation assertions pass.
- Source/static candidate only. Gradle 8.7 wrapper acquisition is unavailable in this sandbox; no APK/install/deployment/promotion claim.

