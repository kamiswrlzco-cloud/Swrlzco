# CLIENT R69 · INT-GPT-ANDROID-LALM-TRANSPORT-162A

## Purpose
Add the real Android acknowledgement/execution edge required by SERVER R103 for GPT-originated LALM jobs.

## CLIENT transport behavior
- Advertises the `reasoning` capability during presence registration.
- Handles protocol-2 `LALM_JOB` and `LALM_CANCEL` inside the existing durable inbox worker; no competing poller or cursor was added.
- `LALM_JOB` runs on the existing serialized heavy-analysis lane.
- Logs `trace_lalm_job_received` without logging prompt text; only bounded metadata/hash is recorded.
- Returns `ACK / NODE_ACK` carrying the exact jobId, traceId, and current nodeId.
- Returns `RUNNING / INFERENCE_STARTED` immediately before invoking the local provider route.
- Invokes `CoreNodeApi.providerReason` using the same jobId as requestId with paid providers disabled.
- Returns one correlated `COMPLETED`, `FAILED`, or `CANCELLED` terminal payload.
- `LALM_CANCEL` cancels the active provider child without cancelling/racing the durable inbox worker.
- Reply event IDs encode phase order to keep ACK → RUNNING → terminal deterministic when timestamps are close.

## Preservation
- R68 Google Credential Manager/activity flow, bounded OpenAI archive import, encrypted vault recovery, history/account continuity, and Observatory-related functionality remain intact.
- Local-only behavior and imported-history non-execution remain intact.

## Validation boundary
- Successor source verifier: 65/65 PASS.
- Android compilation/APK installation/live-device transport remains Auto Forge/device evidence and is not claimed by this source checkpoint.
