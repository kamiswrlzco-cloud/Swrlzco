#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
is_client=(ROOT/'android/app/build.gradle.kts').is_file()
checks=[]
def check(name, cond):
    checks.append((name,bool(cond))); print(('PASS' if cond else 'FAIL')+' | '+name)
def text(rel): return (ROOT/rel).read_text(errors='replace')
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()

if is_client:
    build=text('android/app/build.gradle.kts')
    ui=text('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt')
    base='android/swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/'
    rack='android/model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt'
    check('CLIENT R31 versionCode 157','versionCode = 157' in build)
    check('CLIENT R31 versionName','2.1.27-swrlzx-advanced-runtime-r31' in build)
    check('009A patch label','INT-AI-SWRLZX-009A' in build)
    check('CLIENT advanced runtime status panel','ADVANCED RUNTIME' in ui and 'advancedRuntimeEnabledCapabilities' in ui and 'advancedRuntimeFallbacks' in ui)
else:
    build=text('app/build.gradle.kts')
    engine=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlzxNativeEngine.kt')
    runtime=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlzxAdvancedRuntime.kt')
    native=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlzxNativeRuntime.kt')
    rack_impl=text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieModelRack.kt')
    inference=text('ai-runtime-contract/src/main/kotlin/sh/swrlz/ai/runtime/LocalInferenceContract.kt')
    base='swrlzx-contract/src/main/kotlin/sh/swrlz/swrlzx/'
    rack='model-rack-contract/src/main/kotlin/sh/swrlz/modelrack/ModelRackContract.kt'
    check('SERVER R56 versionCode 179','versionCode = 179' in build)
    check('SERVER R56 versionName','2.1.27-swrlzx-advanced-runtime-r56' in build)
    check('009A patch id','INT-AI-SWRLZX-009A' in build)
    check('paged KV active primitive','SwrlzxPagedTokenKvV1' in runtime and 'private val paged = SwrlzxPagedTokenKvV1' in native)
    check('bounded prompt token cache active','SwrlzxPrefixTokenCacheV1' in runtime and 'prefixTokenCache' in engine and 'promptTokenizationIdentity' in native)
    check('advanced metrics emitted','kvPageCount=result.kvPageCount' in engine and 'prefixTokenizationCacheHit=result.prefixTokenizationHit' in engine and 'advancedEnabledCapabilities' in inference)
    check('speculation target authoritative','SwrlzxSpeculativeVerifierV1' in runtime and 'target-authoritative' in runtime.lower())
    check('optional speculation not falsely active','draftTargetExecutionAvailable = false' in runtime and 'SPECULATIVE_DECODE→TARGET_ONLY' in runtime)
    check('accelerator CPU fallback explicit','ACCELERATOR_BACKEND→CPU_REFERENCE' in runtime)
    check('Model Rack publishes advanced state','advancedRuntimeEnabledCapabilities = advancedStatus?.first.orEmpty()' in rack_impl and 'advancedRuntimeFallbacks = advancedStatus?.second.orEmpty()' in rack_impl)

contract=text(base+'SwrlzxAdvancedRuntimeContractV1.kt')
rack_contract=text(rack)
check('advanced runtime contract id','swrlzx.advanced-runtime.v1' in contract and 'INT-AI-SWRLZX-009A' in contract)
check('required/preferred capability separation','requiredCapabilities' in contract and 'preferredCapabilities' in contract)
check('required capability fail closed','FAIL_CLOSED_REQUIRED_CAPABILITY' in contract and 'missingRequiredCapabilities' in contract)
check('target/output authority invariant','targetModelAuthoritative' in contract and 'outputAuthorityUnchanged' in contract)
check('paged KV contract','swrlzx.kv.paged.v1' in contract)
check('prefix reuse identity model bound','prefixIdentity' in contract and 'logicalModelSha256' in contract and 'modelRootDigest' in contract)
check('speculative target verification contract','SwrlzxSpeculativeContractV1' in contract and 'targetVerifiedTokens' in contract)
check('accelerator contract','swrlzx.accelerator.v1' in contract and 'CPU_REFERENCE' in contract)
check('signature semantic binding','swrlzx.signature-binding.v1' in contract and 'signatureSemanticDigest' in contract and 'headerFlags' in contract and 'minor' in contract)
check('Model Rack advanced status fields','advancedRuntimeContract' in rack_contract and 'advancedRuntimeEnabledCapabilities' in rack_contract and 'advancedRuntimeFallbacks' in rack_contract)

for rel in [
 'docs/checkpoints/INT-AI-SWRLZX-009A_ADVANCED_DECODE_RUNTIME.md',
 'docs/contracts/SWRLZX_ADVANCED_RUNTIME_V1.md',
 'docs/contracts/SWRLZX_SIGNATURE_BINDING_V1.md',
 'docs/architecture/ADR-0028_SWRLZX_ADVANCED_RUNTIME_NEGOTIATION.md',
 'docs/evidence/INT-AI-SWRLZX-009A_STRONG_SUITE.md',
 'docs/evidence/INT-AI-SWRLZX-009A_STRONG_SUITE.json',
]: check('doc '+rel,(ROOT/rel).is_file())
failed=[n for n,ok in checks if not ok]
print(f'RESULT | {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    print('FAILED | '+', '.join(failed)); sys.exit(1)
