# INT-SERVICE-WORKFLOW-DRAGON-JAR-168A — CLIENT R76 / VC202 PATCH NOTES

## Code 🫙 send/render boundary repair
- Composer behavior now matches the operator contract exactly: selecting text and pressing 🫙 visibly inserts editable `[🫙]...[/🫙]` serialization in the input field.
- After SEND/history persistence, the same serialization is parsed into a real nested Code 🫙 UI segment inside the message bubble; raw jar markers are not normal sent-message presentation.
- Fixes the concrete R75 root cause: `detectLanguage()` contained an invalid Kotlin regex (`Unclosed character class`) which threw during rich parsing; the renderer caught that exception and fell back to raw serialized text.
- Marker canonicalization tolerates variation selectors and zero-width format characters around jar tokens, supports multiple containers, converges fenced Markdown onto the same code segment, and strips structural markers on malformed-display fallback rather than leaking them into chat.
- Historical/imported/user/assistant/LALM messages continue using the same non-destructive presentation model over immutable original provenance.

## Dragon theme/persona contract
- Mirrors the SERVER shared theme-persona contract so theme identity can provide the baseline dragon presentation personality while custom node/user profile instructions layer on top later.
- Default built-in theme resolves to `ANCIENT_DRAGON`; variant themes carry their own presentation-only persona metadata.
- CLIENT theme/persona metadata never alters tool schemas, truth, trust, authority, confirmation, or execution semantics.

## Preservation / validation boundary
- R75 execution ownership, group/trust presentation, active-GGUF exclusion, Forge behavior, and SERVER_LOCAL pairing remain preserved.
- Canonical `SWRLZ-LALM-001A.§wyrlzx` remains external and unmodified.
- Actual CLIENT jar parser source passes a dedicated Kotlin harness including the exact leaked-marker screenshot sentence and malformed/Unicode cases.
- Local Gradle compilation cannot start because this workspace cannot resolve `services.gradle.org`; fresh Auto Forge/APK/device evidence remains required.

---

