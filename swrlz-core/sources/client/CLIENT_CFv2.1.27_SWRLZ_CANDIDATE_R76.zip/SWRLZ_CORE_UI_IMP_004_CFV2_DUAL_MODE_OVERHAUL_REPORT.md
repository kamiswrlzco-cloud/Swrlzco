# Checkpoint UI-IMP-004: CLIENT CFv2.0.0 Dual-Mode Interface Overhaul

**Mode:** IMPLEMENT
**Lifecycle state:** IMPLEMENTATION_VERIFIED
**Status:** SOURCE LAYER COMPLETE; BUILD AND DEVICE EVIDENCE PENDING

## Objective

Promote the approved Glitch Dragon Glass experience onto the canonical CLIENT CFv1.0.2 source as the default streamlined User Mode, preserve every legacy engineering surface as SWRLZ Dev Mode, provide persistent switching in both directions, and package the result as `CLIENT_CFv2.0.0_SWRLZ.zip`.

## Success criteria

- PASS — User Mode provides Core, Chat, Missions, Nodes, and Settings.
- PASS — Glitch Dragon artwork is bundled as a translucent animated backdrop and core surface.
- PASS — Directional content transitions, dragon drift, core pulse, shard motion, and scanline motion remain reduced-motion aware.
- PASS — User Mode exposes Pause, Resume, Take Over, one-time Approve, Redirect, Decline, Truth Firewall, and local-first boundaries.
- PASS — User and Developer interface selection persists in DataStore and defaults to User Mode when unset.
- PASS — SWRLZ Dev Mode retains Home, Radar, Network, Cockpit, Setup, Style, Permissions, Core Admin, Skills, Allowlist, How To, Info, and More.
- PASS — Dev Mode receives rounded glass navigation, a translucent dragon backdrop, and an always-visible User Mode return control.
- PASS — CFv1.0.2 CF8 admin-fallback and Ktor compatibility corrections remain unchanged.
- PASS — Source identity advances to `CLIENT_CFv2.0.0_SWRLZ.zip`, Android `versionCode 31`, and `versionName 0.2.7.6-cfv2-dual-mode-ui`.
- NOT RUN — Android compilation and APK creation are outside this checkpoint.

## Evidence classification

### Confirmed facts

- Supplied predecessor `CLIENT_CFv1.0.2_SWRLZ.zip` SHA-256: `e4a985bc4024d0407132ac994847da0b60c35cca20366ba0a19ce7ec6f9dc194`.
- Supplied UI-IMP-002 package SHA-256: `5bf62cc0787af54336ff93af4f1b76aac05e60743ff45eb642a72192c294b805`.
- UI-IMP-002 was based on CLIENT CFv1.0.0, so its UI files were selectively ported onto CFv1.0.2 rather than overlaid wholesale.
- `AdminRoutePolicy.kt`, `Api.kt`, `CommandsScreen.kt`, and `NetworkDiscoveryScreen.kt` remain byte-identical to CFv1.0.2.
- The retained Android drawable is a 1536×961 JPEG derived from the approved Glitch Dragon Core artwork.

### Requirements

- Integrate; do not overwrite.
- User Mode is sleek, direct, animated, and translucent.
- SWRLZ Dev Mode preserves every legacy feature.
- Interface switching works in both directions and persists locally.
- Offline-first behavior, identity, trust, Truth Firewall, approvals, local-versus-remote distinctions, and protocol discipline remain intact.

### Assumptions

- `CFv2.0.0` identifies the canonical CLIENT source package line; the Android runtime identity continues the 2.7.6 roadmap line with a new version code.
- The supplied Glitch Dragon artwork is approved for bundling in the source package.

### Recommendations

- Compile this exact source in a separate verification checkpoint.
- Test User/Dev switching, rotation/process recreation, compact screens, large font scale, reduced motion, offline startup, approval sheets, and every legacy Dev route on a device before acceptance.

## Sources of truth inspected

- `CLIENT_CFv1.0.2_SWRLZ.zip` and matching SHA-256 file.
- `SWRLZ_UI_IMP_002_GLITCH_DRAGON_GLASS_SOURCE.zip`.
- `docs/PROJECT_GOVERNANCE.md`, `docs/LOCAL_FIRST_RULES.md`, and `docs/SAFETY_GATE_SPEC.md`.
- Current CFv1.0.2 Android implementation, version metadata, CF8 report, and Ktor repair note.
- No separate canonical SWRLZ Constitution file was present in the supplied source or handoff archives; the available project governance and accepted invariants were applied.

## Files changed or added

- `android/app/build.gradle.kts`
- `android/app/src/main/java/sh/swurlz/core/MainActivity.kt`
- `android/app/src/main/java/sh/swurlz/core/data/Prefs.kt`
- `android/app/src/main/java/sh/swurlz/core/model/Models.kt`
- `android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt`
- `android/app/src/main/java/sh/swurlz/core/ui/screens/StyleScreen.kt`
- `android/app/src/main/java/sh/swurlz/core/ui/theme/Theme.kt`
- `android/app/src/main/res/drawable-nodpi/glitch_dragon_core.jpg`
- `core/version.json`
- `core/patch_manifest.json`
- `README.md`
- `README_LATEST_2.7.6.md`
- `SWRLZ_CORE_ANDROID_CLIENT_ROADMAP_2.7.md`
- `scripts/verify_ui_imp_004_static.js`
- `scripts/test_cf8_admin_fallback.py`
- this report.

## Preserved CFv1.0.2 boundaries

- No SERVER or NODE_HOST source changed.
- No endpoint, request model, response model, protocol version, discovery rule, trust rule, authentication rule, mission engine, or safety policy changed.
- No legacy developer screen was deleted.
- No secret, signing material, build cache, APK, or generated dependency was added.
- `AdminRoutePolicy.kt`, `Api.kt`, `CommandsScreen.kt`, and `NetworkDiscoveryScreen.kt` are preserved from the canonical CFv1.0.2 baseline.

## Verification plan and result

- Static Kotlin delimiter and required-integration checks: required.
- JSON parse and version-identity checks: required.
- Byte comparison of CF8/Ktor protected files against CFv1.0.2: required.
- Legacy surface inventory: required.
- Drawable signature and minimum-size check: required.
- ZIP integrity, canonical root, exclusions, and checksum: required during packaging.
- Android build: NOT RUN; not authorized by this source-only checkpoint.

## Verification performed

- `node scripts/verify_ui_imp_004_static.js` — PASS; checked 32 Kotlin files, all 13 legacy Dev surfaces, dual-mode persistence, CF8/Ktor guards, CFv2 identity, JSON metadata, and drawable signature.
- `python3 scripts/test_cf8_admin_fallback.py .` — PASS; confirms the CF8 verified-admin fallback remains present under the CFv2 identity.
- `python3 -m json.tool core/version.json` and `python3 -m json.tool core/patch_manifest.json` — PASS.
- SHA-256 comparison against CFv1.0.2 — PASS; `AdminRoutePolicy.kt`, `Api.kt`, `CommandsScreen.kt`, and `NetworkDiscoveryScreen.kt` are byte-identical.
- Source diff whitespace/conflict-marker checks — PASS.
- Repair cycles used: 0.
- Branch head and relationship to `main`: NOT APPLICABLE; the user supplied an archive rather than a checked-out repository.

## Recovery boundary

The supplied `CLIENT_CFv1.0.2_SWRLZ.zip` and its checksum remain the unchanged rollback baseline. Interface mode is local preference state; switching modes does not mutate node identity, trust, mission, admin, allowlist, or protocol state.

## Known limitations

- Static verification does not prove Kotlin compilation, installability, runtime rendering, screen-size fit, performance, persistence across actual process death, or on-device accessibility behavior.
- The developer screens retain their established internal layouts; the overhaul updates their surrounding navigation, shared palette, shapes, and animated backdrop without rewriting their feature logic.

## Current branch disposition

No repository or Git branch was available in the supplied archive workspace. The source package is verified locally but not promoted to the GitHub canonical CLIENT lane.

## Approval required to continue

- Waiting for approval to: compile and device-verify this exact CFv2.0.0 source, or separately promote it to the canonical repository source lane.
- Compilation approval would authorize: a focused debug build and direct repairs caused by this UI integration only.
- Compilation approval would not authorize: GitHub writes, release, deployment, protocol changes, NODE_HOST changes, or canonical promotion.
- Expected result: a debug APK plus compile evidence, followed by user device testing.
- Exact approval phrase: `Approve UI-VER-005 — Compile CLIENT CFv2.0.0 for debug verification only`
