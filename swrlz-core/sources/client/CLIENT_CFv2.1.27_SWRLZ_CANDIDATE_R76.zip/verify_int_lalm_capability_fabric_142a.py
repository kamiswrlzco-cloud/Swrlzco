#!/usr/bin/env python3
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parent
checks=[]
def t(p): return (R/p).read_text(errors='replace')
def c(name,v): checks.append((name,bool(v))); print(('PASS' if v else 'FAIL')+' | '+name)
b=t('android/app/build.gradle.kts')
c('R51/VC177/checkpoint', 'versionCode = 177' in b and '2.1.27-capability-fabric-r51' in b and 'INT-LALM-CAPABILITY-FABRIC-142A' in b)
d=t('android/app/src/main/java/sh/swurlz/core/directory/DirectoryVfsEngine.kt')
c('Directory ALLOCATE', all(x in d for x in ['"ALLOCATE"','SPARSE_OR_ZERO_FILL','ALLOCATE_VERIFY_FAILED','4L * 1024L * 1024L * 1024L']))
a=t('android/app/src/main/java/sh/swurlz/core/archive/ArchiveMutationEngine.kt')
c('Archive transactional mutation', all(('"'+x+'"') in a for x in ['WRITE_TEXT','MKDIR','COPY','MOVE','RENAME','DELETE','REPACK']) and 'archive-rollback-' in a and 'ARCHIVE_COMMIT_VERIFY_FAILED' in a)
c('Nested archive mutation fail closed', 'NESTED_ARCHIVE_MUTATION_REQUIRES_REPACK' in a)
c('archive.write advertised', '"archive.write"' in t('android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt'))
bad=[]; count=0
for p in R.rglob('*.json'):
    count+=1
    try: json.loads(p.read_text())
    except Exception as e: bad.append((str(p),str(e)))
c(f'JSON valid ({count})', not bad)
c('External LALM unbundled', not any(p.name.endswith('.§wyrlzx') for p in R.rglob('*') if p.is_file()))
fail=[n for n,v in checks if not v]
print(f'CLIENT_142A={len(checks)-len(fail)}/{len(checks)}')
sys.exit(1 if fail else 0)
