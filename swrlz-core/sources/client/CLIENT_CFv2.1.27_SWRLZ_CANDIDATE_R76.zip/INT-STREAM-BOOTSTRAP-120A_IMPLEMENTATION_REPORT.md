# INT-STREAM-BOOTSTRAP-120A — CLIENT R17 implementation report

## Accepted parent evidence

Matched SERVER R38 + CLIENT R16 completed live 1 MiB, 10 MiB, and 100 MiB localhost Forge transfers. The 100 MiB / 256 KiB run completed 400 requests at about 1.01 MiB/s with average RTT 220.70 ms, SERVER work 25.71 ms, and about 194.99 ms outside SERVER per request. This isolated request/response cycling as the dominant remaining wall-time cost.

## Implemented transport change

R17 consumes SERVER's streaming capability and prefers `DEVICE_BINARY_STREAM_V2`. After `/forge/uploads/start`, the CLIENT sends all remaining bytes in one Ktor `WriteChannelContent` request instead of waiting for one response per chunk. Staged-file uploads stream from disk through bounded buffers rather than loading the whole file into memory. The stream request has a bounded 30-minute total request limit, 120-second socket-idle limit, and 15-second connect limit for large/tunnel acceptance. Existing binary-chunk and legacy Base64 paths remain compatibility fallbacks for older SERVER peers.

## Benchmark change

The loopback benchmark now measures one-body transport directly. The 4/64/256 KiB selector is a stream writer buffer size when streaming-v2 is available, and remains a fallback chunk size otherwise. Results expose transport, payload request count, CLIENT buffer count, SERVER read count, stream RTT, SERVER/outside-SERVER timing, checkpoint/fsync counts, and incremental-SHA evidence.

## Preserved trust and authority

R16 proof-aware heartbeat and same-device reinstall rebind recovery remain unchanged. SERVER remains authoritative for trust, admin, Forge staging, verification, and promotion consequences. Upload alone still never implies build/install/release/deployment.

## Validation boundary

Focused source verifier: 23/23 PASS. Source manifest is finalized separately after accounting. Android Gradle compilation was attempted but did not begin because this environment could not resolve `services.gradle.org`; GitHub Actions remains the compile/sign acceptance gate. No localhost streaming-speed or tunnel/plugin-speed claim is made for R17/R39 before device acceptance.
