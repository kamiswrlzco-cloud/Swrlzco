#!/usr/bin/env python3
"""Apply INT-FORGE-039F+039N CI transport support to a checked-out Swrlzco repository.

This script is packaged as handoff evidence only. It is not executed by the CLIENT runtime.
"""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

PATCH_ROOT = Path(__file__).resolve().parent


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if text.count(old) != 1:
        raise SystemExit(f"Patch precondition failed for {label}: expected exactly one current pattern")
    return text.replace(old, new, 1)


def main() -> int:
    repo = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    workflow = repo / ".github/workflows/swrlz-apk-router.yml"
    if not workflow.is_file():
        raise SystemExit(f"Missing router workflow: {workflow}")
    text = workflow.read_text(encoding="utf-8")

    old_paths = """      - 'swrlz-core/sources/client/*.zip'\n      - 'swrlz-core/sources/client/*.sha256'\n      - 'swrlz-core/sources/client/*.sha'\n      - 'swrlz-core/sources/client/*.txt'\n      - 'swrlz-core/sources/client/*.manifest.json'\n      - 'swrlz-core/sources/server/*.zip'\n      - 'swrlz-core/sources/server/*.sha256'\n      - 'swrlz-core/sources/server/*.sha'\n      - 'swrlz-core/sources/server/*.txt'\n      - 'swrlz-core/sources/server/*.manifest.json'\n"""
    new_paths = """      - 'swrlz-core/sources/client/*.zip'\n      - 'swrlz-core/sources/client/*.transport.json'\n      - 'swrlz-core/sources/server/*.zip'\n      - 'swrlz-core/sources/server/*.transport.json'\n"""
    text = replace_once(text, old_paths, new_paths, "push path policy")

    old_resolve = """          python3 \"$SWRLZ_CI_ROOT/resolve_swrlz_source.py\" \\\n            --component \"$COMPONENT\" \\\n            --github-output \"$GITHUB_OUTPUT\" \\\n            \"${SOURCE_ARGUMENTS[@]}\"\n"""
    new_resolve = """          python3 \"$SWRLZ_CI_ROOT/resolve_swrlz_source.py\" \\\n            --component \"$COMPONENT\" \\\n            --work-dir \"$RUNNER_TEMP/swrlz-source-resolver/$COMPONENT\" \\\n            --github-output \"$GITHUB_OUTPUT\" \\\n            \"${SOURCE_ARGUMENTS[@]}\"\n"""
    text = replace_once(text, old_resolve, new_resolve, "resolver work directory")

    old_verify = """          python3 \"$SWRLZ_CI_ROOT/verify_swrlz_package_pair.py\" \\\n            \"${{ steps.resolve.outputs.selected_source }}\" \\\n            --checksum \"${{ steps.resolve.outputs.checksum_file }}\"\n"""
    new_verify = """          VERIFY_ARGS=(\"${{ steps.resolve.outputs.selected_source }}\")\n          if [[ -n \"${{ steps.resolve.outputs.checksum_file }}\" ]]; then\n            VERIFY_ARGS+=(--checksum \"${{ steps.resolve.outputs.checksum_file }}\")\n          fi\n          if [[ -n \"${{ steps.resolve.outputs.manifest_file }}\" ]]; then\n            VERIFY_ARGS+=(--manifest \"${{ steps.resolve.outputs.manifest_file }}\")\n          fi\n          python3 \"$SWRLZ_CI_ROOT/verify_swrlz_package_pair.py\" \"${VERIFY_ARGS[@]}\"\n"""
    text = replace_once(text, old_verify, new_verify, "optional evidence verifier")

    old_summary = """            echo \"- Checksum file: \\`${{ steps.resolve.outputs.checksum_file }}\\`\"\n            echo \"- Signing mode: \\`${{ steps.signing.outputs.signing_mode }}\\`\"\n"""
    new_summary = """            echo \"- Source kind: \\`${{ steps.resolve.outputs.source_kind }}\\`\"\n            echo \"- Checksum file: \\`${{ steps.resolve.outputs.checksum_file || 'none supplied' }}\\`\"\n            echo \"- Manifest file: \\`${{ steps.resolve.outputs.manifest_file || 'none supplied' }}\\`\"\n            echo \"- Transport manifest: \\`${{ steps.resolve.outputs.transport_manifest || 'direct ZIP' }}\\`\"\n            echo \"- Signing mode: \\`${{ steps.signing.outputs.signing_mode }}\\`\"\n"""
    text = replace_once(text, old_summary, new_summary, "provenance summary")

    workflow.write_text(text, encoding="utf-8")

    target_ci = repo / "swrlz-core/tools/ci"
    target_ci.mkdir(parents=True, exist_ok=True)
    for name in ("resolve_swrlz_source.py", "verify_swrlz_package_pair.py", "test_resolve_swrlz_source.py"):
        shutil.copy2(PATCH_ROOT / "swrlz-core/tools/ci" / name, target_ci / name)

    print("INT-FORGE-039F+039N repository CI patch applied to working tree (not committed).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
