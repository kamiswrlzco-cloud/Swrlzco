# INT-FORGE-039F + INT-FORGE-039N Repository CI Patch

This directory is a **source-only handoff** for the official `kamiswrlzco-cloud/Swrlzco` repository.
It is not applied automatically by the CLIENT package.

It updates the APK router so:

- a direct source ZIP is build-eligible without SHA/manifest sidecars;
- supplied sidecars remain strict evidence and mismatches fail closed;
- `<stem>.transport.json` identifies a chunked source transport;
- each chunk is SHA-256 verified;
- the runner reconstructs the ZIP under `$RUNNER_TEMP`;
- whole ZIP size and SHA-256 are verified before the existing package/build stages;
- sidecar-only pushes do not trigger builds; direct ZIP or final transport-manifest pushes do.

`apply_to_repo.py <repo-root>` modifies a checked-out repository working tree only. It does not commit or push.
