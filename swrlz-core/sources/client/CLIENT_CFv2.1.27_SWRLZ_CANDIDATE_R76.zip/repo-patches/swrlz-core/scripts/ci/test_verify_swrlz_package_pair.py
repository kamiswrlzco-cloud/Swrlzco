#!/usr/bin/env python3
from __future__ import annotations
import hashlib, importlib.util, json, sys, tempfile, unittest, zipfile
from pathlib import Path
spec=importlib.util.spec_from_file_location('verifier',Path(__file__).with_name('verify_swrlz_package_pair.py'))
verifier=importlib.util.module_from_spec(spec); sys.modules['verifier']=verifier; spec.loader.exec_module(verifier)

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def fixture(root: Path):
    source=root/'SERVER_CFv2.1.26_SWRLZ_CANDIDATE_R4.zip'
    with zipfile.ZipFile(source,'w') as z:z.writestr('app/build.gradle.kts','fixture')
    digest=sha(source); stem=source.stem
    bundle=root/(stem+'_METADATA.zip')
    manifest={'component':'SERVER','versionCode':87,'revision':'R4','sourceZip':{'filename':source.name,'sha256':digest,'sizeBytes':source.stat().st_size},'verified':True}
    with zipfile.ZipFile(bundle,'w') as z:
        z.writestr(stem+'.sha256',f'{digest}  {source.name}\n')
        z.writestr(stem+'.manifest.json',json.dumps(manifest))
    return source,bundle
class T(unittest.TestCase):
    def test_bundle(self):
        with tempfile.TemporaryDirectory() as d:
            source,bundle=fixture(Path(d)); r=verifier.verify(source,bundle,None,None)
            self.assertTrue(r['verified']); self.assertEqual(r['format'],'metadata-bundle-v1')
    def test_reject_modified_source(self):
        with tempfile.TemporaryDirectory() as d:
            source,bundle=fixture(Path(d)); source.write_bytes(source.read_bytes()+b'x')
            with self.assertRaises(ValueError): verifier.verify(source,bundle,None,None)

    def test_reject_revision_mismatch(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); source,bundle=fixture(root)
            stem=source.stem; digest=sha(source)
            manifest={'component':'SERVER','versionCode':87,'revision':'R3','sourceZip':{'filename':source.name,'sha256':digest,'sizeBytes':source.stat().st_size},'verified':True}
            with zipfile.ZipFile(bundle,'w') as z:
                z.writestr(stem+'.sha256',f'{digest}  {source.name}\n')
                z.writestr(stem+'.manifest.json',json.dumps(manifest))
            with self.assertRaises(ValueError): verifier.verify(source,bundle,None,None)

    def test_requires_complete_legacy(self):
        with tempfile.TemporaryDirectory() as d:
            source,_=fixture(Path(d))
            with self.assertRaises(ValueError): verifier.verify(source,None,None,None)
if __name__=='__main__':unittest.main(verbosity=2)
