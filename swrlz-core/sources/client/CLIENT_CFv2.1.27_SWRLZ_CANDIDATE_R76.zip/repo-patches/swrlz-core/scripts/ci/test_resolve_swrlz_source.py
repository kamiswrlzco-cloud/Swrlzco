#!/usr/bin/env python3
from __future__ import annotations
import hashlib, importlib.util, json, tempfile, unittest, zipfile, sys
from pathlib import Path

SCRIPT = Path(__file__).with_name('resolve_swrlz_source.py')
spec = importlib.util.spec_from_file_location('resolver', SCRIPT)
resolver = importlib.util.module_from_spec(spec); sys.modules['resolver'] = resolver; spec.loader.exec_module(resolver)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_source(path: Path, marker: str='source') -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('settings.gradle.kts', '// fixture')
        z.writestr('app/src/main/java/Test.kt', f'// {marker}')


def make_metadata(source: Path, component: str, version_code: int, revision: str) -> Path:
    digest=sha(source); size=source.stat().st_size; stem=source.stem
    manifest={
        'schemaVersion': 2,
        'component': component,
        'versionCode': version_code,
        'revision': revision,
        'sourceZip': {'filename': source.name, 'sha256': digest, 'sizeBytes': size},
        'verified': True,
    }
    bundle=source.with_name(stem+'_METADATA.zip')
    with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr(stem+'.sha256', f'{digest}  {source.name}\n')
        z.writestr(stem+'.manifest.json', json.dumps(manifest, sort_keys=True))
    return bundle


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        for lane in resolver.COMPONENTS.values(): (self.root/lane).mkdir(parents=True,exist_ok=True)
    def tearDown(self): self.tmp.cleanup()

    def test_direct_metadata_bundle(self):
        lane=self.root/resolver.COMPONENTS['CLIENT']; src=lane/'CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R2.zip'
        make_source(src); bundle=make_metadata(src,'CLIENT',125,'R2')
        result=resolver.resolve(self.root,'CLIENT',work_dir=self.root/'work')
        self.assertEqual(result['source_kind'],'direct-bundle')
        self.assertEqual(result['canonical_filename'],src.name)
        self.assertEqual(result['version_code'],125)
        self.assertEqual(result['revision'],'R2')
        self.assertEqual(Path(result['metadata_bundle']).name,bundle.name)
        self.assertEqual(result['canonical_stem'],src.stem)
        self.assertEqual(result['lane'],'swrlz-core/sources/client')
        self.assertTrue(result['build_eligible'])
        self.assertEqual(result['metadata_mode'],'metadata-bundle-v1')
        self.assertIn(src.name,result['source_description'])
        self.assertIn('Build CLIENT APK from',result['build_description'])
        self.assertIn('metadata',result['evidence_description'])

    def test_chunked_v2_metadata_bundle(self):
        lane=self.root/resolver.COMPONENTS['SERVER']; src=self.root/'staging'/'SERVER_CFv2.1.26_SWRLZ_CANDIDATE_R4.zip'
        make_source(src,'server'); bundle=make_metadata(src,'SERVER',87,'R4')
        dest_bundle=lane/bundle.name; dest_bundle.write_bytes(bundle.read_bytes())
        payload=src.read_bytes(); chunks=[]; transport_root=lane/'.transport'/src.stem; transport_root.mkdir(parents=True)
        for i,start in enumerate(range(0,len(payload),73),1):
            part=payload[start:start+73]; part_path=transport_root/f'{src.name}.part{i:04d}'; part_path.write_bytes(part)
            chunks.append({'index':i,'path':part_path.relative_to(self.root).as_posix(),'size_bytes':len(part),'sha256':hashlib.sha256(part).hexdigest()})
        transport={
            'schema':2,'transport':'chunked-git-blobs-v2','component':'SERVER',
            'source_zip':src.name,'source_sha256':sha(src),'source_size_bytes':len(payload),
            'chunk_size_bytes':73,'chunks':chunks,'metadata_bundle':bundle.name,
            'metadata_bundle_path':dest_bundle.relative_to(self.root).as_posix(),
            'metadata_bundle_sha256':sha(dest_bundle),'checksum_entry':src.stem+'.sha256',
            'manifest_entry':src.stem+'.manifest.json','verified':True,
        }
        transport_path=lane/(src.stem+'.transport.json'); transport_path.write_text(json.dumps(transport))
        result=resolver.resolve(self.root,'SERVER',work_dir=self.root/'work')
        self.assertEqual(result['source_kind'],'chunked-v2')
        rebuilt=Path(result['selected_source'])
        self.assertEqual(rebuilt.read_bytes(),payload)
        self.assertEqual(result['version_code'],87)
        self.assertEqual(result['revision'],'R4')
        self.assertEqual(result['uploaded_filename'],transport_path.name)


    def test_rejects_revision_mismatch(self):
        lane=self.root/resolver.COMPONENTS['SERVER']; src=lane/'SERVER_CFv2.1.26_SWRLZ_CANDIDATE_R4.zip'
        make_source(src); bundle=make_metadata(src,'SERVER',87,'R3')
        with self.assertRaises((resolver.ResolutionError, ValueError)):
            resolver.resolve(self.root,'SERVER',work_dir=self.root/'work')

    def test_rejects_mismatched_metadata(self):
        lane=self.root/resolver.COMPONENTS['CLIENT']; src=lane/'CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R2.zip'
        make_source(src); bundle=make_metadata(src,'CLIENT',125,'R2')
        with zipfile.ZipFile(bundle,'a') as z: z.writestr('EXTRA.txt','bad')
        with self.assertRaises((resolver.ResolutionError, ValueError)):
            resolver.resolve(self.root,'CLIENT',work_dir=self.root/'work')

    def test_legacy_complete_sidecars_bootstrap(self):
        lane=self.root/resolver.COMPONENTS['CLIENT']; src=lane/'CLIENT_CFv2.1.25_SWRLZ_CANDIDATE_R1.zip'
        make_source(src); digest=sha(src); stem=src.stem
        (lane/(stem+'.sha256')).write_text(f'{digest}  {src.name}\n')
        (lane/(stem+'.manifest.json')).write_text(json.dumps({'component':'CLIENT','versionCode':124,'revision':'R1','sourceZip':{'filename':src.name,'sha256':digest,'sizeBytes':src.stat().st_size},'verified':True}))
        result=resolver.resolve(self.root,'CLIENT',work_dir=self.root/'work')
        self.assertEqual(result['source_kind'],'direct-legacy')
        self.assertEqual(result['version_code'],124)
        self.assertEqual(result['metadata_mode'],'legacy-loose-sidecars')
        self.assertIn('legacy checksum',result['evidence_description'])


    def test_github_output_preserves_router_keys(self):
        lane=self.root/resolver.COMPONENTS['CLIENT']; src=lane/'CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R2.zip'
        make_source(src); make_metadata(src,'CLIENT',125,'R2')
        result=resolver.resolve(self.root,'CLIENT',work_dir=self.root/'work')
        output=self.root/'github-output.txt'; resolver.write_outputs(output,result)
        text=output.read_text()
        for key in ('component','source_kind','metadata_mode','source_description','build_description','evidence_description','canonical_filename','canonical_stem','logical_stem','uploaded_filename','duplicate_suffix','lane','selected_source','source_sha256','checksum_file','manifest_file'):
            self.assertIn(key+'=',text)

    def test_evidence_first_ranking_uses_version_code_revision(self):
        lane=self.root/resolver.COMPONENTS['CLIENT']
        old=lane/'CLIENT_CFv9.9.9_SWRLZ_CANDIDATE_R1.zip'; make_source(old,'old'); make_metadata(old,'CLIENT',10,'R1')
        new=lane/'CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R2.zip'; make_source(new,'new'); make_metadata(new,'CLIENT',125,'R2')
        result=resolver.resolve(self.root,'CLIENT',work_dir=self.root/'work')
        self.assertEqual(result['canonical_filename'],new.name)

if __name__=='__main__': unittest.main(verbosity=2)
