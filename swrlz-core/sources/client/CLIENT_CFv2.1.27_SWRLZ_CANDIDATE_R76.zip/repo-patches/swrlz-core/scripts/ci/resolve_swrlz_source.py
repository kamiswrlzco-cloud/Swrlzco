#!/usr/bin/env python3
"""Resolve SWRLZ CLIENT/SERVER sources from direct ZIPs or chunk transports.

Supports:
- schema 2 `chunked-git-blobs-v2` with one metadata bundle containing checksum+manifest;
- schema 1 `chunked-git-blobs-v1` with legacy loose sidecars during bootstrap;
- direct source ZIP + metadata bundle;
- direct source ZIP + legacy loose checksum/manifest during bootstrap.

Selection is evidence-first. Filename timestamps never outrank verified versionCode/revision.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

SHA_RE = re.compile(r"(?i)^[0-9a-f]{64}$")
SHA_FIND_RE = re.compile(r"(?i)(?<![0-9a-f])([0-9a-f]{64})(?![0-9a-f])")
VERSION_RE = re.compile(r"(?i)CFv(?P<v>\d+\.\d+\.\d+)")
REVISION_RE = re.compile(r"(?i)_CANDIDATE_R(?P<r>\d+)$")
COPY_SUFFIX_RE = re.compile(r"\s*\(\d+\)$")
COMPONENTS = {
    "CLIENT": Path("swrlz-core/sources/client"),
    "SERVER": Path("swrlz-core/sources/server"),
}


class ResolutionError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_stem(name: str, suffix: str) -> str:
    if not name.lower().endswith(suffix.lower()):
        raise ResolutionError(f"{name!r} does not end with {suffix}")
    return COPY_SUFFIX_RE.sub("", name[: -len(suffix)].rstrip()).rstrip()


def canonical_zip_name(name: str) -> str:
    return canonical_stem(name, ".zip") + ".zip"


def metadata_name_for_zip(zip_name: str) -> str:
    return canonical_stem(zip_name, ".zip") + "_METADATA.zip"


def safe_join(root: Path, relative: str) -> Path:
    value = relative.replace("\\", "/").strip()
    if not value or value.startswith("/") or re.match(r"^[A-Za-z]:/", value):
        raise ResolutionError(f"Unsafe path: {relative!r}")
    parts = [part for part in value.split("/") if part not in ("", ".")]
    if not parts or any(part == ".." or part.casefold() == ".git" for part in parts):
        raise ResolutionError(f"Unsafe path: {relative!r}")
    path = (root / Path(*parts)).resolve()
    try:
        path.relative_to(root.resolve())
    except ValueError as exc:
        raise ResolutionError(f"Path leaves repository root: {relative!r}") from exc
    return path


def parse_version(name: str) -> tuple[int, int, int]:
    match = VERSION_RE.search(name)
    return tuple(map(int, match.group("v").split("."))) if match else (0, 0, 0)


def parse_revision(name: str) -> int:
    stem = canonical_stem(name, ".zip")
    match = REVISION_RE.search(stem)
    return int(match.group("r")) if match else 0


@dataclass(frozen=True)
class MetadataEvidence:
    bundle_path: Path | None
    bundle_sha256: str
    checksum_path: Path
    manifest_path: Path
    source_name: str
    source_sha256: str
    source_size: int
    component: str
    version_code: int
    revision: str


@dataclass(frozen=True)
class Candidate:
    kind: str
    identity_path: Path
    component: str
    source_name: str
    source_sha256: str
    source_size: int
    version: tuple[int, int, int]
    version_code: int
    revision_number: int
    transport_payload: dict | None = None
    metadata: MetadataEvidence | None = None


def parse_checksum(path: Path) -> tuple[str, str]:
    text = path.read_text(encoding="utf-8", errors="strict").strip()
    match = SHA_FIND_RE.search(text)
    if not match:
        raise ResolutionError(f"No SHA-256 in {path}")
    remainder = text[match.end():].strip().lstrip("*").strip()
    return match.group(1).lower(), remainder


def manifest_source(payload: dict) -> tuple[str, str, int]:
    source = payload.get("sourceZip") if isinstance(payload.get("sourceZip"), dict) else {}
    name = str(source.get("filename") or payload.get("zip") or "")
    sha = str(source.get("sha256") or payload.get("sha256") or "").lower()
    size = source.get("sizeBytes", source.get("size_bytes", payload.get("sizeBytes", payload.get("size_bytes", -1))))
    try:
        size_int = int(size)
    except Exception as exc:
        raise ResolutionError("Manifest source size is invalid") from exc
    return name, sha, size_int


def validate_manifest_payload(payload: dict, expected_name: str, expected_sha: str, expected_size: int, component: str) -> tuple[int, str]:
    name, sha, size = manifest_source(payload)
    if canonical_zip_name(name).casefold() != canonical_zip_name(expected_name).casefold():
        raise ResolutionError(f"Manifest source basename mismatch: {name!r} != {expected_name!r}")
    if not SHA_RE.fullmatch(sha) or sha != expected_sha:
        raise ResolutionError("Manifest source SHA-256 mismatch")
    if size != expected_size:
        raise ResolutionError("Manifest source size mismatch")
    manifest_component = str(payload.get("component") or component).upper()
    if manifest_component != component:
        raise ResolutionError("Manifest component mismatch")
    if "verified" in payload and payload.get("verified") is not True:
        raise ResolutionError("Manifest verified flag is not true")
    version_code = int(payload.get("versionCode", payload.get("version_code", -1)))
    if version_code <= 0:
        raise ResolutionError("Manifest versionCode is missing or invalid")
    revision = str(payload.get("revision") or "")
    return version_code, revision


def extract_metadata_bundle(bundle: Path, work_dir: Path, expected_source: str, expected_component: str, declared_bundle_sha: str = "") -> MetadataEvidence:
    if not bundle.is_file() or bundle.stat().st_size > 4 * 1024 * 1024:
        raise ResolutionError(f"Metadata bundle is missing or exceeds 4 MiB: {bundle}")
    actual_bundle_sha = sha256_file(bundle)
    if declared_bundle_sha and actual_bundle_sha != declared_bundle_sha:
        raise ResolutionError(f"Metadata bundle SHA-256 mismatch: {bundle}")
    expected_stem = canonical_stem(expected_source, ".zip")
    expected_checksum = f"{expected_stem}.sha256"
    expected_manifest = f"{expected_stem}.manifest.json"
    out_dir = work_dir / "metadata" / expected_stem
    out_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(bundle) as archive:
        files = [item for item in archive.infolist() if not item.is_dir()]
        if len(files) != 2:
            raise ResolutionError(f"Metadata bundle must contain exactly two files: {bundle}")
        for item in files:
            if "/" in item.filename.replace("\\", "/") or item.file_size > 1024 * 1024:
                raise ResolutionError(f"Unsafe or oversized metadata entry: {item.filename}")
        names = {item.filename.casefold(): item for item in files}
        checksum_item = names.get(expected_checksum.casefold())
        manifest_item = names.get(expected_manifest.casefold())
        if checksum_item is None or manifest_item is None:
            raise ResolutionError(f"Metadata bundle does not contain {expected_checksum} and {expected_manifest}")
        checksum_path = out_dir / expected_checksum
        manifest_path = out_dir / expected_manifest
        checksum_path.write_bytes(archive.read(checksum_item))
        manifest_path.write_bytes(archive.read(manifest_item))
    checksum_sha, checksum_target = parse_checksum(checksum_path)
    if checksum_target and canonical_zip_name(checksum_target).casefold() != canonical_zip_name(expected_source).casefold():
        raise ResolutionError("Metadata checksum target filename mismatch")
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    name, manifest_sha, size = manifest_source(payload)
    if checksum_sha != manifest_sha:
        raise ResolutionError("Metadata checksum and manifest SHA-256 disagree")
    version_code, revision = validate_manifest_payload(payload, expected_source, checksum_sha, size, expected_component)
    expected_revision_number = parse_revision(expected_source)
    expected_revision = f"R{expected_revision_number}" if expected_revision_number else ""
    if expected_revision and revision.upper() != expected_revision.upper():
        raise ResolutionError(f"Manifest revision {revision!r} does not match source revision {expected_revision}")
    return MetadataEvidence(
        bundle_path=bundle,
        bundle_sha256=actual_bundle_sha,
        checksum_path=checksum_path,
        manifest_path=manifest_path,
        source_name=canonical_zip_name(name),
        source_sha256=checksum_sha,
        source_size=size,
        component=expected_component,
        version_code=version_code,
        revision=revision,
    )


def legacy_evidence(lane: Path, source: Path, component: str) -> MetadataEvidence | None:
    stem = canonical_stem(source.name, ".zip")
    checksum_candidates = [p for ext in (".sha256", ".sha", ".sha256.txt") for p in lane.glob(f"{stem}*{ext}") if canonical_stem(p.name, ext).casefold() == stem.casefold()]
    manifest_candidates = [p for p in lane.glob(f"{stem}*.manifest.json") if canonical_stem(p.name, ".manifest.json").casefold() == stem.casefold()]
    if not checksum_candidates and not manifest_candidates:
        return None
    if len(checksum_candidates) != 1 or len(manifest_candidates) != 1:
        raise ResolutionError(f"Legacy evidence is incomplete or ambiguous for {source.name}")
    checksum = checksum_candidates[0]
    manifest = manifest_candidates[0]
    source_sha = sha256_file(source)
    source_size = source.stat().st_size
    checksum_sha, checksum_target = parse_checksum(checksum)
    if checksum_sha != source_sha:
        raise ResolutionError(f"Legacy checksum mismatch for {source.name}")
    if checksum_target and canonical_zip_name(checksum_target).casefold() != canonical_zip_name(source.name).casefold():
        raise ResolutionError("Legacy checksum target mismatch")
    payload = json.loads(manifest.read_text(encoding="utf-8"))
    version_code, revision = validate_manifest_payload(payload, source.name, source_sha, source_size, component)
    expected_revision_number = parse_revision(source.name)
    expected_revision = f"R{expected_revision_number}" if expected_revision_number else ""
    if expected_revision and revision and revision.upper() != expected_revision.upper():
        raise ResolutionError(f"Legacy manifest revision {revision!r} does not match source revision {expected_revision}")
    return MetadataEvidence(None, "", checksum, manifest, canonical_zip_name(source.name), source_sha, source_size, component, version_code, revision or expected_revision)


def parse_transport(path: Path, component: str, repo_root: Path, lane: Path, work_dir: Path) -> Candidate:
    payload = json.loads(path.read_text(encoding="utf-8"))
    schema = payload.get("schema")
    transport = payload.get("transport")
    if schema == 2 and transport == "chunked-git-blobs-v2":
        source_name = str(payload.get("source_zip") or "")
        source_sha = str(payload.get("source_sha256") or "").lower()
        source_size = int(payload.get("source_size_bytes", -1))
    elif schema == 1 and transport == "chunked-git-blobs-v1":
        source_name = str(payload.get("zip") or "")
        source_sha = str(payload.get("sha256") or "").lower()
        source_size = int(payload.get("size_bytes", -1))
    else:
        raise ResolutionError(f"Unsupported transport schema in {path.name}")
    if str(payload.get("component") or "").upper() != component:
        raise ResolutionError(f"Transport component mismatch in {path.name}")
    if not source_name or not SHA_RE.fullmatch(source_sha) or source_size < 1 or payload.get("verified") is not True:
        raise ResolutionError(f"Invalid transport identity in {path.name}")
    chunks = payload.get("chunks")
    if not isinstance(chunks, list) or not chunks:
        raise ResolutionError(f"No chunks in {path.name}")
    indexes = [int(item.get("index", -1)) for item in chunks]
    if indexes != list(range(1, len(chunks) + 1)):
        raise ResolutionError(f"Non-sequential chunks in {path.name}")
    materialized = work_dir / "sources" / component.lower() / canonical_zip_name(source_name)
    materialized.parent.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256()
    total = 0
    with materialized.open("wb") as output:
        for item in chunks:
            chunk_path = safe_join(repo_root, str(item.get("path") or ""))
            try:
                chunk_path.relative_to(lane.resolve())
            except ValueError as exc:
                raise ResolutionError("Chunk is outside component lane") from exc
            expected_size = int(item.get("size_bytes", -1))
            expected_sha = str(item.get("sha256") or "").lower()
            if not chunk_path.is_file() or chunk_path.stat().st_size != expected_size or sha256_file(chunk_path) != expected_sha:
                raise ResolutionError(f"Chunk verification failed: {chunk_path}")
            with chunk_path.open("rb") as source:
                for block in iter(lambda: source.read(1024 * 1024), b""):
                    output.write(block); digest.update(block); total += len(block)
    if total != source_size or digest.hexdigest() != source_sha:
        raise ResolutionError(f"Reassembled source verification failed: {path.name}")

    metadata: MetadataEvidence | None = None
    if schema == 2:
        bundle_rel = str(payload.get("metadata_bundle_path") or "")
        bundle_name = str(payload.get("metadata_bundle") or "")
        bundle_sha = str(payload.get("metadata_bundle_sha256") or "").lower()
        if not bundle_rel or not bundle_name or not SHA_RE.fullmatch(bundle_sha):
            raise ResolutionError("Transport v2 metadata bundle declaration is incomplete")
        bundle_path = safe_join(repo_root, bundle_rel)
        try:
            bundle_path.relative_to(lane.resolve())
        except ValueError as exc:
            raise ResolutionError("Metadata bundle is outside component lane") from exc
        if bundle_path.name.casefold() != bundle_name.casefold():
            raise ResolutionError("Metadata bundle basename mismatch")
        metadata = extract_metadata_bundle(bundle_path, work_dir, source_name, component, bundle_sha)
        if metadata.source_sha256 != source_sha or metadata.source_size != source_size:
            raise ResolutionError("Metadata bundle does not bind the reconstructed source")
        if payload.get("checksum_entry") != metadata.checksum_path.name or payload.get("manifest_entry") != metadata.manifest_path.name:
            raise ResolutionError("Transport v2 metadata entry declaration mismatch")
    else:
        checksum_rel = str(payload.get("checksum_evidence") or "")
        manifest_rel = str(payload.get("manifest_evidence") or "")
        if checksum_rel and manifest_rel:
            checksum = safe_join(repo_root, checksum_rel)
            manifest = safe_join(repo_root, manifest_rel)
            if not checksum.is_file() or not manifest.is_file():
                raise ResolutionError("Legacy transport evidence is missing")
            checksum_sha, _ = parse_checksum(checksum)
            manifest_payload = json.loads(manifest.read_text(encoding="utf-8"))
            version_code, revision = validate_manifest_payload(manifest_payload, source_name, source_sha, source_size, component)
            if checksum_sha != source_sha:
                raise ResolutionError("Legacy transport checksum mismatch")
            metadata = MetadataEvidence(None, "", checksum, manifest, canonical_zip_name(source_name), source_sha, source_size, component, version_code, revision)

    version_code = metadata.version_code if metadata else -1
    revision_number = parse_revision(source_name)
    return Candidate("chunked-v2" if schema == 2 else "chunked-v1", path, component, canonical_zip_name(source_name), source_sha, source_size, parse_version(source_name), version_code, revision_number, payload, metadata)


def discover(repo_root: Path, component: str, work_dir: Path) -> list[Candidate]:
    lane = (repo_root / COMPONENTS[component]).resolve()
    if not lane.is_dir():
        raise ResolutionError(f"Source lane does not exist: {lane}")
    candidates: list[Candidate] = []
    for source in sorted(lane.glob("*.zip")):
        name_upper = source.name.upper()
        if name_upper.endswith("_METADATA.ZIP") or name_upper.endswith("_EVIDENCE.ZIP"):
            continue
        if not name_upper.startswith(component + "_"):
            continue
        source_sha = sha256_file(source)
        source_size = source.stat().st_size
        bundle = lane / metadata_name_for_zip(source.name)
        metadata = extract_metadata_bundle(bundle, work_dir, source.name, component) if bundle.is_file() else legacy_evidence(lane, source, component)
        if metadata is None:
            continue
        if metadata.source_sha256 != source_sha or metadata.source_size != source_size:
            raise ResolutionError(f"Evidence mismatch for direct source {source.name}")
        candidates.append(Candidate("direct-bundle" if metadata.bundle_path else "direct-legacy", source, component, canonical_zip_name(source.name), source_sha, source_size, parse_version(source.name), metadata.version_code, parse_revision(source.name), None, metadata))
    for transport in sorted(lane.glob("*.transport.json")):
        candidates.append(parse_transport(transport, component, repo_root, lane, work_dir))
    return candidates


def changed_paths(repo_root: Path) -> set[Path]:
    if os.environ.get("GITHUB_EVENT_NAME") != "push":
        return set()
    before = os.environ.get("GITHUB_EVENT_BEFORE", "")
    after = os.environ.get("GITHUB_SHA", "")
    if not after:
        return set()
    command = ["git", "show", "--pretty=", "--name-only", after] if not before or set(before) == {"0"} else ["git", "diff", "--name-only", before, after]
    try:
        text = subprocess.check_output(command, cwd=repo_root, text=True)
    except Exception:
        return set()
    return {(repo_root / line.strip()).resolve() for line in text.splitlines() if line.strip()}


def choose(candidates: list[Candidate], repo_root: Path, explicit: str = "") -> tuple[Candidate, str]:
    if not candidates:
        raise ResolutionError("No source with a verified metadata bundle or complete legacy sidecars was found")
    if explicit:
        path = (repo_root / explicit).resolve()
        matches = [item for item in candidates if item.identity_path.resolve() == path]
        if len(matches) != 1:
            raise ResolutionError("Explicit source identity is absent or ambiguous")
        return matches[0], "explicit-source"
    changed = changed_paths(repo_root)
    current = [item for item in candidates if item.identity_path.resolve() in changed or (item.metadata and item.metadata.bundle_path and item.metadata.bundle_path.resolve() in changed)]
    if len(current) == 1:
        return current[0], "current-push"
    if len(current) > 1:
        raise ResolutionError("Multiple verified source identities changed in the same component lane")
    ranked = sorted(candidates, key=lambda item: (item.version_code, item.revision_number, item.version, item.identity_path.name.casefold()), reverse=True)
    return ranked[0], "verified-latest"


def resolve(repo_root: Path, component: str, explicit: str = "", work_dir: Path | None = None) -> dict:
    component = component.upper()
    if component not in COMPONENTS:
        raise ResolutionError("component must be CLIENT or SERVER")
    work_dir = work_dir or repo_root / ".swrlz-work" / component.lower()
    candidates = discover(repo_root, component, work_dir)
    selected, reason = choose(candidates, repo_root, explicit)
    source = selected.identity_path if selected.kind.startswith("direct") else work_dir / "sources" / component.lower() / selected.source_name
    metadata = selected.metadata
    if metadata is None:
        raise ResolutionError("Selected source lacks verified evidence")
    lane = COMPONENTS[component]
    logical_stem = canonical_stem(selected.source_name, ".zip")
    uploaded_filename = selected.identity_path.name
    duplicate_match = COPY_SUFFIX_RE.search(Path(uploaded_filename).stem)
    duplicate_suffix = int(re.search(r"\((\d+)\)$", duplicate_match.group(0)).group(1)) if duplicate_match else None
    metadata_mode = "metadata-bundle-v1" if metadata.bundle_path else "legacy-loose-sidecars"
    source_description = (
        f"{component} source {selected.source_name} · CFv{'.'.join(map(str, selected.version))} "
        f"R{selected.revision_number} · VC{selected.version_code} · {selected.kind} · "
        f"{metadata_mode} · SHA-256 {selected.source_sha256} · {selected.source_size} bytes · "
        f"repository {lane.as_posix()}"
    )
    build_description = f"Build {component} APK from {source_description} · selected by {reason}"
    evidence_description = (
        f"metadata {metadata.bundle_path.relative_to(repo_root)} · SHA-256 {metadata.bundle_sha256}"
        if metadata.bundle_path
        else f"legacy checksum {metadata.checksum_path} + manifest {metadata.manifest_path}"
    )
    return {
        "schema": 5,
        "component": component,
        "source_kind": selected.kind,
        "metadata_mode": metadata_mode,
        "source_description": source_description,
        "build_description": build_description,
        "evidence_description": evidence_description,
        "selected_source": str(source),
        "identity_path": str(selected.identity_path.relative_to(repo_root)),
        "canonical_filename": selected.source_name,
        "canonical_stem": logical_stem,
        "logical_stem": logical_stem,
        "uploaded_filename": uploaded_filename,
        "duplicate_suffix": duplicate_suffix,
        "lane": lane.as_posix(),
        "source_sha256": selected.source_sha256,
        "source_size_bytes": selected.source_size,
        "version": ".".join(map(str, selected.version)),
        "version_code": selected.version_code,
        "revision": f"R{selected.revision_number}",
        "metadata_bundle": str(metadata.bundle_path.relative_to(repo_root)) if metadata.bundle_path else "",
        "metadata_bundle_sha256": metadata.bundle_sha256,
        "checksum_file": str(metadata.checksum_path),
        "manifest_file": str(metadata.manifest_path),
        "transport_manifest": str(selected.identity_path.relative_to(repo_root)) if selected.kind.startswith("chunked") else "",
        "selection_reason": reason,
        "verified": True,
        "build_eligible": True,
        "evidence_policy": "metadata bundle required; complete legacy loose sidecars accepted only during bootstrap",
    }


def write_outputs(path: Path, result: dict) -> None:
    keys = ["component", "source_kind", "metadata_mode", "source_description", "build_description", "evidence_description", "selected_source", "canonical_filename", "canonical_stem", "logical_stem", "uploaded_filename", "duplicate_suffix", "lane", "source_sha256", "source_size_bytes", "version", "version_code", "revision", "metadata_bundle", "metadata_bundle_sha256", "checksum_file", "manifest_file", "transport_manifest", "selection_reason"]
    with path.open("a", encoding="utf-8") as handle:
        for key in keys:
            handle.write(f"{key}={result.get(key, '')}\n")
        handle.write("resolution_json<<SWRLZ_RESOLUTION_JSON\n")
        handle.write(json.dumps(result, sort_keys=True) + "\nSWRLZ_RESOLUTION_JSON\n")


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", default=".")
    parser.add_argument("--component", required=True, choices=sorted(COMPONENTS))
    parser.add_argument("--source-zip", default="")
    parser.add_argument("--work-dir", default="")
    parser.add_argument("--github-output", default="")
    args = parser.parse_args(argv)
    try:
        result = resolve(Path(args.repo_root).resolve(), args.component, args.source_zip, Path(args.work_dir).resolve() if args.work_dir else None)
    except (ResolutionError, ValueError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        print(f"SWRLZ source resolution failed: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, indent=2, sort_keys=True))
    if args.github_output:
        write_outputs(Path(args.github_output), result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
