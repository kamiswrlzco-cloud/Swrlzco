#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re, sys, zipfile
from pathlib import Path

SHA_RE = re.compile(r'(?i)(?<![0-9a-f])([0-9a-f]{64})(?![0-9a-f])')
COPY_RE = re.compile(r'\s*\(\d+\)$')


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()


def stem(name: str, suffix: str) -> str:
    if not name.lower().endswith(suffix.lower()): raise ValueError(f'{name} does not end with {suffix}')
    return COPY_RE.sub('',name[:-len(suffix)].rstrip()).rstrip()


def manifest_source(payload: dict):
    source=payload.get('sourceZip') if isinstance(payload.get('sourceZip'),dict) else {}
    return (
        str(source.get('filename') or payload.get('zip') or ''),
        str(source.get('sha256') or payload.get('sha256') or '').lower(),
        int(source.get('sizeBytes',source.get('size_bytes',payload.get('sizeBytes',payload.get('size_bytes',-1))))),
    )


def verify(zip_path: Path, metadata: Path | None, checksum: Path | None, manifest: Path | None) -> dict:
    actual=sha256(zip_path); size=zip_path.stat().st_size; source_name=stem(zip_path.name,'.zip')+'.zip'
    if metadata:
        expected_checksum=stem(source_name,'.zip')+'.sha256'
        expected_manifest=stem(source_name,'.zip')+'.manifest.json'
        with zipfile.ZipFile(metadata) as z:
            entries=[i for i in z.infolist() if not i.is_dir()]
            if len(entries)!=2: raise ValueError('metadata ZIP must contain exactly checksum + manifest')
            names={i.filename.casefold():i for i in entries}
            if expected_checksum.casefold() not in names or expected_manifest.casefold() not in names:
                raise ValueError('metadata ZIP entry names do not match source')
            if any('/' in i.filename.replace('\\','/') or i.file_size>1024*1024 for i in entries):
                raise ValueError('metadata ZIP contains nested or oversized entry')
            checksum_text=z.read(names[expected_checksum.casefold()]).decode('utf-8').strip()
            match=SHA_RE.search(checksum_text)
            if not match: raise ValueError('metadata checksum missing SHA-256')
            expected=match.group(1).lower()
            target=checksum_text[match.end():].strip().lstrip('*').strip()
            if target and stem(target,'.zip').casefold()!=stem(source_name,'.zip').casefold(): raise ValueError('metadata checksum target mismatch')
            payload=json.loads(z.read(names[expected_manifest.casefold()]).decode('utf-8'))
        mname,msha,msize=manifest_source(payload)
        if stem(mname,'.zip').casefold()!=stem(source_name,'.zip').casefold(): raise ValueError('metadata manifest source mismatch')
        if not (actual==expected==msha): raise ValueError('source/checksum/manifest SHA-256 mismatch')
        if size!=msize: raise ValueError('manifest source size mismatch')
        if int(payload.get('versionCode',payload.get('version_code',-1)))<=0: raise ValueError('manifest versionCode missing or invalid')
        expected_component=source_name.split('_',1)[0].upper()
        if str(payload.get('component') or expected_component).upper()!=expected_component: raise ValueError('manifest component mismatch')
        rev_match=re.search(r'(?i)_CANDIDATE_R(\d+)\.zip$',source_name)
        expected_revision=f"R{rev_match.group(1)}" if rev_match else ''
        revision=str(payload.get('revision') or '')
        if expected_revision and revision.upper()!=expected_revision.upper(): raise ValueError('manifest revision mismatch')
        if 'verified' in payload and payload.get('verified') is not True: raise ValueError('manifest verified flag is false')
        return {'source':str(zip_path),'source_sha256':actual,'size_bytes':size,'metadata_bundle':str(metadata),'metadata_bundle_sha256':sha256(metadata),'verified':True,'format':'metadata-bundle-v1'}
    if not checksum or not manifest: raise ValueError('metadata bundle or complete legacy sidecars required')
    ctext=checksum.read_text(encoding='utf-8'); match=SHA_RE.search(ctext)
    if not match or match.group(1).lower()!=actual: raise ValueError('legacy checksum mismatch')
    payload=json.loads(manifest.read_text(encoding='utf-8')); mname,msha,msize=manifest_source(payload)
    if stem(mname,'.zip').casefold()!=stem(source_name,'.zip').casefold() or msha!=actual or msize!=size: raise ValueError('legacy manifest mismatch')
    if int(payload.get('versionCode',payload.get('version_code',-1)))<=0: raise ValueError('legacy manifest versionCode missing or invalid')
    expected_component=source_name.split('_',1)[0].upper()
    if str(payload.get('component') or expected_component).upper()!=expected_component: raise ValueError('legacy manifest component mismatch')
    rev_match=re.search(r'(?i)_CANDIDATE_R(\d+)\.zip$',source_name); expected_revision=f"R{rev_match.group(1)}" if rev_match else ''
    revision=str(payload.get('revision') or expected_revision)
    if expected_revision and revision.upper()!=expected_revision.upper(): raise ValueError('legacy manifest revision mismatch')
    if 'verified' in payload and payload.get('verified') is not True: raise ValueError('legacy manifest verified flag is false')
    return {'source':str(zip_path),'source_sha256':actual,'size_bytes':size,'checksum':str(checksum),'manifest':str(manifest),'verified':True,'format':'legacy-sidecars'}


def main():
    p=argparse.ArgumentParser(); p.add_argument('zip_path',type=Path); p.add_argument('--metadata',type=Path); p.add_argument('--checksum',type=Path); p.add_argument('--manifest',type=Path); a=p.parse_args()
    try: result=verify(a.zip_path,a.metadata,a.checksum,a.manifest)
    except Exception as exc:
        print(f'Package verification failed: {exc}',file=sys.stderr); return 2
    print(json.dumps(result,indent=2,sort_keys=True)); return 0

if __name__=='__main__': raise SystemExit(main())
