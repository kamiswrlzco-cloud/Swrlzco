# INT-DEVLOGGER-FORGE-133A repository workflow follow-up

Observed live repository behavior on 2026-08-13:

- one Forge source upload creates a push commit and then explicitly dispatches `swrlz-apk-router.yml`, producing two APK Router runs for the same head SHA; SERVER R70 fixes the app-side cause by suppressing that explicit dispatch when a fresh commit already drives the push lane.
- Source Package Integrity is a distinct source-verification gate and does not build an APK.
- Patch Note Accounting currently fails candidate source uploads because it requires repository CURRENT_* documentation to already identify the newly uploaded, not-yet-built candidate. Package-internal CHANGELOG/ReleaseNotes/lineage validation should remain strict, while repository current-pointer validation should be promotion/accounting-stage policy rather than a prerequisite for compiling a candidate.

Recommended repository follow-up (requires explicit repository-write approval):

1. Keep one APK Router trigger per source transaction. With R70 Forge installed, keep Router `push` for fresh commits and use explicit `workflow_dispatch` only for exact-source rebuilds/no-op uploads.
2. Keep Integrity and Accounting as independent gates, but present them as one source transaction in Forge rather than pretending each is another APK build.
3. Split Patch Note Accounting into PACKAGE accounting (strict on every candidate source push) and REPOSITORY CURRENT-pointer accounting (strict when CURRENT_AUTHORITY/CURRENT_CANDIDATE_LINEAGE or promotion surfaces change).
4. Add component/candidate/revision outputs to each workflow summary so CLIENT/SERVER/BOTH results are visible without opening logs.
