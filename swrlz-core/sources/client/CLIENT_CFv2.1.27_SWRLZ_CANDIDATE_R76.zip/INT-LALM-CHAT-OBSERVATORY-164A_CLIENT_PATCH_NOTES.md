# CLIENT R73 — Durable 🫙 Message Containers + Paired Conversational LALM
Checkpoint: `INT-LALM-CHAT-OBSERVATORY-164A` · VC199 · `2.1.27-lalm-chat-containers-r73`

- Replaces the R72 crash-prone secondary code-structure editor with a single portable structural syntax: `[🫙]selected text[/🫙]`.
- Composer 🫙 acts directly on the current `TextFieldValue`: non-empty selection wraps exactly that range; cursor/selection anywhere touching an existing container unwraps that whole container.
- Historical/imported/user/assistant/LALM plain-text segments are selectable in-place. Pressing the message 🫙 control persists a non-destructive effective-text overlay and immediately recomposes the message; original provenance stays recoverable.
- Rendered containers expose `🫙 REMOVE` plus COPY-content-only. Legacy/imported fenced Markdown continues to render and can be unwrapped through the same control path.
- Adds unit coverage for exact wrapping, inside-container unwrapping, intersection unwrapping, and imported fenced-code unwrapping.
- Preserves R72 progressive history/cache behavior, direct newest-message thread opening, wide timestamped chat, admin Observatory mirror, Google configuration path, and the device-proven GPT↔Android LALM transport.
- Pairs with SERVER R107, which repairs conversational generation selection, same-device bootstrap authorization, native provider health reporting, and LALM Observatory readability.
- Fresh R73 compile/APK/device acceptance remains external Auto Forge evidence and is not claimed by this source checkpoint.
