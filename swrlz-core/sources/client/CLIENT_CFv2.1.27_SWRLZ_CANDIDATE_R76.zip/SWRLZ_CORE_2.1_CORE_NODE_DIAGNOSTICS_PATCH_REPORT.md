# SWRLZ-Core 2.1 Core Node Diagnostics Patch Report

## Patch label

`2.1-CORE-NODE-DIAGNOSTICS`

## Source

Based on:

```text
SWRLZ_CORE_2.0_LOCAL_NODE_BRIDGE_SOURCE.zip
```

## Android identity

```text
versionName = 0.2.1-core-node-diagnostics
versionCode = 8
```

## Fixes

### 1. Core Node app request not reaching Termux server

The app was likely blocked by Android cleartext policy because the 2.0 manifest used:

```xml
android:usesCleartextTraffic="false"
```

The Local Core Node test uses local HTTP:

```text
http://192.168.x.x:8787/status
```

This patch sets cleartext traffic true and adds a network security config.

### 2. Failed/unreachable text displayed green

The prior logic checked for `reachable` before failure. Since `unreachable` contains `reachable`, failed status could appear green.

This patch checks failure/unreachable first.

### 3. Server lacked app identity headers

The app now sends:

```text
X-SWRLZ-Device-Node-Id
X-SWRLZ-App-Version
X-SWRLZ-App-Version-Code
X-SWRLZ-Patch-Label
X-SWRLZ-Roadmap-Revision
```

## Test checklist

1. Build the APK.
2. Install over current SWRLZ-Core.
3. Confirm Home shows `v0.2.1-core-node-diagnostics · code 8`.
4. Run Local Node Server 0.2 Connection Observer on the second phone.
5. Enter the LAN URL, for example `http://192.168.1.177:8787`.
6. Tap SAVE CORE.
7. Tap TEST CORE NODE.
8. Confirm app says Core Node reachable.
9. Confirm Termux displays `[SWRLZ BRIDGE CHECK-IN]`.
