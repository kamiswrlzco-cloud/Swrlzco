#!/usr/bin/env python3
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parent
checks=[]
def t(p): return (R/p).read_text(errors='replace')
def c(name,v): checks.append((name,bool(v))); print(('PASS' if v else 'FAIL')+' | '+name)
b=t('android/app/build.gradle.kts')
c('R52/VC178/checkpoint', 'versionCode = 178' in b and '2.1.27-deep-dig-r52' in b and 'INT-DEEP-DIG-ANALYSIS-FABRIC-143A' in b)
a=t('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt')
d=t('android/app/src/main/java/sh/swurlz/core/archive/ArchiveDeepDig.kt')
p=t('android/app/src/main/java/sh/swurlz/core/archive/ArchiveConversationProfiles.kt')
cache=t('android/app/src/main/java/sh/swurlz/core/archive/ArchiveDeepDigCache.kt')
ident=t('android/app/src/main/java/sh/swurlz/core/archive/ArchiveContentIdentifier.kt')
c('Corpus Deep Dig operations', all(('"'+x+'"') in a for x in ['SEARCH_MESSAGES','MESSAGE_AGGREGATE','MESSAGE_TIMELINE','CONCEPT_LINEAGE','RECONSTRUCT_CONVERSATION','IDENTIFY_ENTRY']))
c('Exact regex fuzzy semantic modes', all(x in d for x in ['Mode.EXACT','Mode.REGEX','Mode.FUZZY','Mode.SEMANTIC','LEXICAL_TOKEN_COVERAGE_V1']))
c('Message-level research filters', all(x in a for x in ['modelFilter','message.attachmentCount','roleFilter','titleFilter','fromMs','toMs','minLength','maxLength']))
c('Unique aggregation + provenance', all(x in a for x in ['uniqueMessages','uniqueConversations','uniqueDays','firstOccurrence','lastOccurrence','provenance(source, entryPath)']))
c('Conversation evidence profiles bounded', all(x in p for x in ['HEURISTIC_PHRASE_PROFILE_V1','SUPPORT','CONCERN','TECHNICAL_COLLABORATION','ASSISTANT_PROMISE','claimBoundary']))
c('Thread reconstruction uses parentId', all(x in a for x in ['branchPointCount','parentId','childId','roots']))
c('Magic-byte identification static-only', all(x in ident for x in ['PE_EXECUTABLE_OR_DLL','ELF_BINARY','ANDROID_DEX','SQLITE_DATABASE','MACH_O_BINARY','staticOnly']))
c('Incremental structural/query reuse', 'ArchiveIndexStore.state' in cache and 'sourceFingerprint' in cache and 'RESULT_CACHE_V1' in cache and 'MAX_FILES_PER_ARCHIVE' in cache)
c('Prior mutable Archive VFS preserved', all(x in t('android/app/src/main/java/sh/swurlz/core/archive/ArchiveMutationEngine.kt') for x in ['WRITE_TEXT','MKDIR','COPY','MOVE','RENAME','DELETE','REPACK','ARCHIVE_COMMIT_VERIFY_FAILED']))
c('Local allocation preserved', 'SPARSE_OR_ZERO_FILL' in t('android/app/src/main/java/sh/swurlz/core/directory/DirectoryVfsEngine.kt'))
c('analysis.deep.read advertised', '"analysis.deep.read"' in t('android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt'))
bad=[]; count=0
for file in R.rglob('*.json'):
    count+=1
    try: json.loads(file.read_text())
    except Exception as e: bad.append((str(file),str(e)))
c(f'JSON valid ({count})', not bad)
c('External LALM unbundled', not any(x.name.endswith('.§wyrlzx') for x in R.rglob('*') if x.is_file()))
fail=[n for n,v in checks if not v]
print(f'CLIENT_143A={len(checks)-len(fail)}/{len(checks)}')
sys.exit(1 if fail else 0)
