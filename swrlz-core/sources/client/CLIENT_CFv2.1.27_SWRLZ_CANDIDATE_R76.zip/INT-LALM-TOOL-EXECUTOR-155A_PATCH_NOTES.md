# INT-LALM-TOOL-EXECUTOR-155A — CLIENT R64 Patch Notes

- Repairs async routed TOOL/MISSION execution loss between inbox consumption and VFS execution.
- Normalizes allowlisted archive/directory/log envelopes; `swrlz_archive_repack` becomes canonical `REPACK_SELECTED` on CLIENT.
- Unsupported tool envelopes now fail visibly/correlated instead of being silently consumed.
- Preserves R63 Forge live auto-selection and all exact-plan destructive safety boundaries.
- APK/device acceptance remains pending.
