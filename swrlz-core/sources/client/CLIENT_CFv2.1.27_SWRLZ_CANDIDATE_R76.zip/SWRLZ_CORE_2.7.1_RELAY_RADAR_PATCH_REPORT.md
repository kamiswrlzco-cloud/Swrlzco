# SWRLZ-Core 2.7.1 Patch Report — Relay Radar

## Summary

This patch reduces UI clutter in the command/relay area and turns the 2.7 Two-Phone Sigil screen into a cleaner Relay Radar cockpit.

## Added

- Relay Radar hero card with server URL, group count, device count, online count, queue count, and status badge.
- Server-pulled group list cards.
- Server-pulled device list cards.
- Green/yellow/red online state language.
- Tap-to-select device targets.
- Quick target mode buttons: SELF / DEVICE / GROUP.
- Quick command buttons: PING / MESSAGE / STATUS.
- Ready-check panel showing missing setup steps before sending.
- Manual setup collapsed behind a toggle.
- Admin controls collapsed behind a toggle.
- Debug JSON output collapsed behind a toggle.
- Better human-readable relay/auth failure messages.
- Main header order changed from raw `Cmds` to `Radar`, placed near Home.
- Build identity bumped to `0.2.7.1-relay-radar` / code `14`.

## Fixed

- Preserved the 2.7 Codefix1 Kotlin string correction in `CoreNodeScreen.kt`.
- Reduced eye strain from always-visible admin/password/key/debug sections.
- Reduced manual typing by letting device cards populate the target field.

## Requires

- Best with Local Node Server 0.7.1 Presence Index.
- APK build still needs Codespaces/GitHub because this sandbox cannot download Gradle.
