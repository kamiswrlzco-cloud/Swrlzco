# SWRLZ-Core Android Client Roadmap 2.7

## Current release
**2.7 — Two-Phone Sigil**

Client-facing mythic release for relay flow, device cards, admin session mode, and offline packet cards.

## Completed
- Saved admin token/session state UI.
- Admin Mode ON/OFF persistence.
- Group ID/Key and Device ID/Key UI.
- Device join/check-in controls.
- Online device cards.
- Packet composer for self/device/group.
- Offline queue packet inbox.
- Packet lifecycle buttons.

## Next recommended client release
**2.8 — Dragon Queue**

Focus:
- Better packet filtering/search.
- Queue badges on Home/Core screens.
- More polished motion states: pulse, ripple, slide-in, success flash.
- Per-device capability chips.
- Safer OPEN_APP prototype with allowlist + confirmation only.


## CF8 Verified Admin Fallback

- Treat an admin UI toggle as preference only, never authentication authority.
- Require token plus successful verification before selecting `/admin/*`.
- Keep Forget Admin local-first and best-effort remote.
- Preserve successful public presence reads when optional write/admin surfaces are unavailable.
- Keep Radar connection health separate from heartbeat and command-operation status.

## UI-IMP-004 — CFv2.0.0 Dual-Mode Interface Overhaul

- Make Glitch Dragon Glass User Mode the fresh-install default.
- Keep everyday Core, Chat, Missions, Nodes, and Settings flows concise.
- Persist explicit User Mode / SWRLZ Dev Mode selection locally.
- Preserve the full existing engineering and debug surface in SWRLZ Dev Mode.
- Apply translucent dragon motion and rounded glass navigation to both interface modes.
- Respect the existing motion-off preference.
- Preserve CF8 admin routing, Ktor compatibility, offline-first operation, identity, trust, Truth Firewall, approval gates, and protocol behavior.
- Source integration and static verification are complete; Android compilation and device acceptance remain separate evidence gates.
