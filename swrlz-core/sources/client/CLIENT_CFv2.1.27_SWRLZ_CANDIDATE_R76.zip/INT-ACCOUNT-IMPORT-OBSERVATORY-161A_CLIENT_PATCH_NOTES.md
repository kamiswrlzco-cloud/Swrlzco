# INT-ACCOUNT-IMPORT-OBSERVATORY-161A · CLIENT R68

Parent: CLIENT R67 (`fa812132e7fe05d0396ab805951fe0fed98dfa9ab7adcceeb5a9c5562387d39a`)
Paired SERVER: R102
Version: `2.1.27-account-import-observatory-r68` · VC194

## Fixes
- Google sign-in now resolves a real Activity before launching Credential Manager, uses a dedicated explicit Sign in with Google request, then authorized-account and all-account fallback paths with named failure states.
- OpenAI archive commit no longer collects all 2,461 staged conversation JSON bodies into a single heap-resident list. Conversation bodies and FTS indexing are processed one at a time with bounded progress checkpoints.
- Import cancellation remains non-executable and idempotent; stage/body/index boundaries cannot authorize tools or replay historical commands.
- Optional Google-backed SWRLZ account recovery can now save the credential-vault recovery passphrase as SERVER-key ciphertext and restore it after sign-in. Restore is re-wrapped to a one-time CLIENT RSA key.
- Existing encrypted credential-envelope backup remains separate from chat/history sync and local-only operation remains supported.

## Preserved
R67 API35/AGP8.6.1 compatibility, R66 archive provenance/branch handling, canonical history sync/tombstones/fragments, Tool Request Compiler, and Cain/Jerry/clarification/narrative/approval safety.

## Validation boundary
Source/static/package validation is recorded. APK/device success must come from the external Auto Forge/device run.
