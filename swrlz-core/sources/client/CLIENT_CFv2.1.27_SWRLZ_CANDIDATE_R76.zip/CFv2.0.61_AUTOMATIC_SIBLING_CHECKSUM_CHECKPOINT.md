# CLIENT CFv2.0.61 — Automatic Same-Directory Checksum Resolution

**Android:** versionCode 88 / versionName `2.0.61-automatic-sibling-checksum-v1`  
**Status:** source/static prepared; GitHub build and device acceptance pending.

## Runtime evidence preserved

Device testing confirmed that repeated same-install Forge uploads now produce new commits and that upload-success commit notifications appear correctly from the CLIENT and its bubble.

## Problem

Selecting one source ZIP could trigger a second Android file browser immediately because a weak direct URI-substitution lookup could not open the sibling SHA file for some Downloads/document-provider URI forms.

## Repair

For a selected `<base>.zip`, Forge derives `<base>.sha256` and attempts:

1. ordinary file-parent lookup;
2. direct document-ID substitution for path-based providers;
3. parent-directory child enumeration when a parent document ID is available;
4. Android 10+ MediaStore Files lookup using source display name, size, and relative directory.

Forge accepts an automatic match only when the candidate has the exact derived display name and can be opened.

If every provider-safe strategy fails, Forge keeps the ZIP staged and displays `LOCATE SHA-256`. It does not launch a second picker without a direct user action.

## Security and authority

- No broad storage or all-files permission is requested.
- No Downloads-root tree grant is required.
- ZIP/SHA validation remains mandatory before upload.
- Provider denial is reported as unresolved access, never as a successful match.

## Acceptance

1. Select a ZIP and confirm the exact same-directory `.sha256` stages without another picker.
2. Confirm a provider that blocks sibling access leaves the ZIP staged and shows `LOCATE SHA-256`.
3. Confirm upload remains blocked until the exact checksum is present.
4. Build through GitHub and verify repeated uploads and notifications remain intact.
