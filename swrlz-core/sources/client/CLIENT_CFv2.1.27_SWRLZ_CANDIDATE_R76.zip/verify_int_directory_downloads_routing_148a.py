#!/usr/bin/env python3
from pathlib import Path
import json, sys, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def t(rel): return (ROOT/rel).read_text(errors='replace')
build=t('android/app/build.gradle.kts')
grant=t('android/app/src/main/java/sh/swurlz/core/directory/DirectoryGrantStore.kt')
engine=t('android/app/src/main/java/sh/swurlz/core/directory/DirectoryVfsEngine.kt')
shell=t('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt')
perm=t('android/app/src/main/java/sh/swurlz/core/ui/screens/PermissionsScreen.kt')
notifier=t('android/app/src/main/java/sh/swurlz/core/notification/ToolActionNotifier.kt')
ck('client R57 identity', 'versionCode = 183' in build and 'R57' in build and 'INT-DIRECTORY-DOWNLOADS-ROUTING-148A' in build)
ck('blocked Download SAF picker removed', 'recommendedDownloadsInitialUri' not in grant and 'SET DEFAULT ANDROID DOWNLOADS DIRECTORY' not in shell)
ck('Downloads is toggle controlled', 'Android Downloads directory' in shell and 'Switch(androidDownloadsEnabled' in shell and 'setAndroidDownloadsEnabled' in shell)
ck('built-in opaque grant id', 'ANDROID_DOWNLOADS_GRANT_ID = "android-downloads"' in grant)
ck('built-in root uses Android Downloads location', 'getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)' in grant)
ck('all-files readiness gates built-in root', 'Environment.isExternalStorageManager()' in grant and 'requiresAllFilesAccess' in grant)
ck('built-in root is read-only', 'writeAllowed = false' in grant and 'recoveryEnabled = false' in grant)
ck('built-in Downloads advertises only when enabled', 'builtInDownloadsGrant(context)?.let' in grant and 'builtInAndroidDownloads' in grant)
ck('Downloads becomes implicit read-only default', 'if (androidDownloadsEnabled(context)) ANDROID_DOWNLOADS_GRANT_ID' in grant and 'defaultable = operation in setOf("INFO", "TREE", "LIST", "READ", "SEARCH", "ANALYZE")' in engine)
ck('raw file root supported without path disclosure', 'DocumentFile.fromFile(root)' in engine and 'rawDevicePathDisclosed' in engine)
ck('canonical boundary protection', 'withinFileBoundary' in engine and 'canonicalFile' in engine)
ck('permission error truthful', 'ANDROID_DOWNLOADS_PERMISSION_REQUIRED' in engine)
ck('custom scoped grants remain available', 'GRANT ANOTHER DIRECTORY' in shell and 'ActivityResultContracts.OpenDocumentTree()' in shell)
ck('permission centre no Download tree picker', 'Android Downloads Directory' in perm and 'OPEN ALL FILES ACCESS' in perm and 'OpenDocumentTree' not in perm)
ck('live notification surfaces preserved', all(x in notifier for x in ['STATUS_STREAM','ANDROID_EVENTS','CHAT_BUBBLE']))
ck('destructive safeguards preserved', all(x in engine for x in ['MUTATION_PLAN','DELETE_COMPLETE','approvalPlanHash','withMutationLock']))
json_bad=[]
for p in ROOT.rglob('*.json'):
    try: json.loads(p.read_text(errors='strict'))
    except Exception as e: json_bad.append((str(p.relative_to(ROOT)),str(e)))
ck('all JSON valid', not json_bad)
xml_bad=[]
for p in (ROOT/'android/app/src/main').rglob('*.xml'):
    try: ET.parse(p)
    except Exception as e: xml_bad.append((str(p.relative_to(ROOT)),str(e)))
ck('Android XML valid', not xml_bad)
mods=[build,grant,engine,shell,perm,notifier]
ck('no merge conflict markers', not any('<<<<<<<' in x or '>>>>>>>' in x for x in mods))
for n,c in checks: print(('PASS' if c else 'FAIL'), n)
print(f'RESULT {sum(c for _,c in checks)}/{len(checks)}')
if json_bad: print('JSON_BAD',json_bad[:5])
if xml_bad: print('XML_BAD',xml_bad[:5])
sys.exit(0 if all(c for _,c in checks) else 1)
