# INT-LALM-STREAM-TRUTH-136A Validation

## Result

Source/static focused verifier: **PASS**.

## Passed gates

- protocol remains 2 and schema remains 1;
- event enum unchanged; all added fields defaulted;
- CLIENT and SERVER shared contract source is byte-identical;
- direct and native output use DELTA;
- status cannot be appended through the CLIENT assistant buffer;
- reference-CPU stream guard emits FAILED and no CommittedDelta;
- SERVER Chat calls the same V2 Flow adapter as transport;
- Truth Capsule precedes presentation profile;
- profile/style excluded from capsule semantic identity;
- new stream logs omit raw prompt/response fields;
- component version/revision identity is advanced;
- documentation and focused verifier are present.

## Additional static/integrity checks

- CLIENT JSON corpus: 37/37 valid.
- SERVER JSON corpus: 76/76 valid.
- Shared stream contract source and its test source: byte-identical across the pair.
- Modified Kotlin structural delimiter scan: 11/11 balanced.
- Modified code/text trailing-whitespace scan: PASS.
- Changed-path credential/private-key/token pattern scan: 0 hits.

## Blocked gate

`./gradlew :llm-contract:test --no-daemon` was attempted with an isolated writable `GRADLE_USER_HOME`. Gradle 8.7 was not cached, and the environment returned `java.net.SocketException: Network is unreachable` while fetching `https://services.gradle.org/distributions/gradle-8.7-bin.zip`. Project compilation did not start.

## Evidence boundary

The included unit tests are prepared but not reported as executed. Android compile/APK/device acceptance is not run per user direction. Archive/manifest/integrity checks are recorded separately after final packaging.
