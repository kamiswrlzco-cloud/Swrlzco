# INT-LALM-TOOL-ORCHESTRATION-141A — CLIENT Implementation Report

## Checkpoint

- Component: CLIENT
- Candidate: CFv2.1.27 R50
- Version code: 176
- Version name: `2.1.27-tool-orchestration-r50`
- Parent: CLIENT CFv2.1.27 R49
- Paired SERVER: SERVER CFv2.1.27 R79
- External LALM runtime pin: `d3e3692f7bd7160baff27ca2b3479033d2a494081a1a8ada17a27c2183fcd565`

## Intent

R50 turns the CLIENT chat shell into the visible control surface for §wyrlz tool orchestration while keeping user language natural. The user does not need to memorize MCP names, repository verbs, directory-VFS function names, or workflow IDs. CLIENT consumes typed orchestration telemetry from SERVER, renders only observable operational state, separates approval from execution, and streams grounded answer state without exposing private chain-of-thought.

## User-facing tool model

The current user-facing capability model has two primary suites:

1. **Forge / GitHub** — source handoff, Auto Forge, GitHub repository administration, workflow dispatch/inspection, run/job inspection, failure logs, artifacts, rerun/cancel, and supported source routes including native/chat handoff, Forge UI, and Google Drive handoff where configured.
2. **File Analysis Lab** — selected-directory inspection, list/search/read/analyze, archive/GPT-export inspection, conversation/archive analysis, and permission-gated filesystem writes/copy/move/delete/recovery.

CLIENT deliberately presents these as meaningful suites rather than dumping low-level RPC names unless raw diagnostics are explicitly requested.

## Stream contract v2

R50 consumes schema 2 of `SwrlzLlmStreamContractV2`. Tool-oriented events can now carry:

- `toolSuite`
- `toolOperation`
- `toolRequiredCapability`
- `toolRisk`
- `toolSourceRoute`
- `toolTargetSummary`
- `toolCandidateExecutors`
- `toolExecutionState`
- `evidenceState`
- `answerState`

Operational phases include `TOOL_INTENT_RESOLVED`, `TOOL_PLAN_READY`, `TOOL_REVIEW_READY`, `TOOL_EXECUTOR_WAIT`, `TOOL_EXECUTING`, `TOOL_EVIDENCE_READY`, `ANSWER_STREAMING`, and `FINALIZING`.

`STATUS` is an operational event. It updates the execution/progress surface and never becomes assistant prose.

## Chat presentation

The live CLIENT bubble now keeps a bounded recent operational trail and a typed tool card containing suite, operation, target, required capability, risk, execution state, and evidence state. This allows a request such as “analyze my GPT export conversations” to visibly progress through real system states without fabricating hidden reasoning.

The intended presentation invariant is:

`observable action state -> executor evidence -> grounded answer streaming -> final locked answer`

The UI explicitly distinguishes:

- **REVIEW_REQUIRED** — explicit user approval is still required and no tool has been invoked.
- **APPROVED** — permission was granted; approval is not execution or success.
- **NOT_REQUIRED** — no extra confirmation is required for the proposed read-only operation, but capability and evidence are still required.
- **REJECTED** — operation remains blocked.

## STOP / retry ownership repair

R49 could stop the CLIENT stream before SERVER/native LALM had fully released the generation owner. A quick retry could therefore receive `LALM_BUSY` even though the user had already pressed Stop.

R50 changes replacement and retry behavior so CLIENT requests cancellation, waits for the SERVER drain acknowledgment, and only treats `quiescent=true` as proof that the old request has released registry/native ownership. Replacement sends and transport retries use the same bounded drain path. If quiescence cannot be confirmed within the acknowledgment window, CLIENT reports a cancellation-drain timeout rather than pretending the executor is free.

## Safety and authority invariants

- Natural-language recognition is not authorization.
- Authorization is not execution.
- Execution is not success until bounded executor evidence exists.
- Consequential operations remain approval-gated.
- Read-only operations may avoid redundant confirmation, but never bypass capability/evidence checks.
- STATUS/progress narration contains observable states only; it does not expose private chain-of-thought.
- CLIENT does not infer tool success from LALM prose.

## Session-bootstrap compatibility

R50 preserves R49’s session bootstrap architecture: environment/tool/capability orientation belongs to SERVER connection lifecycle, conversation continuity belongs to chat-thread bootstrap, and normal turns remain lightweight. The tool catalog can therefore be resident before the first user command rather than rediscovered on every message.

## Extensibility

The CLIENT UI is intentionally typed rather than hardcoded to Forge-only strings. Future suites can reuse the same contract by supplying suite/operation/capability/risk/execution/evidence metadata. This lets §wyrlz knowledge, aliases, user corrections, and new SERVER capability manifests evolve without forcing users into command syntax.

## Evidence class

This candidate is source/static validated. No APK was built, installed, deployed, promoted, or device-tested in this environment.
