# INT-TUNNEL-LALM-NODE-ADMIN-144A — Implementation Report

## Reproduction grounded fix

The observed clean-install failure was `POST /nodes/register -> 422 IDENTITY_REJECTED`, followed by heartbeat/tool preflight failure. Source inspection found a deterministic namespace mismatch: the native ChatGPT MCP identity store generates `client-swurlz-${recoveryId.take(16)}`, while the protocol-2 SERVER validator in R82 only admitted `client-${recoveryId.take(24)}`. R83 admits the plugin namespace only for the exact ChatGPT plugin device/package declaration, keeps the generic CLIENT namespace unchanged, and retains recovery-bound prior canonical IDs for lineage.

## Reconnect semantics

`ensureLivePresence()` now treats session-level `NOT_REGISTERED`, `ADMIN_DISCONNECTED`, and proof-rebind states as recoverable. It re-registers and retries heartbeat. `IDENTITY_REJECTED` is intentionally not part of that retry set. The foreground service continues to resume an armed inactive tunnel independently, and the new local SERVER-root `Reset ChatGPT tunnel` action clears the node session record and restarts the bridge while preserving credentials/app-private identity.

## Node administration

The Nodes UI now consumes `observeAllNodes()`, while operational consumers can retain active-only `observeNodes()`. The `/nodes` inventory uses `listAllNodes()`. Local deletion removes the Room registry row, deactivates active group memberships, removes external Current/Retired mirrors when available, and stores a private deletion tombstone so stale SAF data cannot resurrect the node. Historical chats/evidence are intentionally left intact.

## LALM operational observation freshness

`SwrlzObservationFreshnessV1` tracks bounded safe observations with source, safe value summary, observation time, authority, volatility, confidence, TTL, and optional event-generation domain. Domain invalidation is event-driven. LALM V2 emits permission preflight, capability discovery, state validation, mutation-triggered revalidation, and terminal verification phases. Capability intent is re-resolved before Truth Capsule construction if its domain changed. This is execution-state telemetry only and does not store/expose hidden chain-of-thought.

## Verification

- Focused SERVER verifier: 28/28 PASS before final lineage/manifest rebuild.
- Focused CLIENT verifier: 10/10 PASS before final lineage/manifest rebuild.
- `SwrlzObservationFreshnessV1.kt`: standalone Kotlin compiler PASS.
- SERVER/CLIENT `SwrlzLlmStreamContractV2.kt`: byte-identical after phase additions.
- Android Gradle test attempt: blocked before project compilation because Gradle 8.9 distribution download failed with `UnknownHostException: services.gradle.org`.

No APK/install/device/deployment/production-promotion claim is made by this source checkpoint.
