from pathlib import Path
import json, re, sys

CLIENT=Path('/mnt/data/_r55work')
SERVER=Path('/mnt/data/_r86work')
checks=[]
def ck(name, cond, detail=''):
    checks.append((name,bool(cond),detail))

def txt(root, rel):
    return (root/rel).read_text(errors='replace')

# Identity
cb=txt(CLIENT,'android/app/build.gradle.kts')
sb=txt(SERVER,'app/build.gradle.kts')
ck('client_r55_identity', 'SWRLZ_REVISION", "\\"R55\\""' in cb and 'versionCode = 181' in cb)
ck('server_r86_identity', 'quotedBuildConfig("R86")' in sb and 'versionCode = 209' in sb)

# CLIENT notifications and controls
cn=txt(CLIENT,'android/app/src/main/java/sh/swurlz/core/notification/ToolActionNotifier.kt')
for mode in ['OFF','IMPORTANT_ONLY','MUTATIONS_APPROVALS_ONLY','TOOL_START_FINISH','DETAILED_TOOL_LIFECYCLE','DEVELOPER_DIAGNOSTIC']:
    ck(f'client_notification_mode_{mode}', mode in cn)
ck('client_safety_notifications_survive_off', 'if (isSafetyCritical(state, risk, failure) || important) return true' in cn)
cf=txt(CLIENT,'android/app/src/main/java/sh/swurlz/core/ui/client/ClientFullLogSettingsPanel.kt')
ck('client_notification_mode_ui', 'NOTIFICATION MODE · ${notificationMode.label}' in cf)
cd=txt(CLIENT,'android/app/src/main/java/sh/swurlz/core/directory/DirectoryVfsEngine.kt')
ca=txt(CLIENT,'android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt')
for state in ['REQUESTED','TARGET_ACKNOWLEDGED','EXECUTING','EVIDENCE_READY','VERIFYING','VERIFIED','COMPLETED','FAILED']:
    ck(f'client_dir_state_{state}', f'"{state}"' in cd)
ck('client_deep_dig_execution_notice', 'Deep Dig / analysis is running' in ca)

# Recovery and mutation semantics
for op in ['DELETE_COMPLETE','RECOVERY_PURGE','RECOVERY_RESTORE','RECOVERY_SCAN']:
    ck(f'client_recovery_{op}', op in cd)
ck('client_attributable_only', 'ATTRIBUTABLE_ONLY' in cd and 'attributionStrength' in cd and 'STRONG' in cd)
ck('client_recovery_provenance_exact', 'EXACT_RECOVERY_ID_AND_SOURCE_PATH' in cd)
ck('client_mutation_lock', 'withMutationLock' in cd)
cam=txt(CLIENT,'android/app/src/main/java/sh/swurlz/core/archive/ArchiveMutationEngine.kt')
ck('client_archive_mutation_lock', 'archiveMutationLock' in cam and 'synchronized(archiveMutationLock' in cam)
ck('client_append_expected_state', all(k in cd for k in ['expectedSize','expectedSha256','idempotency']))

# Client workload lanes
car=txt(CLIENT,'android/app/src/main/java/sh/swurlz/core/archive/ArchiveNodeRuntime.kt')
ck('client_workload_lanes', all(k in car for k in ['safetyDispatcher','normalDispatcher','heavyAnalysisDispatcher','limitedParallelism']))

# SERVER event fabric / SSE / redaction
sn=txt(SERVER,'app/src/main/java/sh/swrlz/nodehost/notification/ToolActionNotifier.kt')
se=txt(SERVER,'app/src/main/java/sh/swrlz/nodehost/notification/ToolActionEventBus.kt')
sm=txt(SERVER,'app/src/main/java/sh/swrlz/nodehost/mcp/SwurlzMcpRuntime.kt')
for mode in ['OFF','IMPORTANT_ONLY','MUTATIONS_APPROVALS_ONLY','TOOL_START_FINISH','DETAILED_TOOL_LIFECYCLE','DEVELOPER_DIAGNOSTIC']:
    ck(f'server_notification_mode_{mode}', mode in sn)
ck('server_unique_event_ids', 'copy.put("eventId", "$correlationId:$seq")' in se)
ck('server_action_stream_sse', 'ToolActionEventBus.eventsSince' in sm)
slog=txt(SERVER,'app/src/main/java/sh/swrlz/nodehost/logging/ServerFullLogStore.kt')
clog=txt(CLIENT,'android/app/src/main/java/sh/swurlz/core/logging/ClientFullLogStore.kt')
ck('server_central_secret_redaction', 'passphrase' in slog and 'authorization' in slog and 'REDACTED' in slog)
ck('client_central_secret_redaction', 'passphrase' in clog and 'authorization' in clog and 'REDACTED' in clog)

# Credential consolidation
forge=txt(SERVER,'app/src/main/java/sh/swrlz/nodehost/forge/ServerForgeScreen.kt')
tunnel=txt(SERVER,'app/src/main/java/sh/swrlz/nodehost/ui/SecureTunnelSettingsPanel.kt')
cred=txt(SERVER,'app/src/main/java/sh/swrlz/nodehost/ui/ServerAccountsCredentialPanel.kt')
ck('forge_no_github_token_editor', 'GITHUB FINE-GRAINED TOKEN' not in forge and 'ForgeField("RECOVERY PASSPHRASE"' not in forge)
ck('forge_status_only_credential_route', 'Manage all GitHub credential material only under Settings → Account & Credential Vault.' in forge)
ck('tunnel_no_runtime_key_editor', 'label = { Text("Tunnel runtime key") }' not in tunnel and 'saveAndStart(' not in tunnel)
ck('tunnel_status_only_credential_route', 'managed only under Settings → Account & Credential Vault' in tunnel)
ck('vault_owns_github_secret_editor', 'label = { Text("GitHub fine-grained token") }' in cred and 'VALIDATE + SAVE' in cred)
ck('vault_owns_tunnel_secret_editor', 'label = { Text("Tunnel runtime key") }' in cred and 'SAVE + START' in cred)
ck('vault_passphrase_modal', 'AlertDialog(' in cred and 'Vault recovery / unlock passphrase' in cred and 'PasswordVisualTransformation' in cred)
ck('vault_has_github_removal', 'REMOVE GITHUB CREDENTIAL' in cred and 'GitHubConnectionStore.disconnect' in cred)
ck('vault_has_tunnel_removal', 'REMOVE TUNNEL CREDENTIAL' in cred and 'tunnelViewModel.clearCredentials()' in cred)
trm=txt(SERVER,'app/src/main/java/sh/swrlz/nodehost/tunnel/SecureTunnelRuntimeManager.kt')
ts=txt(SERVER,'app/src/main/java/sh/swrlz/nodehost/tunnel/IsolatedTunnelRuntimeManager.kt')
ck('tunnel_clear_secure_storage', 'suspend fun clearCredentials()' in trm and 'ServerCredentialVault.deleteCredential' in ts and '.remove("runtimeKey")' in ts)
ck('credential_to_tunnel_auto_resume', 'ACTION_CREDENTIAL_VAULT_UNLOCKED' in cred)

# Embedded engineering input
ck('client_addendum_embedded', (CLIENT/'docs/engineering-inputs/SWRLZ_OPERATIONAL_CONTROL_V1.3_ADDENDUM_2026-08-14.txt').exists())
ck('server_addendum_embedded', (SERVER/'docs/engineering-inputs/SWRLZ_OPERATIONAL_CONTROL_V1.3_ADDENDUM_2026-08-14.txt').exists())

# MCP catalog JSON validity and operations
catalog=SERVER/'app/src/main/assets/mcp/swrlz_chatgpt_client_node_tool_catalog_v1.json'
try:
    data=json.loads(catalog.read_text())
    ck('server_mcp_catalog_json', True)
    raw=catalog.read_text()
    ck('server_mcp_recovery_ops', 'RECOVERY_PURGE' in raw and 'DELETE_COMPLETE' in raw)
except Exception as e:
    ck('server_mcp_catalog_json', False, repr(e))

fails=[c for c in checks if not c[1]]
for name, ok, detail in checks:
    print(('PASS' if ok else 'FAIL'), name, detail)
print(f'RESULT {len(checks)-len(fails)}/{len(checks)} PASS')
sys.exit(1 if fails else 0)
