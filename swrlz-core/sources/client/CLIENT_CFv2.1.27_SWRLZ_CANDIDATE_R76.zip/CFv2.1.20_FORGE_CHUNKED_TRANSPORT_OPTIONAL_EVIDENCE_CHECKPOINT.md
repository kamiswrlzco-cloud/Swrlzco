# CFv2.1.20 — Forge Chunked Transport + Optional Evidence Checkpoint

Checkpoint: `INT-FORGE-039F + INT-FORGE-039N`

CLIENT CFv2.1.20 candidate R1 introduces verified chunk transport for protected CLIENT/SERVER source ZIPs and separates **build eligibility** from **promotion evidence**.

A source ZIP is sufficient to attempt an APK build. SHA-256 and package manifest sidecars are optional evidence; when supplied, they remain strict and conflicting evidence blocks.

Large protected sources use `AUTO` chunking by default above 8 MiB. Each chunk and the whole reconstructed ZIP are SHA-256 verified. Repository CI changes required for runner-side reassembly are packaged under `repo-patches/INT-FORGE-039F-039N/` but are not committed or pushed by this checkpoint.

Android compile/build/device validation remain pending.
