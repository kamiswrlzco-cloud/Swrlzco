# INT-FORGE-064G Dual Storage Performance Implementation Report

## User-observed failures

1. Returning from the project-root picker produced a black screen for roughly five seconds.
2. Rescan repeatedly triggered Android "not responding" warnings before eventually recovering.
3. Android would not permit selecting the public Download root through the folder-tree picker.

## Root causes

- Project-root URI persistence and directory-layout creation ran from the activity-result callback on the Compose/UI thread.
- CLIENT and SERVER scans independently listed the same root and child folders, opened evidence repeatedly, and hashed large source ZIPs repeatedly.
- Automatic and manual scans had no shared single-flight boundary.
- Android 11+ deliberately restricts selecting the public Download root with `ACTION_OPEN_DOCUMENT_TREE`.

## Repair

Forge now uses direct public Downloads as the default after explicit system authorization, with a custom SAF override remaining optional. Storage-provider and hashing work runs on `Dispatchers.IO`. A mutex serializes scans, a single snapshot feeds CLIENT and SERVER classification, and a bounded identity cache avoids rehashing unchanged files during preview. Upload still performs full uncached revalidation.

## Validation

- Focused synchronized verifier: 33/33 PASS per component.
- `ForgeStoragePerformance.kt` focused Kotlin compilation: PASS per component.
- `ForgeAutomatedBuildRunner.kt` focused Kotlin compilation: PASS per component.
- Android manifest XML parse: PASS per component.
- Kotlin lexical balance for focused modified files: PASS.
- Android/Gradle compilation: NOT RUN — source-only boundary.
