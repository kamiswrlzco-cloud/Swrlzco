# INT-FORGE-064A Implementation Report

## Functional result

Both Forge implementations now classify and pair:

```text
<source>.zip
<source>_METADATA.zip
```

The metadata ZIP is validated before a protected CLIENT/SERVER source becomes commit eligible. On chunked uploads, Forge generates `chunked-git-blobs-v2`, retains the metadata ZIP as a small repository blob, and records the metadata archive and inner-entry hashes in the transport manifest.

The combined evidence archive remains uploaded as evidence while its declared repository files are expanded into exact allowlisted destinations in the same transaction. The exact shared resolver/verifier scripts are included so the existing APK Router workflow can consume schema 2 without a workflow YAML rewrite; the legacy resolver output names used by the workflow are preserved.

## Fail-closed conditions

- missing metadata ZIP and incomplete legacy sidecars;
- mismatched source, checksum, manifest, component, source size, versionCode, or revision;
- metadata archive nesting, extra entries, duplicate names, traversal, or size-limit violations;
- metadata ZIP and loose sidecars mixed for the same source;
- orphan metadata ZIP without a matching source;
- evidence archive undeclared entries targeted for expansion;
- non-allowlisted repository destinations;
- source or metadata hashes differing from transport declarations.

## Validation performed

- Python resolver fixtures (7/7): direct metadata bundle, chunked schema 2 reconstruction, legacy bootstrap, evidence-first selection, workflow-output compatibility, mismatch rejection, and candidate-revision mismatch rejection.
- Python package-pair verifier fixtures (4/4): valid bundle, modified-source rejection, candidate-revision mismatch rejection, and incomplete-evidence rejection.
- Focused Kotlin compilation of CLIENT and SERVER metadata/evidence helper classes using API stubs.
- Balanced Kotlin lexical structure check across the ten modified Forge Kotlin files.
- Python syntax compilation for resolver and package verifier.
- INT-FORGE-064A static verifier: 57/57 PASS for each component.
- Focused Forge source-resolver Kotlin section compilation: PASS for each component.
- No Gradle/APK build.

## CLIENT lineage disclosure

The accepted lineage anchor remains `CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R1.zip` with SHA-256 `7b0202c01ea2ffbf7c7a3cb50f1e635c1eb6658299abb63de78b2b78502589eb` and VC124. That byte-exact archive was not available in the active runtime. Implementation therefore used the verified CFv2.1.27 R1 descendant source as the working base and preserved its File Lab surfaces while rebasing the delivery identity to the approved CFv2.1.26 R2 / VC125 target. This is a functional descendant rebase and is not represented as a byte-exact direct-parent reconstruction.
