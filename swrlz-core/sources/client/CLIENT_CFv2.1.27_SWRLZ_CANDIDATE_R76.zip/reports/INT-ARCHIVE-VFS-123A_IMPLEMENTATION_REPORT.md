# CLIENT R19 Archive VFS implementation

CLIENT adds persistent SAF archive sources, a local ZIP/ZIP64 VFS with nested `!` traversal, bounded direct reads, streaming conversation catalog/retrieval, and a background protocol-2 archive query worker. Local URIs remain private to CLIENT.
