# INT-FORGE-064D Dual Downloads Pipeline Implementation Report

## Implemented in CLIENT and SERVER

- Downloads inbox folder slot and resolver.
- Source + metadata ZIP recognition without extraction.
- Legacy exact loose sidecar support in root or one child folder.
- CLIENT/SERVER/BOTH automatic classification and newest-valid selection.
- Exact operator-facing source/build descriptions before upload.
- Per-component build watches and source-grounded ledger entries.
- Secure actual-APK extraction and storage under the derived project name.
- Optional retention of the workflow artifact ZIP.
- Shared evidence allowlist for current workflow and root `scripts/ci` paths.
- Local source workflows that state the exact candidate and VC being built.
- Prepared root APK Router source-description patch.

## CI compatibility

The resolver reports metadata mode, source description, build description, evidence description, source transport, identity, size, hash, lane, and selection reason while retaining prior router output keys and legacy resolution modes.

## Validation boundary

Only source/static, focused Kotlin compilation, resolver fixtures, package-verifier fixtures, package-integrity, and deterministic packaging checks are authorized here. Android compilation remains the next GitHub workflow test.
