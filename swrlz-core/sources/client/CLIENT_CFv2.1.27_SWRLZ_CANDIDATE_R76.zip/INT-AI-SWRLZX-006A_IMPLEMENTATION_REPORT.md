# INT-AI-SWRLZX-006A — CLIENT R28 Implementation Report

Checkpoint 006A connects the R52/R53 SERVER V2 stream to the CLIENT chat surface without granting raw model drafts persistence or presentation authority.

## Network reader
- `CoreNodeApi.swrlzLlmChatStream()` uses Ktor `bodyAsChannel()` and bounded `readUTF8Line()` parsing on successful `application/x-ndjson` responses.
- Protocol/schema/contract/request identity is validated before an event enters the chat state machine.
- The existing V1 `swrlzLlmChat()` completed-response API remains intact as an explicit compatibility fallback.

## Stream state + rendering
- `ClientLlmStreamStateMachine` rejects sequence gaps/duplicates, request or stream identity drift, routed model/runtime identity drift, and events after a terminal event.
- RESET clears only the transient live-generation buffer.
- `ClientLlmStreamRuntime` is application-scoped and survives ordinary Activity recreation while the process remains alive.
- A conflated channel plus a 32 ms cadence limits UI publications while applying wire events in exact order first. STARTED, RESET and terminal boundaries publish immediately.
- `ClientShellScreen` renders a transient live assistant bubble and STOP control from the runtime `StateFlow`.

## Persistence/recovery behavior
- Only COMPLETED committed text is appended to `ClientChatHistoryStore`.
- `sourceRequestId` makes the terminal append idempotent across UI reattachment.
- One transport retry is allowed only before committed text. Once a DELTA has been presented, automatic replay is forbidden until a future resume-offset contract exists.
- V2 HTTP 404/405/501 uses V1 completed-chat compatibility; arbitrary failures do not silently fall back.

## Evidence boundary
Targeted Kotlin state-machine/runtime fixtures and a real localhost chunked-NDJSON trace pass. Android Gradle wrapper bootstrap is DNS-blocked before project compilation, so no APK/device-build claim is made. Target-device rotation/background, process-death resume, remote-LAN latency/throughput, thermal/power and optimized-LFM2 acceptance remain pending.
