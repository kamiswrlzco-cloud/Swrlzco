# INT-AI-SWRLZX-011A — LALM Native Architecture Execution

## Goal

Advance the SWRLZ-native **LALM (Local Adaptive Language Model)** runtime from the generic 003A reference graph to a first-party reference execution path for the LFM2-derived architecture represented by the canonical `SWRLZ-LALM-001A.§wyrlzx` conversion profile.

## Implemented source scope

- Add `swrlzx.lalm.runtime.v1`, `swrlzx.lalm.tensor_kv.v1`, `swrlzx.lalm.chat_template.v1`, `swrlzx.lalm.sampler.v1`, and `swrlzx.quant.ggml-k.v1` contracts.
- Extend the native graph with `LFM_CONV`, `GQA_ATTENTION`, `ROPE`, `GATED_MLP`, and `SAMPLE`.
- Add auditable reference implementations for RMSNorm, SiLU-gated MLP, rotate-half RoPE, short-convolution recurrent state, grouped-query causal attention, seeded temperature/top-k/repetition-penalty sampling, and tensor-valued request-owned K/V pages.
- Add BF16, Q4_K and Q6_K row decoding while preserving F32/F16/Q4_0/Q8_0 support from the previous native runtime.
- Add a GGML/GPT-2-style byte-BPE reference tokenizer and the LALM ChatML-like template contract.
- Add an 011A conversion profile that turns the exact-source GGUF metadata/tensor table into an executable 100-node SWRLZX graph rather than the imported descriptor used by 010A.
- Add an exact-source two-pass 011A bring-up runner that refuses unsupported source quantizers and leaves production selection/parity untouched.

## Authority boundaries

The model remains an advisory generator. The runtime does not gain trust, approval, mission, file, Forge, or execution authority. Draft output still passes through the streaming Truth Firewall before presentation. Unsupported operators, tokenizer requirements, quantizers, tensor shapes, model identities, and source provenance fail closed.

## Acceptance boundary

This candidate is a **source/reference implementation checkpoint**, not a claim that the canonical 229,315,680-byte optimized source has already been converted and executed in this workspace. The exact source bytes remain unavailable here, so the following stay open:

1. exact source tensor/quantizer reconciliation against the real optimized artifact;
2. canonical `SWRLZ-LALM-001A.§wyrlzx` native full-model execution;
3. exact Liquid `tokenizer.ggml.pre=lfm2` parity on the real tokenizer corpus;
4. GGUF↔LALM logit/token parity, which belongs to 012A;
5. Android/device performance, which belongs to 013A;
6. production promotion, which belongs to 014A.

## Exit status

- **Source/reference operator foundation:** implemented and host-tested.
- **Independent Q4_K/Q6_K row decoding reference comparison:** implemented and passed.
- **Canonical live-model execution exit criterion:** **OPEN pending exact source bytes and 012A parity evidence.**
- **GGUF rollback:** preserved.
