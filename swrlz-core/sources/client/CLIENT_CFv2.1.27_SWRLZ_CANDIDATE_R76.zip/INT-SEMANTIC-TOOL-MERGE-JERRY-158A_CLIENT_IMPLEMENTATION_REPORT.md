# INT-SEMANTIC-TOOL-MERGE-JERRY-158A — CLIENT Implementation Report

## Identity

- Component: CLIENT
- Candidate: R65
- versionCode: 191
- versionName: `2.1.27-semantic-clarification-jerry-r65`
- Primary parent: CLIENT R64 `f78a354060986225f304c893d90dd4c619af13ce9824bdd26ebb3fbfb0bcf3e8`
- Sibling target: SERVER R100 / VC223
- Checkpoint: `INT-SEMANTIC-TOOL-MERGE-JERRY-158A`

## Goal

Preserve the completed R64 routed tool-executor behavior while making SERVER R100's clarification and Jerry/self-preservation phases explicit in the client chat/status presentation.

## Implemented changes

- `ClientLlmStreamStateMachine` recognizes `PAUSED_FOR_CLARIFICATION`, `CLARIFICATION_WAIT`, and `SEMANTIC_CLARIFICATION` as an awaiting-clarification state.
- `SELF_PRESERVATION_BLOCKED` is surfaced as `SELF-PRESERVATION BLOCKED`.
- `UNDERSTOOD_NOT_EXECUTABLE` is surfaced as `UNDERSTOOD · NOT EXECUTABLE`.
- A completed streaming turn that is waiting on clarification is labeled `§WYRLZ · NEEDS DETAIL` rather than ordinary completion.
- The chat shell explicitly states that clarification supplies missing meaning only; it does not approve or execute a tool action.

## Preserved R64 behavior

The R64 durable inbox normalization remains intact, including allowlisted generic TOOL/MISSION envelope routing to Archive/Directory/Log VFS, selected archive repack routing, explicit unsupported-envelope errors, exact destructive-plan safety, Forge live inbox behavior, admin log pulling and LALM stress scheduling.

## Protocol boundary

No new transport event type was required. The existing V2 stream already carries generic STATUS/ROUTE/DELTA/COMPLETED events and SERVER phase strings. SERVER R100 can stream a clarification question as DELTA and terminate the turn in `CLARIFICATION_WAIT`; the next user message on the same conversation/thread can be consumed by the server's bounded resume state.

## Truth boundary

This is a source/host-syntax-validation candidate. APK compilation, installation, device regression, deployment and production promotion are not claimed without external evidence.
