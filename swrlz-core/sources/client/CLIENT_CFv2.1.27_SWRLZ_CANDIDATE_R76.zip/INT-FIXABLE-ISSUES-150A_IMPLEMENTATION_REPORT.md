# INT-FIXABLE-ISSUES-150A — CLIENT R58 Implementation Report

## Scope
Parent: CLIENT R57 / VC183 / SHA-256 `9f7e52d25c377c872ce7b7a0042d65c56ad9935047273d8d5ef13f306dd82797`.
Pair target: SERVER R90 / VC213.
Input register: `SWRLZ_Fixable_Issues_Register_2026-08-15.docx`.

This checkpoint repairs source-contained CLIENT issues and adds executable research/recovery evidence. It does **not** claim that every item in the register is resolved, and it does not convert static/host evidence into Android build/device evidence.

## Repairs implemented

### 1. Android Downloads file/archive-object deletion authority
- `android-downloads` remains a user-toggleable built-in root; no impossible SAF root-Download picker is used.
- When enabled, `effectiveAuthority()` now requires Android All Files access, an existing canonical Downloads root, `canRead()`, and `canWrite()` before advertising authority.
- The built-in grant may advertise `writeAllowed=true` only when the live filesystem is actually writable.
- `recoveryEnabled` remains false for this broad root.
- Directory destructive operations remain exact-plan bound; no storage permission becomes mutation approval.
- Direct filesystem recursive deletion verifies absence after the operation.
- Toggling Downloads pushes a best-effort immediate presence/authority heartbeat instead of relying only on the next periodic heartbeat.

### 2. E-01 / E-04 / E-05 — resumable conversation-only research harness
`tools/resumable_archive_body_scan.py`:
- accepts ZIP/ZIP64 conversation exports;
- allowlists only canonical conversation shard names;
- never opens unrelated/media payloads;
- writes an atomic per-shard immutable receipt after every completed shard;
- stores archive fingerprint, shard content SHA-256, high-water ordinal and digest chain;
- emits `INDEX_READY`, `BODY_PARTIAL`, and `BODY_RECONCILED` coverage states;
- resumes only when the archive fingerprint and prior receipts reconcile.

`tools/test_resumable_archive_body_scan.py` interrupts after every one of 25 synthetic shard boundaries and proves the resumed merged metrics/digest chain equals uninterrupted execution.

### 3. C-02 / U-04 — process-death-safe stream presentation
New `ClientLlmStreamRecoveryStore` uses Android `AtomicFile` for a minimal active-stream journal.
- active/partial stream state is checkpointed periodically and on significant/terminal transitions;
- process restart reconciles prior `COMPLETED` records idempotently into chat history;
- non-terminal records become explicit `RECOVERABLE_PARTIAL` or `INTERRUPTED_PROCESS_RESTART` failed presentation states;
- partial text is never inserted as a normal completed assistant turn;
- failed/cancelled text is labeled `PARTIAL COMMITTED PREFIX · NOT A COMPLETED TURN`.

This does not implement the cross-transport V3 byte/token resume contract from C-01; that remains separate.

### 4. C-03 partial durability hardening
CLIENT chat-history snapshot replacement now uses `AtomicFile` and backup-aware reads. This closes the prior temp/rename/fallback crash-loss window, but it **does not** eliminate whole-history write amplification. Room/append-only migration remains open.

## Preserved boundaries
- R57/R88 semantic approval-mode repair remains required and unchanged.
- Directory write permission, capability, local grant, fresh live mutation plan, exact approval hash and final CLIENT revalidation remain distinct.
- Built-in Downloads does not receive recovery/trash purge authority.
- No unrelated user files are deleted automatically.

## Evidence
- Host research harness: 25/25 hostile interruption/resume boundaries PASS.
- Static/source verifier: see `INT-FIXABLE-ISSUES-150A_STATIC_VALIDATION.txt`.
- Prior operational-control verifier is rerun separately.
- Android Gradle/APK/device evidence remains separate and is not claimed by this report.
