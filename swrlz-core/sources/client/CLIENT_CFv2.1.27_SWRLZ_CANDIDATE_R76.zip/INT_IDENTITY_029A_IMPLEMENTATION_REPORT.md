# INT-IDENTITY-029A Implementation Report

**Date:** 2026-07-23  
**Scope:** Reinstall-safe CLIENT/SERVER logical device continuity

## Files Changed

### CLIENT
- `android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt`
- `android/app/build.gradle.kts`
- `CHANGELOG.md`
- `docs/protocol/PROTOCOL_HISTORY.md`
- `docs/architecture/ADR-0018_REINSTALL_SAFE_DEVICE_CONTINUITY.md`
- `docs/releases/CLIENT_CFv2.0.23.md`

### SERVER
- `app/src/main/java/sh/swrlz/nodehost/service/NodeRegistrationProtocol.kt`
- `app/src/main/java/sh/swrlz/nodehost/service/NodeRuntime.kt`
- `app/src/main/java/sh/swrlz/nodehost/data/dao/NodeEntityDao.kt`
- `app/src/main/java/sh/swrlz/nodehost/data/repository/NodeRepository.kt`
- `app/build.gradle.kts`
- `CHANGELOG.md`
- `docs/protocol/PROTOCOL_HISTORY.md`
- `docs/architecture/ADR-0018_REINSTALL_SAFE_DEVICE_CONTINUITY.md`
- `docs/releases/SERVER_CFv2.0.20.md`

## Behavior

A matching recovery digest maps a fresh installation back to the existing canonical node. The new
installation ID is added to lineage. Recovery does not bypass trust: absent proof, trust becomes
`UNTRUSTED` and reapproval is required.

## Verification Status

- **Verified:** source payload no longer sends raw `ANDROID_ID` in protocol v2.
- **Verified:** legacy digest derivation remains byte-for-byte compatible.
- **Verified:** SERVER lookup/upsert/archive is wrapped in a Room transaction.
- **Not executed:** Gradle tests, because wrapper distributions were unavailable locally and outbound
  network resolution was unavailable.
