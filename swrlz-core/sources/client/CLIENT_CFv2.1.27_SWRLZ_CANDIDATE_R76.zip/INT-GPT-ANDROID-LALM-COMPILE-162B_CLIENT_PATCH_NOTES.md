# INT-GPT-ANDROID-LALM-COMPILE-162B — CLIENT R70

Parent: CLIENT R69 (`45f8c5f30475bd70fffbeafcf1a91cf1929ea8f95d3183265c78d07c0b3869a4`)
Paired SERVER: R104 / VC227

## Fix
Auto Forge reached `:app:compileDebugKotlin` and reported `ClientLalmNodeJobRuntime.kt:116:52 Unresolved reference isActive`.
R70 adds `import kotlinx.coroutines.isActive`, which is the extension required by `currentCoroutineContext().isActive` in the cancellation path.

## Preservation
No GPT→Android LALM runtime semantics are changed. R69 durable inbox routing, ACK/NODE_ACK, RUNNING/INFERENCE_STARTED, terminal correlation, cancellation, reasoning capability advertising, and R68 account/import/Observatory behavior remain intact.
