# CLIENT CFv2.0.50 — Forge Reliability and Workflow Logs Checkpoint

## Implemented

- Repeated uploads replace staged files that target the same repository path instead of retaining duplicate destination entries.
- Successful uploads clear staging only after GitHub branch-head confirmation.
- Forge does not report 100% completion until the selected branch resolves to the newly created commit.
- GitHub credentials are synchronously persisted in Android Keystore-backed encrypted preferences.
- Temporary GitHub/network verification failures no longer delete a saved credential.
- Each workflow card can download the GitHub Actions run log archive as a ZIP.
- Existing source ZIP/SHA-256 auto-matching remains enabled by default.

## Security

Workflow logs are user-initiated downloads. GitHub credentials remain in encrypted preferences and are not included in exported logs by SWRLZ.

## Verification

Static source checkpoint packaged with matching SHA-256. Clean Android compilation and device behavior require Forge/Android verification.
