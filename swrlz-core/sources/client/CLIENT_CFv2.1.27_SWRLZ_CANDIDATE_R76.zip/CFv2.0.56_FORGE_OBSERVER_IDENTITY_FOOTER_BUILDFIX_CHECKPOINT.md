# CLIENT CFv2.0.56 — Forge Observer, Identity, Footer, and Build Repair

**Version:** CFv2.0.56  
**Android:** versionCode 83 / versionName `2.0.56-forge-observer-identity-footer-buildfix-v1`

## Scope

- Repairs the CFv2.0.55 Kotlin compiler failure by converting the notified-outcome set to a list before bounded `takeLast` retention.
- Refreshes workflow state every 2 seconds while a run is active and every 5 seconds while idle.
- Polls immediately after an upload until GitHub exposes a workflow associated with the verified commit SHA.
- Displays all active workflow runs plus a user-adjustable 2–20 completed-run history, defaulting to 4.
- Collapses duplicate cards sharing workflow name, head SHA, and event.
- Adds persistent `CLIENT · CFv2.0.56` / versionCode footers to User and Developer main interfaces.
- Rebuilds theme launcher families from the current cyan crystal-dragon identity instead of legacy theme artwork.
- Makes CLIENT, remote SERVER, and fusion bubble icons follow Theme Armor and refreshes the interactive dock in place.

## Evidence boundary

Source structure, resource mappings, ZIP integrity, and checksum pairing are statically verified. GitHub APK compilation, launcher cache behavior, theme-switch behavior, bubble refresh, and workflow observer timing remain device/CI acceptance gates.
