# CLIENT CFv1.0.2 — Ktor Compatibility Repair

## Source lineage

- Predecessor: `CLIENT_CFv1.0.1_SWRLZ.zip`
- Successor: `CLIENT_CFv1.0.2_SWRLZ.zip`
- Android runtime identity remains `0.2.7.6-cf8-admin-fallback` / versionCode `30`.

## Bounded source correction

The Ktor 2.3.12-compatible request path in `Api.kt` is:

```kotlin
response.call.request.url.encodedPath
```

This replaces the non-compiling direct `response.request` access while preserving route-specific HTTP error reporting.

## Packaging correction

The canonical archive root and source metadata now use `CLIENT_CFv1.0.2_SWRLZ`. No SERVER, CORE_BASE, LAUNCHER_BASE, KEYBOARD_BASE, trust, identity, mission, Truth Firewall, release, deployment, or installation behavior is changed.
