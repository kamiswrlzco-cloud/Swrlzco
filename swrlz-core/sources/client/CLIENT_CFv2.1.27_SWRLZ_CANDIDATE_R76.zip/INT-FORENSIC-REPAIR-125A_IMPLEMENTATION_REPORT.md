# INT-FORENSIC-REPAIR-125A — CLIENT R21 implementation report

The repair focuses on cross-subsystem integrity rather than feature expansion. The most consequential change is that Forge idempotency is now content-addressed: the transaction fingerprint incorporates SHA-256 of every staged file. A reused URI with same-size changed bytes therefore cannot inherit an earlier transaction marker.

Repository reconciliation now treats `commit found + path verification failed` as a mismatch, not a degraded success. Repository move/delete retries also preserve optimistic concurrency by rechecking the exact source SHA and destination absence after each refreshed branch-head read.

GitHub Actions artifact/log transport is moved off heap-backed `ByteArray` paths. Downloads stream into app cache with bounded size, incremental SHA-256, declared-length verification, and file descriptor sync. APK extraction enumerates/validates first, selects one APK, then streams just that entry to a temporary file. Save and update handoff paths stream from files.

The CLIENT build identity bug found during review is repaired: R20's Gradle file still exposed the R19 patch label/build line/source ZIP even though the outer package was R20. R21 advances all visible runtime identity fields together.
