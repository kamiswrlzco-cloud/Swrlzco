#!/usr/bin/env python3
from pathlib import Path
import json, sys, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def t(rel): return (ROOT/rel).read_text(errors='replace')

build=t('android/app/build.gradle.kts')
grants=t('android/app/src/main/java/sh/swurlz/core/directory/DirectoryGrantStore.kt')
vfs=t('android/app/src/main/java/sh/swurlz/core/directory/DirectoryVfsEngine.kt')
presence=t('android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt')
recovery=t('android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamRecoveryStore.kt')
runtime=t('android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamRuntime.kt')
history=t('android/app/src/main/java/sh/swurlz/core/data/ClientChatHistoryStore.kt')
ui=t('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt')
harness=t('tools/resumable_archive_body_scan.py')
harness_test=t('tools/test_resumable_archive_body_scan.py')

ck('CLIENT R58 identity', 'versionCode = 184' in build and '2.1.27-fixable-issues-phase1-r58' in build and 'INT-FIXABLE-ISSUES-150A' in build and 'SWRLZ_REVISION' in build and 'R58' in build)
ck('Downloads built-in grant can expose write intent', 'ANDROID_DOWNLOADS_GRANT_ID' in grants and 'writeAllowed = true' in grants and 'recoveryEnabled = false' in grants)
ck('Downloads live write authority requires All Files plus filesystem canWrite', 'androidDownloadsEnabled(context) && hasAllFilesAccess() && root.exists() && root.isDirectory' in grants and 'writable = available && root.canWrite()' in grants)
ck('Downloads advertisement reports effective writable not a constant', '.put("writeAllowed", authority.writable)' in grants and '.put("builtInAndroidDownloads", true)' in grants)
ck('Directory destructive permission remains plan-bound', 'approvalPlanHash' in vfs and 'approvalDecision' in vfs and 'MUTATION_PLAN' in vfs)
ck('Directory delete recursively verifies absence', 'private fun deleteNode' in vfs and 'VERIFIED_ABSENT' in vfs and 'DELETE_UNVERIFIED' in vfs)
ck('Authority toggle pushes immediate best-effort advertisement', 'fun refreshAdvertisements' in presence and 'authority_advertisement_refresh' in presence and 'ClientPresenceRegistration.refreshAdvertisements(context)' in ui)
ck('LALM process recovery store uses AtomicFile', 'object ClientLlmStreamRecoveryStore' in recovery and 'AtomicFile' in recovery and 'active-streams-v1.json' in recovery)
ck('Nonterminal process restart is never normal completion', 'RECOVERABLE_PARTIAL' in runtime and 'INTERRUPTED_PROCESS_RESTART' in runtime and 'was not added to normal history' in runtime)
ck('Completed recovery is history-idempotent', 'alreadyCommitted' in runtime and 'appendAssistantMessage' in runtime and 'ClientLlmStreamRecoveryStore.remove' in runtime)
ck('Stream journal checkpointing is bounded', 'charsAdvanced >= 2_048' in runtime and 'timeAdvanced >= 2_000L' in runtime and 'checkpointIfNeeded' in runtime)
ck('CLIENT shell restores stream journal on launch', 'ClientLlmStreamRuntime.restore(context)' in ui)
ck('Incomplete partial text is visibly distinguished', '§WYRLZ · INCOMPLETE' in ui and 'PARTIAL COMMITTED PREFIX · NOT A COMPLETED TURN' in ui)
ck('CLIENT chat history uses AtomicFile replacement and backup read', 'AtomicFile(source).openRead()' in history and 'atomic.startWrite()' in history and 'CLIENT_CHAT_HISTORY_COMMIT_FAILED' in history)
ck('Research harness has per-shard atomic receipts', 'receipt' in harness.lower() and 'atomic_write_json' in harness and 'highWaterShardOrdinal' in harness)
ck('Research harness coverage truth states exist', all(x in harness for x in ['INDEX_READY','BODY_PARTIAL','BODY_RECONCILED']))
ck('Research harness allowlists conversation shards', 'conversations.json' in harness and 'SHARD_RE' in harness and 'attachment' in harness.lower())
ck('Host hostile resume test covers 25 boundaries', '25' in harness_test and 'stop_after_shards=1' in harness_test)
ck('Status report records unresolved boundaries', (ROOT/'FIXABLE_ISSUES_STATUS_150A.json').exists() and 'OPEN_STREAM_V3' in t('FIXABLE_ISSUES_STATUS_150A.json'))

json_bad=[]
for p in ROOT.rglob('*.json'):
    try: json.loads(p.read_text(errors='strict'))
    except Exception as e: json_bad.append((str(p.relative_to(ROOT)),str(e)))
ck('all JSON valid', not json_bad)
xml_bad=[]
for p in (ROOT/'android/app/src/main').rglob('*.xml'):
    try: ET.parse(p)
    except Exception as e: xml_bad.append((str(p.relative_to(ROOT)),str(e)))
ck('Android XML valid', not xml_bad)
mods=[build,grants,vfs,presence,recovery,runtime,history,ui,harness]
ck('no merge conflict markers', not any('<<<<<<<' in x or '>>>>>>>' in x for x in mods))

for n,c in checks: print(('PASS' if c else 'FAIL'), n)
print(f'RESULT {sum(c for _,c in checks)}/{len(checks)}')
if json_bad: print('JSON_BAD',json_bad[:10])
if xml_bad: print('XML_BAD',xml_bad[:10])
sys.exit(0 if all(c for _,c in checks) else 1)
