# INT-FORGE-LIVE-INBOX-AUTOSELECT-154A — CLIENT R63

Date: 2026-08-15

## Trigger
Live Forge screenshots showed the installed SERVER Forge continuing to auto-select CLIENT R59 / SERVER R92 while newer source + metadata bundles had been delivered. The displayed R59/R92 pair itself was valid; the stale selection was the defect.

## Root cause
Forge auto-selection was event-bound rather than inbox-bound. CLIENT performed a one-shot scan when the Forge composable was created. SERVER rescanned only when Forge layout/target state changed. Downloading a new candidate while Forge remained composed or returning from ChatGPT did not mutate either trigger, so the prior `ForgeProjectDiscovery` could remain cached indefinitely.

The delivered R62/R95 metadata bundles were separately checked against the strict R91-era metadata contract: each bundle contained exactly the canonical `.sha256` and `.manifest.json` root entries, and source filename/SHA-256/size all reconciled. No metadata schema change caused this stale-selection symptom.

## Repair
- Adds `ForgeSourceResolver.inboxFingerprint()` based only on relevant Download entry logical name, size, modified time and URI.
- Forge watches that lightweight fingerprint every 2 seconds while automatic latest-source selection is enabled and the Forge UI is idle.
- Source ZIP bodies are not re-hashed merely because the timer fires. A full discovery scan runs only when the fingerprint changes; the existing hash cache remains advisory and pre-upload revalidation remains uncached.
- Changing build target restarts the watcher and forces a fresh discovery for that target.
- A newer-looking rejected source now creates a blocking conflict rather than silently allowing Forge to fall back to an older valid revision. The exact existing rejection text is surfaced to the operator.
- Active checkpoint index is synchronized to R63 so package documentation no longer advertises R59 as current inside the newer source candidate.

## Safety / truth boundaries
- Filename/revision appearance is not verification; source SHA-256 + strict metadata remain authoritative.
- Automatic rescanning does not upload, build, delete, move or mutate Downloads content.
- The watcher pauses source switching while Forge is busy with an active operation.
- Existing R62 LALM stress/queue/cancellation behavior and R61 archive/log/approval behavior are preserved.

## Build evidence boundary
Source/static validation is performed in this checkpoint. Android APK compilation and live-device regression remain separate acceptance evidence.
