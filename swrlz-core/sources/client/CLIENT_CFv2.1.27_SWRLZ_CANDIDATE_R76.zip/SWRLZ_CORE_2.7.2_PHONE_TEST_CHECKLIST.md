# SWRLZ-Core 2.7.2 Phone Test Checklist

## Identity

- [ ] App shows `0.2.7.2-signal-polish`.
- [ ] Version code is `15`.
- [ ] Patch shows `2.7.2-SIGNAL-POLISH`.
- [ ] Source shows `SWRLZ_CORE_2.7.2_SIGNAL_POLISH_SOURCE.zip`.

## Style / Options

- [ ] Style tab opens.
- [ ] Original Core theme can be selected.
- [ ] Pharaoh Gold theme can be selected.
- [ ] Glitch Teal theme can be selected.
- [ ] Dark/Sunlight mode selection persists after leaving screen.
- [ ] Animation/Text/Card selections persist.
- [ ] Active tab highlight is visibly stronger.

## Auto Device Presence

- [ ] App auto-fills/stores Device ID.
- [ ] App auto-fills/stores Device Key.
- [ ] Style screen shows this device identity.
- [ ] Rotate ID works.
- [ ] Forget ID regenerates identity.
- [ ] Node Heartbeat toggle persists.

## Radar

- [ ] Core Node URL saved.
- [ ] Refresh Radar works.
- [ ] Auto Register / Heartbeat works.
- [ ] This device shows online after heartbeat.
- [ ] Second phone appears as second device when using different device ID.
- [ ] Packet send still works.
- [ ] Pull queue still works.
- [ ] DISPLAY / ACK / COMPLETE lifecycle still works.
