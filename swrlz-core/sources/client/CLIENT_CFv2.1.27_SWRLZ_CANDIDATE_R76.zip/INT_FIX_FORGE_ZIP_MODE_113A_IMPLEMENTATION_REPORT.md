# INT-FIX-FORGE-ZIP-MODE-113A — CLIENT R12 Forge ZIP Mode Repair

## Failure evidence

GitHub Actions workflow `31268220792`, job `Build CLIENT APK`, successfully resolved and SHA-verified `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R11.zip`. The build then failed before Gradle project discovery. `find` reported `Permission denied` for the extracted root children and the router exited 65 with `No Android Gradle project root found`.

Inspection of R11 ZIP external attributes confirmed 189 directory entries were encoded with Unix mode `0600`. Directories require an execute/traverse bit; preserving `0600` during unzip made descendants inaccessible.

## R12 repair

1. Preserve the R11 Kotlin suspend-boundary repair unchanged.
2. Repackage the full source tree with directory entries encoded as Unix `0755`.
3. Preserve readable regular-file modes and existing executable bits.
4. Verify there are zero non-traversable directory entries in the canonical R12 ZIP.
5. Advance Android identity to VC138 / `2.1.27-forge-zip-mode-repair-r12`.

## Shared router hardening

Repository `kamiswrlzco-cloud/Swrlzco` commit `0bb7cbc46e06f36ec36804d13d35631fa035a41b` updates `swrlz-core/tools/ci/build_swrlz_component.sh` to normalize extracted source permissions using `chmod -R u+rwX,go+rX` before Android Gradle root discovery. This prevents future valid source archives from failing solely because ZIP mode metadata encoded non-traversable directories.

## Signing continuity note

The APK Router already supports stable development signing through the four `SWRLZ_DEV_KEYSTORE_*` GitHub Actions secrets. Workflow evidence shows those values were absent for the SERVER R33 run, so the build used `runner/default-source-signing`. Stable OAuth package/SHA-1 identity therefore still requires provisioning the existing signing secrets; this source repair does not embed a private signing key.

## Acceptance boundary

R12 is a source/package repair with static/package validation. The next GitHub Actions Android build remains authoritative for compilation and APK production.
