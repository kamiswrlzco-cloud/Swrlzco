# CLIENT CFv2.0.44 — Canonical Identity + Forge UX

Implemented:
- Canonical wordless cyan SWRLZ launcher identity across default and Glitch Dragon aliases.
- True-alpha launcher, adaptive foreground, bubble/person, and branded identity assets.
- Dedicated monochrome notification small icon.
- Correct cyan CLIENT status/bubble artwork and fused SWURVER admin artwork.
- GitHub Forge entry in the normal USER interface Settings screen.
- Workflow auto-refresh every five seconds while Forge is open.
- Theme-aware workflow cards: warning while queued/running, success on completion, danger on failure.
- Artifact action automatically downloads when a run exposes one valid artifact; otherwise it opens the artifact list.
- Existing upload percentage, elapsed timestamps, and artifact timestamps preserved.

Static verification:
- ZIP/resource paths checked.
- Kotlin delimiter counts balanced.
- Full Gradle compilation unavailable because the wrapper requires the Gradle 8.7 distribution from the network.
