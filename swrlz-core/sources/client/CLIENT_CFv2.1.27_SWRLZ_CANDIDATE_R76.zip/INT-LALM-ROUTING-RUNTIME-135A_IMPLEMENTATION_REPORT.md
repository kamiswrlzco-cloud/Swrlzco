# INT-LALM-ROUTING-RUNTIME-135A — CLIENT Implementation Report

## Candidate

- CLIENT CFv2.1.27 R45 / VC171
- Parent: R44 / `cf945429cfbb3e6f2c2890407848047b2cb33ab9c76b04124221ca94fdc05223`
- Sibling: SERVER R73

## Field failure addressed

R44 successfully reconciled registration and heartbeat over the co-resident loopback SERVER, but `CoreNodeApi.connection()` continued to read only the configured Core Node URL. The captured Chat stream therefore attempted the stale LAN endpoint even though presence was healthy on loopback.

## Implementation

- `ClientPresenceRegistration.operationalBaseUrl()` chooses the fresh ONLINE `lastServerBaseUrl` as a temporary operational endpoint.
- `CoreNodeApi` resolves all Core operations through that central operational endpoint.
- Configured URL remains persistent preference/fallback and is not silently overwritten.
- `ClientLlmStreamRuntime` logs `stream_endpoint_resolved` before stream collection.

## Boundary

This fixes CLIENT transport routing only. It does not claim that SERVER native LALM interactive inference is production-speed.
