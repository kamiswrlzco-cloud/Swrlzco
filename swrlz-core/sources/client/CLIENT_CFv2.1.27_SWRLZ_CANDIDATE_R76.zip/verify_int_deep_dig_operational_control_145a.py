from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parent
checks=[]
def check(name, cond):
    checks.append((name,bool(cond))); print(('PASS' if cond else 'FAIL')+' | '+name)
def text(rel): return (ROOT/rel).read_text(errors='replace')

build=text('android/app/build.gradle.kts')
engine=text('android/app/src/main/java/sh/swurlz/core/archive/ArchiveVfsEngine.kt')
deep=text('android/app/src/main/java/sh/swurlz/core/archive/ArchiveDeepDig.kt')
intel=text('android/app/src/main/java/sh/swurlz/core/archive/ArchiveCorpusIntelligence.kt')
mut=text('android/app/src/main/java/sh/swurlz/core/archive/ArchiveMutationEngine.kt')
dirv=text('android/app/src/main/java/sh/swurlz/core/directory/DirectoryVfsEngine.kt')
logs=text('android/app/src/main/java/sh/swurlz/core/logging/ClientFullLogStore.kt')
notify=text('android/app/src/main/java/sh/swurlz/core/notification/ToolActionNotifier.kt')
settings=text('android/app/src/main/java/sh/swurlz/core/ui/client/ClientFullLogSettingsPanel.kt')
ledger=text('android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt')

check('CLIENT R54 / VC180 build identity', all(x in build for x in ['versionCode = 180','2.1.27-deep-dig-control-r54','SWRLZ_REVISION", "\\"R54\\"','INT-DEEP-DIG-OPERATIONAL-CONTROL-145A']))
check('Corpus aggregate and seedless neologism operations are dispatched', all(x in engine for x in ['"CORPUS_AGGREGATE" -> corpusAggregate','"NEOLOGISM_ANALYZE" -> neologismAnalyze']))
check('Corpus aggregation reports role totals and transparent estimates', all(x in intel for x in ['sms160Equivalents','estimatedModelTokens','lexicalTokens','userVsAssistant']))
check('Neologism analysis records mutual adoption and first/last evidence', all(x in intel for x in ['MUTUALLY_ADOPTED_NEOLOGISM_FAMILY','mutualAdoption','firstAppearance','lastAppearance','PROBABLE_TYPO_OR_ONE_OFF']))
check('Strong neologism labels require creative/family evidence', 'creativeEvidence' in intel and 'score >= 0.72 && mutual && creativeEvidence' in intel and 'score >= 0.62 && creativeEvidence' in intel)
check('Near-family merge is bounded', 'take(350)' in intel and 'levenshteinAtMostOne' in intel)
check('Fuzzy search prepares each message once and token-compares short seeds', all(x in deep for x in ['PreparedText(text)','fuzzyTokens','FUZZY_TOKEN','for (candidate in text.fuzzyTokens)']))
check('Deep Dig query fingerprint includes date/morphology analysis dimensions', all(x in deep for x in ['analysisKind','fromDate','toDate','timezoneOffsetMinutes','minOccurrences','familyLimit']))
check('Date bounds normalize epoch seconds and support YYYY-MM-DD', all(x in engine for x in ['SECONDS_NORMALIZED','LocalDate.parse(fromDate)','LocalDate.parse(toDate)','DEEP_DIG_DATE_RANGE_INVALID']))
check('Directory exposes read-only mutation planning and hard live-plan approval', all(x in dirv for x in ['"MUTATION_PLAN" -> mutationPlan','approvalPlanHash','approvalDecision','DESTRUCTIVE_APPROVAL_STALE']))
check('Large directory destructive planning fails closed if full inventory is unavailable', 'DESTRUCTIVE_SCOPE_VERIFY_LIMIT' in dirv and 'exceeds the bounded verification inventory' in dirv)
check('Directory APPEND_TEXT has stale guards, idempotency and exact length verification', all(x in dirv for x in ['"APPEND_TEXT" ->','expectedSize','expectedSha256','idempotencyKey','APPEND_VERIFY_FAILED','idempotencyReceiptDurable']))
check('Unsafe append whole-file fallback is refused', 'APPEND_UNSUPPORTED' in dirv and 'whole-file replacement fallback is intentionally not used' in dirv)
check('Archive mutations require live plan hash and treat replacement as whole archive', all(x in mut for x in ['swrlz-archive-mutation-plan-v1','wholeArchiveReplacement','requiresDoubleVerification','ARCHIVE_DESTRUCTIVE_APPROVAL_STALE']))
check('CLIENT tool-action notifications exclude hidden reasoning/secrets by contract', 'Hidden reasoning and credential material are excluded' in notify and 'VISIBILITY_PRIVATE' in notify)
check('CLIENT logger has TOOLS analysis/authority controls', all(x in logs for x in ['ClientLogMenuSpec("TOOLS"','"ANALYSIS"','"AUTHORITY"']))
check('CLIENT Settings exposes live tool-action notification toggle', 'Live tool-action notifications' in settings and 'ToolActionNotifier.setEnabled' in settings)
check('R54 Update Ledger records Deep Dig + operational control checkpoint', all(x in ledger for x in ['revision = "R54"','CORPUS_AGGREGATE','NEOLOGISM_ANALYZE','APPEND_TEXT','approvalPlanHash']))
check('Engineering input declaration/addendum embedded', (ROOT/'docs/engineering-inputs/SWRLZ_DESTRUCTIVE_ACTION_SAFETY_DECLARATION_2026-08-14.md.txt').is_file() and (ROOT/'docs/engineering-inputs/SWRLZ_OPERATIONAL_CONTROL_ADDENDUM_v1.3_2026-08-14.docx').is_file())
failed=[n for n,ok in checks if not ok]
print(f'RESULT | {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    print('FAILED:',*failed,sep='\n - '); sys.exit(1)
