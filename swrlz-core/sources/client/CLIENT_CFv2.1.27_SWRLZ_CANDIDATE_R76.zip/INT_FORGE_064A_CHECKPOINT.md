# INT-FORGE-064A — Source/Metadata Bundle + Workflow Resolver Bootstrap

Component: CLIENT
Candidate: `CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R2`
versionCode: `125`
versionName: `2.1.26-forge-metadata-bundle-candidate-r2`

Status: SOURCE CANDIDATE

## Approved scope implemented

- Automatic CLIENT and SERVER source-ZIP pairing with one metadata ZIP containing checksum + manifest.
- Selection-order independence: source, metadata, and combined evidence archives may be selected together or separately before commit.
- Strict metadata archive inspection and source/checksum/manifest cross-verification.
- Protected metadata and evidence archives excluded from generic source-ZIP classification and generic archive expansion.
- Combined evidence archive with hash-verified, allowlisted repository documentation and exact CI resolver/verifier updates.
- Chunk transport schema 2 binding the source reconstruction to its metadata bundle.
- Direct-source and chunked-source workflow resolution using the same evidence-first contract.
- Output-compatible shared resolver fields retained for the existing APK Router workflow.
- Complete legacy loose checksum + manifest support retained for the one-time bootstrap path.

## Preserved boundaries

- No GitHub write or workflow was triggered.
- No Gradle or APK build was run.
- No installation, promotion, release, or deployment occurred.
- CLIENT/SERVER runtime protocol behavior outside Forge packaging was not changed.
- Existing source archives and historical checkpoint documents remain present.

## Validation level

Source/static validation only. Focused Kotlin helper compilation and resolver/verifier fixture tests were run. Android Gradle compilation and device acceptance remain external checkpoints.

## CLIENT lineage disclosure

The accepted lineage anchor remains `CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R1.zip` with SHA-256 `7b0202c01ea2ffbf7c7a3cb50f1e635c1eb6658299abb63de78b2b78502589eb` and VC124. That byte-exact archive was not available in the active runtime. Implementation therefore used the verified CFv2.1.27 R1 descendant source as the working base and preserved its File Lab surfaces while rebasing the delivery identity to the approved CFv2.1.26 R2 / VC125 target. This is a functional descendant rebase and is not represented as a byte-exact direct-parent reconstruction.
