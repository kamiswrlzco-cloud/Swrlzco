# CLIENT CFv2.0.72 — Mission Control, Companion, and Gemini Onboarding

Recorded: 2026-07-25

## Implemented
- Added first-class `MISSION_STOP`, `MISSION_PAUSE`, and `MISSION_RESUME` chat intents so mission control is handled locally before any LLM consultation.
- Added a Mission HUD STOP control and preserved Take Over / observe-only behavior.
- Added a Volume Up + Volume Down safety chord through the enabled AccessibilityService; holding both for ~2.2 seconds pauses an active mission and publishes the pause into Chat.
- Mission HUD automatically collapses to its draggable puck while SWRLZ is actively executing, reducing overlay interference with target UI.
- Missions launched from the Android chat bubble finish the expanded bubble activity so SWRLZ can continue against the target app while the conversation bubble remains available.
- Improved accessibility scrolling by choosing the largest visible scrollable container before falling back to a longer viewport swipe, improving Settings-style navigation.
- Repaired the Chat companion rendering by removing whole-bitmap tinting of the dragon art. The full-color dragon is now clipped as a circular companion with a complementary theme border/status rail.
- When a knowledge request could benefit from outside reasoning and Gemini is not configured, SWRLZ now asks whether to connect Gemini and provides a secure API-key dialog on approval.

## Acceptance gates
1. Verify the GitHub Android build.
2. Start a mission and hold Volume Up + Volume Down for 2–3 seconds; mission must pause without invoking Gemini.
3. Say “stop mission” while running/paused; mission must terminate and HUD close.
4. Confirm STOP is available directly in Mission HUD.
5. Start a mission from the expanded bubble and confirm bubble content closes before device execution.
6. Confirm Mission HUD collapses during active execution and remains draggable as a puck.
7. Confirm companion dragon artwork renders instead of a tinted rectangle and its border uses the adaptive complementary accent.
8. Ask a question with no Gemini key; accept the connect prompt, save a key, and verify persistence.
