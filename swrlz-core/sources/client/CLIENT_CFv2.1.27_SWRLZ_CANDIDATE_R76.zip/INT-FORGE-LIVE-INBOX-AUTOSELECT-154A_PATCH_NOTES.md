# INT-FORGE-LIVE-INBOX-AUTOSELECT-154A Patch Notes — CLIENT R63

- Live Forge Downloads inbox fingerprint watcher (2 s while visible/idle).
- Automatic rescan when source, metadata, checksum, manifest or evidence package identity changes.
- No periodic source-body rehash; existing cached scan hash + uncached pre-upload verification retained.
- Newer-looking rejected candidates now block silent fallback to older revisions.
- BLOCKED scan status includes the exact verification conflict.
- Active checkpoint documentation synchronized to R63 / VC189.
- R62 LALM stress lifecycle preserved (68/68 preservation verifier).
