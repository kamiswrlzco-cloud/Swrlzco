# CLIENT CFv2.0.3 SWRLZ Lineage

- Checkpoint: `INT-CONV-012A`
- Canonical baseline: `CLIENT_CFv2.0.2_SWRLZ.zip`
- Baseline SHA-256: `95e84eeb74776a1d4fe719678fc0743f11088d3460d9b721abcc20d71b314d0c`
- New identity: versionCode 34 / versionName `0.2.7.8-cfv2.0.3-int-conv-012a`
- Build: NOT RUN
- Integration law: Integrate, do not overwrite.

Final archive digest is recorded in the sibling checksum and delivery receipt because embedding a ZIP's own digest would change the archive.
