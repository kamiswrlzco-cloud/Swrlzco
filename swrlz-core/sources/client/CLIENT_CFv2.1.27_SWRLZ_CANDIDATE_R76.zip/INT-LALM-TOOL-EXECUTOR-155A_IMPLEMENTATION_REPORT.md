# INT-LALM-TOOL-EXECUTOR-155A — CLIENT R64 Implementation Report

## Scope
CLIENT R64 repairs the durable node inbox → executor bridge exposed by live GPT archive work. The observed failure was `trace_tool_queued` with no `trace_tool_execute` while the durable inbox cursor continued advancing. Direct Archive VFS INFO/LIST/CONVERSATIONS/READ remained healthy, isolating the defect to routed generic TOOL/MISSION envelope handling rather than the archive engine.

## Repair
- Added an allowlisted routed-request normalizer in `ArchiveNodeRuntime`.
- Canonical `swrlz-archive-query-v1`, `swrlz-directory-query-v1`, and `swrlz-log-query-v1` requests continue to execute without translation.
- Nested `request`, `toolRequest`, `action`, `payload`, `arguments`, `args`, and `input` objects are inspected to a bounded depth for canonical VFS requests.
- Recognized generic `swrlz_archive_*`, `swrlz_directory_*`, and `swrlz_logs` envelopes are normalized into canonical CLIENT requests.
- `swrlz_archive_repack` maps to `REPACK_SELECTED`, preserving the non-destructive source-archive rule and destination-grant revalidation.
- Unsupported routed tool traffic no longer returns `handled=true` silently. It returns a correlated `TOOL_ENVELOPE_UNSUPPORTED` (or invalid-JSON) result and writes explicit diagnostic evidence.
- Queue and execute traces now include normalization mode so future routing loss can be correlated.

## Safety / truth boundaries
Normalization does not infer arbitrary execution from natural-language chat. Only recognized tool names/capabilities and allowlisted operations are converted. Directory/archive mutation authority, live grants, consequential confirmation, exact destructive plan hashes, CLIENT revalidation, and recovery policy remain unchanged.

## Expected live regression
For the conversation-only export job, a routed selected-repack request should now produce `trace_tool_queued` → `trace_tool_execute` → terminal executor evidence. Output creation remains conditional on exact source entries, destination write authority, confirmation, structural verification, and SHA verification.

## Build boundary
This report is source/static evidence. A successful Android APK compile/install/device run is not claimed until the external APK Router/GitHub workflow and device regression provide that evidence.
