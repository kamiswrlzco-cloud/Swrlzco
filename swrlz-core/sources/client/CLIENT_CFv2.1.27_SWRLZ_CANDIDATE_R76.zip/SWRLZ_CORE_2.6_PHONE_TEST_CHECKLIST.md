# SWRLZ-Core 2.6 Phone Test Checklist

## Build identity

1. Install/update APK.
2. Open Home.
3. Confirm:
   - version `0.2.6-bridge-truth`
   - code `12`
   - patch `2.6-BRIDGE-TRUTH`
   - source `SWRLZ_CORE_2.6_BRIDGE_TRUTH_SOURCE.zip`

## Bridge truth test

1. Start Local Node Server 0.6 in Termux.
2. Open SWRLZ-Core → Setup.
3. Enter Core Node URL.
4. Tap SAVE CORE.
5. Confirm Setup says configured but not manually tested.
6. Tap TEST CORE NODE.
7. Confirm green success only if `/status` returns valid server identity.
8. Stop server.
9. Tap TEST CORE NODE again.
10. Confirm failed/unreachable state is red.

## Home layout test

1. Open Home on narrow phone screen.
2. Confirm `Local Core Node bridge` is readable and not split into `Loc / al / Cor / e`.
3. Confirm long server version wraps underneath the label.
4. Confirm bridge truth card shows configured/manual/auto state.

## Command card test

1. Open Cmds.
2. Create safe PING command.
3. Pull pending.
4. Confirm Pending card shows ACK/REJECT active and COMPLETE disabled.
5. ACK card.
6. Confirm Accepted card shows COMPLETE active.
7. COMPLETE card.
8. Confirm Completed card is read-only.
9. Check Termux command history logs.
