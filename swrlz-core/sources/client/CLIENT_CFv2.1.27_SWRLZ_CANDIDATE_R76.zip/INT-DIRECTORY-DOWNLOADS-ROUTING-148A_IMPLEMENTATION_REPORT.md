# INT-DIRECTORY-DOWNLOADS-ROUTING-148A · CLIENT R57

- Candidate: `CLIENT CFv2.1.27 R57` · `versionCode 183` · `2.1.27-downloads-toggle-routing-r57`.
- Parent: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R56.zip` · SHA-256 `5754d39a988eb15200720a6dcb0f9eb48f7916b8e966a4d83d0695c1fa83288b`.
- Pair: SERVER R88 / VC211.

## Live-device issue resolved
Android 11+ disables selection of the root `Download` directory through `ACTION_OPEN_DOCUMENT_TREE`, so the R56 "Set default Android Downloads directory" picker could only surface Android's "Can't use this folder" privacy message.

R57 removes that impossible picker path. `Android Downloads directory` is now a local ON/OFF authority switch. When enabled, CLIENT exposes a synthetic opaque grant `android-downloads` that resolves locally to Android's known public Downloads root and becomes the default only for bounded read-only Directory VFS operations (`INFO`, `TREE`, `LIST`, `READ`, `SEARCH`, `ANALYZE`). On Android 11+, readiness additionally requires Android All Files special access. Other folders continue to use explicit SAF tree grants.

## Safety boundaries
- Built-in Downloads advertises `writeAllowed=false` and `recoveryEnabled=false`.
- Mutations never inherit the built-in default because Directory VFS defaulting remains restricted to read-only operations.
- Raw device paths remain local and are not returned to SERVER/ChatGPT.
- File-backed traversal applies canonical-root containment checks to prevent a relative/symlink escape outside Downloads.
- If All Files access is revoked while the Downloads toggle remains ON, requests fail truthfully with `ANDROID_DOWNLOADS_PERMISSION_REQUIRED` rather than silently switching authority.
- Custom scoped grants remain independent and are not removed when Downloads is toggled off.

## UI changes
- Archives & Data: replaced `SET DEFAULT ANDROID DOWNLOADS DIRECTORY` with an `Android Downloads directory` switch and readiness text.
- Permission Centre: Downloads onboarding no longer opens `OpenDocumentTree`; it enables the local Downloads authority and routes to Android All Files special-access settings when needed.
- `GRANT ANOTHER DIRECTORY` remains for user-selected scoped trees.

## Validation
- `verify_int_directory_downloads_routing_148a.py`: **19/19 PASS**.
- JSON corpus and Android XML parsed successfully in the focused verifier.
- Existing notification surfaces and destructive `MUTATION_PLAN` / `DELETE_COMPLETE` / mutation-lock contracts remain present.
- Full Android Gradle compile is not claimed in this environment because wrapper acquisition requires external Gradle distribution access.
- Gradle attempt evidence: wrapper attempted Gradle 8.7 and stopped before Kotlin compilation with `UnknownHostException: services.gradle.org`.
