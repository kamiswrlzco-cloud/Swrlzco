# INT-FILE-059A CLIENT Implementation Report

## Facts
- Parent source: CLIENT CFv2.1.26 R1, SHA-256 `7b0202c01ea2ffbf7c7a3cb50f1e635c1eb6658299abb63de78b2b78502589eb`.
- Candidate identity: CLIENT CFv2.1.27 R1 / VC125 / `2.1.27-file-lab-cartographer-candidate-r1`.
- CLIENT mirrors the SERVER baseline **FILE LAB** surface and deterministic File Lab engine.
- File Lab computes source SHA-256, maps ZIP entries, searches names/types and bounded text content, previews bounded text, selectively extracts chosen entries, stages text changes, commits only to a new revised archive, and emits lineage metadata.
- Binary splitting defaults to 500 MiB parts and records per-part SHA-256 plus original SHA for exact verified recombination.
- Logical sharding creates independently readable ZIP shards targeted around 500 MiB of uncompressed territory with entry→shard provenance and logical recombination support.
- Settings automatically expose File Lab working/output/shard lanes because they enumerate `ForgeFolderSlot.entries`.

## CLIENT parity boundary
- Shared Forge File Lab functionality mirrors SERVER.
- CLIENT Missions, legacy Dev Mode, and CLIENT-only surfaces remain present.
- SERVER-only inference/model/evidence authority is not copied into CLIENT.

## Assumptions
- ZIP operations support standard Java ZIP methods available through `ZipInputStream`/`ZipOutputStream`; exotic/encrypted formats are not claimed.
- Large-archive ZIP mapping is sequential in this foundation, prioritizing SAF compatibility and bounded storage over random-access speed.
- Logical shards reconstruct archive content/structure, not byte-identical parent ZIP bytes. Byte-identical transport is handled by binary split/recombine.

## Validation
- Static checkpoint verifier is included at `tools/verify_int_file_059a.py`.
- Kotlin parser smoke check was used only to detect syntax-class errors; Android references cannot resolve outside the Android Gradle classpath.
- Android Gradle compilation, APK build, workflow execution, device testing, installation, release, and deployment were not performed.
