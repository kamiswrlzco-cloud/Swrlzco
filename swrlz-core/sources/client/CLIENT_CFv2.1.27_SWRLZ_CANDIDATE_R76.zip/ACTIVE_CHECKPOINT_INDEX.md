# ACTIVE CHECKPOINT — CLIENT
- Current revision: **R76**
- Version code: **202**
- Version name: `2.1.27-jar-render-theme-persona-r76`
- Checkpoint: **INT-SERVICE-WORKFLOW-DRAGON-JAR-168A**
- Candidate: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R76.zip`
- Parent: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R75.zip`
- Parent SHA-256: `7281126c1c14ad99682939c0ea2ab0ac2d716161534190567507baee3206c7d7`
- Paired SERVER: **R111 / VC234**

R76 repairs the sent-message Code 🫙 boundary: composer serialization stays visibly editable while persisted USER/assistant/LALM/history bubbles parse it into nested Code 🫙 UI. It also mirrors the dragon theme-persona contract used by SERVER R111. Fresh Android compile/APK/device acceptance remains external Auto Forge evidence.
