# CLIENT CFv2.1.9 — Package Pair Repair

Canonical checkpoint evidence:

`docs/checkpoints/INT-THEME-035D_CLIENT_PACKAGE_PAIR_REPAIR.md`

This is a packaging/identity repair. It preserves CFv2.1.8 application behavior,
corrects the repository package-manifest contract, and preserves the failed
CFv2.1.8 pair as immutable lineage.
