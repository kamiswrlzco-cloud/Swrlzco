# CLIENT CFv2.1.1 Forge Portable Repository Checkpoint

- Default GitHub target: `kamiswrlzco-cloud/Swrlzco` on `main`.
- Fine-grained token template display name is configurable; default remains `SWRLZ GitHub Forge`.
- Added pre-filled GitHub fine-grained PAT creation link using the configured token name and owner.
- CLIENT and SERVER auto-route directories plus the generic upload destination are independently configurable and persisted.
- Default routes remain `SOURCES/CLIENT` and `SOURCES/SERVER`; they can be changed to layouts such as `Swrlz/sources/client` and `Swrlz/sources/server` without rebuilding.
- Generic files and documentation ZIPs now use the configurable fallback destination and are not forced through source ZIP structure or ZIP/SHA pair validation.
- Chat Forge uses the same deterministic uploader and routing profile, so generic GitHub uploads do not require an external LLM to reason about the transfer.
- Strict source protection remains enabled for `CLIENT_*.zip` and `SERVER_*.zip`: checksum pairing plus source-content guard.
- Forge upload still performs atomic commit, branch/path verification, workflow observation, log retrieval, and artifact retrieval.
- Source-only update; compile/device validation remains evidence-gated.
