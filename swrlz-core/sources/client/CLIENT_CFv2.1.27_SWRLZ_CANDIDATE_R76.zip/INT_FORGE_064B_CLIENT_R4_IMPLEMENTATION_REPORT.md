# INT-FORGE-064B-CLIENT-R4 Implementation Report

## Purpose

Turn Forge auto-detect into a real project-root conveyor rather than a manual target label.

## Source changes

- `ForgeSourceResolver` now builds a verified project discovery result with effective route, candidates, conflicts, and matching evidence.
- `ForgeAutomatedBuildRunner` accepts AUTO-DETECT and variable 2-file/3-file package formats.
- `ForgePendingTransactionStore` preserves unresolved transaction identity for retry safety.
- `GitHubForgeClient` searches recent commits for the transaction marker, reconciles transient confirmation failures, and reports degraded verification separately from failure.
- `GitHubForgeScreen` scans on entry, exposes a project-root preview/rescan control, and performs one-action upload.
- `ForgeRuntimeState` now includes `RECONCILING`.

## Truth boundary

A package is selected only after source bytes, metadata/sidecars, component, versionCode, revision, size, and SHA-256 agree. Modification time is used only to choose among matching evidence bundles, never to establish source authority.

## Validation boundary

Source/static and focused checks only. Full Android compilation remains external workflow evidence.
