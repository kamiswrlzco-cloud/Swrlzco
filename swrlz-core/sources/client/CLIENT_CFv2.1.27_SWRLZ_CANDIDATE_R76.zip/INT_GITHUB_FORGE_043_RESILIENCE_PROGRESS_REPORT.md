# INT-GITHUB-FORGE-043 — Resilient Upload and Build Telemetry

- Extended GitHub API connect/read/write/call timeouts for large source ZIP blobs.
- Added staged Forge upload progress and phase status.
- Added actionable fine-grained PAT repository/Contents permission failure guidance.
- Added workflow start age, elapsed duration, and determinate/indeterminate progress presentation.
- Added artifact creation timestamps.
- Reconciles the selected launcher activity alias at startup to repair blank launcher-cache state after APK updates.
- Version: 2.0.43-forge-resilience-progress (71).
