# SWRLZ-Core 2.7.6 — Network Discovery

## Identity

- Version: `0.2.7.6-cockpit-shell`
- Code: `17`
- Patch: `2.7.6-NETWORK-DISCOVERY`
- Roadmap: `2.7.6`
- Source ZIP: `SWRLZ_CORE_2.7.6_NETWORK_DISCOVERY_SOURCE.zip`

## Server Pair

- Local Node Server: `0.7.1 Presence Index`
- Server source unchanged from 0.7.1.

## What changed

- Main top navigation is now cleaner: `Home | Radar | Cockpit | Setup | Style | More`.
- Added **More / Advanced Drawer** for Core, Permissions, Allowlist, Skills, How To, and Info.
- Added **Guided Pairing Ladder** to Radar.
- Added **Device Roster Summary** to Radar.
- Added clearer repair path when a device is not visible or online.
- Preserved Auto Presence / Node Heartbeat.
- Preserved Theme Armor: Original Core, Glitch Neon, Pharaoh Emerald, Void Jester, Dark/Sunlight/Inverse.
- Packet terminal states now become read-only history cards.

## Build law

No invisible patches. No mystery APKs. Visible build identity must match this file.
