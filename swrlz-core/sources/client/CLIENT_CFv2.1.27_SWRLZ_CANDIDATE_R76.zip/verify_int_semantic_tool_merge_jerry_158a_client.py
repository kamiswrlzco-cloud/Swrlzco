#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
checks=[]
def ck(n,c): checks.append((n,bool(c)))
def tx(p): return (root/p).read_text(errors='replace')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
build=tx('android/app/build.gradle.kts')
state=tx('android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamStateMachine.kt')
shell=tx('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt')
ledger=tx('android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt')
idx=tx('ACTIVE_CHECKPOINT_INDEX.md')
ck('R65 VC191','versionCode = 191' in build)
ck('R65 versionName','2.1.27-semantic-clarification-jerry-r65' in build)
ck('active R65','Current revision: **R65**' in idx)
ck('checkpoint 158A','INT-SEMANTIC-TOOL-MERGE-JERRY-158A' in idx and 'INT-SEMANTIC-TOOL-MERGE-JERRY-158A' in ledger)
ck('awaiting clarification property','val awaitingClarification' in state)
ck('clarification phases',all(x in state for x in ['PAUSED_FOR_CLARIFICATION','CLARIFICATION_WAIT','SEMANTIC_CLARIFICATION']))
ck('Jerry blocked label','SELF-PRESERVATION BLOCKED' in state)
ck('understood not executable label','UNDERSTOOD · NOT EXECUTABLE' in state)
ck('needs detail header','§WYRLZ · NEEDS DETAIL' in shell)
ck('clarification not approval copy','Clarification supplies missing meaning only' in shell and 'does not approve or execute a tool action' in shell)
ck('R65 ledger entry','revision = "R65"' in ledger and 'versionCode = 191' in ledger)
ck('R64 preserved ledger entry','revision = "R64"' in ledger and 'versionCode = 190' in ledger)
ck('implementation report exists',(root/'INT-SEMANTIC-TOOL-MERGE-JERRY-158A_CLIENT_IMPLEMENTATION_REPORT.md').exists())
ck('patch notes exist',(root/'INT-SEMANTIC-TOOL-MERGE-JERRY-158A_CLIENT_PATCH_NOTES.md').exists())
# R65 only modifies known presentation/release files; every other R64 file must be byte-identical.
incoming=Path('/mnt/data/merge_incoming_client_r64')
allowed={
'ACTIVE_CHECKPOINT_INDEX.md','CHANGELOG.md','ReleaseNotes.md','SOURCE_MANIFEST.sha256','android/app/build.gradle.kts',
'android/app/src/main/java/sh/swurlz/core/ai/ClientLlmStreamStateMachine.kt',
'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt',
'android/app/src/main/java/sh/swurlz/core/update/UpdateLedgerCatalog.kt',
'INT-SEMANTIC-TOOL-MERGE-JERRY-158A_CLIENT_IMPLEMENTATION_REPORT.md','INT-SEMANTIC-TOOL-MERGE-JERRY-158A_CLIENT_PATCH_NOTES.md',
'verify_int_semantic_tool_merge_jerry_158a_client.py',
}
if incoming.exists():
  for p in incoming.rglob('*'):
    if not p.is_file(): continue
    rel=p.relative_to(incoming).as_posix()
    if rel in allowed: continue
    q=root/rel
    ck('R64 preserved '+rel,q.exists() and sha(q)==sha(p))
else: ck('incoming R64 worktree available',False)
# JSON corpus validity
bad=[];total=0
for p in root.rglob('*.json'):
 total+=1
 try: json.loads(p.read_text(errors='strict'))
 except Exception as e: bad.append((str(p.relative_to(root)),str(e)))
ck('JSON corpus valid',total>0 and not bad)
failed=[n for n,v in checks if not v]
for n,v in checks: print(('PASS' if v else 'FAIL')+': '+n)
print(f'JSON_FILES={total}; JSON_BAD={len(bad)}')
print(f'RESULT {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
