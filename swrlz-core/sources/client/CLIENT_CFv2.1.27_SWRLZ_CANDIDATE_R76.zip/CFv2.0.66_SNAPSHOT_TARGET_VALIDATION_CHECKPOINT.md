# CLIENT CFv2.0.66 — Snapshot Target Validation

## Implemented
- Every screen observation receives a UUID snapshot identity.
- Plan requests include `snapshot_id`.
- Planner actions may include snapshot identity plus expected package, class, text, description, and bounds.
- Tap and text actions validate the active package and live accessibility node immediately before execution.
- Window/content changes invalidate the current snapshot.
- Accessibility click remains primary; locally derived center-point gesture remains fallback only after validation.
- Existing planners remain compatible: omitted target metadata is bound to the current client observation.

## Safety behavior
A stale, hidden, disabled, moved, relabeled, reclassified, or package-mismatched target returns failure. The mission loop then records the failure and performs a fresh observation/replan cycle.

## Build verification
Source-level validation completed. A local Gradle build could not run in the packaging environment because the Gradle 8.7 distribution was not cached and outbound network access was unavailable.
