# CFv2.0.67 Gemini Provider Foundation

- Added encrypted Gemini API-key storage to Client Settings.
- Key survives app restart and can be shown, hidden, replaced, or cleared.
- Added Gemini REST provider using `x-goog-api-key` and `gemini-3.6-flash`.
- Council Chat now requests a Gemini response, reports provider errors, and then starts the existing local mission path when operator permissions are ready.
- No API key is embedded in source, logs, or build configuration.
