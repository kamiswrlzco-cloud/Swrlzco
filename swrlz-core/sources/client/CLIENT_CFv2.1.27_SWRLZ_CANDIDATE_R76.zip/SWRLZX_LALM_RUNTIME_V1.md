# SWRLZX LALM Runtime V1

Contract ID: `swrlzx.lalm.runtime.v1`  
Checkpoint: `INT-AI-SWRLZX-011A`

## Purpose

This additive contract defines the first SWRLZ-native reference execution profile for the LFM2-derived `SWRLZ-LALM-001A` generation. It does not redefine Container V1 and does not make model files authoritative.

## Companion contracts

- `swrlzx.lalm.tensor_kv.v1` — request-owned tensor-valued K/V state.
- `swrlzx.lalm.chat_template.v1` — system/user/assistant framing contract.
- `swrlzx.lalm.sampler.v1` — temperature/top-k/repetition-penalty generation profile.
- `swrlzx.quant.ggml-k.v1` — bounded GGML K-quant row semantics used by the reference decoder.

## Canonical reference profile

The source contract records the exact dimensions and layer layout required by the pinned LALM bring-up profile, including 16 layers, 1024 hidden width, 16 query heads, 8 K/V heads for attention layers, 64-dimensional heads, 3-tap short convolution, 65,536 vocabulary entries, and a 32,768-token current runtime context ceiling. These constants are compatibility gates: a real source conversion that disagrees fails closed rather than silently reshaping tensors.

## Required graph operators

The 011A executable profile uses these first-party operations in addition to the generic 003A primitives:

- `LFM_CONV`
- `GQA_ATTENTION`
- `ROPE`
- `GATED_MLP`
- `SAMPLE`

Unknown required operations fail capability negotiation.

## Tensor state

Attention execution appends rotated K plus V tensors into request-owned pages. Reads and writes require the exact request owner. Cross-owner access is rejected. This replaces the old token-history-only reference state **for the LALM GQA execution path**; persistent cross-request transformer KV reuse remains a separate optimization.

## Quantization

The reference runtime supports F32, F16, BF16, Q4_0, Q8_0, Q4_K and Q6_K. Q4_K uses 256 values / 144 bytes and Q6_K uses 256 values / 210 bytes. The 011A exact-source runner derives the quantizer set from the actual converted tensor histogram and refuses the canonical bring-up if that set contains an unsupported type.

## Tokenizer boundary

`GGML_BPE` implements the GPT-2 byte-to-Unicode map, ranked pair merges, special-token atomicity and UTF-8 reconstruction. Exact `lfm2` pre-tokenizer parity is intentionally not promoted to PROVEN without the real tokenizer fixture and the 012A side-by-side corpus.

## Sampling

The canonical reference sampler profile records temperature `0.1`, top-k `50`, and repetition penalty `1.05`. Seed ownership stays with the request/runtime so deterministic test fixtures remain reproducible.

## Fail-closed rules

The native LALM path rejects unsupported source quantizers, missing required tensors, invalid graph shapes, mismatched model/runtime contracts, cross-owner state access, malformed tokenizer data, invalid sampler profiles, and canonical-source provenance mismatches. It never converts native execution back into GGUF as a hidden implementation path.
