# CLIENT CFv2.0.58 — Dragon Kamileon and Forge Log Build Repair

**Status:** source/static verification complete; GitHub APK compilation and device acceptance pending.

## Scope

CLIENT CFv2.0.58 preserves the CFv2.0.57 live Forge diagnostics and connector-continuity work while repairing its bounded Kotlin compile failure and adding the Dragon Kamileon Theme Armor family.

## Build repair

The CFv2.0.57 APK Router reached `:app:compileDebugKotlin` and failed at `ForgeUploadLogStore.kt` because `startSession()` referenced `prefs.edit()` without first resolving the local SharedPreferences instance. CFv2.0.58 adds:

```kotlin
val prefs = prefs(context)
```

before the synchronous current/latest session write. No upload, redaction, connector, authority, or workflow semantics are changed by this repair.

## Dual-Forge actor evidence

Every CLIENT Forge upload now records and commits:

```text
SWRLZ-Forge-Transaction: <unique UUID>
SWRLZ-Forge-Actor: CLIENT
```

This makes CLIENT and SERVER transactions distinguishable in GitHub history and exported diagnostics. Repository safety remains based on latest-head resolution, atomic tree/commit creation, branch confirmation, uploaded-path verification, and bounded retry when the branch advances.

## Dragon Kamileon Theme Armor

A new selectable `Dragon Kamileon` family is available in Style. It includes:

- a dark iridescent interface palette with cyan, violet, magenta, and gold energy;
- a dedicated CLIENT launcher alias and adaptive icon;
- CLIENT, SERVER-context, and fusion bubble identities;
- Theme Armor synchronization through the existing launcher/bubble identity manager.

Visual theme state remains presentation only and never grants trust, SERVER authority, or fusion capability.

## Android identity

```text
versionCode: 85
versionName: 2.0.58-kamileon-theme-forge-log-buildfix-v1
source: CLIENT_CFv2.0.58_SWRLZ.zip
```

The authoritative digest is supplied in the sibling external `CLIENT_CFv2.0.58_SWRLZ.sha256` receipt.

## Static evidence

- all project XML files parse;
- all PNG resources open and verify;
- new drawable and mipmap references resolve;
- modified Kotlin files pass structural delimiter checks;
- the reported `prefs` compile defect is removed;
- no explicit Compose `foundation.layout.weight` import exists in active Kotlin source;
- local Gradle compilation remains unavailable because the isolated preparation environment cannot reach the Gradle distribution host.

## Acceptance gate

1. Upload the ZIP/SHA pair through either Forge.
2. Confirm exactly one Source Package Integrity run.
3. Confirm CLIENT APK Router passes Kotlin compilation and produces an artifact.
4. Install with the same signing certificate.
5. Select Dragon Kamileon and verify interface, launcher, CLIENT bubble, SERVER-context bubble, and fusion identity.
6. Export a Forge upload log and confirm `forge_actor=CLIENT` and the transaction UUID are present without credentials.
