from pathlib import Path
import re, json, sys
ROOT=Path(__file__).resolve().parent
checks=[]
def add(name, ok, detail=''):
    checks.append((name,bool(ok),detail))

def txt(rel): return (ROOT/rel).read_text(errors='replace')
# component-aware paths
if (ROOT/'android/app/build.gradle.kts').exists():
    component='CLIENT'
    build=txt('android/app/build.gradle.kts')
    auto=txt('android/app/src/main/java/sh/swurlz/core/github/ForgeAutomation.kt')
    screen=txt('android/app/src/main/java/sh/swurlz/core/ui/screens/GitHubForgeScreen.kt')
    expected=('R63','189','CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R63.zip','INT-FORGE-LIVE-INBOX-AUTOSELECT-154A')
else:
    component='SERVER'
    build=txt('app/build.gradle.kts')
    auto=txt('app/src/main/java/sh/swrlz/nodehost/forge/ForgeAutomation.kt')
    screen=txt('app/src/main/java/sh/swrlz/nodehost/forge/ServerForgeScreen.kt')
    expected=('R96','219','SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R96.zip','INT-FORGE-LIVE-INBOX-AUTOSELECT-154A')
rev,vc,zipname,patch=expected
add('build revision', rev in build)
add('build versionCode', f'versionCode = {vc}' in build)
add('build source zip', zipname in build)
add('build checkpoint', patch in build)
active=txt('ACTIVE_CHECKPOINT_INDEX.md')
add('active checkpoint revision', f'Current revision: **{rev}**' in active)
add('active checkpoint patch', patch in active)
add('lightweight inbox fingerprint', 'fun inboxFingerprint(context: Context): String' in auto)
add('fingerprint uses logical name', 'logicalSourceKey(doc.name.orEmpty())' in auto)
add('fingerprint uses size', 'doc.length().toString()' in auto)
add('fingerprint uses mtime', 'doc.lastModified().toString()' in auto)
add('fingerprint uses uri', 'doc.uri.toString()' in auto)
add('fingerprint excludes package body reads', 'openInputStream' not in auto[auto.index('fun inboxFingerprint'):auto.index('fun latest(context')])
add('newer rejection guard', 'newerRejectedCandidateConflict' in auto)
add('silent fallback refusal text', 'will not silently fall back' in auto)
add('live 2 second watcher', 'delay(2_000)' in screen)
add('watcher compares fingerprint', 'fingerprint != lastInboxFingerprint' in screen)
add('watcher honors auto-select', 'ForgeAutomationPreferences.autoSelectLatest(context)' in screen)
add('watcher pauses while busy', '!busy' in screen and '!projectScanBusy' in screen)
add('watcher scan target', 'ForgeBuildTarget.valueOf(packageTarget)' in screen)
add('watcher failure visible', 'AUTO SOURCE REFRESH FAILED' in screen)
# preservation anchors
add('metadata bundle strict reader preserved', 'ForgeMetadataBundle' in auto)
add('equal-rank hash conflict preserved', 'different SHA-256 values' in auto)
add('preupload/hash validation path preserved', 'validateCandidate' in auto and 'ForgeDocumentHashCache.sha256' in auto)

# scan progress must surface conflicts when blocked
perf = txt('android/app/src/main/java/sh/swurlz/core/github/ForgeStoragePerformance.kt') if component=='CLIENT' else txt('app/src/main/java/sh/swrlz/nodehost/forge/ForgeStoragePerformance.kt')
add('blocked progress surfaces conflicts', 'result.conflicts.joinToString(" | ")' in perf)

# JSON corpus
json_files=list(ROOT.rglob('*.json'))
invalid=[]
for p in json_files:
    try: json.loads(p.read_text())
    except Exception as e: invalid.append((str(p.relative_to(ROOT)),str(e)))
add('JSON corpus valid', not invalid, f'{len(json_files)} files')
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL'), '|', name, detail)
failed=[c for c in checks if not c[1]]
print(f'RESULT {len(checks)-len(failed)}/{len(checks)} PASS')
if failed: sys.exit(1)
