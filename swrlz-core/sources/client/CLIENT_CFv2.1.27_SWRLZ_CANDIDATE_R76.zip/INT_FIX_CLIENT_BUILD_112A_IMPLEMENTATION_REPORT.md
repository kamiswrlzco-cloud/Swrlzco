# INT-FIX-CLIENT-BUILD-112A — CLIENT R11 Build Repair

## Failure evidence

GitHub Actions workflow `31266574472` routed `BOTH`. SERVER R33 completed Android compilation/build, while CLIENT R10 failed `:app:compileDebugKotlin` at `ServerForgeTransferClient.kt:401`:

`Suspend function coreNodeConfig(ctx: Context) should be called only from a coroutine or another suspend function.`

## Root cause

`Prefs.coreNodeConfig(context)` is a suspend DataStore read. R10 called it from non-suspend `loopbackConnection(context)`. The helper is only used by `runLoopbackLegacyBenchmark`, which is already suspend.

## Repair

Change `loopbackConnection` to `private suspend fun`. This propagates the existing coroutine boundary correctly and avoids blocking shims.

## Preservation

No transfer protocol, endpoint, chunking, SHA-256, node-proof, pairing-token, Forge approval, GitHub dispatch, release, deployment, or install authority semantics are changed. SERVER R33 is unchanged because it compiled successfully in the same workflow.

## Identity

- Candidate: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R11`
- Parent: `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R10`
- versionCode: `137`
- versionName: `2.1.27-client-build-repair-r11`
- Checkpoint: `INT-FIX-CLIENT-BUILD-112A`

## Acceptance

Authoritative acceptance requires the next GitHub Actions Android compile/build of canonical R11.
