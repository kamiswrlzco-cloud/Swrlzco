# INT-RUNTIME-STREAM-OBSERVATORY-COMPILE-163B — CLIENT R72

## Trigger
Auto Forge correctly resolved and verified `CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R71.zip`, then `:app:compileDebugKotlin` failed in `ClientShellScreen.kt`.

## Repairs
1. The live LALM committed-text path now invokes `ChatBubble(threadId = "live:${live.requestId}", message = ClientMessage(...))`, matching the R71 rich-chat signature and keeping structure-overlay keys request-scoped.
2. `SettingLine` now declares `trailing: @Composable () -> Unit = {}` so read-only Observatory rows such as Proof and Revision remain concise and compile correctly.

## Preservation
No SERVER source change. R71 streamed history, persistent app-scoped loading, instant newest-message entry, wide rich-message/code-container rendering, user-created non-destructive 🫙 overlays, timestamps, Google public-ID configuration, and admin-gated SERVER Observatory behavior are preserved.

## Truth boundary
This checkpoint does not claim APK/device success. A fresh Auto Forge build is required.
