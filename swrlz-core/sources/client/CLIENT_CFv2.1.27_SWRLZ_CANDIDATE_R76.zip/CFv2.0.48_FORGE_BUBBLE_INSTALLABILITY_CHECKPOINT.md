# CLIENT CFv2.0.48 Forge, Bubble, and Installability Checkpoint

Implemented:
- File picker now appends new selections to existing staging instead of replacing them.
- Duplicate URI selections are removed without clearing prior staged files.
- Local CLIENT/SERVER ZIP and SHA-256 pair validation runs before upload.
- Workflow observer requests GitHub job and step state and renders real phases without fabricated percentages.
- Bubble shortcut icons use adaptive bitmaps and tighter transparent artwork to reduce white padding.
- Version advanced to 2.0.48.

Installability:
- Debug and release builds already support a persistent SWRLZ development signing key through
  SWRLZ_DEV_KEYSTORE_FILE, SWRLZ_DEV_KEYSTORE_PASSWORD, SWRLZ_DEV_KEY_ALIAS, and
  SWRLZ_DEV_KEY_PASSWORD.
- An APK signed by a different certificate cannot update an existing installation. Configure the same
  persistent key in every Forge build. A one-time uninstall is still required when replacing an
  installation signed by an older or different key.
