# SWRLZ CLIENT / SERVER Feature Parity — INT-FORGE-054A-R2

Status: **SOURCE CANDIDATE — static/source validation only**  
Checkpoint: `INT-FORGE-054A-R2`

## Parity rule

CLIENT follows the shared SWRLZ interaction/Forge baseline (the “dragon tail”), while SERVER remains authoritative for SERVER-owned inference/runtime facts. Parity means shared behavior and contracts match where the capability belongs on both sides; it does **not** mean copying SERVER-only inference authority into CLIENT.

## Shared baseline mirrored by this checkpoint

| Capability | CLIENT | SERVER | Boundary |
|---|---|---|---|
| Forge target selection `ASK / CLIENT / SERVER / BOTH / FILES` | Yes | Yes | Persisted; optional remember-last-target |
| One-button `BUILD LATEST VERIFIED` | Yes | Yes | User-initiated only |
| Latest-source resolution | Yes | Yes | Manifest `versionCode` + component + ZIP SHA + checksum + manifest SHA; filename/mtime non-authoritative |
| Source transport `AUTO / DIRECT / CHUNKED` | Yes | Yes | Uses existing GitHub Forge transport |
| Configurable SAF directory routing | Yes | Yes | Root, CLIENT source, SERVER source, artifact, failed logs, LLM models, SWRLZMODs, evidence |
| Auto-download successful GitHub Actions artifact ZIP | Yes | Yes | Default ON; no install |
| Auto-download failed workflow logs | Yes | Yes | Default ON |
| Persistent build ledger | Yes | Yes | Built/downloaded/install-pending states remain distinct |
| Manual source staging / validated override | Preserved | Preserved | Existing manual Forge path remains available |
| Credential lifecycle / repository verification / workflow watch | Preserved | Preserved | Existing authority and credential boundaries unchanged |
| Machine-readable patch/checkpoint lineage index | Yes | Yes | Index points to canonical evidence; it is not higher authority |

## CLIENT chat catch-up in this checkpoint

CLIENT gains local thread continuity so its Chat shell no longer has to be a single volatile conversation:

- CLIENT-local thread history persisted in app-private storage;
- new/select/rename/delete thread controls;
- compact Chat header with history/new/settings controls;
- paired-SERVER model selector in Chat using the existing Model Rack control API; profile/EQ detail remains routed through CLIENT Settings where the current protocol exposes it;
- explicit UI notice that CLIENT-local history does not make CLIENT authoritative for SERVER reasoning state.

This deliberately does **not** fabricate SERVER response evidence, model residency, model SHA, sampler telemetry, token timings, EQ lineage, Truth-runtime facts, or SERVER Room evidence on CLIENT. Those remain SERVER-owned and must be obtained through supported SERVER interfaces when required.

## CLIENT-only capabilities preserved

- legacy Dev Mode interface and associated compatibility/testing surfaces;
- Missions / mission UI and CLIENT-side mission interaction flow;
- CLIENT device/interaction capabilities such as client UI/runtime integrations that do not belong to NODE_HOST/SERVER;
- client-local chat continuity introduced by this checkpoint.

## SERVER-only authoritative capabilities preserved

- local GGUF inference execution and residency;
- SERVER model authority / activation / native compatibility checks;
- SERVER prompt/profile/module compilation for inference;
- SERVER Room chat/evidence records and response telemetry;
- node-host/background SERVER runtime and SERVER-owned runtime facts.

## Known intentional asymmetry

SERVER may expose a richer response-evidence/feedback interface because it owns the inference evidence. CLIENT may later display SERVER-provided evidence through an explicit protocol/API, but this checkpoint does not duplicate or invent it locally.

## Authority order

1. canonical source ZIP + SHA-256 receipt;
2. accepted contracts / protocol definitions;
3. accepted checkpoint/build/device evidence;
4. source manifest / validated implementation files;
5. this parity/lineage documentation as a navigation index.

Patch/lineage notes are useful self-history, but they never override contradictory canonical evidence.
