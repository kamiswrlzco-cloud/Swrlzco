#!/usr/bin/env python3
from __future__ import annotations
import base64, gzip, hashlib, json, os, re, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SERVER = ROOT / 'server_r101'
SERVER_PARENT = ROOT / 'server_r100'
CLIENT = ROOT / 'client_r66'
CLIENT_PARENT = ROOT / 'client_r65'
ARCHIVE = Path('/mnt/data/GPT_CONVERSATIONS_ONLY_2026-08-09.zip')
SPEC = Path('/mnt/data/SWRLZ_NEXT_UPDATE_MASTER_FIX_SPEC_R101_R66_2026-08-16.docx')
BASE_SERVER_ZIP = Path('/mnt/data/SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R100.zip')
BASE_CLIENT_ZIP = Path('/mnt/data/CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R65.zip')

EXPECTED_SHA = {
    BASE_SERVER_ZIP: '33ff2c4d494fb927d6763bc349ed1ff7245634ace5d254c0818c28dcc6cd3562',
    BASE_CLIENT_ZIP: '8d81ec74a7e39fa011b2c224e5c450bfcb7c67d58a62bcb90a22c76636f680e2',
    ARCHIVE: '6cf1c45e60d35bc8e275238ea2ed35b741550cee3b73709bcc0e9dbe8dfa8969',
    SPEC: '7dd4e64888a806d05c24bfec6ab07b5de89c59fb0c9a5f434b92826d05accb36',
}

checks: list[tuple[bool,str,str]] = []
def check(ok: bool, name: str, detail: str=''):
    checks.append((bool(ok), name, detail))

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def text(rel: str, base: Path) -> str:
    return (base/rel).read_text(encoding='utf-8', errors='replace')

def contains_all(body: str, needles: list[str]) -> bool:
    return all(n in body for n in needles)

def same_file(rel: str, a: Path, b: Path) -> bool:
    return sha256(a/rel) == sha256(b/rel)

# 1. Baseline/spec identity
for p, exp in EXPECTED_SHA.items():
    check(p.exists() and sha256(p)==exp, f'identity:{p.name}', sha256(p) if p.exists() else 'missing')

# 2. Successor build identity
sb = text('app/build.gradle.kts', SERVER)
cb = text('android/app/build.gradle.kts', CLIENT)
check(contains_all(sb, ['versionCode = 224','versionName = "2.1.27-next-update-master-r101"','"SWRLZ_REVISION", quotedBuildConfig("R101")','INT-NEXT-UPDATE-MASTER-159A','SERVER_CFv2.1.27_SWRLZ_CANDIDATE_R101.zip']), 'server:R101 build identity')
check(contains_all(cb, ['versionCode = 192','versionName = "2.1.27-next-update-master-r66"','"SWRLZ_REVISION", "\\"R66\\""','INT-NEXT-UPDATE-MASTER-159A','CLIENT_CFv2.1.27_SWRLZ_CANDIDATE_R66.zip','androidx.credentials:credentials:1.6.0','com.google.android.libraries.identity.googleid:googleid:1.2.0']) and 'play-services-auth:21.6.0' not in cb, 'client:R66 build identity + Credential Manager dependencies')

# 3. LALM job lifecycle + trace bridge
state = text('app/src/main/java/sh/swrlz/nodehost/ai/llm/LalmReasonJobStateV2.kt', SERVER)
store = text('app/src/main/java/sh/swrlz/nodehost/ai/llm/LalmReasonJobStore.kt', SERVER)
local = text('app/src/main/java/sh/swrlz/nodehost/ai/local/SwrlieLocalRuntime.kt', SERVER)
required_states = ['QUEUED','ACQUIRED','DISPATCH_PENDING','DISPATCHED','CLIENT_ACK','RUNNING','RESULT_UPLOADING','COMPLETED','FAILED']
check(contains_all(state, required_states), 'lalm:explicit lifecycle states')
check(contains_all(store, ['jobId','traceId','CLIENT_ACK','RESULT_UPLOADING','failureStage','terminalReason','reason_job_stage']), 'lalm:correlated state/terminal tracing')
check(contains_all(local, ['InferenceEvent.Started','trace_lalm_job_received','onNativeStarted']), 'lalm:CLIENT receipt tied to native-start edge')

# 4. Preflight compiler
sp = text('app/src/main/java/sh/swrlz/nodehost/mcp/ServerToolPreflightV1.kt', SERVER)
smcp = text('app/src/main/java/sh/swrlz/nodehost/mcp/SwurlzMcpToolClient.kt', SERVER)
cp = text('android/app/src/main/java/sh/swurlz/core/tools/ToolRequestCompilerV1.kt', CLIENT)
archrt = text('android/app/src/main/java/sh/swurlz/core/archive/ArchiveNodeRuntime.kt', CLIENT)
check(contains_all(sp, ['REPACK_SELECTED','archiveId','includePaths','destinationGrantId','destinationPath','preflightFingerprint','idempotencyKey','PRESERVE_ORIGINAL']), 'preflight:SERVER complete canonical repack contract')
check(contains_all(smcp, ['TOOL_PREFLIGHT_INCOMPLETE','ServerToolPreflightV1']), 'preflight:SERVER one-shot incomplete contract error')
check(contains_all(cp, ['data class Contract','preflightFingerprint','idempotencyKey','preserveSource','missing','blockers']), 'preflight:CLIENT canonical compiler/fingerprint')
check('ToolRequestCompilerV1' in archrt and 'preflight' in archrt.lower(), 'preflight:archive runtime executes after preflight')

# 5. Importer/storage/search safety
imp = text('android/app/src/main/java/sh/swurlz/core/data/OpenAiConversationArchiveImporter.kt', CLIENT)
hist = text('android/app/src/main/java/sh/swurlz/core/data/ImportedChatHistoryStore.kt', CLIENT)
fts = text('android/app/src/main/java/sh/swurlz/core/data/ImportedChatSearchIndexV1.kt', CLIENT)
chat = text('android/app/src/main/java/sh/swurlz/core/data/ClientChatHistoryStore.kt', CLIENT)
check(contains_all(imp, ['stageBatch','commitStagedImport','current_node','historical", true','executable", false','millisecondTimestampCount','multimodal_text','reasoning_recap','OPENAI_ARCHIVE_CHANGED_AFTER_ANALYSIS','shouldCancel','discardStage','OPENAI_IMPORT_CANCELLED_CLEAN_ROLLBACK']), 'importer:staged/cancelable graph-aware immutable historical import')
check(contains_all(hist, ['IMPORT_STAGE_EXECUTION_ISOLATION_INVALID','syncExcluded','historical", true','executable", false','alternateBranchNodes','hiddenNodes']), 'importer:history store isolation/branch/sync policy')
check(contains_all(fts.lower(), ['fts4','visibletext','search','removethread','replacethread']), 'importer:visible-message FTS index')
check(contains_all(chat, ['ImportedChatHistoryStore','HistorySyncTombstoneStoreV1','notifyExternalChange','setThreadSyncExcluded','syncExcluded']), 'importer:first-class thread-list integration + tombstones + per-thread sync exclusion')

# 6. Account continuity / restore / credential boundary
ah = text('app/src/main/java/sh/swrlz/nodehost/history/AccountHistoryStoreV1.kt', SERVER)
gv = text('app/src/main/java/sh/swrlz/nodehost/history/GoogleIdTokenVerifierV1.kt', SERVER)
ap = text('app/src/main/java/sh/swrlz/nodehost/service/AccountContinuityProtocol.kt', SERVER)
ca = text('android/app/src/main/java/sh/swurlz/core/data/ClientAccountContinuity.kt', CLIENT)
cred = text('android/app/src/main/java/sh/swurlz/core/data/ClientCredentialEnvelopeV1.kt', CLIENT)
tombs = text('android/app/src/main/java/sh/swurlz/core/data/HistorySyncTombstoneStoreV1.kt', CLIENT)
ui = text('android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt', CLIENT)
gid = text('android/app/src/main/java/sh/swurlz/core/data/ClientGoogleIdentityV1.kt', CLIENT)
check(contains_all(ap, ['/v1/account/google/session','/v1/account/history/push','/v1/account/history/push-fragment','/v1/account/history/pull','/v1/account/credentials/envelope']), 'account:SERVER session/history/fragment/credential routes')
check(contains_all(gv, ['RS256','kid','iss','aud','exp','sub']), 'account:Google ID-token verification boundary')
check(contains_all(ah, ['tombstone','historical','executable','pushFragment','fragmentSha256','compressedSha256','PLAINTEXT']), 'account:canonical history, stale-delete, fragmented sync, plaintext rejection')
check(contains_all(ca, ['establishGoogleSession','push-fragment','signOut','removeLocalHistory','HistorySyncTombstoneStoreV1']), 'account:CLIENT optional session/sync/signout/tombstone protocol')
check(contains_all(cred, ['PBKDF2WithHmacSHA256','AES/GCM/NoPadding','210_000','recovery']), 'account:encrypted recovery envelope crypto')
check(contains_all(tombs, ['tombstone','executable','historical']), 'account:durable client tombstone queue')
check(contains_all(gid, ['CredentialManager','GetSignInWithGoogleOption','GoogleIdTokenCredential','clearCredentialState']) and 'GoogleSignInClient' not in ui, 'account:Credential Manager Sign in with Google path')
check(contains_all(ui, ['CONTINUE WITH GOOGLE','CONTINUE LOCAL-ONLY','SIGN OUT · KEEP LOCAL DATA','Secure credential backup','Local only','Local now, sync later','Local + sync now']), 'account:UI optional startup + local-only + import modes')

# 7. Preserve load-bearing semantic controls exactly where update did not need to touch them.
semantic_files = [
 'app/src/main/java/sh/swrlz/nodehost/ai/semantic/SwrlzSemanticControlFlowV1.kt',
 'app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzClarificationPlannerV1.kt',
 'app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzClarificationResumeStoreV1.kt',
 'app/src/main/java/sh/swrlz/nodehost/ai/llm/SwrlzToolSuiteCatalogV1.kt',
]
for rel in semantic_files:
    check(same_file(rel, SERVER_PARENT, SERVER), f'preservation:unchanged:{Path(rel).name}')
sem = text(semantic_files[0], SERVER)
clar = text(semantic_files[1], SERVER) + '\n' + text(semantic_files[2], SERVER)
toolcat = text(semantic_files[3], SERVER)
check(contains_all(toolcat.lower(), ['in the story','figuratively','return null']), 'semantic:narrative isolation marker retained')
check(any(s in sem.lower() for s in ['ground','operand','semantic']), 'semantic:grounding boundary retained')
check(any(s in clar.lower() for s in ['clarif','resume','missing']), 'semantic:clarification/resume retained')

# 8. Actual conversation archive harness. Mirrors importer semantics, not raw mapping-node count.
archive_stats = dict(shards=0, conversations=0, message_nodes=0, current_path_messages=0, alternate_messages=0,
                     branch_conversations=0, text=0, multimodal=0, thoughts=0, reasoning_recap=0,
                     attachment_refs=0, messages_with_attachments=0, millis=0, uncompressed_bytes=0)
max_raw=0; max_gzip=0; max_b64=0; max_id=''
with zipfile.ZipFile(ARCHIVE) as zf:
    names=[n for n in zf.namelist() if re.search(r'(^|/)conversations(?:-\d{3,})?\.json$', n, re.I)]
    archive_stats['shards']=len(names)
    for name in names:
        raw=zf.read(name); archive_stats['uncompressed_bytes'] += len(raw)
        arr=json.loads(raw)
        for conv in arr:
            archive_stats['conversations'] += 1
            mapping=conv.get('mapping') or {}
            cur=[]; seen=set(); cursor=conv.get('current_node') or ''
            while cursor and cursor not in seen and cursor in mapping:
                seen.add(cursor); cur.append(cursor); cursor=(mapping.get(cursor) or {}).get('parent') or ''
            cur.reverse(); curset=set(cur)
            child={}
            for node_id,node in mapping.items():
                if not isinstance(node,dict): continue
                parent=node.get('parent') or ''
                if parent: child[parent]=child.get(parent,0)+1
                msg=node.get('message')
                if not isinstance(msg,dict): continue
                archive_stats['message_nodes'] += 1
                if node_id in curset: archive_stats['current_path_messages'] += 1
                else: archive_stats['alternate_messages'] += 1
                ct=((msg.get('content') or {}).get('content_type'))
                if ct == 'text': archive_stats['text'] += 1
                elif ct == 'multimodal_text': archive_stats['multimodal'] += 1
                elif ct == 'thoughts': archive_stats['thoughts'] += 1
                elif ct == 'reasoning_recap': archive_stats['reasoning_recap'] += 1
                atts=((msg.get('metadata') or {}).get('attachments'))
                if isinstance(atts,list) and atts:
                    archive_stats['attachment_refs'] += len(atts)
                    archive_stats['messages_with_attachments'] += 1
                ts=msg.get('create_time')
                if isinstance(ts,(int,float)) and ts >= 1_000_000_000_000: archive_stats['millis'] += 1
            if any(v>1 for v in child.values()): archive_stats['branch_conversations'] += 1
            payload=json.dumps(conv,separators=(',',':'),ensure_ascii=False).encode()
            if len(payload)>max_raw:
                max_raw=len(payload); gz=gzip.compress(payload); max_gzip=len(gz); max_b64=len(base64.b64encode(gz)); max_id=conv.get('conversation_id') or conv.get('id') or ''

expected={
 'shards':25,'conversations':2461,'message_nodes':88673,'current_path_messages':86437,'alternate_messages':2236,
 'branch_conversations':372,'text':69162,'multimodal':3009,'thoughts':11299,'reasoning_recap':5203,
 'attachment_refs':2962,'messages_with_attachments':1437,'millis':10,
}
for k,v in expected.items(): check(archive_stats[k]==v, f'archive:{k}={v}', str(archive_stats[k]))
check(archive_stats['uncompressed_bytes']==197_016_784, 'archive:uncompressed_bytes=197016784', str(archive_stats['uncompressed_bytes']))
check(max_raw > 1_600_000 and max_b64 > 1_600_000, 'archive:oversized conversation proves fragment route necessity', f'id={max_id} raw={max_raw} gzip={max_gzip} b64gzip={max_b64}')

# 9. Parse every JSON file shipped in source trees (where present).
json_files=0; json_errors=[]
for root in (SERVER,CLIENT):
    for p in root.rglob('*.json'):
        if any(part in {'build','.gradle'} for part in p.parts): continue
        json_files += 1
        try: json.loads(p.read_text(encoding='utf-8'))
        except Exception as e: json_errors.append(f'{p.relative_to(root)}:{e}')
check(not json_errors, 'static:all shipped .json parse', f'files={json_files}; errors={json_errors[:3]}')

passed=sum(1 for ok,_,_ in checks if ok); failed=len(checks)-passed
print(f'SWRLZ INT-NEXT-UPDATE-MASTER-159A verifier: {passed}/{len(checks)} PASS; {failed} FAIL')
for ok,name,detail in checks:
    print(f'[{"PASS" if ok else "FAIL"}] {name}' + (f' :: {detail}' if detail else ''))
print('ARCHIVE_STATS=' + json.dumps(archive_stats,sort_keys=True))
print('LARGEST_CONVERSATION=' + json.dumps({'id':max_id,'raw_bytes':max_raw,'gzip_bytes':max_gzip,'base64_gzip_bytes':max_b64},sort_keys=True))
sys.exit(1 if failed else 0)
