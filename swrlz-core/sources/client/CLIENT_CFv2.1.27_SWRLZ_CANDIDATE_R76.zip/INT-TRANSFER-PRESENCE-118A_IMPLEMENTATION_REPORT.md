# INT-TRANSFER-PRESENCE-118A — CLIENT R15 implementation report

## Device evidence addressed
With CLIENT R14 and SERVER R36 installed on the same phone, the 1 MiB loopback benchmark still failed at `0 chunks / 0 B/s`. The previous UI could also lose the useful benchmark error behind source-pair picker status, and no benchmark log existed when presence failed before log creation.

## Repair
1. Preserve HTTP status, SERVER protocol code, and elapsed time for presence calls.
2. Recover only explicit `NOT_REGISTERED` by performing one registration and BUSY-heartbeat retry.
3. Create benchmark NDJSON before presence preflight and log the preflight result.
4. Report presence / registration-recovery / `/start` timing and exact failure stage.
5. Isolate benchmark status from generic/source-pair transfer status.

R14 binary transfer and compatibility behavior remain preserved.
