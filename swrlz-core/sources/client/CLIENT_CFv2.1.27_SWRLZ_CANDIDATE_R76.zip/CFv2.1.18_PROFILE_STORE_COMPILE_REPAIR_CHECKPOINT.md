# INT-FIX-039G — CLIENT Profile Store Kotlin Compile Repair

Date: 2026-07-27  
Target: CLIENT  
Successor: CFv2.1.18 / VC116 / `2.1.18-forge-rescue-profile-store-compile-repair-v1`

## Trigger evidence

GitHub Actions workflow `30302109949` successfully selected and verified CLIENT CFv2.1.17, entered Android/Kotlin compilation, and failed at `ClientProfileStore.kt:142:29` with `Function invocation 'providerProfileId(...)' expected.`

The source defect was:

```kotlin
providerProfileId = providerProfileId?.let { providerProfileId(document, it) },
```

`resolveClientToServer` declares the nullable argument as `providerId`; `providerProfileId` at that location resolves to the helper function name, so Kotlin correctly rejected nullable-call syntax on the function symbol.

## Repair

```kotlin
providerProfileId = providerId?.let { providerProfileId(document, it) },
```

No profile semantics change is intended. The repaired expression now matches the already-correct SERVER implementation and the CLIENT `resolveProvider` helper path.

## SERVER parity audit

SERVER CFv2.1.7 was verified at SHA-256 `96d05d0fa7a9c11ea565be0ce3453d0e1d3449112205ce787b679df47541d7e1`. `ServerProfileStore.kt` already uses `providerId?.let { providerProfileId(document, it) }` in its relevant resolver paths. A package-wide scan found no identical nullable-let/function-name shadowing pattern in SERVER Kotlin sources, so SERVER is intentionally unchanged and no fake successor version is issued.

## Preserved boundary

CFv2.1.18 remains a temporary default-theme Forge rescue edition. It preserves the CFv2.1.17 credential/write-preflight repair and the reduced `Glitch Dragon Glass` runtime payload. Full ThemePack artwork remains in the CFv2.1.16 lineage for restoration after transport hardening.

Protocol, trust, Truth Firewall, mission/permission authority, provider/profile/command contracts, Forge transaction semantics, and offline-first behavior are unchanged.

## Evidence boundary

Static/source/package verification only. This checkpoint does **not** claim a successful Gradle compile, test run, APK build, device acceptance, GitHub upload/write, workflow dispatch, commit/push, release, deployment, or installation.
