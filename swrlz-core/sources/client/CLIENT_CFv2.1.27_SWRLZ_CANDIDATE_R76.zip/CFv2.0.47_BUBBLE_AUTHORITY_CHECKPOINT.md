# CLIENT CFv2.0.47 — Bubble Authority Checkpoint

## Implemented
- Restored the Client-owned interactive bubble cluster foundation.
- SWRLZ Client remains available without a server.
- SWURLZER Server and SWURVER fused bubbles are gated by verified admin session state.
- Persisted layout choices cannot grant authority.
- Added explicit bubble identities and capability vocabulary.
- Verified admin opening the native conversation surface can start the all-three overlay layout when overlay permission is available.

## Security boundary
This checkpoint does not treat visual fusion as authorization. The Client resolves encrypted admin-token state before exposing Server or Fused surfaces. Command-level capability enforcement remains required for CFv2.1.0.

## Remaining
- Session-expiry and revocation push handling.
- Server-issued per-session capability grants.
- In-place animated radial menus rather than activity-backed role surfaces.
- TalkBack linear fallback and sensitive-screen suppression.
- Full client/server/fused chat routing.
