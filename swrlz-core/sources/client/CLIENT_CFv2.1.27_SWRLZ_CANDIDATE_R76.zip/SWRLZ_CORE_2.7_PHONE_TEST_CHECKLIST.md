# SWRLZ-Core 2.7 Phone Test Checklist

## Server setup
- Start Local Node Server 0.7.
- Confirm `/status` shows `local-node-server-0.7-group-relay-ledger`.
- Copy the LAN URL into the SWRLZ-Core app.

## Admin session
- Open Cmds / Two-Phone Sigil.
- Enter admin username/password.
- Tap **Activate Admin**.
- Confirm saved token says yes.
- Toggle Admin Mode OFF, close/reopen app, confirm it stays OFF.
- Toggle Admin Mode ON, close/reopen app, confirm it stays ON.
- Tap Verify and confirm success.

## Group/device
- Enter Group ID and Group Key.
- Tap Create Group.
- Enter Device ID/Label/Role.
- Tap Join Group.
- Confirm Device Key returns/saves if blank.
- Tap Check-In.
- Tap Group Devices and confirm device card appears.

## Offline queue
- On Core Phone, send SHOW_MESSAGE to Action Phone while Action Phone is not polling.
- On Action Phone, reconnect/check-in.
- Tap Pull Queue.
- Confirm queued packet appears as a card.
- Tap Displayed, Ack, Complete.
- Confirm server admin ledger shows lifecycle events.

## Group broadcast
- Join two devices to same group.
- Set target mode to `group`.
- Send PING.
- Pull queue on each device.
- Confirm each device gets its own packet and result receipt.
