# INT-AI-SWRLZX-006A — Validation Boundary

## Proven by source/JVM/localhost fixtures
- Exact CLIENT state-machine sequence, request/stream identity, routed identity, RESET and terminal guards pass.
- 10,000 synthetic 1 ms event-times map to 313 eligible 32 ms publication slots (96.87% fewer publication opportunities than per-event UI writes). This is cadence evidence, not a measured Compose recomposition count.
- Actual `ClientLlmStreamRuntime.kt` and the state machine compile in a targeted Kotlin harness with bounded Android/API stubs.
- Runtime behavior fixture passes seven cases: normal completion/persistence, renderer detach/reattach, RESET replacement, explicit V1 fallback, one pre-delta reconnect, post-delta failure with no replay/persistence, and cancellation with no persistence.
- Real localhost HTTP/1.1 chunked-NDJSON trace receives STARTED/ROUTE/three DELTAs/COMPLETED in order; first DELTA arrives before completion.
- The successful V2 API path uses byte-channel line parsing, while the legacy V1 completed-response call remains available.
- SERVER R53 preserves R52 chunked writer/stream registry/V2 route and the shared wire contract remains byte-identical across the pair.

## Measured fixture values
- State cadence fixture: 10,000 event-times -> 313 publication slots at 32 ms.
- Loopback trace: 6 events, 3 DELTAs, final text `Streaming works live.`
- First DELTA: 35.579 ms; COMPLETED: 145.847 ms; DELTA lead over completion: 110.268 ms. These are localhost architecture timings, not handset/LAN performance.

## Not proven here
- Android project compilation: wrapper bootstrap fails on `UnknownHostException: services.gradle.org` before project compilation.
- Physical-device Compose recomposition counts, Android rotation/background/network handoff behavior and process-death resume.
- Remote handset/Wi-Fi LAN TTFT/throughput, thermal/power and long soak.
- Exact optimized 229 MB LFM2 SWRLZX conversion/native device execution parity.

## Acceptance
006A CLIENT source/reader/state/render/persistence foundation: **PASS**. Android/device/network acceptance: **PENDING**.
