# CLIENT CFv2.0.60 — Theme Connector Continuity and Collapsible Forge Panels

**Android:** versionCode 87 / versionName `2.0.60-theme-connector-collapse-v1`  
**Status:** source/static prepared; GitHub build and device acceptance pending.

## Device evidence

CLIENT CFv2.0.58 built successfully. Dragon Kamileon rendered correctly across the interface, launcher/bubble identity, and upload-success notification.

After switching Theme Armor, Forge appeared disconnected and exposed a new GitHub device-code flow.

## Root cause

The Android Keystore token was loaded independently from the display login. After an alias/task refresh, `connectedLogin` began blank and Forge rendered the authorization controls while asynchronous saved-token validation was still running. This created a false disconnected state and allowed redundant OAuth authorization even when a token was present.

## Repair

- initializes the visible login from the persisted connection profile whenever a runtime token exists;
- treats token presence as connected/pending-validation rather than disconnected;
- shows `Validating the saved Android Keystore token…` during verification;
- hides the device-code and manual-token authorization controls while a saved token exists;
- retains the token on temporary validation failure;
- requires the existing approval dialog for deliberate disconnect.

Theme Armor remains visual state and cannot clear GitHub authority.

## Forge layout

`REPOSITORY TARGET` and `SOURCE PACKAGE MATCHING` are now persistent collapsible panels. Both default collapsed for a shorter bubble cockpit and remember their expanded/collapsed state.

## Acceptance

1. Build and install with the same signing certificate.
2. Connect GitHub once and verify Forge.
3. Switch through every Theme Armor family and display variant.
4. Confirm the account remains shown as saved/connected and no new device code appears.
5. Confirm both panels expand, collapse, and retain their state after navigation and restart.
