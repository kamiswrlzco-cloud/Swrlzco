# INT-APPROVAL-PRIVATE-ROOT-151A — CLIENT R59 implementation report

## Scope

CLIENT successor to R58. This checkpoint addresses two live Android Directory VFS observations while preserving the existing exact-plan destructive authority model.

## Repairs

1. **Exact file-backed filenames**
   - Raw/file-backed Directory VFS roots no longer call `DocumentFile.createFile(mimeType, requestedName)` for new files.
   - A bounded `createFileExact` path creates the exact leaf with `java.io.File` after canonical-parent validation, then wraps it with `DocumentFile.fromFile`.
   - SAF/content-provider grants retain provider-native creation behavior.
   - This removes the MIME-extension synthesis path that produced `SWRLZ_TEST_1MB.bin.bin` when `.bin` was already present.

2. **CLIENT app-private data toggle**
   - Adds built-in grant `client-app-private` for this package's own `Context.dataDir` (`/data/user/0/sh.swurlz.core` on the normal Android layout).
   - Default OFF.
   - READ-ONLY; `writeAllowed=false`; `recoveryEnabled=false`.
   - Advertised as `sensitiveScope=true`, `scope=OWN_APP_SANDBOX_ONLY`, and never selected as the default analysis root automatically.
   - Exposed in Archives & Data and first-run/ongoing Permission Centre controls.
   - This does **not** claim access to the entire `/data/user/0` parent or other packages. Normal Android sandboxing prohibits that without privileged/root authority.

## Preserved boundaries

- Android Downloads remains the default read-analysis root only when its own toggle is enabled.
- Downloads write authority still reflects actual All Files + filesystem authority.
- App-private toggle does not grant mutation authority.
- Device URIs/raw paths are not advertised to SERVER; only opaque grant identity and authority bits leave CLIENT.
- Existing exact live `MUTATION_PLAN` + explicit approval hash remains mandatory for destructive mutations on writable grants.

## Evidence boundary

Source/static checkpoint. APK/device acceptance requires the normal APK Router/device regression run.
