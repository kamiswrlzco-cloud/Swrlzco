## 2026-07-27 — INT-CHAT-039J

Workflow `30306467282` intentionally routed CLIENT only, verified the CFv2.1.19 candidate, configured the Android build environment, and reached `:app:compileDebugKotlin`. The compiler exposed one blocker at `ClientShellScreen.kt:1034:9`: `ProviderMeshStatusStrip` invoked experimental Material3 `ModalBottomSheet` without `@OptIn(ExperimentalMaterial3Api::class)`. Candidate v2 adds the narrow function-level opt-in. The validation method was hardened with `scripts/verify_compose_experimental_optins.py`; its negative/positive self-test and full Kotlin production-source scan pass. The candidate is not promoted until Android compilation/build evidence is green.

## 2026-07-27 — INT-CHAT-039I

Created an adaptive Chat candidate from CLIENT CFv2.1.18 after on-device evidence showed the parent running. Added test-first `ChatWorkspacePolicy`, IME-aware bottom chrome suppression, compact provider mesh, active-conversation onboarding collapse, secondary telemetry collapse, and compact Kapanion composer. Pure Kotlin acceptance vectors pass. Full Android Gradle compilation is pending because the local execution environment does not contain the Android SDK/dependency cache; this candidate is not promoted as compile/build verified.

---

