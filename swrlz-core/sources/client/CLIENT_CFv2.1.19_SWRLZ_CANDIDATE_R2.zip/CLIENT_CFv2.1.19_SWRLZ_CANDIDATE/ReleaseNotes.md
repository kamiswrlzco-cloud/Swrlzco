# CLIENT CFv2.1.18 — Forge Rescue Profile-Store Compile Repair

Checkpoint: `INT-FIX-039G`

- Repairs the `ClientProfileStore.resolveClientToServer` provider-profile expression that blocked `compileDebugKotlin` in workflow `30302109949`.
- Changes the incorrect function-symbol nullable access `providerProfileId?.let` to the declared `providerId?.let`.
- Audits SERVER CFv2.1.7 profile-store Kotlin; the corresponding SERVER paths are already correct, so SERVER remains unchanged.
- Preserves the CFv2.1.17 default-theme Forge rescue payload and GitHub credential/write-preflight repair.
- Source/static verification only; successful compilation remains pending the next authorized build/workflow.

---

# CLIENT CFv2.1.17 — Forge Rescue / Default-Theme Bootstrap

Checkpoint: `INT-FORGE-039E`

This source-only rescue successor is intentionally transport-light. It preserves the current CLIENT code lineage while exposing only the canonical default `Glitch Dragon Glass` ThemePack at runtime and removing optional ThemePack/ignition payloads from the package so the Forge uploader repair can itself be transported through older CLIENT builds.

## Forge repair

- Preflight now proves authentication, repository read, and `Contents: write` before a large transfer by creating a tiny unreferenced Git blob. The probe does not modify a branch/tree/file.
- A 401 during a later repository operation is no longer automatically interpreted as proof that the credential is revoked. Forge re-probes authentication and preserves the credential when the re-probe succeeds.
- 422 `input was too large` is classified as a transport-size failure, not an authentication failure.
- Sanitized GitHub request ID / accepted-permission evidence is included when supplied by GitHub.

## Temporary bootstrap theme boundary

- Runtime registry selectable set: `Glitch Dragon Glass` only.
- Alternate launcher aliases are removed from the bootstrap Android manifest.
- Optional theme progress, ignition, launcher, Kapanion, and legacy alternate identity artwork is omitted.
- The full declarative ThemePack definitions remain in source lineage for restoration; this bootstrap edition is not a design rollback.
- ThemePack authority/trust/protocol/mission semantics are unchanged.

## Evidence boundary

Source/static/package verification only. No Gradle build, APK, device acceptance, GitHub upload, workflow, commit, push, release, deployment, or installation is claimed.
