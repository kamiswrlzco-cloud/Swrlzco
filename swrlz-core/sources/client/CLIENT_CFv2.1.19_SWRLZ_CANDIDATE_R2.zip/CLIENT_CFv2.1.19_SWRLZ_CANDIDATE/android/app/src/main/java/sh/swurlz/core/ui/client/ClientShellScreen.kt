package sh.swurlz.core.ui.client

import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeveloperMode
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.PanTool
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import sh.swurlz.core.net.GroupClientApi
import sh.swurlz.core.net.CoreNodeApi
import sh.swurlz.core.github.ForgeRuntimeState
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.ai.GeminiClient
import sh.swurlz.core.ai.SwrlzIntentRouter
import sh.swurlz.core.ai.ProviderClientRuntime
import sh.swurlz.core.ai.ProviderSourceIntentParser
import sh.swrlz.provider.ProviderHealthStatus
import sh.swrlz.provider.ProviderHealthV1
import sh.swrlz.provider.ProviderId
import sh.swrlz.provider.ProviderMeshSnapshotV1
import sh.swrlz.provider.ProviderReasonRequestV1
import sh.swrlz.provider.ProviderSourceAnalyzeRequestV1
import sh.swrlz.provider.ProviderStrategy
import sh.swrlz.provider.ProviderTagParser
import sh.swurlz.core.github.ChatForgeCoordinator
import sh.swurlz.core.update.AutonomousUpdateCoordinator
import sh.swurlz.core.github.GitHubForgeClient
import sh.swurlz.core.github.GitHubConnectionStore
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.PermissionHelper
import sh.swurlz.core.data.MissionBus
import sh.swurlz.core.data.ChatRuntimeBus
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.CoreNodeTruthState
import sh.swurlz.core.model.ChatSettings
import sh.swurlz.core.model.ChatWorkspacePolicy
import sh.swurlz.core.profile.ClientProfileStore
import sh.swrlz.profile.BuiltInProfiles
import sh.swrlz.profile.ProfileDocumentV1
import sh.swrlz.profile.ProfileScope
import sh.swrlz.profile.SwrlzProfileV1
import sh.swurlz.core.model.UiStyleSettings
import sh.swurlz.core.net.ClientPresenceRegistration
import sh.swurlz.core.net.CoreNodeAutoDiscovery
import sh.swurlz.core.overlay.OverlayService
import sh.swurlz.core.service.MissionRunnerService
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import sh.swurlz.core.ui.theme.LocalThemeMotionPolicy
import sh.swurlz.core.ui.theme.LocalThemePack
import sh.swurlz.core.ui.theme.ProgressSnapshot
import sh.swurlz.core.ui.theme.ThemeAppBackdrop
import sh.swurlz.core.ui.theme.ThemeChromeBox
import sh.swurlz.core.ui.theme.ThemeChromePanel
import sh.swurlz.core.ui.theme.ThemeKapanionAvatar
import sh.swurlz.core.ui.theme.ThemedProgressBar
import sh.swurlz.core.ui.screens.GitHubForgeScreen
import sh.swrlz.theme.ThemeProgressState

private enum class ClientTab(val label: String, val icon: ImageVector) {
    Core("Core", Icons.Outlined.Home),
    Chat("Chat", Icons.Outlined.Chat),
    Groups("Groups", Icons.Outlined.Hub),
    Missions("Missions", Icons.Outlined.ListAlt),
    Activity("Activity", Icons.Outlined.Radar),
    Forge("Forge", Icons.Outlined.Build),
    Settings("Settings", Icons.Outlined.Settings),
}

private data class ClientMessage(val fromUser: Boolean, val text: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientShellScreen(
    onOpenDeveloper: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenDiscovery: () -> Unit,
    onOpenCoreAdmin: () -> Unit,
    onOpenStyle: () -> Unit,
    onOpenSetup: () -> Unit,
    onOpenForge: () -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    val mission by MissionBus.mission.collectAsState()
    val ambient by MissionBus.ambient.collectAsState()
    val timeline by MissionBus.timeline.collectAsState()
    val paused by MissionBus.pauseRequest.collectAsState()
    val needsApproval by MissionBus.needsApproval.collectAsState()
    val style by Prefs.uiStyleFlow(context).collectAsState(initial = UiStyleSettings())
    val nodeTruth by Prefs.coreNodeTruthStateFlow(context).collectAsState(initial = CoreNodeTruthState())
    val statusNotificationEnabled by Prefs.statusNotificationEnabledFlow(context).collectAsState(initial = true)
    val chatAutoFollow by Prefs.chatAutoFollowFlow(context).collectAsState(initial = true)
    val chatSettings by Prefs.chatSettingsFlow(context).collectAsState(initial = ChatSettings())
    val profileDocument by ClientProfileStore.documentFlow(context).collectAsState(initial = ProfileDocumentV1())
    val providerSnapshot by ProviderClientRuntime.snapshot.collectAsState()
    val missionStartApprovalMode by Prefs.missionStartApprovalModeFlow(context).collectAsState(initial = "Always ask")

    val motionEnabled = style.animationLevel != "Off"
    var selectedTabName by rememberSaveable { mutableStateOf(ClientTab.Core.name) }
    val selectedTab = ClientTab.entries.firstOrNull { it.name == selectedTabName } ?: ClientTab.Core
    val imeVisible = WindowInsets.ime.asPaddingValues().calculateBottomPadding() > 0.dp
    var showSovereignty by remember { mutableStateOf(false) }
    var showApproval by remember { mutableStateOf(false) }
    var pendingMissionStart by remember { mutableStateOf<String?>(null) }
    var chatDraft by rememberSaveable { mutableStateOf("") }
    var lastMissionCandidate by rememberSaveable { mutableStateOf("") }
    var showGeminiConnectOffer by remember { mutableStateOf(false) }
    var showGeminiKeyDialog by remember { mutableStateOf(false) }
    var geminiKeyDraft by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ClientMessage(
                fromUser = false,
                text = "I’m ready. Tell me the outcome you want; I’ll keep local work local and pause before sensitive steps.",
            )
        )
    }
    val shellChatLayout = ChatWorkspacePolicy.resolve(
        imeVisible = imeVisible,
        hasUserConversation = messages.any { it.fromUser },
        providerStatusEnabled = chatSettings.showProviderStatus,
    )

    fun select(tab: ClientTab) {
        selectedTabName = tab.name
    }

    fun notify(message: String) {
        scope.launch { snackbar.showSnackbar(message) }
    }

    fun seedChat(prompt: String) {
        chatDraft = prompt
        select(ClientTab.Chat)
    }

    LaunchedEffect(needsApproval) {
        if (needsApproval) showApproval = true
    }

    LaunchedEffect(Unit) {
        ProviderClientRuntime.refresh(context)
    }

    LaunchedEffect(chatSettings.autoOpenRuntimeEvents) {
        ChatRuntimeBus.events.collect { event ->
            messages += ClientMessage(false, event)
            if (chatSettings.autoOpenRuntimeEvents) select(ClientTab.Chat)
        }
    }

    var previousForgeStep by remember { mutableStateOf(ChatForgeCoordinator.Step.IDLE) }
    val forgeState by ChatForgeCoordinator.state.collectAsState()
    LaunchedEffect(forgeState.step, forgeState.title, forgeState.detail) {
        if (forgeState.step != previousForgeStep) {
            val milestone = when (forgeState.step) {
                ChatForgeCoordinator.Step.NEEDS_GITHUB -> "Forge needs GitHub access before I can continue."
                ChatForgeCoordinator.Step.ASK_SHA_PAIRING -> "GitHub is ready. Choose whether you want SHA pairing for this Forge run."
                ChatForgeCoordinator.Step.NEEDS_FILES -> "Forge is ready for the source files."
                ChatForgeCoordinator.Step.READY_TO_UPLOAD -> "Files are staged and ready. I’m waiting for your approval to upload."
                ChatForgeCoordinator.Step.UPLOADING -> "Forge upload started. I’ll keep the live progress card updated here."
                ChatForgeCoordinator.Step.LOADING_WORKFLOWS -> "Upload finished. I’m loading workflow actions tied to this upload."
                ChatForgeCoordinator.Step.WATCHING_WORKFLOWS -> "Forge is tracking the workflows tied to this upload."
                ChatForgeCoordinator.Step.ARTIFACTS_READY -> "Forge finished with artifact(s) ready to download."
                ChatForgeCoordinator.Step.COMPLETE -> "Forge operation complete."
                ChatForgeCoordinator.Step.CANCELLED -> "Forge stopped. I won’t start any additional steps from this chat session."
                ChatForgeCoordinator.Step.FAILED -> "Forge stopped because something failed: ${forgeState.detail}"
                else -> null
            }
            if (milestone != null) {
                messages += ClientMessage(false, milestone)
                if (chatSettings.autoOpenRuntimeEvents) select(ClientTab.Chat)
            }
            previousForgeStep = forgeState.step
        }
    }

    Box(Modifier.fillMaxSize().background(tokens.surfaces.bgApp)) {
        GlitchDragonBackdrop(motionEnabled = motionEnabled)

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(snackbar) },
            topBar = {
                ClientTopBar(
                    selectedTab = selectedTab,
                    ambient = ambient,
                    approvalWaiting = needsApproval,
                    onOpenSovereignty = { showSovereignty = true },
                )
            },
            bottomBar = {
                if (selectedTab != ClientTab.Chat || shellChatLayout.showBottomNavigation) {
                    Column {
                        ClientVersionFooter()
                        ClientBottomBar(selected = selectedTab, onSelect = ::select)
                    }
                }
            },
        ) { innerPadding ->
            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = {
                    if (!motionEnabled) {
                        EnterTransition.None togetherWith ExitTransition.None
                    } else {
                        val direction = if (targetState.ordinal >= initialState.ordinal) 1 else -1
                        (
                            slideInHorizontally(tween(320)) { width -> direction * width / 5 } +
                                fadeIn(tween(240))
                            ) togetherWith (
                            slideOutHorizontally(tween(260)) { width -> -direction * width / 7 } +
                                fadeOut(tween(180))
                            )
                    }
                },
                label = "client-tab-transition",
                modifier = Modifier.fillMaxSize().padding(innerPadding),
            ) { tab ->
                when (tab) {
                    ClientTab.Core -> ClientCoreScreen(
                        mission = mission,
                        ambient = ambient,
                        paused = paused,
                        motionEnabled = motionEnabled,
                        onSpeak = { seedChat("") },
                        onCreate = { seedChat("Create ") },
                        onObserve = { seedChat("Observe this and help me ") },
                        onTeach = { seedChat("Teach and record this workflow: ") },
                        onConnect = onOpenDiscovery,
                        onOpenMission = { select(ClientTab.Missions) },
                        truth = nodeTruth,
                        onOpenDiscovery = onOpenDiscovery,
                        onOpenCoreAdmin = onOpenCoreAdmin,
                        onOpenGroups = { select(ClientTab.Groups) },
                        onNotify = ::notify,
                    )

                    ClientTab.Chat -> ClientChatScreen(
                        messages = messages,
                        draft = chatDraft,
                        mission = mission,
                        autoFollow = chatAutoFollow,
                        followTarget = chatSettings.followTarget,
                        providerSnapshot = providerSnapshot,
                        showProviderStatus = chatSettings.showProviderStatus,
                        providerStrategy = chatSettings.providerStrategy,
                        imeVisible = imeVisible,
                        onProviderStrategyChanged = { strategy -> scope.launch { Prefs.setChatSettings(context, chatSettings.copy(providerStrategy = strategy)) } },
                        onProbeProviders = { scope.launch { ProviderClientRuntime.probeAll(context) } },
                        onDraftChange = { chatDraft = it },
                        onOpenPermissions = onOpenPermissions,
                        onSend = { goal ->
                            messages += ClientMessage(true, goal)
                            chatDraft = ""
                            val providerTag = ProviderTagParser.resolve(goal, chatSettings.providerStrategy)
                            val routedGoal = providerTag.cleanedPrompt.ifBlank { goal }
                            val routed = SwrlzIntentRouter.classify(routedGoal)
                            when (routed.kind) {
                                    SwrlzIntentRouter.Kind.PROVIDER_SOURCE_ANALYSIS -> {
                                    val sourceIntent = ProviderSourceIntentParser.parse(goal)
                                    if (sourceIntent == null) {
                                        messages += ClientMessage(false, "I couldn't resolve which canonical SWRLZ source you meant.")
                                    } else {
                                        val sourceStrategy = when {
                                            providerTag.explicit -> providerTag.strategy
                                            sourceIntent.providerHint == "openai" -> ProviderStrategy.OPENAI
                                            sourceIntent.providerHint == "gemini" -> ProviderStrategy.GEMINI
                                            sourceIntent.providerHint == "council" -> ProviderStrategy.COUNCIL
                                            else -> chatSettings.providerStrategy
                                        }
                                        messages += ClientMessage(false, "SWRLZ is resolving the latest canonical ${sourceIntent.component} source, verifying its checksum/manifest, sanitizing the analysis bundle, then routing it through ${sourceStrategy.name}…")
                                        scope.launch {
                                            val result = runCatching {
                                                withContext(Dispatchers.IO) {
                                                    CoreNodeApi.analyzeCanonicalSource(
                                                        context,
                                                        ProviderSourceAnalyzeRequestV1(
                                                            component = sourceIntent.component,
                                                            strategy = sourceStrategy,
                                                            prompt = routedGoal,
                                                            allowPaidProviders = providerTag.explicit || sourceIntent.providerHint != null || chatSettings.allowRemoteProvidersAutomatically,
                                                        ),
                                                    )
                                                }
                                            }
                                            messages.removeLastOrNull()
                                            result.onSuccess { response ->
                                                messages += ClientMessage(false, response.swrlzText ?: response.errors.joinToString(" · ").ifBlank { "Provider source analysis returned no text." })
                                                ProviderClientRuntime.refresh(context)
                                            }.onFailure { failure ->
                                                messages += ClientMessage(false, "I couldn't dispatch that canonical source analysis: ${failure.message?.take(220) ?: "provider route unavailable"}")
                                            }
                                        }
                                    }
                                }
                                SwrlzIntentRouter.Kind.QUICK_ACTION_SETTINGS -> {
                                        runCatching {
                                            context.startActivity(Intent(AndroidSettings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                        }.onSuccess {
                                            messages += ClientMessage(false, "Yep — opening Settings.")
                                        }.onFailure {
                                            messages += ClientMessage(false, "I couldn't launch Settings directly, so I'll need an alternate device route.")
                                        }
                                    }
                                    SwrlzIntentRouter.Kind.UPDATE -> {
                                        messages += ClientMessage(false, "I’m starting the v2.1 autonomous update loop: locate exact ZIP/SHA → verify → Forge upload → watch build → analyze failure or retrieve artifact → prepare install handoff.")
                                        scope.launch { AutonomousUpdateCoordinator.start(context, goal) }
                                    }
                                    SwrlzIntentRouter.Kind.FORGE -> {
                                        val lower = goal.lowercase()
                                        val target = when {
                                            ("client" in lower && "server" in lower) || "both" in lower || "combo" in lower -> ChatForgeCoordinator.PackageTarget.BOTH
                                            "client" in lower -> ChatForgeCoordinator.PackageTarget.CLIENT
                                            "server" in lower -> ChatForgeCoordinator.PackageTarget.SERVER
                                            "file" in lower -> ChatForgeCoordinator.PackageTarget.FILES
                                            else -> ChatForgeCoordinator.PackageTarget.ASK
                                        }
                                        ChatForgeCoordinator.begin(context, target)
                                        messages += ClientMessage(false, "I’m opening a Forge session here in chat${if (target == ChatForgeCoordinator.PackageTarget.ASK) "" else " for ${target.name}"}. Protected source ZIPs will auto-resolve checksum + manifest companions when available. You can stop it at any point by saying ‘stop Forge’ or using the stop control.")
                                    }
                                    SwrlzIntentRouter.Kind.FORGE_BOOTSTRAP -> {
                                        val lower = goal.lowercase()
                                        val removeZip = listOf("remove zip", "delete zip", "without zip", "clean up zip", "cleanup zip", "discard zip").any { it in lower }
                                        ChatForgeCoordinator.beginBootstrap(context, removeZipAfterExpansion = removeZip)
                                        messages += ClientMessage(
                                            false,
                                            if (removeZip) {
                                                "Bootstrap Forge is armed for the new repository. Select the bootstrap ZIP; I’ll expand it into repository root atomically and leave the outer ZIP out of the final tree."
                                            } else {
                                                "Bootstrap Forge is armed for the new repository. Select the bootstrap ZIP; I’ll expand it into repository root. The outer ZIP stays at root unless you toggle removal in the Forge card."
                                            },
                                        )
                                    }
                                    SwrlzIntentRouter.Kind.FORGE_STOP -> {
                                        ChatForgeCoordinator.cancel()
                                    }
                                    SwrlzIntentRouter.Kind.SYSTEM_STATE -> {
                                        val lower = goal.lowercase()
                                        val answer = when {
                                            "gemini" in lower -> providerStatusSentence(providerSnapshot, ProviderId.GEMINI)
                                            "gpt" in lower || "openai" in lower -> providerStatusSentence(providerSnapshot, ProviderId.OPENAI)
                                            "provider" in lower -> providerSnapshot.providers.joinToString(" · ") { "${it.providerId.uppercase()} ${it.status.name}" }
                                            "github" in lower -> if (SecretStore.githubToken(context).isBlank()) "GitHub is not connected in Forge yet. Want to configure it now?" else "GitHub credentials are saved for Forge."
                                            "accessibility" in lower -> if (PermissionHelper.isAccessibilityEnabled(context)) "SWRLZ accessibility control is enabled." else "Accessibility control is not enabled yet. Want me to open the permission setup?"
                                            else -> "I checked the live SWRLZ runtime state, but I don’t have a dedicated status adapter for that component yet."
                                        }
                                        messages += ClientMessage(false, answer)
                                    }
                                    SwrlzIntentRouter.Kind.MISSION_STOP -> {
                                        MissionRunnerService.cancel(context, "Stopped from SWRLZ Chat")
                                        messages += ClientMessage(false, "Mission stopped. I won’t send that command to any reasoning provider.")
                                    }
                                    SwrlzIntentRouter.Kind.MISSION_PAUSE -> {
                                        MissionBus.pauseRequest.value = true
                                        MissionBus.setAmbient(MissionBus.Ambient.Paused)
                                        messages += ClientMessage(false, "Mission paused.")
                                    }
                                    SwrlzIntentRouter.Kind.MISSION_RESUME -> {
                                        MissionBus.pauseRequest.value = false
                                        messages += ClientMessage(false, "Mission resumed.")
                                    }
                                    SwrlzIntentRouter.Kind.MISSION -> {
                                        val accessibilityReady = PermissionHelper.isAccessibilityEnabled(context)
                                        val overlayReady = PermissionHelper.isOverlayGranted(context)
                                        val resolvedGoal = if (("does that" in goal.lowercase() || "do that" in goal.lowercase()) && lastMissionCandidate.isNotBlank()) lastMissionCandidate else goal
                                        if (!accessibilityReady || !overlayReady) {
                                            messages += ClientMessage(false, "This is ready to become a mission, but execution permissions are incomplete. Open permissions first and I’ll continue from the same goal.")
                                        } else if (missionStartApprovalMode == "Always ask") {
                                            pendingMissionStart = resolvedGoal
                                            messages += ClientMessage(false, "I expanded that into a mission plan. Your settings require approval before I touch Android, so I’m waiting for you to start it.")
                                        } else {
                                            OverlayService.start(context)
                                            MissionRunnerService.start(context, resolvedGoal)
                                            if (context is sh.swurlz.core.bubble.ClientBubbleActivity) context.finish()
                                            messages += ClientMessage(false, "Got it — I started that as a mission. I’ll navigate, observe, verify the result, then bring the result back into chat.")
                                        }
                                    }
                                    SwrlzIntentRouter.Kind.CHAT, SwrlzIntentRouter.Kind.QUESTION -> {
                                        val lowerGoal = goal.lowercase()
                                        val deviceModelQuestion = routed.kind == SwrlzIntentRouter.Kind.QUESTION && "model" in lowerGoal && ("phone" in lowerGoal || "device" in lowerGoal) && "settings" in lowerGoal
                                        if (deviceModelQuestion) {
                                            lastMissionCandidate = "Open Android Settings, navigate to the About phone/device area, find the device model/model name/model number visible on screen, verify it, then return to SWRLZ Chat and report the gathered model information."
                                            messages += ClientMessage(false, "You can usually find it in Settings → About phone/device → Model or Model number. I can also verify it myself by navigating there and reading the on-screen value. Want me to make that a mission?")
                                        } else {
                                            val strategy = providerTag.strategy
                                            val shouldCallProvider = providerTag.explicit || strategy != ProviderStrategy.SWRLZ_AUTO || chatSettings.allowRemoteProvidersAutomatically
                                            if (!shouldCallProvider || strategy == ProviderStrategy.LOCAL_ONLY) {
                                                messages += ClientMessage(
                                                    false,
                                                    if (routed.kind == SwrlzIntentRouter.Kind.CHAT) {
                                                        "I'm here. SWRLZ is staying local for this message. Use @gpt, @gemini, @both, or change the provider route when you want outside reasoning."
                                                    } else {
                                                        "I can reason locally first. Use @gpt, @gemini, or @both when you want the SERVER provider mesh to consult an outside model."
                                                    },
                                                )
                                            } else {
                                                val routeLabel = when (strategy) {
                                                    ProviderStrategy.OPENAI -> "GPT"
                                                    ProviderStrategy.GEMINI -> "Gemini"
                                                    ProviderStrategy.COUNCIL -> "GPT + Gemini Council"
                                                    ProviderStrategy.COMPARE -> "GPT + Gemini Compare"
                                                    else -> "SWRLZ provider mesh"
                                                }
                                                messages += ClientMessage(false, "SWRLZ is consulting $routeLabel…")
                                                scope.launch {
                                                    val request = ProviderReasonRequestV1(
                                                        strategy = strategy,
                                                        prompt = routedGoal,
                                                        systemDirective = "${chatSettings.reasoningDirective()} ${ClientProfileStore.resolveClientLocal(profileDocument).directive()}",
                                                        allowPaidProviders = providerTag.explicit || chatSettings.allowRemoteProvidersAutomatically,
                                                        requestSynthesis = strategy != ProviderStrategy.COMPARE,
                                                    )
                                                    val response = runCatching { withContext(Dispatchers.IO) { CoreNodeApi.providerReason(context, request) } }
                                                    messages.removeLastOrNull()
                                                    response.onSuccess { result ->
                                                        if (result.ok) {
                                                            messages += ClientMessage(false, result.swrlzText ?: result.contributions.joinToString("\n\n") { it.text }.ifBlank { "Provider mesh returned no text." })
                                                            ProviderClientRuntime.refresh(context)
                                                        } else {
                                                            val reason = result.errors.joinToString(" · ").ifBlank { "provider request declined" }
                                                            messages += ClientMessage(false, if ("REMOTE_PROVIDER_APPROVAL_REQUIRED" in reason) "That remote provider route needs an explicit @gpt, @gemini, or @both request (or automatic remote use enabled in Chat settings)." else "Provider mesh couldn't complete that request: $reason")
                                                        }
                                                    }.onFailure { failure ->
                                                        val legacyKey = SecretStore.geminiApiKey(context)
                                                        if (strategy == ProviderStrategy.GEMINI && legacyKey.isNotBlank() && providerTag.explicit) {
                                                            val consultantPrompt = """Legacy direct-device Gemini fallback for SWRLZ. ${chatSettings.reasoningDirective()} ${ClientProfileStore.resolveProvider(profileDocument, "gemini").directive()} User message: $routedGoal"""
                                                            val legacy = withContext(Dispatchers.IO) { GeminiClient.generate(legacyKey, consultantPrompt) }
                                                            messages += ClientMessage(false, legacy.text ?: "SERVER provider mesh was unavailable and the legacy Gemini fallback also failed: ${legacy.error ?: failure.message}")
                                                        } else {
                                                            messages += ClientMessage(false, "SWRLZ couldn't reach the SERVER provider mesh: ${failure.message?.take(220) ?: "unavailable"}")
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                        },
                    )

                    ClientTab.Groups -> ClientGroupsScreen(
                        truth = nodeTruth,
                        onNotify = ::notify,
                    )

                    ClientTab.Missions -> ClientMissionsScreen(
                        mission = mission,
                        ambient = ambient,
                        timeline = timeline,
                        paused = paused,
                        needsApproval = needsApproval,
                        onPauseToggle = {
                            MissionBus.pauseRequest.value = !MissionBus.pauseRequest.value
                            notify(if (MissionBus.pauseRequest.value) "Mission paused." else "Mission resumed.")
                        },
                        onTakeOver = {
                            MissionBus.takeoverRequest.value = true
                            MissionRunnerService.stop(context)
                            notify("You have control. SWRLZ is observing only.")
                        },
                        onReviewApproval = { showApproval = true },
                    )

                    ClientTab.Activity -> ClientActivityScreen(
                        timeline = timeline,
                        truth = nodeTruth,
                        permissionsReady = PermissionHelper.isAccessibilityEnabled(context) && PermissionHelper.isOverlayGranted(context),
                    )

                    ClientTab.Forge -> GitHubForgeScreen()

                    ClientTab.Settings -> ClientSettingsScreen(
                        style = style,
                        statusNotificationEnabled = statusNotificationEnabled,
                        chatAutoFollow = chatAutoFollow,
                        chatSettings = chatSettings,
                        missionStartApprovalMode = missionStartApprovalMode,
                        onStatusNotificationChanged = { enabled ->
                            scope.launch { Prefs.setStatusNotificationEnabled(context, enabled) }
                        },
                        onChatAutoFollowChanged = { enabled ->
                            scope.launch { Prefs.setChatAutoFollow(context, enabled) }
                        },
                        onChatSettingsChanged = { next ->
                            scope.launch { Prefs.setChatSettings(context, next) }
                        },
                        onMissionStartApprovalModeChanged = { mode ->
                            scope.launch { Prefs.setMissionStartApprovalMode(context, mode) }
                        },
                        onAutoPresenceChanged = { enabled ->
                            scope.launch { Prefs.setAutoPresenceEnabled(context, enabled) }
                        },
                        onMotionChanged = { enabled ->
                            scope.launch {
                                Prefs.setUiStyle(
                                    context,
                                    style.copy(animationLevel = if (enabled) "Standard" else "Off"),
                                )
                            }
                        },
                        onOpenStyle = onOpenStyle,
                        onOpenBubble = {
                            sh.swurlz.core.bubble.ClientBubbleController.showNow(
                                context,
                                title = "SWRLZ Client",
                                detail = if (nodeTruth.auto.success || nodeTruth.manual.success) "Server connected" else "Server offline",
                            )
                        },
                        onOpenBubbleSettings = {
                            sh.swurlz.core.bubble.ClientBubbleController.openBubbleSettings(context)
                        },
                        onOpenPermissions = onOpenPermissions,
                        onOpenDiscovery = onOpenDiscovery,
                        onOpenCoreAdmin = onOpenCoreAdmin,
                        onOpenSetup = onOpenSetup,
                        onOpenForge = onOpenForge,
                        onOpenDeveloper = onOpenDeveloper,
                    )
                }
            }
        }

        if (showGeminiConnectOffer) {
            AlertDialog(
                onDismissRequest = { showGeminiConnectOffer = false },
                title = { Text("Connect Gemini?") },
                text = { Text("SWRLZ can keep working locally, or you can add Gemini as a private reasoning provider.") },
                confirmButton = { TextButton(onClick = { showGeminiConnectOffer = false; geminiKeyDraft = ""; showGeminiKeyDialog = true }) { Text("CONNECT") } },
                dismissButton = { TextButton(onClick = { showGeminiConnectOffer = false }) { Text("NOT NOW") } },
            )
        }
        if (showGeminiKeyDialog) {
            AlertDialog(
                onDismissRequest = { showGeminiKeyDialog = false; geminiKeyDraft = "" },
                title = { Text("Gemini API key") },
                text = { OutlinedTextField(value = geminiKeyDraft, onValueChange = { geminiKeyDraft = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(), label = { Text("API key") }) },
                confirmButton = { TextButton(enabled = geminiKeyDraft.isNotBlank(), onClick = { SecretStore.setGeminiApiKey(context, geminiKeyDraft); geminiKeyDraft = ""; showGeminiKeyDialog = false; messages += ClientMessage(false, "Gemini key saved securely. I can now use Gemini as a private reasoning provider when needed.") }) { Text("SAVE") } },
                dismissButton = { TextButton(onClick = { showGeminiKeyDialog = false; geminiKeyDraft = "" }) { Text("CANCEL") } },
            )
        }

        if (showSovereignty) {
            SovereigntyDialog(
                paused = paused,
                onDismiss = { showSovereignty = false },
                onPauseToggle = {
                    MissionBus.pauseRequest.value = !MissionBus.pauseRequest.value
                    showSovereignty = false
                    notify(if (MissionBus.pauseRequest.value) "Mission paused." else "Mission resumed.")
                },
                onTakeOver = {
                    MissionBus.takeoverRequest.value = true
                    MissionRunnerService.stop(context)
                    showSovereignty = false
                    notify("Take Over armed. No further automated action will run.")
                },
            )
        }

        pendingMissionStart?.let { goal ->
            AlertDialog(
                onDismissRequest = { pendingMissionStart = null },
                title = { Text("Start SWRLZ mission?") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(goal)
                        Text("SWRLZ may navigate Android, observe visible UI, and report the verified result back into Chat. Mission-start approval does not bypass later sensitive-action gates.", color = tokens.text.secondary, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        OverlayService.start(context)
                        MissionRunnerService.start(context, goal)
                        pendingMissionStart = null
                        messages += ClientMessage(false, "Mission approved — starting now.")
                        if (context is sh.swurlz.core.bubble.ClientBubbleActivity) context.finish()
                    }) { Text("✓ START MISSION") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        pendingMissionStart = null
                        messages += ClientMessage(false, "Mission declined. I kept the plan in chat and did not touch Android.")
                    }) { Text("✕ DECLINE") }
                },
            )
        }

        if (showApproval && needsApproval) {
            ApprovalSheet(
                missionGoal = mission.goal,
                onApprove = {
                    MissionBus.approvalGranted.value = true
                    showApproval = false
                    notify("Approved once. The next gate will still pause.")
                },
                onRedirect = {
                    MissionBus.pauseRequest.value = true
                    chatDraft = "Redirect this mission step: "
                    select(ClientTab.Chat)
                    showApproval = false
                },
                onDecline = {
                    MissionBus.pauseRequest.value = true
                    showApproval = false
                    notify("Approval declined. Mission remains paused.")
                },
                onDismiss = { showApproval = false },
            )
        }
    }
}

@Composable
internal fun GlitchDragonBackdrop(
    motionEnabled: Boolean,
    artAlpha: Float? = null,
) {
    ThemeAppBackdrop(
        motionEnabled = motionEnabled,
        artAlphaOverride = artAlpha,
    )
}

@Composable
private fun ClientTopBar(
    selectedTab: ClientTab,
    ambient: MissionBus.Ambient,
    approvalWaiting: Boolean,
    onOpenSovereignty: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val pack = LocalThemePack.current
    val statusPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(tokens.surfaces.bgTopBar.copy(alpha = .58f))
            .border(1.dp, tokens.accents.primary.copy(alpha = .18f))
            .padding(top = statusPadding + 8.dp, bottom = 10.dp, start = 16.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ThemeKapanionAvatar(
            size = 42.dp,
            animated = true,
            contentDescription = "${pack.displayName} Kapanion",
            statusTone = if (approvalWaiting) tokens.status.warning else tokens.accents.primary,
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("SWRLZ · USER", color = tokens.text.primary, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.1.sp)
            val topBarState = if (selectedTab == ClientTab.Forge) ForgeRuntimeState.phase.label else ambient.name.uppercase()
            Text(
                "${selectedTab.label.uppercase()} · $topBarState",
                color = if (approvalWaiting) tokens.status.warning else when {
                    selectedTab == ClientTab.Forge && ForgeRuntimeState.phase == ForgeRuntimeState.Phase.FAILED -> tokens.status.danger
                    selectedTab == ClientTab.Forge && ForgeRuntimeState.phase in setOf(ForgeRuntimeState.Phase.BUILDING, ForgeRuntimeState.Phase.UPLOADING, ForgeRuntimeState.Phase.DOWNLOADING, ForgeRuntimeState.Phase.VALIDATING) -> tokens.status.warning
                    selectedTab == ClientTab.Forge && ForgeRuntimeState.phase in setOf(ForgeRuntimeState.Phase.COMPLETE, ForgeRuntimeState.Phase.ARTIFACTS_READY) -> tokens.status.success
                    else -> ambientColor(ambient)
                },
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                letterSpacing = 1.3.sp,
            )
        }
        if (approvalWaiting) {
            TinyPill("APPROVAL", tokens.status.warning)
            Spacer(Modifier.width(4.dp))
        }
        IconButton(onClick = onOpenSovereignty) {
            Icon(Icons.Outlined.Shield, contentDescription = "Open Pause and Take Over controls", tint = tokens.accents.primary)
        }
    }
}

@Composable
private fun ClientVersionFooter() {
    val tokens = LocalSwurlzTokens.current
    val cf = "CFv${BuildConfig.VERSION_NAME.substringBefore('-')}"
    Row(
        Modifier.fillMaxWidth()
            .background(tokens.surfaces.bgTopBar.copy(alpha = .82f))
            .border(1.dp, tokens.accents.primary.copy(alpha = .18f))
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text("CLIENT · $cf", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.sp)
        Text("VC ${BuildConfig.VERSION_CODE}", color = tokens.text.muted, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
    }
}

@Composable
private fun ClientBottomBar(selected: ClientTab, onSelect: (ClientTab) -> Unit) {
    val tokens = LocalSwurlzTokens.current
NavigationBar(
        containerColor = tokens.surfaces.bgTopBar.copy(alpha = .72f),
        tonalElevation = 0.dp,
        windowInsets = WindowInsets.navigationBars,
        modifier = Modifier.border(1.dp, tokens.accents.primary.copy(alpha = .16f)),
    ) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            ClientTab.entries.forEach { tab ->
                NavigationBarItem(
                    selected = selected == tab,
                    onClick = { onSelect(tab) },
                    modifier = Modifier.width(88.dp),
                    icon = { Icon(tab.icon, contentDescription = null) },
                    label = { Text(tab.label, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = tokens.accents.primary,
                        selectedTextColor = tokens.text.primary,
                        indicatorColor = tokens.accents.primary.copy(alpha = .13f),
                        unselectedIconColor = tokens.text.muted,
                        unselectedTextColor = tokens.text.muted,
                    ),
                )
            }
        }
    }
}

@Composable
private fun ClientCoreScreen(
    mission: MissionBus.MissionLive,
    ambient: MissionBus.Ambient,
    paused: Boolean,
    motionEnabled: Boolean,
    onSpeak: () -> Unit,
    onCreate: () -> Unit,
    onObserve: () -> Unit,
    onTeach: () -> Unit,
    onConnect: () -> Unit,
    onOpenMission: () -> Unit,
    truth: CoreNodeTruthState,
    onOpenDiscovery: () -> Unit,
    onOpenCoreAdmin: () -> Unit,
    onOpenGroups: () -> Unit,
    onNotify: (String) -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("GOOD TO SEE YOU, KAMI", color = tokens.text.muted, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.8.sp)
            Text(
                if (mission.goal.isBlank()) "Your core is ready." else "Your mission is in motion.",
                color = tokens.text.primary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = (-0.6f).sp,
            )
            Text(
                "Speak naturally. SWRLZ handles routing and exposes every sensitive gate.",
                color = tokens.text.secondary,
                fontSize = 13.sp,
                lineHeight = 18.sp,
            )
        }
        item {
            DragonCoreOrb(ambient = ambient, motionEnabled = motionEnabled, onClick = onSpeak)
        }
        if (mission.goal.isNotBlank()) {
            item {
                GlassPanel(highlighted = true, modifier = Modifier.clickable(onClick = onOpenMission)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            SectionLabel("ACTIVE MISSION")
                            Text(mission.goal, color = tokens.text.primary, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                if (mission.total > 0) "Step ${mission.step} of ${mission.total}" else mission.state.replaceFirstChar { it.uppercase() },
                                color = tokens.text.muted,
                                fontSize = 11.sp,
                            )
                        }
                        TinyPill(if (paused) "PAUSED" else ambient.name.uppercase(), if (paused) tokens.status.warning else ambientColor(ambient))
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction("Create", Icons.Outlined.CheckCircle, Modifier.weight(1f), onCreate)
                QuickAction("Observe", Icons.Outlined.Hub, Modifier.weight(1f), onObserve)
                QuickAction("Teach", Icons.Outlined.Mic, Modifier.weight(1f), onTeach)
                QuickAction("Connect", Icons.Outlined.Radar, Modifier.weight(1f), onConnect)
            }
        }
        item {
            ClientCoreNodePanel(
                truth = truth,
                onOpenDiscovery = onOpenDiscovery,
                onOpenCoreAdmin = onOpenCoreAdmin,
                onOpenGroups = onOpenGroups,
                onNotify = onNotify,
            )
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Shield, contentDescription = null, tint = tokens.status.success, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Truth Firewall armed · local-first routing active", color = tokens.text.secondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun DragonCoreOrb(
    ambient: MissionBus.Ambient,
    motionEnabled: Boolean,
    onClick: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val pack = LocalThemePack.current
    val motion = LocalThemeMotionPolicy.current
    val transition = if (motionEnabled && motion.enabled) {
        rememberInfiniteTransition(label = "client-core-orb")
    } else {
        null
    }
    val pulse = transition?.animateFloat(
        initialValue = .96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse),
        label = "core-pulse",
    )?.value ?: 1f
    Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(190.dp)
                .graphicsLayer { scaleX = pulse; scaleY = pulse }
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            tokens.accents.primary.copy(alpha = .30f),
                            tokens.accents.tertiary.copy(alpha = .18f),
                            tokens.surfaces.bgOverlay.copy(alpha = .78f),
                        )
                    )
                )
                .border(1.dp, ambientColor(ambient).copy(alpha = .85f), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            ThemeKapanionAvatar(
                size = 174.dp,
                animated = motionEnabled,
                statusTone = ambientColor(ambient),
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 20.dp)
                    .clip(RoundedCornerShape(99.dp))
                    .background(tokens.surfaces.bgOverlay.copy(alpha = .82f))
                    .border(1.dp, tokens.accents.primary.copy(alpha = .72f), RoundedCornerShape(99.dp))
                    .padding(horizontal = 12.dp, vertical = 5.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    "TAP TO SPEAK",
                    color = tokens.accents.primary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.8.sp,
                )
            }
        }
        Text(
            pack.displayName.uppercase(),
            color = tokens.text.muted,
            fontFamily = FontFamily.Monospace,
            fontSize = 8.sp,
            letterSpacing = 1.4.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp),
        )
        TinyPill("LOCAL FIRST", tokens.accents.primary, Modifier.align(Alignment.TopEnd).padding(top = 18.dp, end = 10.dp))
        TinyPill("TRUTH FIREWALL · ON", tokens.status.success, Modifier.align(Alignment.BottomStart).padding(bottom = 18.dp, start = 4.dp))
    }
}

private fun providerStatusSentence(snapshot: ProviderMeshSnapshotV1, providerId: ProviderId): String {
    val health = snapshot.providers.firstOrNull { it.providerId == providerId.wireId }
        ?: return "${providerId.wireId} has no status record yet."
    val model = health.selectedModel?.let { " · model $it" }.orEmpty()
    return "${providerId.wireId.uppercase()} is ${health.status.name.replace('_', ' ')}$model. ${health.detail}"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProviderMeshStatusStrip(
    snapshot: ProviderMeshSnapshotV1,
    strategy: ProviderStrategy,
    onStrategyChanged: (ProviderStrategy) -> Unit,
    onProbeAll: () -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    ProviderMeshCompactBar(
        snapshot = snapshot,
        strategy = strategy,
        onExpand = { expanded = true },
    )
    if (expanded) {
        ModalBottomSheet(onDismissRequest = { expanded = false }) {
            ProviderMeshExpandedPanel(
                snapshot = snapshot,
                strategy = strategy,
                onStrategyChanged = onStrategyChanged,
                onProbeAll = onProbeAll,
                onDismiss = { expanded = false },
            )
        }
    }
}

@Composable
private fun ProviderMeshCompactBar(
    snapshot: ProviderMeshSnapshotV1,
    strategy: ProviderStrategy,
    onExpand: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    ThemeChromeBox(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onExpand),
        innerPadding = 1.dp,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("🧠", fontSize = 14.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                strategy.chatLabel(),
                color = tokens.accents.primary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.width(8.dp))
            Row(
                modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ProviderStatusMini("SWRLZ", ProviderHealthStatus.READY)
                ProviderStatusMini("SERVER", if (snapshot.swrlzIdentity.contains("SERVER", ignoreCase = true)) ProviderHealthStatus.READY else ProviderHealthStatus.OFFLINE)
                ProviderStatusMini("GPT", snapshot.providers.firstOrNull { it.providerId == ProviderId.OPENAI.wireId }?.status ?: ProviderHealthStatus.OFFLINE)
                ProviderStatusMini("GEM", snapshot.providers.firstOrNull { it.providerId == ProviderId.GEMINI.wireId }?.status ?: ProviderHealthStatus.OFFLINE)
            }
            Icon(Icons.Outlined.ChevronRight, contentDescription = "Expand reasoning mesh", tint = tokens.text.muted, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun ProviderMeshExpandedPanel(
    snapshot: ProviderMeshSnapshotV1,
    strategy: ProviderStrategy,
    onStrategyChanged: (ProviderStrategy) -> Unit,
    onProbeAll: () -> Unit,
    onDismiss: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp)) {
        Text("REASONING MESH", color = tokens.text.primary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("SWRLZ remains the conversation owner; providers are selectable reasoning routes.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
        Spacer(Modifier.height(12.dp))
        ProviderMeshDetailRow("SWRLZ CLIENT", ProviderHealthStatus.READY, "Local conversation authority")
        ProviderMeshDetailRow("SWRLZ SERVER", if (snapshot.swrlzIdentity.contains("SERVER", ignoreCase = true)) ProviderHealthStatus.READY else ProviderHealthStatus.OFFLINE, snapshot.swrlzIdentity)
        val openAi = snapshot.providers.firstOrNull { it.providerId == ProviderId.OPENAI.wireId }
        val gemini = snapshot.providers.firstOrNull { it.providerId == ProviderId.GEMINI.wireId }
        ProviderMeshDetailRow("OpenAI / GPT", openAi?.status ?: ProviderHealthStatus.OFFLINE, openAi?.selectedModel ?: "AUTO")
        ProviderMeshDetailRow("Gemini", gemini?.status ?: ProviderHealthStatus.OFFLINE, gemini?.selectedModel ?: "AUTO")
        Spacer(Modifier.height(12.dp))
        Text("ROUTING", color = tokens.text.muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.4.sp)
        listOf(
            ProviderStrategy.SWRLZ_AUTO,
            ProviderStrategy.LOCAL_ONLY,
            ProviderStrategy.OPENAI,
            ProviderStrategy.GEMINI,
            ProviderStrategy.COUNCIL,
            ProviderStrategy.COMPARE,
        ).forEach { option ->
            TextButton(
                onClick = { onStrategyChanged(option) },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(if (option == strategy) "✓ ${option.chatLabel()}" else option.chatLabel(), modifier = Modifier.fillMaxWidth())
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onProbeAll, modifier = Modifier.weight(1f)) { Text("PROBE ALL") }
            TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("CLOSE") }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun ProviderMeshDetailRow(label: String, status: ProviderHealthStatus, detail: String) {
    val tokens = LocalSwurlzTokens.current
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ProviderStatusMini(label, status)
        Spacer(Modifier.width(8.dp))
        Text(detail, color = tokens.text.muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun ProviderStatusMini(label: String, status: ProviderHealthStatus) {
    val tone = when (status) {
        ProviderHealthStatus.READY -> Color(0xFF45FF98)
        ProviderHealthStatus.PROBING -> Color(0xFFFFD65A)
        ProviderHealthStatus.STORED, ProviderHealthStatus.DEGRADED -> Color(0xFFFFB74D)
        ProviderHealthStatus.AUTH_FAILED, ProviderHealthStatus.ERROR -> Color(0xFFFF6B7A)
        else -> Color(0xFF7D8796)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).background(tone, CircleShape))
        Spacer(Modifier.width(4.dp))
        Text("$label ${status.name.replace('_', ' ')}", color = LocalSwurlzTokens.current.text.secondary, fontSize = 8.sp)
    }
}

private fun ProviderStrategy.chatLabel(): String = when (this) {
    ProviderStrategy.SWRLZ_AUTO -> "SWRLZ AUTO"
    ProviderStrategy.LOCAL_ONLY -> "LOCAL ONLY"
    ProviderStrategy.OPENAI -> "GPT"
    ProviderStrategy.GEMINI -> "GEMINI"
    ProviderStrategy.COUNCIL -> "GPT + GEMINI"
    ProviderStrategy.COMPARE -> "COMPARE"
}

@Composable
private fun ClientChatScreen(
    messages: List<ClientMessage>,
    draft: String,
    mission: MissionBus.MissionLive,
    autoFollow: Boolean,
    followTarget: String,
    providerSnapshot: ProviderMeshSnapshotV1,
    showProviderStatus: Boolean,
    providerStrategy: ProviderStrategy,
    imeVisible: Boolean,
    onProviderStrategyChanged: (ProviderStrategy) -> Unit,
    onProbeProviders: () -> Unit,
    onDraftChange: (String) -> Unit,
    onOpenPermissions: () -> Unit,
    onSend: (String) -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    val permissionsReady = PermissionHelper.isAccessibilityEnabled(context) && PermissionHelper.isOverlayGranted(context)
    val listState = rememberLazyListState()
    var followSession by remember { mutableStateOf(true) }
    var programmaticScroll by remember { mutableStateOf(false) }
    var previousFirstIndex by remember { mutableStateOf(0) }
    var previousFirstOffset by remember { mutableStateOf(0) }
    var previousRationale by remember { mutableStateOf(mission.rationale) }
    var showCommandQuickMenu by remember { mutableStateOf(false) }
    var showCommandCenter by remember { mutableStateOf(false) }
    val renderedItemCount = messages.size + if (mission.rationale.isNotBlank()) 1 else 0
    val latestAssistantIndex = messages.indexOfLast { !it.fromUser }
    val rationaleIndex = if (mission.rationale.isNotBlank()) messages.size else -1
    val atBottom by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            if (info.totalItemsCount == 0) true
            else info.visibleItemsInfo.lastOrNull()?.index == info.totalItemsCount - 1
        }
    }

    suspend fun animateToFollowTarget(targetOverride: Int? = null) {
        val target = targetOverride ?: if (followTarget == ChatSettings.FOLLOW_BOTTOM) {
            renderedItemCount - 1
        } else {
            latestAssistantIndex.takeIf { it >= 0 } ?: rationaleIndex
        }
        if (target < 0) return
        programmaticScroll = true
        try {
            listState.animateScrollToItem(target, 0)
        } finally {
            programmaticScroll = false
        }
    }

    LaunchedEffect(
        listState.isScrollInProgress,
        listState.firstVisibleItemIndex,
        listState.firstVisibleItemScrollOffset,
        followTarget,
    ) {
        val currentIndex = listState.firstVisibleItemIndex
        val currentOffset = listState.firstVisibleItemScrollOffset
        val movedUp = currentIndex < previousFirstIndex || (currentIndex == previousFirstIndex && currentOffset < previousFirstOffset)
        if (listState.isScrollInProgress && !programmaticScroll && movedUp) followSession = false
        previousFirstIndex = currentIndex
        previousFirstOffset = currentOffset
    }

    LaunchedEffect(atBottom, followTarget) {
        if (followTarget == ChatSettings.FOLLOW_BOTTOM && atBottom) followSession = true
    }

    LaunchedEffect(messages.size, mission.rationale, autoFollow, followSession, followTarget) {
        val assistantAppended = messages.lastOrNull()?.fromUser == false
        val rationaleChanged = mission.rationale.isNotBlank() && mission.rationale != previousRationale
        if (autoFollow && followSession && renderedItemCount > 0) {
            if (followTarget == ChatSettings.FOLLOW_BOTTOM) {
                animateToFollowTarget()
            } else {
                val responseTarget = when {
                    assistantAppended -> latestAssistantIndex
                    rationaleChanged -> rationaleIndex
                    else -> -1
                }
                if (responseTarget >= 0) animateToFollowTarget(responseTarget)
            }
        }
        previousRationale = mission.rationale
    }
    val hasUserConversation = messages.any { it.fromUser }
    val workspaceLayout = ChatWorkspacePolicy.resolve(
        imeVisible = imeVisible,
        hasUserConversation = hasUserConversation,
        providerStatusEnabled = showProviderStatus,
    )
    val showChatOnboarding = workspaceLayout.showOnboarding

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = if (imeVisible) 6.dp else 12.dp)
            .imePadding()
    ) {
        if (showChatOnboarding) {
            Text("COUNCIL CHAT", color = tokens.text.muted, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.8.sp)
            Text("Say it your way.", color = tokens.text.primary, fontSize = 28.sp, fontWeight = FontWeight.Medium)
            Text("No command syntax. Sensitive actions always stop for you.", color = tokens.text.secondary, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
        }

        if (workspaceLayout.showProviderCompactBar) {
            ProviderMeshStatusStrip(
                snapshot = providerSnapshot,
                strategy = providerStrategy,
                onStrategyChanged = onProviderStrategyChanged,
                onProbeAll = onProbeProviders,
            )
            Spacer(Modifier.height(if (imeVisible) 5.dp else 8.dp))
        }

        BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
            val responseTopReserve = if (followTarget == ChatSettings.FOLLOW_RESPONSE_TOP && maxHeight > 72.dp) maxHeight - 72.dp else 10.dp
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(9.dp),
                contentPadding = PaddingValues(bottom = responseTopReserve),
            ) {
                items(messages) { message -> ChatBubble(message) }
                if (mission.rationale.isNotBlank()) {
                    item { ChatBubble(ClientMessage(false, mission.rationale)) }
                }
            }
        }

        if (autoFollow && !followSession && renderedItemCount > 0) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = {
                    followSession = true
                    scope.launch { animateToFollowTarget() }
                }) { Text("↓ LATEST") }
            }
        }

        if (workspaceLayout.showSecondaryTelemetry) {
            ChatForgeCard()
            Spacer(Modifier.height(6.dp))
            SwrlzCompanionRail(mission = mission)
            Spacer(Modifier.height(6.dp))
        }

        if (!imeVisible && !permissionsReady) {
            ThemeChromeBox(modifier = Modifier.fillMaxWidth(), innerPadding = 1.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Permissions incomplete · execution stays paused", color = tokens.status.warning, fontSize = 9.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = onOpenPermissions, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 2.dp)) { Text("OPEN", fontSize = 9.sp) }
                }
            }
            Spacer(Modifier.height(6.dp))
        }

        if (showCommandCenter) {
            ChatCommandCenterDialog(
                onDismiss = { showCommandCenter = false },
                onInsert = { template -> onDraftChange(template) },
            )
        }

        ChatCompactComposer(
            draft = draft,
            maxLines = workspaceLayout.composerMaxLines,
            quickMenuExpanded = showCommandQuickMenu,
            onQuickMenuChanged = { showCommandQuickMenu = it },
            onOpenCommandCenter = { showCommandCenter = true },
            onDraftChange = onDraftChange,
            onSend = {
                if (draft.isNotBlank()) {
                    followSession = true
                    onSend(draft.trim())
                }
            },
        )
    }
}


@Composable
private fun ChatCompactComposer(
    draft: String,
    maxLines: Int,
    quickMenuExpanded: Boolean,
    onQuickMenuChanged: (Boolean) -> Unit,
    onOpenCommandCenter: () -> Unit,
    onDraftChange: (String) -> Unit,
    onSend: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    ThemeChromeBox(modifier = Modifier.fillMaxWidth(), innerPadding = 1.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(contentAlignment = Alignment.Center) {
                IconButton(onClick = { onQuickMenuChanged(true) }, modifier = Modifier.size(40.dp)) {
                    ThemeKapanionAvatar(size = 30.dp, animated = false, contentDescription = "Open Chat quick actions")
                }
                ChatCommandQuickMenu(
                    expanded = quickMenuExpanded,
                    onDismiss = { onQuickMenuChanged(false) },
                    onInsert = { template -> onDraftChange(template) },
                    onOpenCommandCenter = onOpenCommandCenter,
                )
            }
            TextField(
                value = draft,
                onValueChange = onDraftChange,
                placeholder = { Text("Message SWRLZ…") },
                modifier = Modifier.weight(1f),
                minLines = 1,
                maxLines = maxLines.coerceIn(1, 6),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = tokens.accents.primary,
                ),
            )
            IconButton(onClick = onSend, enabled = draft.isNotBlank()) {
                Icon(
                    Icons.Outlined.Send,
                    contentDescription = "Send message",
                    tint = if (draft.isNotBlank()) tokens.accents.primary else tokens.text.muted,
                )
            }
        }
    }
}

@Composable
private fun ChatForgeCard() {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    val state by ChatForgeCoordinator.state.collectAsState()
    var tokenDraft by remember { mutableStateOf("") }
    var showToken by remember { mutableStateOf(false) }
    var pendingDownload by remember { mutableStateOf<Pair<String, ByteArray>?>(null) }
    val prefs = remember { context.getSharedPreferences("swrlz_forge_chat", android.content.Context.MODE_PRIVATE) }

    fun saveArtifactToTree(treeUri: Uri, name: String, bytes: ByteArray): Boolean = runCatching {
        val resolver = context.contentResolver
        val treeId = DocumentsContract.getTreeDocumentId(treeUri)
        val parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeId)
        val mime = if (name.endsWith(".apk", true)) "application/vnd.android.package-archive" else "application/zip"
        val doc = DocumentsContract.createDocument(resolver, parent, mime, name) ?: error("Unable to create artifact file.")
        resolver.openOutputStream(doc, "w")?.use { it.write(bytes) } ?: error("Unable to open artifact output stream.")
        true
    }.getOrDefault(false)

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
        ChatForgeCoordinator.stageFiles(context, uris)
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        val pending = pendingDownload
        if (uri != null && pending != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            prefs.edit().putString("artifact_tree_uri", uri.toString()).apply()
            if (saveArtifactToTree(uri, pending.first, pending.second)) ChatForgeCoordinator.markDownloaded(pending.first)
            pendingDownload = null
        }
    }

    LaunchedEffect(state.step, state.commitSha) {
        if (state.step == ChatForgeCoordinator.Step.WATCHING_WORKFLOWS || state.step == ChatForgeCoordinator.Step.LOADING_WORKFLOWS) {
            repeat(90) {
                kotlinx.coroutines.delay(2_000)
                runCatching { ChatForgeCoordinator.refresh(context) }
                if (ChatForgeCoordinator.state.value.step !in setOf(ChatForgeCoordinator.Step.WATCHING_WORKFLOWS, ChatForgeCoordinator.Step.LOADING_WORKFLOWS)) return@repeat
            }
        }
    }

    if (state.step == ChatForgeCoordinator.Step.IDLE) return
    GlassPanel(modifier = Modifier.fillMaxWidth()) {
        Text("FORGE · ${state.title.uppercase()}", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(4.dp))
        Text(state.detail, color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
        if (state.progress != null || state.step in setOf(
                ChatForgeCoordinator.Step.VALIDATING,
                ChatForgeCoordinator.Step.UPLOADING,
                ChatForgeCoordinator.Step.LOADING_WORKFLOWS,
                ChatForgeCoordinator.Step.WATCHING_WORKFLOWS,
                ChatForgeCoordinator.Step.DOWNLOADING,
                ChatForgeCoordinator.Step.COMPLETE,
                ChatForgeCoordinator.Step.CANCELLED,
                ChatForgeCoordinator.Step.FAILED,
            )
        ) {
            Spacer(Modifier.height(7.dp))
            ThemedProgressBar(
                snapshot = ProgressSnapshot(
                    operationId = state.transactionId.ifBlank { "chat-forge-current" },
                    value = state.progress?.coerceIn(0, 100)?.div(100f),
                    state = when (state.step) {
                        ChatForgeCoordinator.Step.COMPLETE -> ThemeProgressState.SUCCESS
                        ChatForgeCoordinator.Step.CANCELLED -> ThemeProgressState.CANCELLED
                        ChatForgeCoordinator.Step.FAILED -> ThemeProgressState.FAILED
                        ChatForgeCoordinator.Step.VALIDATING -> ThemeProgressState.STARTING
                        else -> ThemeProgressState.ACTIVE
                    },
                    label = "Chat Forge operation",
                    statusText = state.progress?.let { "${state.step.name} · $it%" }
                        ?: "${state.step.name} · EXACT PERCENTAGE UNKNOWN",
                ),
            )
        }
        if (state.runs.isNotEmpty()) {
            Spacer(Modifier.height(7.dp))
            state.runs.take(4).forEach { run ->
                Text("${if (run.status == "completed") "✓" else "●"} ${run.name} · ${run.status}${run.conclusion?.let { " / $it" } ?: ""}", color = tokens.text.secondary, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        if (state.step !in setOf(ChatForgeCoordinator.Step.IDLE, ChatForgeCoordinator.Step.COMPLETE, ChatForgeCoordinator.Step.CANCELLED, ChatForgeCoordinator.Step.FAILED)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { ChatForgeCoordinator.cancel() }) { Text("✕ STOP FORGE", color = tokens.status.danger) }
            }
        }
        when (state.step) {
            ChatForgeCoordinator.Step.NEEDS_GITHUB -> {
                OutlinedTextField(
                    value = tokenDraft,
                    onValueChange = { tokenDraft = it },
                    label = { Text("Fine-grained token") },
                    visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { showToken = !showToken }) { Text(if (showToken) "HIDE" else "SHOW") }
                    Button(onClick = { scope.launch { ChatForgeCoordinator.saveAndValidateToken(context, tokenDraft); tokenDraft = "" } }, enabled = tokenDraft.isNotBlank()) { Text("VALIDATE") }
                }
            }
            ChatForgeCoordinator.Step.ASK_SHA_PAIRING -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { ChatForgeCoordinator.chooseShaPairing(true) }) { Text("✓ STRICT SOURCE") }
                OutlinedButton(onClick = { ChatForgeCoordinator.chooseShaPairing(false) }) { Text("GENERIC / NO SHA") }
            }
            ChatForgeCoordinator.Step.NEEDS_FILES -> {
                if (state.packageTarget == ChatForgeCoordinator.PackageTarget.ASK) {
                    Text("Choose package target", color = tokens.text.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { ChatForgeCoordinator.choosePackageTarget(ChatForgeCoordinator.PackageTarget.CLIENT) }, modifier = Modifier.weight(1f)) { Text("CLIENT") }
                        OutlinedButton(onClick = { ChatForgeCoordinator.choosePackageTarget(ChatForgeCoordinator.PackageTarget.SERVER) }, modifier = Modifier.weight(1f)) { Text("SERVER") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { ChatForgeCoordinator.choosePackageTarget(ChatForgeCoordinator.PackageTarget.BOTH) }, modifier = Modifier.weight(1f)) { Text("BOTH") }
                        OutlinedButton(onClick = { ChatForgeCoordinator.choosePackageTarget(ChatForgeCoordinator.PackageTarget.FILES) }, modifier = Modifier.weight(1f)) { Text("FILES") }
                    }
                } else {
                    Button(onClick = { filePicker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                        Text(when (state.packageTarget) {
                            ChatForgeCoordinator.PackageTarget.CLIENT -> "SELECT CLIENT ZIP"
                            ChatForgeCoordinator.PackageTarget.SERVER -> "SELECT SERVER ZIP"
                            ChatForgeCoordinator.PackageTarget.BOTH -> "SELECT CLIENT + SERVER ZIPS"
                            else -> "SELECT FILES"
                        })
                    }
                    TextButton(onClick = { ChatForgeCoordinator.choosePackageTarget(ChatForgeCoordinator.PackageTarget.ASK) }) { Text("CHANGE TARGET") }
                }
            }
            ChatForgeCoordinator.Step.READY_TO_UPLOAD -> {
                val hasExpandableZip = state.files.any { file ->
                    file.displayName.endsWith(".zip", true) && !GitHubForgeClient.isProtectedSourceZip(file.displayName)
                }
                if (hasExpandableZip) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("EXPAND ZIP → REPOSITORY ROOT", color = tokens.text.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("Protected CLIENT_/SERVER_ source ZIPs are never unpacked.", color = tokens.text.muted, fontSize = 9.sp)
                        }
                        Switch(
                            checked = state.expandGenericZipToRepositoryRoot,
                            onCheckedChange = { enabled -> ChatForgeCoordinator.setArchiveExpansion(enabled, state.removeExpandedZipAfterUnpack) },
                        )
                    }
                    if (state.expandGenericZipToRepositoryRoot) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text("REMOVE OUTER ZIP", color = tokens.text.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text("Expanded files stay; the selected bootstrap ZIP is not retained.", color = tokens.text.muted, fontSize = 9.sp)
                            }
                            Switch(
                                checked = state.removeExpandedZipAfterUnpack,
                                onCheckedChange = { remove -> ChatForgeCoordinator.setArchiveExpansion(true, remove) },
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { scope.launch { ChatForgeCoordinator.upload(context) } }) { Text(if (state.expandGenericZipToRepositoryRoot) "✓ EXPAND + COMMIT" else "✓ START UPLOAD") }
                    OutlinedButton(onClick = { ChatForgeCoordinator.dismiss() }) { Text("✕") }
                }
            }
            ChatForgeCoordinator.Step.ARTIFACTS_READY -> {
                state.artifacts.take(4).forEach { artifact ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(artifact.name, color = tokens.text.primary, fontSize = 10.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        TextButton(onClick = {
                            ChatForgeCoordinator.requestDownload(artifact)
                            scope.launch {
                                ChatForgeCoordinator.downloadPending(context).onSuccess { pair ->
                                    val stored = prefs.getString("artifact_tree_uri", "").orEmpty()
                                    val tree = stored.takeIf { it.isNotBlank() }?.let(Uri::parse)
                                    if (tree != null && saveArtifactToTree(tree, pair.first, pair.second)) {
                                        ChatForgeCoordinator.markDownloaded(pair.first)
                                    } else {
                                        pendingDownload = pair
                                        ChatForgeCoordinator.markNeedsDirectory(pair.first)
                                    }
                                }
                            }
                        }) { Text("DOWNLOAD") }
                    }
                }
            }
            ChatForgeCoordinator.Step.NEEDS_DOWNLOAD_DIRECTORY -> Button(onClick = { folderPicker.launch(null) }) { Text("CHOOSE FOLDER") }
            ChatForgeCoordinator.Step.COMPLETE, ChatForgeCoordinator.Step.CANCELLED, ChatForgeCoordinator.Step.FAILED -> TextButton(onClick = { ChatForgeCoordinator.dismiss() }) { Text("CLOSE") }
            else -> Unit
        }
    }
}

@Composable
private fun SwrlzCompanionRail(mission: MissionBus.MissionLive) {
    val tokens = LocalSwurlzTokens.current
    val motion = LocalThemeMotionPolicy.current
    val companionColor = tokens.accents.secondary
    val forge by ChatForgeCoordinator.state.collectAsState()
    val busy = forge.step !in setOf(ChatForgeCoordinator.Step.IDLE, ChatForgeCoordinator.Step.COMPLETE, ChatForgeCoordinator.Step.CANCELLED, ChatForgeCoordinator.Step.FAILED) || mission.state !in setOf("idle", "done", "offline", "aborted")
    val transition = if (busy && motion.enabled) {
        rememberInfiniteTransition(label = "swrlz-chat-companion")
    } else {
        null
    }
    val drift = transition?.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse),
        label = "companion-drift",
    )?.value ?: 0f
    val status = when {
        forge.step == ChatForgeCoordinator.Step.UPLOADING -> "SWRLZ · forging upload…"
        forge.step == ChatForgeCoordinator.Step.WATCHING_WORKFLOWS || forge.step == ChatForgeCoordinator.Step.LOADING_WORKFLOWS -> "SWRLZ · watching Forge workflows…"
        mission.state == "running" -> "SWRLZ · observing and planning…"
        else -> "SWRLZ · ready"
    }
    GlassPanel(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ThemeKapanionAvatar(
                modifier = Modifier.graphicsLayer {
                    translationX = if (busy) drift else 0f
                    alpha = if (busy) .98f else .82f
                },
                size = 40.dp,
                animated = busy,
                contentDescription = "SWRLZ Kapanion",
                statusTone = companionColor,
            )
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(status, color = companionColor, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Box(Modifier.fillMaxWidth().height(3.dp).background(tokens.cards.bgAlt, RoundedCornerShape(99.dp))) {
                    if (busy) Box(Modifier.fillMaxWidth(.55f).height(3.dp).graphicsLayer { translationX = drift * 4 }.background(companionColor, RoundedCornerShape(99.dp)))
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(message: ClientMessage) {
    val tokens = LocalSwurlzTokens.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top,
    ) {
        if (!message.fromUser) {
            ThemeKapanionAvatar(
                size = 34.dp,
                animated = false,
                contentDescription = null,
                statusTone = tokens.accents.primary,
            )
            Spacer(Modifier.width(7.dp))
        }
        Box(
            modifier = Modifier
                .fillMaxWidth(if (message.fromUser) .86f else .78f)
                .background(
                    if (message.fromUser) {
                        Brush.linearGradient(listOf(tokens.accents.primary.copy(alpha = .74f), tokens.accents.tertiary.copy(alpha = .70f)))
                    } else {
                        Brush.linearGradient(listOf(tokens.cards.bg.copy(alpha = .72f), tokens.cards.bgAlt.copy(alpha = .60f)))
                    },
                    RoundedCornerShape(18.dp),
                )
                .border(1.dp, if (message.fromUser) tokens.accents.tertiary.copy(alpha = .55f) else tokens.accents.primary.copy(alpha = .34f), RoundedCornerShape(18.dp))
                .padding(13.dp),
        ) {
            Column {
                if (!message.fromUser) {
                    Text("SWRLZ · LOCAL", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(4.dp))
                }
                Text(message.text, color = tokens.text.primary, fontSize = 13.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun ClientMissionsScreen(
    mission: MissionBus.MissionLive,
    ambient: MissionBus.Ambient,
    timeline: List<MissionBus.TimelineEntry>,
    paused: Boolean,
    needsApproval: Boolean,
    onPauseToggle: () -> Unit,
    onTakeOver: () -> Unit,
    onReviewApproval: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("MISSION CONTROL")
            Text("Outcome first. Detail on demand.", color = tokens.text.primary, fontSize = 26.sp, fontWeight = FontWeight.Medium)
            Text("Every action stays visible, pausable, and recoverable.", color = tokens.text.secondary, fontSize = 12.sp)
        }
        item {
            GlassPanel(highlighted = mission.goal.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SectionLabel(if (mission.goal.isBlank()) "NO ACTIVE MISSION" else "ACTIVE MISSION")
                        Text(if (mission.goal.isBlank()) "Start from Core or Chat." else mission.goal, color = tokens.text.primary, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        if (mission.goal.isNotBlank()) {
                            Spacer(Modifier.height(5.dp))
                            Text(
                                if (mission.total > 0) "Step ${mission.step} of ${mission.total}" else mission.state,
                                color = tokens.text.muted,
                                fontSize = 11.sp,
                            )
                        }
                    }
                    TinyPill(if (paused) "PAUSED" else ambient.name.uppercase(), if (paused) tokens.status.warning else ambientColor(ambient))
                }
                if (mission.goal.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    ThemedProgressBar(
                        snapshot = ProgressSnapshot(
                            operationId = mission.missionId ?: "client-mission-current",
                            value = mission.total.takeIf { it > 0 }?.let {
                                mission.step.coerceIn(0, it).toFloat() / it.toFloat()
                            },
                            state = when {
                                paused -> ThemeProgressState.PAUSED
                                ambient == MissionBus.Ambient.Done -> ThemeProgressState.SUCCESS
                                ambient == MissionBus.Ambient.Error -> ThemeProgressState.FAILED
                                mission.state.contains("cancel", ignoreCase = true) ->
                                    ThemeProgressState.CANCELLED
                                ambient == MissionBus.Ambient.Listening ||
                                    mission.state.equals("starting", ignoreCase = true) ->
                                    ThemeProgressState.STARTING
                                else -> ThemeProgressState.ACTIVE
                            },
                            label = "Mission progress",
                            statusText = if (mission.total > 0) {
                                "STEP ${mission.step.coerceIn(0, mission.total)} OF ${mission.total}"
                            } else {
                                "${mission.state.uppercase()} · EXACT PERCENTAGE UNKNOWN"
                            },
                        ),
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onPauseToggle) {
                            Icon(if (paused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause, contentDescription = null)
                            Spacer(Modifier.width(5.dp))
                            Text(if (paused) "RESUME" else "PAUSE")
                        }
                        OutlinedButton(onClick = onTakeOver, colors = ButtonDefaults.outlinedButtonColors(contentColor = tokens.status.danger)) {
                            Icon(Icons.Outlined.PanTool, contentDescription = null)
                            Spacer(Modifier.width(5.dp))
                            Text("TAKE OVER")
                        }
                    }
                }
            }
        }
        if (needsApproval) {
            item {
                GlassPanel(highlighted = true) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Shield, contentDescription = null, tint = tokens.status.warning)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Approval required", color = tokens.status.warning, fontWeight = FontWeight.Medium)
                            Text("Review exact scope before execution continues.", color = tokens.text.secondary, fontSize = 11.sp)
                        }
                        Button(onClick = onReviewApproval) { Text("REVIEW") }
                    }
                }
            }
        }
        item { SectionLabel("ACTION TIMELINE") }
        if (timeline.isEmpty()) {
            item {
                GlassPanel { Text("No mission events yet.", color = tokens.text.muted, fontSize = 12.sp) }
            }
        } else {
            items(timeline.reversed()) { entry -> TimelineRow(entry) }
        }
    }
}

@Composable
private fun TimelineRow(entry: MissionBus.TimelineEntry) {
    val tokens = LocalSwurlzTokens.current
    val tone = phaseColor(entry.phase)
    GlassPanel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(tone))
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.label, color = tokens.text.primary, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${entry.phase.uppercase()} · ${entry.type}", color = tone, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.sp)
            }
            TinyPill(entry.risk.uppercase(), riskColor(entry.risk))
        }
    }
}

private data class CoreGroupStatus(
    val name: String,
    val role: String,
    val onlineCount: Int,
    val activeCount: Int,
)

@Composable
private fun ClientCoreNodePanel(
    truth: CoreNodeTruthState,
    onOpenDiscovery: () -> Unit,
    onOpenCoreAdmin: () -> Unit,
    onOpenGroups: () -> Unit,
    onNotify: (String) -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val presencePrefs = context.getSharedPreferences("swrlz_presence_identity", android.content.Context.MODE_PRIVATE)
    val connectionPrefs = context.getSharedPreferences("swrlz_connection_preferences", android.content.Context.MODE_PRIVATE)
    var registrationState by remember { mutableStateOf(presencePrefs.getString("registrationState", "NOT_REGISTERED").orEmpty()) }
    var enrollmentState by remember { mutableStateOf(presencePrefs.getString("enrollmentState", "NOT_ENROLLED").orEmpty()) }
    var connectionHealth by remember { mutableStateOf(presencePrefs.getString("connectionHealth", "DISCONNECTED").orEmpty()) }
    var registrationDetail by remember { mutableStateOf(presencePrefs.getString("registrationDetail", "Connect to a SERVER to begin verified registration.").orEmpty()) }
    val scope = rememberCoroutineScope()
    var connecting by remember { mutableStateOf(false) }
    var connectionSummary by remember { mutableStateOf("") }
    var autoConnect by remember { mutableStateOf(connectionPrefs.getBoolean("autoConnectOnLaunch", true)) }
    var startupAttempted by remember { mutableStateOf(false) }
    val discoveryReachable = truth.auto.checked || truth.manual.checked
    val connected = connectionHealth == "ONLINE" && registrationState == "REGISTERED"
    var nodeMenu by remember { mutableStateOf(false) }
    var groupDialog by remember { mutableStateOf<String?>(null) }
    var groupInput by remember { mutableStateOf("") }
    val hadSuccessfulConnection = connectionPrefs.getBoolean("hadSuccessfulConnection", connected)
    var coreGroups by remember { mutableStateOf<List<CoreGroupStatus>>(emptyList()) }
    var coreGroupsLoading by remember { mutableStateOf(false) }
    var coreGroupsAvailable by remember { mutableStateOf(false) }

    suspend fun refreshCoreGroups() {
        if (!connected || !truth.config.configured) {
            coreGroups = emptyList()
            coreGroupsAvailable = false
            return
        }
        coreGroupsLoading = true
        val nodeId = presencePrefs.getString("nodeId", "client-unknown").orEmpty()
        val listResult = withContext(Dispatchers.IO) { GroupClientApi.list(truth.config.nodeUrl, nodeId) }
        if (!listResult.ok) {
            coreGroups = emptyList()
            coreGroupsAvailable = false
            coreGroupsLoading = false
            return
        }
        val parsed = runCatching {
            val array = org.json.JSONObject(listResult.payload).optJSONArray("groups") ?: org.json.JSONArray()
            (0 until array.length()).map { index ->
                val item = array.optJSONObject(index) ?: org.json.JSONObject()
                val groupId = item.optString("groupId")
                val activeCountFromList = item.optInt("memberCount", 0)
                val rosterResult = withContext(Dispatchers.IO) { GroupClientApi.roster(truth.config.nodeUrl, groupId) }
                var onlineCount = 0
                var activeCount = activeCountFromList
                if (rosterResult.ok) {
                    val roster = org.json.JSONObject(rosterResult.payload).optJSONArray("members") ?: org.json.JSONArray()
                    var rosterActive = 0
                    for (memberIndex in 0 until roster.length()) {
                        val member = roster.optJSONObject(memberIndex) ?: org.json.JSONObject()
                        if (member.optString("membershipState", "ACTIVE").equals("ACTIVE", ignoreCase = true)) {
                            rosterActive += 1
                            val presence = member.optString("presenceState", "UNKNOWN")
                            if (presence.equals("ONLINE", ignoreCase = true) || presence.equals("CONNECTED", ignoreCase = true)) {
                                onlineCount += 1
                            }
                        }
                    }
                    activeCount = maxOf(activeCount, rosterActive)
                }
                CoreGroupStatus(
                    name = item.optString("name", "Node group"),
                    role = item.optString("role", "MEMBER"),
                    onlineCount = onlineCount,
                    activeCount = activeCount,
                )
            }
        }.getOrDefault(emptyList())
        coreGroups = parsed
        coreGroupsAvailable = true
        coreGroupsLoading = false
    }

    LaunchedEffect(connected, truth.config.nodeUrl, registrationState) {
        refreshCoreGroups()
    }

    LaunchedEffect(autoConnect, connected) {
        if (autoConnect && !connected && !startupAttempted) {
            startupAttempted = true
            connecting = true
            connectionSummary = "Searching for an approved SWURLZER…"
            val result = withContext(Dispatchers.IO) { CoreNodeAutoDiscovery.connectOnLaunch(context, scanWhenNeeded = true, includeLoopbackRange = true) }
            connectionSummary = result.summary
            if (result.connected) connectionPrefs.edit().putBoolean("hadSuccessfulConnection", true).apply()
            registrationState = presencePrefs.getString("registrationState", "NOT_REGISTERED").orEmpty()
            enrollmentState = presencePrefs.getString("enrollmentState", "NOT_ENROLLED").orEmpty()
            connectionHealth = presencePrefs.getString("connectionHealth", if (result.discoveryReachable) "DISCOVERY_ONLY" else "DISCONNECTED").orEmpty()
            registrationDetail = presencePrefs.getString("registrationDetail", result.detail).orEmpty()
            connecting = false
            onNotify(result.summary)
        }
    }

    val actionLabel = when {
        connecting -> "CONNECTING…"
        connected -> "CONNECTED"
        hadSuccessfulConnection -> "RECONNECT"
        truth.auto.checked || truth.manual.checked -> "RETRY CONNECTION"
        else -> "CONNECT"
    }

    GlassPanel(highlighted = connected) {
        SectionLabel("CORE CONNECTION")
        val headline = when {
            connected -> "SERVER SESSION ONLINE"
            connectionHealth == "DISCOVERY_ONLY" || discoveryReachable -> "DISCOVERY REACHABLE"
            connectionHealth == "DEGRADED" -> "SERVER SESSION DEGRADED"
            else -> "CONNECT TO SWURLZER"
        }
        Text(headline, color = if (connected) tokens.status.success else if (discoveryReachable) tokens.status.warning else tokens.text.primary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        NodeLine(
            icon = Icons.Outlined.Hub,
            name = if (truth.config.configured) "Glitch Dragon Core" else "No saved SERVER",
            detail = if (truth.config.configured) truth.config.nodeUrl else "Discovery is available",
            status = when {
                connected -> "ONLINE"
                connectionHealth == "DISCOVERY_ONLY" || discoveryReachable -> "DISCOVERY ONLY"
                connectionHealth == "DEGRADED" -> "DEGRADED"
                else -> "OFFLINE"
            },
            tone = if (connected) tokens.status.info else tokens.status.warning,
        )
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("AUTO-CONNECT ON APP LAUNCH", color = tokens.text.primary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Text("Try the saved SERVER first, then approved discovery.", color = tokens.text.muted, fontSize = 9.sp)
            }
            Switch(
                checked = autoConnect,
                onCheckedChange = {
                    autoConnect = it
                    connectionPrefs.edit().putBoolean("autoConnectOnLaunch", it).apply()
                },
            )
        }
        Spacer(Modifier.height(10.dp))
        Text("Enrollment: $enrollmentState", color = if (enrollmentState == "ENROLLED") tokens.status.success else tokens.status.warning, fontSize = 11.sp)
        Text("Current session: $registrationState · $connectionHealth", color = if (connected) tokens.status.success else tokens.status.warning, fontSize = 11.sp)
        Text(registrationDetail.take(220), color = tokens.text.secondary, fontSize = 9.sp, lineHeight = 13.sp)
        if (connected) {
            Spacer(Modifier.height(10.dp))
            GlassPanel(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenGroups),
                highlighted = coreGroupsAvailable && coreGroups.isNotEmpty(),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Hub, contentDescription = null, tint = tokens.accents.primary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        SectionLabel(if (coreGroups.size == 1) "ACTIVE GROUP" else "ACTIVE GROUPS")
                        when {
                            coreGroupsLoading -> Text("Synchronizing group overview…", color = tokens.text.secondary, fontSize = 10.sp)
                            !coreGroupsAvailable -> Text("Group overview unavailable · open Groups to retry", color = tokens.status.warning, fontSize = 10.sp)
                            coreGroups.isEmpty() -> Text("Not assigned to an active group", color = tokens.text.muted, fontSize = 10.sp)
                            coreGroups.size == 1 -> {
                                val group = coreGroups.first()
                                Text("${group.name} · ${group.role}", color = tokens.accents.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("${group.onlineCount} of ${group.activeCount} devices online", color = tokens.text.secondary, fontSize = 10.sp)
                            }
                            else -> {
                                val online = coreGroups.sumOf { it.onlineCount }
                                val active = coreGroups.sumOf { it.activeCount }
                                Text("${coreGroups.size} groups · ${coreGroups.joinToString(" · ") { it.name }.take(72)}", color = tokens.accents.primary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text("$online of $active group devices online", color = tokens.text.secondary, fontSize = 10.sp)
                            }
                        }
                    }
                    Icon(Icons.Outlined.ChevronRight, contentDescription = "Open Groups", tint = tokens.text.muted)
                }
            }
        }
        if (connectionSummary.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(connectionSummary, color = tokens.text.secondary, fontSize = 10.sp)
        }
        Spacer(Modifier.height(10.dp))
        if (connected) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !connecting,
                    onClick = {
                        scope.launch {
                            connecting = true
                            connectionSummary = "Disconnecting while preserving registration…"
                            val result = withContext(Dispatchers.IO) { ClientPresenceRegistration.disconnect(context, truth.config.nodeUrl) }
                            connectionSummary = result.detail
                            registrationState = "NOT_IN_SESSION"
                            connectionHealth = "DISCONNECTED"
                            registrationDetail = result.detail
                            connecting = false
                            onNotify(result.detail)
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("DISCONNECT", maxLines = 1) }
                OutlinedButton(onClick = onOpenDiscovery, modifier = Modifier.weight(1f)) { Text("SERVER DETAILS", maxLines = 1) }
            }
        } else if (connecting) {
            Button(enabled = false, onClick = {}, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Radar, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("CONNECTING…", maxLines = 1)
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        scope.launch {
                            connecting = true
                            val result = withContext(Dispatchers.IO) { CoreNodeAutoDiscovery.connectOnLaunch(context, scanWhenNeeded = true, includeLoopbackRange = true) }
                            connectionSummary = result.summary
                            if (result.connected) connectionPrefs.edit().putBoolean("hadSuccessfulConnection", true).apply()
                            registrationState = presencePrefs.getString("registrationState", "NOT_REGISTERED").orEmpty()
                            enrollmentState = presencePrefs.getString("enrollmentState", "NOT_ENROLLED").orEmpty()
                            connectionHealth = presencePrefs.getString("connectionHealth", if (result.discoveryReachable) "DISCOVERY_ONLY" else "DISCONNECTED").orEmpty()
                            registrationDetail = presencePrefs.getString("registrationDetail", result.detail).orEmpty()
                            connecting = false
                            onNotify(result.summary)
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) { Text(actionLabel, maxLines = 1) }
                OutlinedButton(onClick = onOpenDiscovery, modifier = Modifier.weight(1f)) { Text("DISCOVERY", maxLines = 1) }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onOpenCoreAdmin, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Outlined.Shield, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("MANAGE NODE TRUST")
        }
    }
}

@Composable
private fun ClientNodesScreen(
    truth: CoreNodeTruthState,
    onOpenDiscovery: () -> Unit,
    onOpenCoreAdmin: () -> Unit,
    onNotify: (String) -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val presencePrefs = context.getSharedPreferences("swrlz_presence_identity", android.content.Context.MODE_PRIVATE)
    val registrationState = presencePrefs.getString("registrationState", "NOT_REGISTERED").orEmpty()
    val registrationDetail = presencePrefs.getString("registrationDetail", "Connect to a SERVER to begin verified registration.").orEmpty()
    val scope = rememberCoroutineScope()
    var reconnecting by remember { mutableStateOf(false) }
    var reconnectSummary by remember { mutableStateOf("") }
    val connected = truth.auto.success || truth.manual.success
    var nodeMenu by remember { mutableStateOf(false) }
    var groupDialog by remember { mutableStateOf<String?>(null) }
    var groupInput by remember { mutableStateOf("") }
    var groupsPayload by remember { mutableStateOf("") }
    var groupsLoading by remember { mutableStateOf(false) }
    fun refreshGroups() { val nodeId=presencePrefs.getString("nodeId","client-unknown").orEmpty(); scope.launch { groupsLoading=true; val r=withContext(Dispatchers.IO){GroupClientApi.list(truth.config.nodeUrl,nodeId)}; groupsPayload=r.payload; groupsLoading=false } }
    LaunchedEffect(connected) { if(connected) refreshGroups() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("YOUR MESH")
            Text("Near, known, and trusted.", color = tokens.text.primary, fontSize = 27.sp, fontWeight = FontWeight.Medium)
            Text("Local and remote identity never collapse into one label.", color = tokens.text.secondary, fontSize = 12.sp)
        }
        item { NodeMeshGraphic(connected = connected) }
        item {
            GlassPanel(highlighted = registrationState == "REGISTERED") {
                SectionLabel("THIS CLIENT")
                Text(registrationState, color = if (registrationState == "REGISTERED") tokens.status.success else tokens.status.warning, fontWeight = FontWeight.SemiBold)
                Text(registrationDetail.take(320), color = tokens.text.secondary, fontSize = 10.sp, lineHeight = 14.sp)
            }
        }
        item {
            GlassPanel {
                NodeLine(
                    icon = Icons.Outlined.Devices,
                    name = "This phone",
                    detail = "CLIENT · local operator",
                    status = "READY",
                    tone = tokens.status.success,
                )
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { NodeLine(
                        icon = Icons.Outlined.Hub,
                        name = if (truth.config.configured) "Glitch Dragon Core" else "Core Node",
                        detail = if (truth.config.configured) "NODE_HOST · local link · ${truth.config.nodeUrl}" else "No node configured",
                        status = if (connected) "CONNECTED" else if (truth.config.configured) "OFFLINE" else "UNPAIRED",
                        tone = if (connected) tokens.status.info else tokens.status.warning,
                    ) }
                    Box {
                        IconButton(onClick={nodeMenu=true}) { Icon(Icons.Outlined.MoreVert, contentDescription="Node actions") }
                        DropdownMenu(expanded=nodeMenu,onDismissRequest={nodeMenu=false}) {
                            DropdownMenuItem(text={Text("View node")},onClick={nodeMenu=false})
                            DropdownMenuItem(text={Text("Send mission")},onClick={nodeMenu=false})
                            DropdownMenuItem(text={Text("Create group")},onClick={nodeMenu=false;groupDialog="create"})
                            DropdownMenuItem(text={Text("Join group with code")},onClick={nodeMenu=false;groupDialog="join"})
                        }
                    }
                }
            }
        }
        if (reconnectSummary.isNotBlank()) {
            item { GlassPanel { Text(reconnectSummary, color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp) } }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !reconnecting,
                    onClick = {
                        scope.launch {
                            reconnecting = true
                            val result = withContext(Dispatchers.IO) {
                                CoreNodeAutoDiscovery.connectOnLaunch(context, scanWhenNeeded = true)
                            }
                            reconnectSummary = result.summary
                            reconnecting = false
                            onNotify(result.summary)
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Outlined.Radar, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (reconnecting) "CONNECTING…" else if (connected) "CONNECTED" else "CONNECT")
                }
                OutlinedButton(onClick = onOpenDiscovery, modifier = Modifier.weight(1f)) { Text("DISCOVERY") }
            }
        }
        item {
            OutlinedButton(onClick = onOpenCoreAdmin, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Shield, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("MANAGE NODE TRUST")
            }
        }
        item { GlassPanel {
            SectionLabel("GROUPS")
            Text("SERVER-owned groups restore on reconnect. Invite entry creates a pending request; the leader must approve before roster visibility becomes active.",color=tokens.text.secondary,fontSize=10.sp,lineHeight=14.sp)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment=Alignment.CenterVertically){ Text("MY GROUPS",color=tokens.text.primary,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f)); TextButton(enabled=connected&&!groupsLoading,onClick={refreshGroups()}){Text(if(groupsLoading)"SYNCING…" else "REFRESH")} }
            val groupMatches = remember(groupsPayload) {
                runCatching {
                    val array = org.json.JSONObject(groupsPayload).optJSONArray("groups") ?: org.json.JSONArray()
                    (0 until array.length()).map { index ->
                        val item = array.optJSONObject(index) ?: org.json.JSONObject()
                        item.optString("name", "Node group") to item.optString("groupId")
                    }
                }.getOrDefault(emptyList())
            }
            if(groupMatches.isEmpty()) Text(if(connected)"No active groups returned for this CLIENT." else "Connect to a SERVER to load groups.",color=tokens.text.muted,fontSize=10.sp)
            groupMatches.forEach { (name, gid) ->
                GlassPanel { Text(name,color=tokens.accents.primary,fontWeight=FontWeight.SemiBold); Text(gid,color=tokens.text.muted,fontSize=9.sp); Row{TextButton(onClick={onNotify("Group roster opens after SERVER roster sync: $gid")}){Text("OPEN")}; TextButton(onClick={onNotify("Node actions are available from the group roster.")}){Text("NODES")}} }
                Spacer(Modifier.height(6.dp))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={groupDialog="create"},modifier=Modifier.weight(1f)){Text("CREATE GROUP")}
                OutlinedButton(onClick={groupDialog="join"},modifier=Modifier.weight(1f)){Text("JOIN WITH CODE")}
            }
        } }
    }
    groupDialog?.let { action ->
        AlertDialog(onDismissRequest={groupDialog=null},title={Text(if(action=="create")"Create group" else "Join group")},text={OutlinedTextField(value=groupInput,onValueChange={groupInput=it},label={Text(if(action=="create")"Unique group name" else "Invite code")})},confirmButton={TextButton(onClick={
            val base=truth.config.nodeUrl; val nodeId=presencePrefs.getString("nodeId","client-unknown").orEmpty(); val value=groupInput.trim(); groupDialog=null
            scope.launch { val result=withContext(Dispatchers.IO){if(action=="create")GroupClientApi.create(base,value,nodeId) else GroupClientApi.join(base,value,nodeId,"This phone")}; onNotify("${result.code}: ${result.detail}"); if(result.ok) refreshGroups() }
        }){Text(if(action=="create")"CREATE" else "REQUEST JOIN")}},dismissButton={TextButton(onClick={groupDialog=null}){Text("CANCEL")}})
    }
}


@Composable
private fun ClientGroupsScreen(
    truth: CoreNodeTruthState,
    onNotify: (String) -> Unit,
) {
    data class GroupSummary(
        val name: String,
        val id: String,
        val role: String,
        val membershipState: String,
        val memberCount: Int,
        val leaderNodeId: String,
    )
    data class RosterMember(
        val nodeId: String,
        val label: String,
        val role: String,
        val membershipState: String,
        val presenceState: String,
    )

    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val prefs = context.getSharedPreferences("swrlz_presence_identity", android.content.Context.MODE_PRIVATE)
    val scope = rememberCoroutineScope()
    val connected = truth.auto.success || truth.manual.success
    var payload by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var syncOk by remember { mutableStateOf(false) }
    var syncError by remember { mutableStateOf<String?>(null) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var input by remember { mutableStateOf("") }
    var rosterTitle by remember { mutableStateOf<String?>(null) }
    var rosterMembers by remember { mutableStateOf<List<RosterMember>>(emptyList()) }
    var rosterLoading by remember { mutableStateOf(false) }

    fun refresh() {
        val nodeId = prefs.getString("nodeId", "client-unknown").orEmpty()
        scope.launch {
            loading = true
            val result = withContext(Dispatchers.IO) { GroupClientApi.list(truth.config.nodeUrl, nodeId) }
            payload = if (result.ok) result.payload else ""
            syncOk = result.ok
            syncError = if (result.ok) null else result.userMessage()
            loading = false
            if (!result.ok) onNotify("GROUP SYNC: ${result.userMessage()}")
        }
    }

    fun openRoster(group: GroupSummary) {
        scope.launch {
            rosterTitle = group.name
            rosterLoading = true
            rosterMembers = emptyList()
            val result = withContext(Dispatchers.IO) { GroupClientApi.roster(truth.config.nodeUrl, group.id) }
            if (result.ok) {
                rosterMembers = runCatching {
                    val array = org.json.JSONObject(result.payload).optJSONArray("members") ?: org.json.JSONArray()
                    (0 until array.length()).map { index ->
                        val item = array.optJSONObject(index) ?: org.json.JSONObject()
                        RosterMember(
                            nodeId = item.optString("nodeId"),
                            label = item.optString("label", item.optString("nodeId")),
                            role = item.optString("role", "MEMBER"),
                            membershipState = item.optString("membershipState", "UNKNOWN"),
                            presenceState = item.optString("presenceState", "UNKNOWN"),
                        )
                    }
                }.getOrDefault(emptyList())
            } else {
                onNotify("GROUP ROSTER: ${result.userMessage()}")
            }
            rosterLoading = false
        }
    }

    LaunchedEffect(connected, truth.config.nodeUrl) {
        if (connected) refresh() else {
            syncOk = false
            syncError = null
        }
    }

    val groups = remember(payload) {
        runCatching {
            val array = org.json.JSONObject(payload).optJSONArray("groups") ?: org.json.JSONArray()
            (0 until array.length()).map { index ->
                val item = array.optJSONObject(index) ?: org.json.JSONObject()
                GroupSummary(
                    name = item.optString("name", "Node group"),
                    id = item.optString("groupId"),
                    role = item.optString("role", "MEMBER"),
                    membershipState = item.optString("membershipState", "UNKNOWN"),
                    memberCount = item.optInt("memberCount", 0),
                    leaderNodeId = item.optString("leaderNodeId"),
                )
            }
        }.getOrDefault(emptyList())
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("COLLABORATION")
            Text("Node groups.", color = tokens.text.primary, fontSize = 27.sp, fontWeight = FontWeight.Medium)
            Text("Membership truth is owned by the connected SERVER and restored after reconnect.", color = tokens.text.secondary, fontSize = 12.sp)
        }
        item {
            val statusText = when {
                !connected -> "OFFLINE CACHE"
                loading -> "SYNCHRONIZING"
                syncOk -> "SYNCHRONIZED"
                else -> "GROUP SYNC ERROR"
            }
            val statusColor = when {
                !connected -> tokens.status.warning
                loading -> tokens.status.info
                syncOk -> tokens.status.success
                else -> tokens.status.danger
            }
            GlassPanel(highlighted = connected && syncOk) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SectionLabel("SERVER GROUP STATUS")
                        Text(statusText, color = statusColor, fontWeight = FontWeight.SemiBold)
                        Text(
                            when {
                                !connected -> "Reconnect to validate current membership."
                                loading -> "Requesting canonical group state from the SERVER."
                                syncOk -> "Group membership was confirmed by the SERVER."
                                else -> syncError ?: "The SERVER connection is active, but group state was not synchronized."
                            },
                            color = tokens.text.secondary,
                            fontSize = 10.sp,
                        )
                    }
                    TextButton(enabled = connected && !loading, onClick = ::refresh) { Text(if (loading) "SYNCING…" else "REFRESH") }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = connected && syncOk, onClick = { dialog = "create" }, modifier = Modifier.weight(1f)) { Text("CREATE GROUP") }
                OutlinedButton(enabled = connected && syncOk, onClick = { dialog = "join" }, modifier = Modifier.weight(1f)) { Text("JOIN WITH CODE") }
            }
        }
        item { SectionLabel("MY GROUPS") }
        if (groups.isEmpty()) {
            item {
                GlassPanel {
                    Text(
                        when {
                            !connected -> "Connect to a SERVER to load groups."
                            !syncOk -> "Group membership is unavailable until synchronization succeeds."
                            else -> "No active groups returned for this CLIENT."
                        },
                        color = tokens.text.muted,
                        fontSize = 11.sp,
                    )
                }
            }
        } else {
            items(groups, key = { it.id }) { group ->
                GlassPanel {
                    Text(group.name, color = tokens.accents.primary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("${group.role} · ${group.membershipState}", color = if (group.membershipState == "ACTIVE") tokens.status.success else tokens.status.warning, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text("${group.memberCount} active member${if (group.memberCount == 1) "" else "s"}", color = tokens.text.secondary, fontSize = 10.sp)
                    Text("Leader: ${group.leaderNodeId}", color = tokens.text.muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { openRoster(group) }) { Text("OPEN") }
                        TextButton(onClick = { openRoster(group) }) { Text("MEMBERS") }
                        TextButton(onClick = { onNotify("Invite controls remain SERVER-authoritative for ${group.name}.") }) { Text("INVITE") }
                    }
                }
            }
        }
    }

    dialog?.let { action ->
        AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(if (action == "create") "Create node group" else "Join node group") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, label = { Text(if (action == "create") "Unique group name" else "Invite code") })
                    Text(if (action == "create") "The SERVER validates uniqueness and makes this CLIENT the initial leader." else "A valid code submits a pending request; membership begins only after leader approval.", fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(enabled = input.trim().isNotEmpty(), onClick = {
                    val value = input.trim()
                    val nodeId = prefs.getString("nodeId", "client-unknown").orEmpty()
                    dialog = null
                    input = ""
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            if (action == "create") GroupClientApi.create(truth.config.nodeUrl, value, nodeId)
                            else GroupClientApi.join(truth.config.nodeUrl, value, nodeId, "This phone")
                        }
                        onNotify(if (result.ok) result.code.replace('_', ' ') else result.userMessage())
                        if (result.ok) refresh()
                    }
                }) { Text(if (action == "create") "CREATE" else "REQUEST JOIN") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("CANCEL") } },
        )
    }

    rosterTitle?.let { title ->
        AlertDialog(
            onDismissRequest = { rosterTitle = null },
            title = { Text("$title members") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    when {
                        rosterLoading -> Text("Synchronizing roster with SERVER…")
                        rosterMembers.isEmpty() -> Text("No active members were returned.")
                        else -> rosterMembers.forEach { member ->
                            GlassPanel {
                                Text(member.label, fontWeight = FontWeight.SemiBold)
                                Text("${member.role} · ${member.membershipState}", fontSize = 10.sp)
                                Text("Presence: ${member.presenceState}", fontSize = 10.sp, color = tokens.text.secondary)
                                Text(member.nodeId, fontSize = 8.sp, color = tokens.text.muted, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { rosterTitle = null }) { Text("CLOSE") } },
        )
    }
}

@Composable
private fun NodeMeshGraphic(connected: Boolean) {
    val tokens = LocalSwurlzTokens.current
    GlassPanel(modifier = Modifier.fillMaxWidth().height(185.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            val left = Offset(size.width * .23f, size.height * .68f)
            val center = Offset(size.width * .50f, size.height * .48f)
            val right = Offset(size.width * .79f, size.height * .28f)
            drawLine(tokens.accents.primary.copy(alpha = .50f), left, center, 2f)
            drawLine(tokens.accents.tertiary.copy(alpha = if (connected) .55f else .18f), center, right, 2f)
            listOf(left, center, right).forEachIndexed { index, point ->
                drawCircle(
                    color = when (index) {
                        1 -> tokens.accents.primary
                        2 -> if (connected) tokens.status.info else tokens.text.disabled
                        else -> tokens.status.success
                    },
                    radius = if (index == 1) 15f else 11f,
                    center = point,
                    alpha = .88f,
                )
                drawCircle(tokens.text.primary.copy(alpha = .14f), radius = 28f, center = point)
            }
        }
    }
}


@Composable
private fun ClientActivityScreen(
    timeline: List<MissionBus.TimelineEntry>,
    truth: CoreNodeTruthState,
    permissionsReady: Boolean,
) {
    val tokens = LocalSwurlzTokens.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionLabel("USER ACTIVITY")
            Text("What SWRLZ is doing.", color = tokens.text.primary, fontSize = 27.sp, fontWeight = FontWeight.Medium)
            Text("Actionable operator events only. Raw protocol traces remain in Developer Mode.", color = tokens.text.secondary, fontSize = 12.sp)
        }
        item {
            GlassPanel {
                SettingLine("Operator permissions", if (permissionsReady) "Ready for local execution" else "Attention required", trailing = { TinyPill(if (permissionsReady) "READY" else "ACTION", if (permissionsReady) tokens.status.success else tokens.status.warning) })
                SettingDivider()
                SettingLine("Core node", truth.auto.summary.ifBlank { truth.manual.summary.ifBlank { "Not reported" } }, trailing = { TinyPill(if (truth.auto.success || truth.manual.success) "READY" else "CHECK", if (truth.auto.success || truth.manual.success) tokens.status.success else tokens.status.warning) })
            }
        }
        if (timeline.isEmpty()) {
            item { GlassPanel { Text("No mission activity has been recorded in this session.", color = tokens.text.secondary, fontSize = 12.sp) } }
        } else {
            items(timeline.asReversed()) { event ->
                GlassPanel {
                    Text(event.label, color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
                    Text("${event.phase} · ${event.type} · risk ${event.risk}", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

@Composable
private fun ClientSettingsScreen(
    style: UiStyleSettings,
    statusNotificationEnabled: Boolean,
    chatAutoFollow: Boolean,
    chatSettings: ChatSettings,
    missionStartApprovalMode: String,
    onStatusNotificationChanged: (Boolean) -> Unit,
    onChatAutoFollowChanged: (Boolean) -> Unit,
    onChatSettingsChanged: (ChatSettings) -> Unit,
    onMissionStartApprovalModeChanged: (String) -> Unit,
    onAutoPresenceChanged: (Boolean) -> Unit,
    onMotionChanged: (Boolean) -> Unit,
    onOpenStyle: () -> Unit,
    onOpenBubble: () -> Unit,
    onOpenBubbleSettings: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenDiscovery: () -> Unit,
    onOpenCoreAdmin: () -> Unit,
    onOpenSetup: () -> Unit,
    onOpenForge: () -> Unit,
    onOpenDeveloper: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    var section by rememberSaveable { mutableStateOf(ClientSettingsSection.ROOT.name) }
    var search by rememberSaveable { mutableStateOf("") }
    val active = ClientSettingsSection.entries.firstOrNull { it.name == section } ?: ClientSettingsSection.ROOT

    if (active == ClientSettingsSection.CHAT) {
        ClientChatSettingsScreen(
            settings = chatSettings,
            autoFollow = chatAutoFollow,
            onAutoFollowChanged = onChatAutoFollowChanged,
            onSettingsChanged = onChatSettingsChanged,
            onOpenSharing = onOpenSetup,
            onBack = { section = ClientSettingsSection.ROOT.name },
        )
        return
    }

    if (active != ClientSettingsSection.ROOT) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                TextButton(onClick = { section = ClientSettingsSection.ROOT.name }) { Text("‹ ALL SETTINGS") }
                SectionLabel(active.title.uppercase())
                Text(active.subtitle, color = tokens.text.secondary, fontSize = 12.sp, lineHeight = 17.sp)
            }
            when (active) {
                ClientSettingsSection.CORE -> item {
                    GlassPanel {
                        SettingLine("Auto presence", "Keep CLIENT identity/presence refreshed while SWRLZ is active", trailing = {
                            Switch(checked = style.autoPresenceEnabled, onCheckedChange = onAutoPresenceChanged)
                        })
                        SettingDivider()
                        SettingsAction("DISCOVER / CONNECT SERVER", onOpenDiscovery)
                        SettingsAction("NODE TRUST / CORE ADMIN", onOpenCoreAdmin)
                        SettingsAction("SHARING APPROVALS", onOpenSetup)
                    }
                }
                ClientSettingsSection.MISSIONS -> item {
                    GlassPanel {
                        Text("Mission start approval", color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
                        Text("Controls the boundary between understanding/planning and the first Android action.", color = tokens.text.secondary, fontSize = 11.sp)
                        Spacer(Modifier.height(8.dp))
                        listOf("Always ask", "Risk-aware", "Automatic").forEach { mode ->
                            OutlinedButton(
                                onClick = { onMissionStartApprovalModeChanged(mode) },
                                modifier = Modifier.fillMaxWidth(),
                                border = BorderStroke(1.dp, if (missionStartApprovalMode == mode) tokens.accents.primary else tokens.borders.neutral),
                            ) { Text(if (missionStartApprovalMode == mode) "✓ $mode" else mode.uppercase()) }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("Always ask is active immediately. Risk-aware and Automatic remain subject to per-action safety/approval gates.", color = tokens.text.muted, fontSize = 10.sp)
                    }
                }
                ClientSettingsSection.ACTIVITY -> item {
                    GlassPanel {
                        SettingLine("Notification widget", "Persistent Glitch Dragon CLIENT status in the notification shade", trailing = {
                            Switch(checked = statusNotificationEnabled, onCheckedChange = onStatusNotificationChanged)
                        })
                    }
                }
                ClientSettingsSection.FORGE -> item {
                    ClientForgeSettingsControls(onOpenForge)
                }
                ClientSettingsSection.INTERFACE -> item {
                    GlassPanel(highlighted = true) {
                        SettingLine(style.themePack, "${style.displayMode} · ${style.animationLevel} motion", trailing = { TextButton(onClick = onOpenStyle) { Text("STYLE") } })
                        SettingDivider()
                        SettingLine("Decorative motion", "Dragon drift, core pulse, and transitions", trailing = { Switch(style.animationLevel != "Off", onMotionChanged) })
                        SettingDivider()
                        SettingLine("Floating Dragon", "Compact chat and mission bubble", trailing = { TextButton(onClick = onOpenBubble) { Text("OPEN") } })
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = onOpenBubbleSettings) { Text("BUBBLE SETTINGS") } }
                    }
                }
                ClientSettingsSection.BRAIN -> item {
                    val context = LocalContext.current
                    var legacyDraft by rememberSaveable { mutableStateOf("") }
                    var legacyConfigured by remember { mutableStateOf(SecretStore.geminiApiKey(context).isNotBlank()) }
                    GlassPanel(highlighted = legacyConfigured) {
                        Text("SWRLZ provider mesh", color = tokens.text.primary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text("OpenAI/GPT and Gemini credentials belong on SERVER. CLIENT receives provider reachability, models, and results without receiving provider secrets.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
                        Spacer(Modifier.height(10.dp))
                        SettingLine("SERVER provider routing", "Configure defaults, status, and @gpt/@gemini/@both under Chat & Commands → AI Providers.", trailing = { TinyPill("SERVER", tokens.status.success) })
                        SettingDivider()
                        Text("Legacy direct-device Gemini", color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
                        Text("Compatibility fallback only. New setups should use SERVER custody. The saved secret is never re-displayed.", color = tokens.text.muted, fontSize = 9.sp, lineHeight = 13.sp)
                        OutlinedTextField(
                            value = legacyDraft,
                            onValueChange = { legacyDraft = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(if (legacyConfigured) "Replacement legacy Gemini key" else "Legacy Gemini key") },
                            placeholder = { Text("Paste once — not shown after save") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { SecretStore.forgetGeminiApiKey(context); legacyDraft = ""; legacyConfigured = false }, enabled = legacyConfigured) { Text("REMOVE") }
                            Button(enabled = legacyDraft.isNotBlank(), onClick = { SecretStore.setGeminiApiKey(context, legacyDraft); legacyDraft = ""; legacyConfigured = true }) { Text("SAVE LEGACY") }
                        }
                    }
                }
                ClientSettingsSection.PRIVACY -> item {
                    GlassPanel {
                        SettingLine("Truth Firewall", "Valid objections and uncertainty stay visible", trailing = { TinyPill("ARMED", tokens.status.success) })
                        SettingDivider()
                        SettingLine("Local-first core", "Online services enhance; they never become the leash", trailing = { TinyPill("ACTIVE", tokens.status.success) })
                        SettingDivider()
                        SettingsAction("PERMISSIONS", onOpenPermissions)
                        SettingsAction("SHARING APPROVALS", onOpenSetup)
                    }
                }
                ClientSettingsSection.DEVELOPER -> item {
                    GlassPanel {
                        Text("Engineering surfaces", color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
                        Text("Raw diagnostics and legacy engineering tools stay separate from everyday action menus.", color = tokens.text.secondary, fontSize = 11.sp)
                        Spacer(Modifier.height(10.dp))
                        SettingsAction("SWITCH TO SWRLZ DEV MODE", onOpenDeveloper)
                    }
                }
                else -> Unit
            }
        }
        return
    }

    val categories = ClientSettingsSection.entries.filter { it != ClientSettingsSection.ROOT }
    val normalized = search.trim().lowercase()
    val visible = categories.filter { category ->
        normalized.isBlank() || category.title.lowercase().contains(normalized) || category.subtitle.lowercase().contains(normalized) || category.keywords.any { it.contains(normalized) }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionLabel("SETTINGS CONTROL CENTER")
            Text("Settings get rooms. Actions get room to breathe.", color = tokens.text.primary, fontSize = 27.sp, fontWeight = FontWeight.Medium)
            Text("Search or open a domain. Each submenu owns configuration for that capability so action surfaces can stay focused on doing the work.", color = tokens.text.secondary, fontSize = 12.sp, lineHeight = 17.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search settings") })
        }
        items(visible) { category ->
            SettingsCategoryCard(category.title, category.subtitle) { section = category.name }
        }
    }
}


private enum class ClientChatSettingsPage(val title: String, val subtitle: String) {
    ROOT("Chat & Commands", "Conversation behavior, response personality, context, and command surfaces"),
    FLOW("Conversation Flow", "How Chat follows new responses and live runtime events"),
    PERSONALITY("Personality & Response", "SWRLZ voice, detail, warmth, energy, humor, structure, and emoji"),
    PROVIDERS("AI Providers", "SWRLZ Auto, GPT, Gemini, Council/Compare, status probes, and model routing"),
    PROFILES("Profiles & Routing", "Endpoint, relationship, provider, inheritance, and custom profile assignments"),
    CONTEXT("Privacy & Context", "Local-first boundaries, Truth Firewall status, and sharing approvals"),
}

@Composable
private fun ClientChatSettingsScreen(
    settings: ChatSettings,
    autoFollow: Boolean,
    onAutoFollowChanged: (Boolean) -> Unit,
    onSettingsChanged: (ChatSettings) -> Unit,
    onOpenSharing: () -> Unit,
    onBack: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val profileDocument by ClientProfileStore.documentFlow(context).collectAsState(initial = ProfileDocumentV1())
    val providerSnapshot by ProviderClientRuntime.snapshot.collectAsState()
    var customProfileName by rememberSaveable { mutableStateOf("") }
    var customProfileInstruction by rememberSaveable { mutableStateOf("") }
    var customProfileTarget by rememberSaveable { mutableStateOf("CLIENT endpoint") }
    var pageName by rememberSaveable { mutableStateOf(ClientChatSettingsPage.ROOT.name) }
    val page = ClientChatSettingsPage.entries.firstOrNull { it.name == pageName } ?: ClientChatSettingsPage.ROOT

    fun update(transform: (ChatSettings) -> ChatSettings) = onSettingsChanged(transform(settings).normalized())

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            TextButton(onClick = {
                if (page == ClientChatSettingsPage.ROOT) onBack() else pageName = ClientChatSettingsPage.ROOT.name
            }) {
                Text(if (page == ClientChatSettingsPage.ROOT) "‹ ALL SETTINGS" else "‹ CHAT & COMMANDS")
            }
            SectionLabel(page.title.uppercase())
            Text(page.subtitle, color = tokens.text.secondary, fontSize = 12.sp, lineHeight = 17.sp)
        }

        when (page) {
            ClientChatSettingsPage.ROOT -> {
                item {
                    GlassPanel(highlighted = true) {
                        Text("SWRLZ conversation control center", color = tokens.text.primary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Chat behavior stays separate from mission authority. Personality changes how SWRLZ speaks; they never weaken approvals, Truth Firewall, or local-first boundaries.",
                            color = tokens.text.secondary,
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                        )
                    }
                }
                item { SettingsCategoryCard("Conversation Flow", "Response-top following, LATEST behavior, and live-event focus") { pageName = ClientChatSettingsPage.FLOW.name } }
                item { SettingsCategoryCard("Personality & Response", "${settings.baseStyle} · ${settings.detailLevel} detail · ${settings.humor} humor") { pageName = ClientChatSettingsPage.PERSONALITY.name } }
                item { SettingsCategoryCard("AI Providers", "${settings.providerStrategy.chatLabel()} · GPT/Gemini status, Council/Compare, and SERVER model routing") { pageName = ClientChatSettingsPage.PROVIDERS.name } }
                item { SettingsCategoryCard("Profiles & Routing", "CLIENT identity, CLIENT → SERVER behavior, provider specialists, and custom inheritance") { pageName = ClientChatSettingsPage.PROFILES.name } }
                item { SettingsCategoryCard("Privacy & Context", "Truth Firewall, local-first boundaries, and context-sharing controls") { pageName = ClientChatSettingsPage.CONTEXT.name } }
            }

            ClientChatSettingsPage.FLOW -> {
                item {
                    GlassPanel(highlighted = true) {
                        SettingLine("Auto-follow new responses", "Follow SWRLZ while you have not intentionally scrolled away.", trailing = {
                            Switch(checked = autoFollow, onCheckedChange = onAutoFollowChanged)
                        })
                        SettingDivider()
                        Text("Follow target", color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
                        Text("Response top keeps the beginning of a new SWRLZ reply visible while it grows downward. Conversation bottom preserves the legacy behavior.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
                        Spacer(Modifier.height(8.dp))
                        SettingsChoiceRow(
                            options = listOf(ChatSettings.FOLLOW_RESPONSE_TOP, ChatSettings.FOLLOW_BOTTOM),
                            selected = settings.followTarget,
                            onSelect = { value -> update { it.copy(followTarget = value) } },
                        )
                    }
                }
                item {
                    GlassPanel {
                        SettingLine("Open Chat for live events", "Bring Chat forward when SWRLZ emits runtime commentary from missions, Forge, or other live capability events.", trailing = {
                            Switch(
                                checked = settings.autoOpenRuntimeEvents,
                                onCheckedChange = { enabled -> update { it.copy(autoOpenRuntimeEvents = enabled) } },
                            )
                        })
                        SettingDivider()
                        Text("Manual upward scrolling pauses follow. ↓ LATEST re-arms follow and uses the selected target above. Sending a new message also re-arms follow for the next SWRLZ response.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
                    }
                }
            }

            ClientChatSettingsPage.PERSONALITY -> {
                item {
                    GlassPanel(highlighted = true) {
                        ChatSettingsChoiceGroup(
                            title = "Base style",
                            detail = "The primary conversation stance. Adaptive SWRLZ shifts with the task instead of locking one tone.",
                            options = listOf(ChatSettings.STYLE_ADAPTIVE, ChatSettings.STYLE_ENGINEER, ChatSettings.STYLE_COMPANION, ChatSettings.STYLE_GLITCH_MUSE, ChatSettings.STYLE_DIRECT, ChatSettings.STYLE_CANDID),
                            selected = settings.baseStyle,
                            onSelect = { value -> update { it.copy(baseStyle = value) } },
                        )
                    }
                }
                item {
                    GlassPanel {
                        ChatSettingsChoiceGroup("Detail", "How deep explanations should normally go.", listOf(ChatSettings.DETAIL_COMPACT, ChatSettings.DETAIL_BALANCED, ChatSettings.DETAIL_DEEP), settings.detailLevel) { value -> update { it.copy(detailLevel = value) } }
                        SettingDivider()
                        ChatSettingsChoiceGroup("Warmth", "How personable the default conversation voice feels.", listOf(ChatSettings.TRAIT_LOW, ChatSettings.TRAIT_BALANCED, ChatSettings.TRAIT_HIGH), settings.warmth) { value -> update { it.copy(warmth = value) } }
                        SettingDivider()
                        ChatSettingsChoiceGroup("Energy", "Calm, balanced, or high conversational energy.", listOf(ChatSettings.TRAIT_LOW, ChatSettings.TRAIT_BALANCED, ChatSettings.TRAIT_HIGH), settings.energy) { value -> update { it.copy(energy = value) } }
                        SettingDivider()
                        ChatSettingsChoiceGroup("Humor", "How readily SWRLZ leans into jokes and glitch-language when context allows.", listOf(ChatSettings.HUMOR_OFF, ChatSettings.HUMOR_LIGHT, ChatSettings.HUMOR_ADAPTIVE, ChatSettings.HUMOR_CHAOS), settings.humor) { value -> update { it.copy(humor = value) } }
                        SettingDivider()
                        ChatSettingsChoiceGroup("Formatting", "Natural prose, balanced structure, or stronger headers/lists.", listOf(ChatSettings.FORMAT_NATURAL, ChatSettings.FORMAT_BALANCED, ChatSettings.FORMAT_STRUCTURED), settings.formatting) { value -> update { it.copy(formatting = value) } }
                        SettingDivider()
                        ChatSettingsChoiceGroup("Emoji", "Never replaces safety/status semantics; only changes conversational decoration.", listOf(ChatSettings.EMOJI_OFF, ChatSettings.EMOJI_LIGHT, ChatSettings.EMOJI_ADAPTIVE), settings.emoji) { value -> update { it.copy(emoji = value) } }
                    }
                }
                item {
                    GlassPanel {
                        Text("Effective profile", color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
                        Text(settings.reasoningDirective(), color = tokens.text.secondary, fontSize = 10.sp, lineHeight = 15.sp)
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { onSettingsChanged(ChatSettings()) }, modifier = Modifier.fillMaxWidth()) { Text("RESET CHAT PERSONALITY") }
                    }
                }
            }

            ClientChatSettingsPage.PROVIDERS -> {
                item {
                    GlassPanel(highlighted = true) {
                        Text("SWRLZ provider mesh", color = tokens.text.primary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text("SWRLZ stays the user-facing identity. GPT and Gemini are SERVER-custodied reasoning specialists; provider output never bypasses Truth Firewall or action approval.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
                        Spacer(Modifier.height(8.dp))
                        ChatSettingsChoiceGroup(
                            title = "Default route",
                            detail = "Per-message tags override this: @gpt, @gemini, @both/@council, @compare, or @local.",
                            options = listOf("SWRLZ AUTO", "LOCAL ONLY", "GPT", "GEMINI", "GPT + GEMINI", "COMPARE"),
                            selected = settings.providerStrategy.chatLabel(),
                            onSelect = { label ->
                                val strategy = when (label) {
                                    "LOCAL ONLY" -> ProviderStrategy.LOCAL_ONLY
                                    "GPT" -> ProviderStrategy.OPENAI
                                    "GEMINI" -> ProviderStrategy.GEMINI
                                    "GPT + GEMINI" -> ProviderStrategy.COUNCIL
                                    "COMPARE" -> ProviderStrategy.COMPARE
                                    else -> ProviderStrategy.SWRLZ_AUTO
                                }
                                update { it.copy(providerStrategy = strategy) }
                            },
                        )
                    }
                }
                item {
                    GlassPanel {
                        SettingLine("Show provider status in Chat", "Compact SWRLZ/GPT/Gemini status orbs and route selector above the conversation.", trailing = {
                            Switch(settings.showProviderStatus, onCheckedChange = { enabled -> update { it.copy(showProviderStatus = enabled) } })
                        })
                        SettingDivider()
                        SettingLine("Automatic remote providers", "Allow the selected default route to call remote providers without an explicit @gpt/@gemini/@both tag.", trailing = {
                            Switch(settings.allowRemoteProvidersAutomatically, onCheckedChange = { enabled -> update { it.copy(allowRemoteProvidersAutomatically = enabled) } })
                        })
                        Text("Explicit provider tags count as an intentional per-message provider request. Automatic remote use stays off by default.", color = tokens.text.muted, fontSize = 9.sp, lineHeight = 13.sp)
                    }
                }
                item {
                    GlassPanel {
                        SectionLabel("LIVE PROVIDER STATUS")
                        ProviderStatusSettingsLine("SWRLZ CLIENT", ProviderHealthStatus.READY, "Local orchestration")
                        SettingDivider()
                        ProviderStatusSettingsLine("SWRLZ SERVER", if (providerSnapshot.swrlzIdentity.contains("SERVER", ignoreCase = true)) ProviderHealthStatus.READY else ProviderHealthStatus.OFFLINE, providerSnapshot.swrlzIdentity)
                        providerSnapshot.providers.filter { it.providerId == ProviderId.OPENAI.wireId || it.providerId == ProviderId.GEMINI.wireId }.forEach { health ->
                            SettingDivider()
                            ProviderStatusSettingsLine(health.providerId.uppercase(), health.status, "${health.selectedModel ?: "AUTO"} · ${health.detail}")
                            ProviderModelSelector(health = health) { modelId -> scope.launch { runCatching { ProviderClientRuntime.selectModel(context, health.providerId, modelId) } } }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { scope.launch { ProviderClientRuntime.probeAll(context) } }, modifier = Modifier.fillMaxWidth()) { Text("PROBE ALL THROUGH SERVER") }
                        Text("Credentials are configured on SERVER and never returned to CLIENT. Cross-device provider execution remains trust/device-proof gated in this checkpoint; same-device loopback is supported.", color = tokens.text.muted, fontSize = 9.sp, lineHeight = 13.sp)
                    }
                }
            }

            ClientChatSettingsPage.PROFILES -> {
                item {
                    GlassPanel(highlighted = true) {
                        Text("Distributed SWRLZ profiles", color = tokens.text.primary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text("Profiles are declarative presentation/reasoning overlays. Precedence is foundation → endpoint → relationship → provider → session → per-message. They cannot weaken Truth Firewall, trust, permissions, approvals, mission authority, Forge authority, or protocol semantics.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
                    }
                }
                item {
                    val endpointProfiles = profileDocument.profiles.filter { it.scope == ProfileScope.CLIENT_ENDPOINT }
                    ProfileAssignmentPanel(
                        title = "CLIENT SWRLZ profile",
                        detail = "How SWRLZ speaks and reasons when you chat directly with this CLIENT.",
                        profiles = endpointProfiles,
                        selectedId = profileDocument.assignments.clientEndpointProfileId,
                        onSelect = { id -> scope.launch { ClientProfileStore.updateAssignments(context) { it.copy(clientEndpointProfileId = id) } } },
                    )
                }
                item {
                    val profiles = profileDocument.profiles.filter { it.scope == ProfileScope.CLIENT_TO_SERVER }
                    ProfileAssignmentPanel(
                        title = "CLIENT → SERVER profile",
                        detail = "How this CLIENT frames work when asking a SERVER/SWURLZER node for reasoning or orchestration.",
                        profiles = profiles,
                        selectedId = profileDocument.assignments.clientToServerProfileId,
                        onSelect = { id -> scope.launch { ClientProfileStore.updateAssignments(context) { it.copy(clientToServerProfileId = id) } } },
                    )
                }
                item {
                    val providers = profileDocument.profiles.filter { it.scope == ProfileScope.PROVIDER && it.providerId == "openai" }
                    ProfileAssignmentPanel(
                        title = "GPT provider profile",
                        detail = "CLIENT-side reasoning emphasis for OpenAI/GPT requests. SERVER owns credentials and executes the provider call.",
                        profiles = providers,
                        selectedId = profileDocument.assignments.openAiProviderProfileId,
                        onSelect = { id -> scope.launch { ClientProfileStore.updateAssignments(context) { it.copy(openAiProviderProfileId = id) } } },
                    )
                }
                item {
                    val providers = profileDocument.profiles.filter { it.scope == ProfileScope.PROVIDER && it.providerId == "gemini" }
                    ProfileAssignmentPanel(
                        title = "Gemini provider profile",
                        detail = "CLIENT-side reasoning emphasis for Gemini requests. SERVER provider routing receives the relationship/provider profile stack; legacy direct-device Gemini remains compatibility-only.",
                        profiles = providers,
                        selectedId = profileDocument.assignments.geminiProviderProfileId,
                        onSelect = { id -> scope.launch { ClientProfileStore.updateAssignments(context) { it.copy(geminiProviderProfileId = id) } } },
                    )
                }
                item {
                    GlassPanel {
                        Text("Create custom profile", color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
                        Text("Clone the currently assigned profile for one route and add a local instruction. Built-ins remain immutable; custom profiles can inherit from them.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
                        Spacer(Modifier.height(8.dp))
                        SettingsChoiceRow(
                            options = listOf("CLIENT endpoint", "CLIENT → SERVER", "GPT provider", "Gemini provider", "Local provider"),
                            selected = customProfileTarget,
                            onSelect = { customProfileTarget = it },
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = customProfileName, onValueChange = { customProfileName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Profile name") }, singleLine = true)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = customProfileInstruction, onValueChange = { customProfileInstruction = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Custom profile instruction") }, minLines = 2)
                        Spacer(Modifier.height(8.dp))
                        Button(
                            enabled = customProfileName.isNotBlank(),
                            onClick = {
                                scope.launch {
                                    val a = profileDocument.assignments
                                    val (scopeType, parentId) = when (customProfileTarget) {
                                        "CLIENT → SERVER" -> ProfileScope.CLIENT_TO_SERVER to a.clientToServerProfileId
                                        "GPT provider" -> ProfileScope.PROVIDER to a.openAiProviderProfileId
                                        "Gemini provider" -> ProfileScope.PROVIDER to a.geminiProviderProfileId
                                        "Local provider" -> ProfileScope.PROVIDER to a.localProviderProfileId
                                        else -> ProfileScope.CLIENT_ENDPOINT to a.clientEndpointProfileId
                                    }
                                    val created = ClientProfileStore.createCustomProfile(context, customProfileName, scopeType, parentId, customProfileInstruction)
                                    val providerAdjusted = when (customProfileTarget) {
                                        "GPT provider" -> created.copy(providerId = "openai")
                                        "Gemini provider" -> created.copy(providerId = "gemini")
                                        "Local provider" -> created.copy(providerId = "local")
                                        else -> created
                                    }
                                    if (providerAdjusted != created) ClientProfileStore.upsertProfile(context, providerAdjusted)
                                    ClientProfileStore.updateAssignments(context) { current ->
                                        when (customProfileTarget) {
                                            "CLIENT → SERVER" -> current.copy(clientToServerProfileId = providerAdjusted.id)
                                            "GPT provider" -> current.copy(openAiProviderProfileId = providerAdjusted.id)
                                            "Gemini provider" -> current.copy(geminiProviderProfileId = providerAdjusted.id)
                                            "Local provider" -> current.copy(localProviderProfileId = providerAdjusted.id)
                                            else -> current.copy(clientEndpointProfileId = providerAdjusted.id)
                                        }
                                    }
                                    customProfileName = ""
                                    customProfileInstruction = ""
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("CREATE + ASSIGN") }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val a = profileDocument.assignments
                                    val activeId = when (customProfileTarget) {
                                        "CLIENT → SERVER" -> a.clientToServerProfileId
                                        "GPT provider" -> a.openAiProviderProfileId
                                        "Gemini provider" -> a.geminiProviderProfileId
                                        "Local provider" -> a.localProviderProfileId
                                        else -> a.clientEndpointProfileId
                                    }
                                    val clone = ClientProfileStore.duplicateProfile(context, activeId, displayName = null)
                                    ClientProfileStore.updateAssignments(context) { current ->
                                        when (customProfileTarget) {
                                            "CLIENT → SERVER" -> current.copy(clientToServerProfileId = clone.id)
                                            "GPT provider" -> current.copy(openAiProviderProfileId = clone.id)
                                            "Gemini provider" -> current.copy(geminiProviderProfileId = clone.id)
                                            "Local provider" -> current.copy(localProviderProfileId = clone.id)
                                            else -> current.copy(clientEndpointProfileId = clone.id)
                                        }
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("DUPLICATE ACTIVE AS TEST") }
                    }
                }
                item {
                    GlassPanel {
                        val resolved = ClientProfileStore.resolveClientLocal(profileDocument)
                        SectionLabel("EFFECTIVE CLIENT PROFILE")
                        Text(resolved.directive(), color = tokens.text.secondary, fontSize = 10.sp, lineHeight = 15.sp)
                    }
                }
            }

            ClientChatSettingsPage.CONTEXT -> {
                item {
                    GlassPanel(highlighted = true) {
                        SettingLine("Truth Firewall", "Valid objections, uncertainty, and conflicting evidence remain visible regardless of personality profile.", trailing = { TinyPill("ARMED", tokens.status.success) })
                        SettingDivider()
                        SettingLine("Local-first core", "Local reasoning and local state remain preferred; remote models are optional reasoning providers.", trailing = { TinyPill("ACTIVE", tokens.status.success) })
                    }
                }
                item {
                    GlassPanel {
                        Text("Context sharing", color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
                        Text("Sharing approvals remain authoritative outside Chat personality. Open them here when you want to review what can leave the device.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
                        Spacer(Modifier.height(8.dp))
                        SettingsAction("OPEN SHARING APPROVALS", onOpenSharing)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProviderModelSelector(health: ProviderHealthV1, onSelect: (String) -> Unit) {
    if (health.discoveredModels.isEmpty()) return
    var expanded by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("MODEL · ${health.selectedModel ?: "AUTO"}", fontSize = 9.sp)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            health.discoveredModels.take(40).forEach { model ->
                DropdownMenuItem(
                    text = { Text(if (model.id == health.selectedModel) "✓ ${model.displayName}" else model.displayName) },
                    onClick = { onSelect(model.id); expanded = false },
                )
            }
        }
    }
}

@Composable
private fun ProviderStatusSettingsLine(label: String, status: ProviderHealthStatus, detail: String) {
    val tokens = LocalSwurlzTokens.current
    val tone = when (status) {
        ProviderHealthStatus.READY -> tokens.status.success
        ProviderHealthStatus.PROBING, ProviderHealthStatus.STORED, ProviderHealthStatus.DEGRADED -> tokens.status.warning
        ProviderHealthStatus.AUTH_FAILED, ProviderHealthStatus.ERROR -> tokens.status.danger
        else -> tokens.text.muted
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(tone, CircleShape))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = tokens.text.primary, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
            Text(detail, color = tokens.text.muted, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        TinyPill(status.name.replace('_', ' '), tone)
    }
}

@Composable
private fun ProfileAssignmentPanel(
    title: String,
    detail: String,
    profiles: List<SwrlzProfileV1>,
    selectedId: String,
    onSelect: (String) -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    GlassPanel {
        Text(title, color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
        Text(detail, color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
        Spacer(Modifier.height(8.dp))
        if (profiles.isEmpty()) {
            Text("No matching profiles are registered.", color = tokens.text.muted, fontSize = 10.sp)
        } else {
            profiles.forEach { profile ->
                OutlinedButton(
                    onClick = { onSelect(profile.id) },
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, if (selectedId == profile.id) tokens.accents.primary else tokens.borders.neutral),
                ) {
                    val star = if (profile.favorite) "★ " else ""
                    val lifecycle = if (profile.builtIn) "STABLE" else profile.lifecycle.name
                    Text(if (selectedId == profile.id) "✓ $star${profile.displayName} · $lifecycle" else "$star${profile.displayName} · $lifecycle")
                }
            }
        }
    }
}

@Composable
private fun ChatSettingsChoiceGroup(
    title: String,
    detail: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    Text(title, color = tokens.text.primary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    Text(detail, color = tokens.text.muted, fontSize = 10.sp, lineHeight = 14.sp)
    Spacer(Modifier.height(6.dp))
    SettingsChoiceRow(options, selected, onSelect)
}

@Composable
private fun SettingsChoiceRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    val tokens = LocalSwurlzTokens.current
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { option ->
            OutlinedButton(
                onClick = { onSelect(option) },
                border = BorderStroke(1.dp, if (option == selected) tokens.accents.primary else tokens.borders.neutral),
            ) {
                Text(if (option == selected) "✓ $option" else option)
            }
        }
    }
}

private enum class ClientSettingsSection(
    val title: String,
    val subtitle: String,
    val keywords: List<String>,
) {
    ROOT("Settings", "All settings", emptyList()),
    CORE("Core & Connection", "Server discovery, presence, node trust, and sharing routes", listOf("server", "node", "connection", "presence", "sharing")),
    CHAT("Chat & Commands", "Conversation flow, personality, providers, profiles, context, and command-surface behavior", listOf("chat", "scroll", "follow", "commands", "personality", "response", "provider", "gpt", "gemini", "model", "warmth", "energy", "humor", "emoji", "formatting", "context")),
    MISSIONS("Missions", "Mission-start approval and execution boundaries", listOf("mission", "approval", "dialog", "automatic", "risk")),
    ACTIVITY("Activity & Notifications", "Status surfaces and operator notifications", listOf("activity", "notification", "status")),
    FORGE("Forge", "Repository, credential, upload, workflow, and artifact configuration", listOf("github", "repository", "workflow", "upload", "forge")),
    INTERFACE("Interface & Bubble", "Theme armor, motion, bubble, and visual behavior", listOf("theme", "style", "bubble", "motion", "interface")),
    BRAIN("Brain & AI", "SERVER provider mesh and legacy direct-device compatibility", listOf("ai", "gemini", "openai", "gpt", "brain", "model", "llm", "provider")),
    PRIVACY("Privacy & Security", "Truth, permissions, sharing, and local-first boundaries", listOf("privacy", "security", "permissions", "truth", "local")),
    DEVELOPER("Developer & Diagnostics", "Engineering surfaces and raw diagnostics", listOf("developer", "debug", "diagnostics", "logs")),
}

@Composable
private fun SettingsCategoryCard(title: String, subtitle: String, onOpen: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    GlassPanel(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
            }
            IconButton(onClick = onOpen) { Icon(Icons.Outlined.ChevronRight, contentDescription = "Open $title", tint = tokens.accents.primary) }
        }
    }
}

@Composable
private fun SettingsAction(label: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text(label) }
}

@Composable
private fun GlassPanel(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    ThemeChromePanel(
        modifier = modifier,
        highlighted = highlighted,
        content = content,
    )
}

@Composable
private fun QuickAction(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    ThemeChromeBox(
        modifier = modifier.clickable(onClick = onClick),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(icon, contentDescription = null, tint = tokens.accents.primary, modifier = Modifier.size(18.dp))
            Spacer(Modifier.height(6.dp))
            Text(label, color = tokens.text.secondary, fontSize = 10.sp, maxLines = 1)
        }
    }
}

@Composable
private fun NodeLine(icon: ImageVector, name: String, detail: String, status: String, tone: Color) {
    val tokens = LocalSwurlzTokens.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(tokens.accents.primary.copy(alpha = .12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = tone)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = tokens.text.primary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = tokens.text.muted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        TinyPill(status, tone)
    }
}

@Composable
private fun SettingLine(title: String, detail: String, trailing: @Composable () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = tokens.text.primary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = tokens.text.muted, fontSize = 10.sp, lineHeight = 14.sp)
        }
        Spacer(Modifier.width(10.dp))
        trailing()
    }
}

@Composable
private fun SettingDivider() {
    val tokens = LocalSwurlzTokens.current
    Spacer(Modifier.height(12.dp))
    Box(Modifier.fillMaxWidth().height(1.dp).background(tokens.borders.neutral.copy(alpha = .45f)))
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun SectionLabel(text: String) {
    val tokens = LocalSwurlzTokens.current
    Text(text, color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.8.sp)
}

@Composable
private fun TinyPill(text: String, tone: Color, modifier: Modifier = Modifier) {
    val tokens = LocalSwurlzTokens.current
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(tokens.surfaces.bgOverlay.copy(alpha = .60f))
            .border(1.dp, tone.copy(alpha = .55f), CircleShape)
            .padding(horizontal = 8.dp, vertical = 5.dp),
    ) {
        Text(text, color = tone, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = .8.sp, maxLines = 1)
    }
}

@Composable
private fun SovereigntyDialog(
    paused: Boolean,
    onDismiss: () -> Unit,
    onPauseToggle: () -> Unit,
    onTakeOver: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.Shield, contentDescription = null, tint = tokens.accents.primary) },
        title = { Text("Sovereign controls") },
        text = { Text("Pause freezes the current mission. Take Over stops automated execution and leaves SWRLZ observing only.") },
        confirmButton = {
            Button(onClick = onPauseToggle) {
                Icon(if (paused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(if (paused) "RESUME" else "PAUSE")
            }
        },
        dismissButton = {
            TextButton(onClick = onTakeOver, colors = ButtonDefaults.textButtonColors(contentColor = tokens.status.danger)) {
                Icon(Icons.Outlined.PanTool, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("TAKE OVER")
            }
        },
        containerColor = tokens.surfaces.bgOverlay.copy(alpha = .97f),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ApprovalSheet(
    missionGoal: String,
    onApprove: () -> Unit,
    onRedirect: () -> Unit,
    onDecline: () -> Unit,
    onDismiss: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = tokens.surfaces.bgOverlay.copy(alpha = .96f),
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
            TinyPill("APPROVAL REQUIRED", tokens.status.warning)
            Spacer(Modifier.height(10.dp))
            Text("Review the next mission step", color = tokens.text.primary, fontSize = 21.sp, fontWeight = FontWeight.Medium)
            Text(
                if (missionGoal.isBlank()) "SWRLZ is waiting for your decision." else missionGoal,
                color = tokens.text.secondary,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            )
            Spacer(Modifier.height(12.dp))
            GlassPanel {
                Text("Approval applies once. It does not grant future sharing, spending, deletion, messaging, account changes, or permanent actions.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = onApprove, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.CheckCircle, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("APPROVE ONCE")
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onRedirect, modifier = Modifier.weight(1f)) { Text("REDIRECT") }
                TextButton(onClick = onDecline, modifier = Modifier.weight(1f)) { Text("DECLINE") }
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}

private fun ambientColor(ambient: MissionBus.Ambient): Color = when (ambient) {
    MissionBus.Ambient.Idle -> Color(0xFF9AA7B2)
    MissionBus.Ambient.Listening -> Color(0xFF45F5FF)
    MissionBus.Ambient.Observing -> Color(0xFF2FEAFF)
    MissionBus.Ambient.Planning -> Color(0xFF9C5CFF)
    MissionBus.Ambient.Acting -> Color(0xFF4DFF88)
    MissionBus.Ambient.Paused -> Color(0xFFFFD45A)
    MissionBus.Ambient.Error -> Color(0xFFFF4D68)
    MissionBus.Ambient.Done -> Color(0xFF4DFF88)
}

private fun phaseColor(phase: String): Color = when (phase.lowercase()) {
    "planned" -> Color(0xFF9C5CFF)
    "executing" -> Color(0xFF2FEAFF)
    "success" -> Color(0xFF4DFF88)
    "failure" -> Color(0xFFFF4D68)
    "rolled_back" -> Color(0xFFFFD45A)
    else -> Color(0xFF9AA7B2)
}

private fun riskColor(risk: String): Color = when (risk.lowercase()) {
    "green", "low" -> Color(0xFF4DFF88)
    "yellow", "medium" -> Color(0xFFFFD45A)
    "red", "high", "locked" -> Color(0xFFFF4D68)
    else -> Color(0xFF9AA7B2)
}
