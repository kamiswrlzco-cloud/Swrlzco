package sh.swurlz.core.ui.client

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sh.swurlz.core.github.GitHubConnectionStore
import sh.swurlz.core.ui.theme.LocalSwurlzTokens

@Composable
internal fun ClientForgeSettingsControls(onOpenForge: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val prefs = remember { context.getSharedPreferences("swrlz_forge_preferences", Context.MODE_PRIVATE) }
    val revision by GitHubConnectionStore.revision.collectAsState()
    val saved = remember(revision) { GitHubConnectionStore.profile(context) }

    var owner by remember(revision) { mutableStateOf(saved.owner) }
    var repository by remember(revision) { mutableStateOf(saved.repository) }
    var branch by remember(revision) { mutableStateOf(saved.branch) }
    var tokenName by remember(revision) { mutableStateOf(saved.fineGrainedTokenName) }
    var clientDir by remember(revision) { mutableStateOf(saved.clientSourceDirectory) }
    var serverDir by remember(revision) { mutableStateOf(saved.serverSourceDirectory) }
    var genericDir by remember(revision) { mutableStateOf(saved.genericUploadDirectory) }
    var autoRoute by remember { mutableStateOf(prefs.getBoolean("auto_route_source_packages", true)) }
    var defaultPackageTarget by remember { mutableStateOf(prefs.getString("default_package_target", "ASK").orEmpty().ifBlank { "ASK" }) }
    var autoMatch by remember { mutableStateOf(prefs.getBoolean("auto_match_source_checksum", true)) }
    var autoManifest by remember { mutableStateOf(prefs.getBoolean("auto_match_source_manifest", true)) }
    var transportMode by remember { mutableStateOf(prefs.getString("source_transport_mode", "AUTO").orEmpty().ifBlank { "AUTO" }) }
    var packagePreview by remember { mutableStateOf(prefs.getBoolean("show_package_destination_preview", true)) }
    var comboOneJob by remember { mutableStateOf(prefs.getBoolean("combo_source_one_transaction", true)) }
    var guard by remember { mutableStateOf(prefs.getBoolean("source_zip_content_guard", true)) }
    var expand by remember { mutableStateOf(prefs.getBoolean("expand_generic_zip_to_repo_root", false)) }
    var removeOuter by remember { mutableStateOf(prefs.getBoolean("remove_expanded_zip_after_unpack", false)) }
    var historyDepth by remember { mutableIntStateOf(prefs.getInt("workflow_history_depth", 4).coerceIn(2, 20)) }
    var autoRefresh by remember { mutableStateOf(prefs.getBoolean("workflow_auto_refresh", true)) }

    fun saveTarget() = GitHubConnectionStore.saveTarget(context, owner, repository, branch)
    fun saveRouting() = GitHubConnectionStore.saveForgeRouting(context, tokenName, clientDir, serverDir, genericDir)

    Column(
        Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral, RoundedCornerShape(18.dp)).background(tokens.cards.bg, RoundedCornerShape(18.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Repository target", color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
        Text("Persistent Forge configuration lives here; Forge and Repository stay action-focused.", color = tokens.text.secondary, fontSize = 11.sp)
        OutlinedTextField(owner, { owner = it; saveTarget() }, modifier = Modifier.fillMaxWidth(), label = { Text("Owner") }, singleLine = true)
        OutlinedTextField(repository, { repository = it; saveTarget() }, modifier = Modifier.fillMaxWidth(), label = { Text("Repository") }, singleLine = true)
        OutlinedTextField(branch, { branch = it; saveTarget() }, modifier = Modifier.fillMaxWidth(), label = { Text("Default branch") }, singleLine = true)
        OutlinedTextField(tokenName, { tokenName = it.take(40); saveRouting() }, modifier = Modifier.fillMaxWidth(), label = { Text("Fine-grained token name") }, singleLine = true)
        OutlinedButton(
            onClick = {
                val tokenTemplate = Uri.parse("https://github.com/settings/personal-access-tokens/new").buildUpon()
                    .appendQueryParameter("name", tokenName.ifBlank { "SWRLZ GitHub Forge" }.take(40))
                    .appendQueryParameter("description", "SWRLZ Forge repository upload, bootstrap expansion, repository actions, workflow dispatch, logs, and artifacts")
                    .appendQueryParameter("target_name", owner.trim())
                    .appendQueryParameter("contents", "write")
                    .appendQueryParameter("actions", "write")
                    .appendQueryParameter("workflows", "write")
                    .build()
                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, tokenTemplate)) }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("OPEN TOKEN SETUP") }

        HorizontalDivider()
        Text("Repository routing", color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
        OutlinedTextField(clientDir, { clientDir = it; saveRouting() }, modifier = Modifier.fillMaxWidth(), label = { Text("CLIENT source directory") }, singleLine = true)
        OutlinedTextField(serverDir, { serverDir = it; saveRouting() }, modifier = Modifier.fillMaxWidth(), label = { Text("SERVER source directory") }, singleLine = true)
        OutlinedTextField(genericDir, { genericDir = it; saveRouting() }, modifier = Modifier.fillMaxWidth(), label = { Text("Generic upload directory") }, singleLine = true)
        Text("Default Forge package target · $defaultPackageTarget", color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("ASK", "CLIENT", "SERVER").forEach { option ->
                OutlinedButton(
                    onClick = { defaultPackageTarget = option; prefs.edit().putString("default_package_target", option).apply() },
                    modifier = Modifier.weight(1f),
                ) { Text(if (defaultPackageTarget == option) "✓ $option" else option, fontSize = 10.sp) }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("BOTH", "FILES").forEach { option ->
                OutlinedButton(
                    onClick = { defaultPackageTarget = option; prefs.edit().putString("default_package_target", option).apply() },
                    enabled = option != "BOTH" || comboOneJob,
                    modifier = Modifier.weight(1f),
                ) { Text(if (defaultPackageTarget == option) "✓ $option" else option, fontSize = 10.sp) }
            }
        }
        ForgeSettingSwitch("Auto-route source packages", "CLIENT_/SERVER_ files route to their configured source lanes.", autoRoute) { autoRoute = it; prefs.edit().putBoolean("auto_route_source_packages", it).apply() }
        ForgeSettingSwitch("Auto-match ZIP + SHA-256", "Attach and validate a checksum companion when available. Missing checksum does not block a source ZIP build.", autoMatch) { autoMatch = it; prefs.edit().putBoolean("auto_match_source_checksum", it).apply() }
        ForgeSettingSwitch("Auto-match package manifest", "Attach and validate a package manifest when available. Missing manifest does not block a source ZIP build.", autoManifest) { autoManifest = it; prefs.edit().putBoolean("auto_match_source_manifest", it).apply() }
        Text("Large source transport · $transportMode", color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("AUTO", "DIRECT", "CHUNKED").forEach { option ->
                OutlinedButton(
                    onClick = { transportMode = option; prefs.edit().putString("source_transport_mode", option).apply() },
                    modifier = Modifier.weight(1f),
                ) { Text(if (transportMode == option) "✓ $option" else option, fontSize = 9.sp) }
            }
        }
        Text("AUTO uses resumable 8 MiB chunks for protected CLIENT/SERVER ZIPs above 8 MiB. DIRECT preserves legacy single-blob transport; CHUNKED forces chunk transport.", color = tokens.text.secondary, fontSize = 10.sp, lineHeight = 14.sp)
        ForgeSettingSwitch("CLIENT + SERVER as one transaction", "Stage both package sources in one Forge transaction while preserving separate CLIENT/SERVER identities and lanes.", comboOneJob) {
            comboOneJob = it
            if (!it && defaultPackageTarget == "BOTH") {
                defaultPackageTarget = "ASK"
                prefs.edit().putBoolean("combo_source_one_transaction", false).putString("default_package_target", "ASK").apply()
            } else {
                prefs.edit().putBoolean("combo_source_one_transaction", it).apply()
            }
        }
        ForgeSettingSwitch("Show package destination preview", "Preview ZIP/checksum/manifest destinations before upload.", packagePreview) { packagePreview = it; prefs.edit().putBoolean("show_package_destination_preview", it).apply() }
        ForgeSettingSwitch("Source ZIP content guard", "Inspect protected source archives locally before upload.", guard) { guard = it; prefs.edit().putBoolean("source_zip_content_guard", it).apply() }
        ForgeSettingSwitch("Expand generic ZIP to repository root", "Treat a generic ZIP as a repository transaction instead of one blob.", expand) { expand = it; prefs.edit().putBoolean("expand_generic_zip_to_repo_root", it).apply() }
        ForgeSettingSwitch("Remove outer ZIP after expansion", "Commit expanded entries without retaining the bootstrap ZIP.", removeOuter) { removeOuter = it; prefs.edit().putBoolean("remove_expanded_zip_after_unpack", it).apply() }

        HorizontalDivider()
        ForgeSettingSwitch("Workflow auto-refresh", "Poll active runs while Forge is open; manual refresh remains available.", autoRefresh) { autoRefresh = it; prefs.edit().putBoolean("workflow_auto_refresh", it).apply() }
        Text("Workflow history depth · $historyDepth", color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
        Slider(
            value = historyDepth.toFloat(),
            onValueChange = { historyDepth = it.toInt().coerceIn(2, 20) },
            onValueChangeFinished = { prefs.edit().putInt("workflow_history_depth", historyDepth).apply() },
            valueRange = 2f..20f,
            steps = 17,
        )
        OutlinedButton(onClick = onOpenForge, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, tokens.accents.primary)) { Text("OPEN FORGE / REPOSITORY") }
    }
}

@Composable
private fun ForgeSettingSwitch(title: String, detail: String, checked: Boolean, onChanged: (Boolean) -> Unit) {
    val tokens = LocalSwurlzTokens.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(1f)) {
            Text(title, color = tokens.text.primary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = tokens.text.secondary, fontSize = 10.sp, lineHeight = 14.sp)
        }
        Switch(checked = checked, onCheckedChange = onChanged)
    }
}
