package sh.swurlz.core.github

import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest

/** Pure JVM chunk planner used by Forge before GitHub transport. */
internal object ForgeChunkTransport {
    const val DEFAULT_CHUNK_SIZE_BYTES: Int = 8 * 1024 * 1024
    const val DEFAULT_THRESHOLD_BYTES: Long = 8L * 1024L * 1024L

    data class Chunk(
        val index: Int,
        val file: File,
        val sizeBytes: Long,
        val sha256: String,
    )

    data class Plan(
        val originalName: String,
        val totalSizeBytes: Long,
        val wholeSha256: String,
        val chunkSizeBytes: Int,
        val chunks: List<Chunk>,
    )

    fun split(
        originalName: String,
        cacheDirectory: File,
        chunkSizeBytes: Int = DEFAULT_CHUNK_SIZE_BYTES,
        openInput: () -> InputStream,
    ): Plan {
        require(chunkSizeBytes in 1024..(32 * 1024 * 1024)) { "Chunk size is outside the supported Forge range." }
        cacheDirectory.mkdirs()
        cacheDirectory.listFiles()?.forEach { it.deleteRecursively() }

        val wholeDigest = MessageDigest.getInstance("SHA-256")
        val chunks = mutableListOf<Chunk>()
        var totalSize = 0L
        var index = 1

        openInput().use { input ->
            val buffer = ByteArray(256 * 1024)
            while (true) {
                val chunkFile = File(cacheDirectory, "%s.part%04d".format(originalName, index))
                val chunkDigest = MessageDigest.getInstance("SHA-256")
                var chunkBytes = 0L

                FileOutputStream(chunkFile).use { output ->
                    while (chunkBytes < chunkSizeBytes) {
                        val maxRead = minOf(buffer.size.toLong(), chunkSizeBytes.toLong() - chunkBytes).toInt()
                        val count = input.read(buffer, 0, maxRead)
                        if (count < 0) break
                        if (count == 0) continue
                        output.write(buffer, 0, count)
                        wholeDigest.update(buffer, 0, count)
                        chunkDigest.update(buffer, 0, count)
                        chunkBytes += count
                        totalSize += count
                    }
                }

                if (chunkBytes == 0L) {
                    chunkFile.delete()
                    break
                }

                chunks += Chunk(
                    index = index,
                    file = chunkFile,
                    sizeBytes = chunkBytes,
                    sha256 = chunkDigest.digest().toHex(),
                )
                index += 1
            }
        }

        require(chunks.isNotEmpty()) { "Source archive is empty." }
        return Plan(
            originalName = originalName,
            totalSizeBytes = totalSize,
            wholeSha256 = wholeDigest.digest().toHex(),
            chunkSizeBytes = chunkSizeBytes,
            chunks = chunks,
        )
    }

    fun reconstruct(plan: Plan, output: File): String {
        output.parentFile?.mkdirs()
        val digest = MessageDigest.getInstance("SHA-256")
        FileOutputStream(output).use { target ->
            plan.chunks.sortedBy { it.index }.forEach { chunk ->
                val chunkDigest = MessageDigest.getInstance("SHA-256")
                chunk.file.inputStream().use { input ->
                    val buffer = ByteArray(256 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (count == 0) continue
                        target.write(buffer, 0, count)
                        digest.update(buffer, 0, count)
                        chunkDigest.update(buffer, 0, count)
                    }
                }
                check(chunkDigest.digest().toHex() == chunk.sha256) { "Chunk ${chunk.index} changed after planning." }
            }
        }
        return digest.digest().toHex()
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }
}
