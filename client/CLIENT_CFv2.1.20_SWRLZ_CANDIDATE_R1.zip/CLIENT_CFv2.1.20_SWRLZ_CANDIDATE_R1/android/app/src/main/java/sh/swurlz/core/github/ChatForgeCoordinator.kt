package sh.swurlz.core.github

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.data.ChatRuntimeBus
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong

/**
 * Chat-facing orchestration facade for Forge. The Forge screen and chat both use the same
 * GitHubForgeClient primitives; chat never simulates taps on the Forge UI.
 */
object ChatForgeCoordinator {
    enum class Step {
        IDLE, NEEDS_GITHUB, ASK_SHA_PAIRING, NEEDS_FILES, READY_TO_UPLOAD,
        VALIDATING, UPLOADING, LOADING_WORKFLOWS, WATCHING_WORKFLOWS,
        ARTIFACTS_READY, DOWNLOADING, NEEDS_DOWNLOAD_DIRECTORY, COMPLETE, CANCELLED, FAILED
    }

    enum class PackageTarget { ASK, CLIENT, SERVER, BOTH, FILES }

    data class UiState(
        val step: Step = Step.IDLE,
        val title: String = "Forge idle",
        val detail: String = "",
        val progress: Int? = null,
        val useShaPairing: Boolean = true,
        val packageTarget: PackageTarget = PackageTarget.ASK,
        val expandGenericZipToRepositoryRoot: Boolean = false,
        val removeExpandedZipAfterUnpack: Boolean = false,
        val files: List<GitHubForgeClient.LocalFile> = emptyList(),
        val transactionId: String = "",
        val commitSha: String = "",
        val runs: List<GitHubForgeClient.WorkflowRun> = emptyList(),
        val artifacts: List<GitHubForgeClient.Artifact> = emptyList(),
        val pendingArtifact: GitHubForgeClient.Artifact? = null,
    )

    private val mutableState = MutableStateFlow(UiState())
    private val operationGeneration = AtomicLong(0L)
    val state: StateFlow<UiState> = mutableState.asStateFlow()

    private fun announce(message: String) {
        if (message.isNotBlank()) ChatRuntimeBus.post(message)
    }

    fun cancel() {
        operationGeneration.incrementAndGet()
        val current = mutableState.value
        mutableState.value = current.copy(
            step = Step.CANCELLED,
            title = "Forge cancelled",
            detail = "Stopped by user. No additional Forge steps will be started from this chat session.",
            progress = null,
        )
        announce("Forge stopped. I cancelled the active chat Forge flow and won’t start any additional steps from it.")
    }

    fun begin(context: Context, target: PackageTarget = PackageTarget.ASK) {
        operationGeneration.incrementAndGet()
        val token = SecretStore.githubToken(context)
        mutableState.value = if (token.isBlank()) {
            UiState(step = Step.NEEDS_GITHUB, title = "Forge needs GitHub", detail = "Enter a fine-grained token securely to continue.", packageTarget = target)
        } else {
            UiState(step = Step.ASK_SHA_PAIRING, title = "Forge connected", detail = "Auto-attach and validate SHA-256/manifest evidence for CLIENT/SERVER source ZIPs when available? The ZIP itself remains the required build input.", packageTarget = target)
        }
    }

    fun beginBootstrap(context: Context, removeZipAfterExpansion: Boolean = false) {
        operationGeneration.incrementAndGet()
        val token = SecretStore.githubToken(context)
        mutableState.value = if (token.isBlank()) {
            UiState(
                step = Step.NEEDS_GITHUB,
                title = "Bootstrap Forge needs GitHub",
                detail = "Connect GitHub, then select the bootstrap ZIP. Forge will expand it into repository root.",
                useShaPairing = false,
                expandGenericZipToRepositoryRoot = true,
                removeExpandedZipAfterUnpack = removeZipAfterExpansion,
            )
        } else {
            UiState(
                step = Step.NEEDS_FILES,
                title = "Select bootstrap ZIP",
                detail = if (removeZipAfterExpansion) {
                    "Repository-root expansion is armed and the outer ZIP will not remain in the final tree."
                } else {
                    "Repository-root expansion is armed. The outer ZIP will be retained at repository root unless you toggle removal."
                },
                useShaPairing = false,
                expandGenericZipToRepositoryRoot = true,
                removeExpandedZipAfterUnpack = removeZipAfterExpansion,
            )
        }
    }

    fun setArchiveExpansion(expand: Boolean, removeZipAfterExpansion: Boolean) {
        mutableState.value = mutableState.value.copy(
            expandGenericZipToRepositoryRoot = expand,
            removeExpandedZipAfterUnpack = expand && removeZipAfterExpansion,
            detail = when {
                !expand -> "ZIP expansion is off. Generic ZIPs use the configured fallback destination."
                removeZipAfterExpansion -> "Repository-root ZIP expansion armed; outer ZIP will not remain in the final tree."
                else -> "Repository-root ZIP expansion armed; outer ZIP will be retained at repository root."
            },
        )
    }

    suspend fun saveAndValidateToken(context: Context, rawToken: String): Result<String> = runCatching {
        val profile = GitHubConnectionStore.profile(context)
        val token = GitHubForgeClient.normalizeToken(rawToken)
        require(token.isNotBlank()) { "Token is empty." }
        val pending = mutableState.value
        mutableState.value = pending.copy(step = Step.VALIDATING, title = "Checking GitHub", detail = "Validating Forge access…", progress = null)
        val account = GitHubForgeClient.validateForgeCredential(profile.owner, profile.repository, profile.branch, token)
        GitHubConnectionStore.saveAuthorizedConnection(
            context = context,
            token = token,
            connectedLogin = account.login,
            oauthClientId = profile.oauthClientId,
            owner = profile.owner,
            repository = profile.repository,
            branch = profile.branch,
        )
        mutableState.value = if (pending.expandGenericZipToRepositoryRoot) {
            pending.copy(
                step = Step.NEEDS_FILES,
                title = "GitHub connected · select bootstrap ZIP",
                detail = "Connected as ${account.login}. Repository-root ZIP expansion is armed.",
                progress = null,
            )
        } else {
            pending.copy(
                step = Step.ASK_SHA_PAIRING,
                title = "GitHub connected",
                detail = "Connected as ${account.login}. Auto-attach SHA-256/manifest evidence for CLIENT/SERVER ZIPs when available?",
                progress = null,
            )
        }
        account.login
    }.onFailure { error ->
        mutableState.value = mutableState.value.copy(step = Step.NEEDS_GITHUB, title = "GitHub connection failed", detail = error.message ?: "Credential validation failed.", progress = null)
    }

    fun chooseShaPairing(enabled: Boolean) {
        mutableState.value = mutableState.value.copy(
            step = Step.NEEDS_FILES,
            title = if (enabled) "Select protected package" else "Select files",
            detail = if (enabled) "Choose CLIENT, SERVER, BOTH, or FILES. Protected source ZIPs automatically resolve checksum and manifest companions when available." else "Choose files. Only recognized CLIENT/SERVER source ZIPs receive source-structure validation.",
            useShaPairing = enabled,
            files = emptyList(),
        )
    }

    fun choosePackageTarget(target: PackageTarget) {
        mutableState.value = mutableState.value.copy(
            packageTarget = target,
            step = Step.NEEDS_FILES,
            title = when (target) {
                PackageTarget.CLIENT -> "Select CLIENT source ZIP"
                PackageTarget.SERVER -> "Select SERVER source ZIP"
                PackageTarget.BOTH -> "Select CLIENT + SERVER source ZIPs"
                PackageTarget.FILES -> "Select files"
                PackageTarget.ASK -> "Choose Forge package target"
            },
            detail = when (target) {
                PackageTarget.CLIENT -> "Select the CLIENT ZIP; Forge will try to attach optional checksum and manifest evidence automatically."
                PackageTarget.SERVER -> "Select the SERVER ZIP; Forge will try to attach optional checksum and manifest evidence automatically."
                PackageTarget.BOTH -> "Select both source ZIPs together; each keeps an independent source identity and any available evidence companions."
                PackageTarget.FILES -> "Select ordinary files without forcing a CLIENT/SERVER package target."
                PackageTarget.ASK -> "Choose which package lane you want to stage."
            },
            files = emptyList(),
        )
    }

    fun stageFiles(context: Context, uris: List<Uri>) {
        val selected = uris.mapNotNull { uri -> runCatching { GitHubForgeClient.describe(context, uri) }.getOrNull() }
        val current = mutableState.value
        val prefs = context.getSharedPreferences("swrlz_forge_preferences", Context.MODE_PRIVATE)
        val autoChecksum = prefs.getBoolean("auto_match_source_checksum", true)
        val autoManifest = prefs.getBoolean("auto_match_source_manifest", true)
        val comboSourceOneTransaction = prefs.getBoolean("combo_source_one_transaction", true)
        val explicitNames = selected.map { GitHubForgeClient.logicalSourceKey(it.displayName) }.toSet()
        val files = buildList {
            addAll(selected)
            selected.filter { GitHubForgeClient.isProtectedSourceZip(it.displayName) }.forEach { zip ->
                val checksumKey = GitHubForgeClient.checksumNameForZip(zip.displayName).lowercase()
                if (autoChecksum && checksumKey !in explicitNames && none { GitHubForgeClient.logicalSourceKey(it.displayName) == checksumKey }) {
                    runCatching { GitHubForgeClient.findMatchingChecksumBesideDocument(context, zip) ?: GitHubForgeClient.generateChecksumReceipt(context, zip) }
                        .getOrNull()?.let(::add)
                }
                val manifestKey = GitHubForgeClient.manifestNameForZip(zip.displayName).lowercase()
                if (autoManifest && manifestKey !in explicitNames && none { GitHubForgeClient.logicalSourceKey(it.displayName) == manifestKey }) {
                    runCatching { GitHubForgeClient.findMatchingManifestBesideDocument(context, zip) }.getOrNull()?.let(::add)
                }
            }
        }.distinctBy { GitHubForgeClient.logicalSourceKey(it.displayName) }

        val clientZip = files.any { GitHubForgeClient.isProtectedSourceZip(it.displayName) && GitHubForgeClient.canonicalSourceFileName(it.displayName).startsWith("CLIENT_", true) }
        val serverZip = files.any { GitHubForgeClient.isProtectedSourceZip(it.displayName) && GitHubForgeClient.canonicalSourceFileName(it.displayName).startsWith("SERVER_", true) }
        val targetSatisfied = when (current.packageTarget) {
            PackageTarget.CLIENT -> clientZip
            PackageTarget.SERVER -> serverZip
            PackageTarget.BOTH -> comboSourceOneTransaction && clientZip && serverZip
            else -> files.isNotEmpty()
        }
        val bootstrapDetected = files.any { file ->
            file.displayName.endsWith(".zip", ignoreCase = true) &&
                file.displayName.contains("bootstrap", ignoreCase = true) &&
                !GitHubForgeClient.isProtectedSourceZip(file.displayName)
        }
        val expand = current.expandGenericZipToRepositoryRoot || bootstrapDetected
        val protectedZips = files.filter { GitHubForgeClient.isProtectedSourceZip(it.displayName) }
        val completeUnits = protectedZips.count { zip ->
            val shaKey = GitHubForgeClient.checksumNameForZip(zip.displayName).lowercase()
            val manifestKey = GitHubForgeClient.manifestNameForZip(zip.displayName).lowercase()
            files.any { GitHubForgeClient.logicalSourceKey(it.displayName) == shaKey } &&
                files.any { GitHubForgeClient.logicalSourceKey(it.displayName) == manifestKey }
        }
        mutableState.value = current.copy(
            step = if (files.isEmpty() || !targetSatisfied) Step.NEEDS_FILES else Step.READY_TO_UPLOAD,
            title = when {
                files.isEmpty() -> "No files selected"
                !targetSatisfied -> "Package target incomplete"
                expand -> "Bootstrap expansion ready"
                current.packageTarget == PackageTarget.BOTH -> "CLIENT + SERVER package transaction ready"
                else -> "Forge upload ready"
            },
            detail = when {
                files.isEmpty() -> "Select files to continue."
                !comboSourceOneTransaction && current.packageTarget == PackageTarget.BOTH -> "CLIENT + SERVER combo transactions are disabled in Forge settings."
                !targetSatisfied && current.packageTarget == PackageTarget.BOTH -> "Select both a CLIENT source ZIP and a SERVER source ZIP. Optional evidence companions will be resolved independently."
                !targetSatisfied -> "The selected files do not contain the requested ${current.packageTarget.name} source ZIP."
                expand && current.removeExpandedZipAfterUnpack -> "${files.size} file(s) staged. Generic ZIP contents will land at repository root; outer ZIP removal is armed."
                expand -> "${files.size} file(s) staged. Generic ZIP contents will land at repository root; outer ZIP retention is armed."
                protectedZips.isNotEmpty() -> "${protectedZips.size} build-eligible source ZIP(s) staged · $completeUnits with complete SHA/manifest evidence. Review before Forge upload."
                else -> "${files.size} file(s) staged. Start Forge upload?"
            },
            files = files,
            useShaPairing = if (expand) false else current.useShaPairing,
            expandGenericZipToRepositoryRoot = expand,
            progress = null,
        )
    }

    suspend fun upload(context: Context): Result<Unit> = runCatching {
        val generation = operationGeneration.incrementAndGet()
        val current = mutableState.value
        require(current.files.isNotEmpty()) { "No files are staged." }
        val profile = GitHubConnectionStore.profile(context)
        val token = SecretStore.githubToken(context)
        val prefs = context.getSharedPreferences("swrlz_forge_preferences", Context.MODE_PRIVATE)
        val transportMode = runCatching {
            GitHubForgeClient.SourceTransportMode.valueOf(
                prefs.getString("source_transport_mode", "AUTO").orEmpty().ifBlank { "AUTO" }
            )
        }.getOrDefault(GitHubForgeClient.SourceTransportMode.AUTO)
        require(token.isNotBlank()) { "GitHub is not connected." }
        val logId = ForgeUploadLogStore.startSession(context, "chat forge transaction")
        ForgeUploadLogStore.append(context, logId, "CHAT_PREFLIGHT", "Starting chat Forge preflight")

        mutableState.value = current.copy(step = Step.VALIDATING, title = "Checking source packages", detail = "Validating before upload…", progress = null)
        val evidence = GitHubForgeClient.validateSourcePairs(context, current.files)
        require(evidence.valid) { evidence.message }
        if (!current.useShaPairing) {
            current.files.filter { GitHubForgeClient.isProtectedSourceZip(it.displayName) }.forEach { zip ->
                val guard = GitHubForgeClient.inspectSourceZip(context, zip)
                require(guard.valid) { guard.message }
            }
        }

        val transaction = UUID.randomUUID().toString()
        ForgeRuntimeState.beginTransaction(transaction)
        mutableState.value = current.copy(step = Step.UPLOADING, title = "Uploading through Forge", detail = "Preparing GitHub transaction…", progress = 1, transactionId = transaction)

        val result = try {
            GitHubForgeClient.upload(
                context,
                GitHubForgeClient.UploadRequest(
                    owner = profile.owner,
                    repository = profile.repository,
                    branch = profile.branch,
                    destinationDirectory = profile.genericUploadDirectory,
                    commitMessage = if (current.expandGenericZipToRepositoryRoot) "Expand repository bootstrap through SWRLZ Chat Forge" else "Upload files through SWRLZ Chat Forge",
                    token = token,
                    files = current.files,
                    dispatchWorkflow = false,
                    autoRouteSourcePackages = true,
                    clientSourceDirectory = profile.clientSourceDirectory,
                    serverSourceDirectory = profile.serverSourceDirectory,
                    expandGenericZipToRepositoryRoot = current.expandGenericZipToRepositoryRoot,
                    removeExpandedZipAfterUnpack = current.removeExpandedZipAfterUnpack,
                    archiveExpansionRoot = "",
                    transactionId = transaction,
                    forgeActor = "CLIENT_CHAT",
                    logSessionId = logId,
                    sourceTransportMode = transportMode,
                    onProgress = { percent, status ->
                        if (operationGeneration.get() == generation) {
                            mutableState.value = mutableState.value.copy(step = Step.UPLOADING, title = "Uploading through Forge", detail = status, progress = percent)
                        }
                    },
                ),
            )
        } catch (failure: Throwable) {
            ForgeUploadLogStore.appendFailure(context, logId, "CHAT_UPLOAD_FAILURE", failure)
            ForgeUploadLogStore.finish(context, logId, "FAILED · chat Forge upload")
            throw failure
        } finally {
            ForgeRuntimeState.endTransaction(transaction)
        }

        if (operationGeneration.get() != generation) return@runCatching
        ForgeBuildWatchStore.add(
            context,
            ForgeBuildWatch(profile.owner, profile.repository, profile.branch, result.commitSha, result.transactionId, System.currentTimeMillis()),
        )
        ForgeUploadLogStore.finish(context, logId, "SUCCESS · commit ${result.commitSha}")
        mutableState.value = mutableState.value.copy(step = Step.LOADING_WORKFLOWS, title = "Upload finished", detail = "Loading Forge workflow actions…", progress = null, commitSha = result.commitSha)
        announce(
            if (current.expandGenericZipToRepositoryRoot) {
                "Bootstrap officially Swurlzed! ✅🐉 Repository-root expansion is confirmed at commit ${result.commitSha.take(12)}. I’m checking for workflows tied to this commit now."
            } else {
                "Upload from Forge officially Swurlzed! ✅🐉 Commit ${result.commitSha.take(12)} is confirmed. I’m checking for workflows tied to this upload now."
            }
        )

        var matched = emptyList<GitHubForgeClient.WorkflowRun>()
        repeat(12) { attempt ->
            if (attempt > 0) delay(2_000)
            val all = GitHubForgeClient.listWorkflowRuns(profile.owner, profile.repository, profile.branch, token)
            matched = all.filter { it.headSha.equals(result.commitSha, ignoreCase = true) }
            if (matched.isNotEmpty()) return@repeat
        }
        mutableState.value = mutableState.value.copy(
            step = if (matched.isEmpty()) Step.WATCHING_WORKFLOWS else Step.WATCHING_WORKFLOWS,
            title = if (matched.isEmpty()) "Forge is watching" else "Forge workflows",
            detail = if (matched.isEmpty()) "GitHub has not exposed a matching workflow yet; checking continues when refreshed." else "${matched.size} workflow run(s) tied to this upload.",
            runs = emptyList(),
        )
        refresh(context)
    }.onFailure { error ->
        if (mutableState.value.step != Step.CANCELLED) {
            val activeLog = ForgeUploadLogStore.currentSessionId(context)
            if (activeLog.isNotBlank()) {
                ForgeUploadLogStore.appendFailure(context, activeLog, "CHAT_FORGE_FAILURE", error)
                ForgeUploadLogStore.finish(context, activeLog, "FAILED · chat Forge operation")
            }
            val analysis = ForgeFailureAnalyzer.analyzeUpload(ForgeUploadLogStore.latestBytes(context), error)
            mutableState.value = mutableState.value.copy(step = Step.FAILED, title = "Forge upload failed", detail = analysis, progress = null)
            announce("Forge upload failed. I analyzed the upload log:\n\n$analysis")
        }
    }

    suspend fun refresh(context: Context) {
        val current = mutableState.value
        if (current.commitSha.isBlank()) return
        val profile = GitHubConnectionStore.profile(context)
        val token = SecretStore.githubToken(context)
        if (token.isBlank()) return
        val previousById = current.runs.associateBy { it.id }
        val runs = GitHubForgeClient.listWorkflowRuns(profile.owner, profile.repository, profile.branch, token)
            .filter { it.headSha.equals(current.commitSha, ignoreCase = true) }

        for (run in runs) {
            val previous = previousById[run.id]
            if (run.status != "completed" && (previous == null || previous.status == "completed")) {
                announce("Workflow started: ${run.name} ⚙️ I’m watching it for completion and will report back here.")
            } else if (run.status == "completed" && previous?.status != "completed") {
                if (run.conclusion == "success") {
                    announce("Workflow succeeded: ${run.name} ✅ I’m checking its artifacts now.")
                } else if (run.conclusion !in setOf("skipped", "neutral")) {
                    val analysis = runCatching {
                        val jobs = GitHubForgeClient.listWorkflowJobs(profile.owner, profile.repository, run.id, token)
                        val logs = GitHubForgeClient.downloadWorkflowLogs(profile.owner, profile.repository, run.id, token)
                        ForgeFailureAnalyzer.analyzeWorkflow(run, jobs, logs)
                    }.getOrElse { failure ->
                        "Verified: ${run.name} finished with ${run.conclusion ?: "failure"}. I could not retrieve the workflow log for deeper analysis (${failure.message ?: failure::class.java.simpleName})."
                    }
                    announce("Workflow failed: ${run.name}. I analyzed the workflow log:\n\n$analysis")
                }
            }
        }

        val active = runs.any { it.status != "completed" }
        val failedRuns = runs.filter { it.status == "completed" && it.conclusion !in setOf("success", "skipped", "neutral") }
        val successful = runs.filter { it.status == "completed" && it.conclusion == "success" }
        val artifacts = successful.flatMap { run -> runCatching { GitHubForgeClient.listArtifacts(profile.owner, profile.repository, run.id, token) }.getOrDefault(emptyList()) }
            .filterNot { it.expired }.distinctBy { it.id }
        mutableState.value = mutableState.value.copy(
            step = when {
                failedRuns.isNotEmpty() && !active -> Step.FAILED
                artifacts.isNotEmpty() -> Step.ARTIFACTS_READY
                active || runs.isNotEmpty() -> Step.WATCHING_WORKFLOWS
                else -> Step.LOADING_WORKFLOWS
            },
            title = when {
                artifacts.isNotEmpty() -> "Workflow artifacts ready"
                active -> "Forge workflows running"
                failedRuns.isNotEmpty() -> "Forge workflow failed"
                runs.isNotEmpty() -> "Forge workflows finished"
                else -> "Waiting for workflow"
            },
            detail = when {
                artifacts.isNotEmpty() -> "${artifacts.size} artifact(s) available. Download?"
                active -> "${runs.count { it.status != "completed" }} active · ${runs.count { it.status == "completed" }} completed"
                failedRuns.isNotEmpty() -> "${failedRuns.size} workflow(s) tied to this upload failed. See SWRLZ chat analysis above."
                runs.isNotEmpty() -> "${runs.size} workflow(s) finished."
                else -> "Checking GitHub for work tied to ${current.commitSha.take(12)}."
            },
            runs = runs,
            artifacts = artifacts,
            progress = null,
        )
    }

    fun requestDownload(artifact: GitHubForgeClient.Artifact) {
        mutableState.value = mutableState.value.copy(step = Step.DOWNLOADING, title = "Downloading artifact", detail = artifact.name, pendingArtifact = artifact, progress = null)
    }

    suspend fun downloadPending(context: Context): Result<Pair<String, ByteArray>> = runCatching {
        val artifact = mutableState.value.pendingArtifact ?: error("No artifact selected.")
        val profile = GitHubConnectionStore.profile(context)
        val token = SecretStore.githubToken(context)
        mutableState.value = mutableState.value.copy(step = Step.DOWNLOADING, title = "Downloading artifact", detail = artifact.name)
        val bytes = GitHubForgeClient.downloadArtifact(profile.owner, profile.repository, artifact.id, token)
        artifact.name to bytes
    }.onFailure { error ->
        mutableState.value = mutableState.value.copy(step = Step.FAILED, title = "Artifact download failed", detail = error.message ?: "Download failed.")
    }

    fun markNeedsDirectory(name: String) {
        mutableState.value = mutableState.value.copy(step = Step.NEEDS_DOWNLOAD_DIRECTORY, title = "Choose artifact folder", detail = "Set a default Forge download folder for $name.")
    }

    fun markDownloaded(name: String) {
        mutableState.value = mutableState.value.copy(step = Step.COMPLETE, title = "Forge finished", detail = "$name downloaded successfully.", progress = 100)
    }

    fun dismiss() { mutableState.value = UiState() }
}
