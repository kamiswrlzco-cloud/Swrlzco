package sh.swurlz.core.net

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom

/** App-private proof material used to bind this CLIENT installation to its SERVER actor. */
internal object ClientNodeProofStore {
    private const val PREFS = "swrlz_client_node_proof"
    private const val KEY_DEVICE_PROOF = "deviceProof"

    @Synchronized
    fun deviceProof(context: Context): String {
        val appContext = context.applicationContext
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        val prefs = EncryptedSharedPreferences.create(
            appContext,
            PREFS,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
        return prefs.getString(KEY_DEVICE_PROOF, null)
            ?: ByteArray(32).also(SecureRandom()::nextBytes).joinToString("") { "%02x".format(it) }
                .also { prefs.edit().putString(KEY_DEVICE_PROOF, it).commit() }
    }
}
