# SWRLZ-Core 2.7.1 Phone Test Checklist

## Identity

- [ ] App shows `0.2.7.1-relay-radar`.
- [ ] Patch shows `2.7.1-RELAY-RADAR`.
- [ ] Roadmap shows `2.7.1`.

## Radar flow

- [ ] Start server 0.7.1.
- [ ] Set Local Core Node URL.
- [ ] Open `Radar` tab.
- [ ] Tap `REFRESH RADAR`.
- [ ] Confirm server card is readable and not cluttered.
- [ ] Confirm groups list appears when authorized.
- [ ] Confirm device cards show online/offline/idle color.
- [ ] Tap a device card and confirm target updates.

## Setup flow

- [ ] Open `Manual setup / raw IDs`.
- [ ] Save group/device fields.
- [ ] Create group.
- [ ] Join/register device.
- [ ] Check in this device.
- [ ] Refresh Radar and confirm the device appears.

## Packet flow

- [ ] Send PING to self.
- [ ] Pull offline queue.
- [ ] Handle packet card: DISPLAY → ACK → COMPLETE.
- [ ] Send SHOW_MESSAGE to another/offline device.
- [ ] Reconnect target device and confirm queued card appears.

## Debug/admin

- [ ] Raw debug output is hidden until toggled.
- [ ] Admin controls are hidden until toggled.
- [ ] Admin mode persists ON/OFF according to last saved state.
