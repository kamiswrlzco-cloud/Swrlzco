# CLIENT CFv2.0.69 — Chat + Mission Runtime Cohesion

**Recorded:** 2026-07-25  
**Baseline:** CLIENT CFv2.0.68  
**Status:** Source/static implementation complete; GitHub Android build and device acceptance pending.

## Purpose
This pass turns Council Chat into a grounded control surface for SWRLZ rather than a direct LLM front end. Chat, quick actions, Forge, provider state, and missions remain distinct execution classes while sharing one user-facing conversation.

## Implemented

### 1. Grounded system-state queries
Questions about Gemini, GitHub Forge credentials, and accessibility now read actual runtime state rather than allowing the conversational fallback to invent configuration status.

### 2. Context-aware mission handoff
Council Chat preserves the last actionable question as a mission candidate. A follow-up such as “make a mission that does that” resolves to the prior concrete objective instead of sending an ambiguous phrase to the mission runner.

Device-model lookup now explains the normal Settings route first, then offers SWRLZ mission execution to verify the value on-screen.

### 3. Gemini mission planner fallback
When the legacy Online Mentor backend is not configured but a Gemini API key is present, MissionRunnerService can use Gemini privately to produce the canonical SWRLZ `PlanResponse` / `Action` contract. SWRLZ remains the executor through Accessibility; Gemini is only a planner.

The Mission Hub therefore no longer reports Online Mentor unavailable merely because the backend URL is absent when Gemini is available.

### 4. Mission completion return-to-chat
Mission completion posts the verified rationale/result back through ChatRuntimeBus and relaunches the CLIENT foreground so the user returns to SWRLZ Chat with the gathered result.

### 5. Forge lifecycle narration
Forge state transitions now emit meaningful chat milestones while the existing inline Forge card continues to carry high-frequency progress. This avoids progress-message spam while preserving a readable transcript.

### 6. Forge cancellation
Natural-language `stop forge` / `cancel forge` / `abort forge` intent maps to a first-class CANCELLED state. Active Forge cards also expose a STOP FORGE control. A generation guard prevents a cancelled in-flight upload callback from advancing the chat session into later workflow stages.

### 7. Companion rail foundation
Council Chat now includes a small animated dragon companion/status rail above the composer. Busy state is driven by mission/Forge runtime state. The dragon tint is derived as an inverse/complementary color from the active UI primary accent so the companion visually contrasts with the current theme.

## Package identity

```text
versionCode: 95
versionName: 2.0.69-chat-mission-runtime-v1
```

## Static verification
- Modified Kotlin files have balanced braces and parentheses.
- Source archive layout preserved.
- Gradle compilation was not run in this environment because the supplied source package does not contain a Gradle wrapper executable at its package root.
- GitHub Android compilation remains the authoritative build gate.

## Device acceptance
1. Save a Gemini key and verify “is Gemini configured?” reports live state.
2. Ask SWRLZ to open Settings; verify quick action still launches Settings without creating a mission.
3. Ask how to find the phone model in Settings; verify SWRLZ explains the route and offers mission execution.
4. Reply “make a mission that does that”; verify the concrete prior objective is used.
5. Verify Mission Hub plans with Gemini rather than showing Online Mentor unavailable.
6. Verify SWRLZ navigates, observes the model value, completes, returns to CLIENT, and posts the gathered result into Chat.
7. Start Forge from Chat and verify milestone messages appear as Forge state changes.
8. Say “stop forge” at file selection, upload, and workflow-observation stages; verify the session becomes CANCELLED and no later chat-stage transition occurs.
9. Verify the companion rail animates during work and uses a contrasting palette relative to the selected theme.
