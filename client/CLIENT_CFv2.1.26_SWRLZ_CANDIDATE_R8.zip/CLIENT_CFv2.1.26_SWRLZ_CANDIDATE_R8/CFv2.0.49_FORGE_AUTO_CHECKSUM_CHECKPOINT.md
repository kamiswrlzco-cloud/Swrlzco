# CLIENT CFv2.0.49 — Forge Auto Checksum Checkpoint

## Vision Note

Forge now treats a source ZIP and its SHA-256 file as one logical source package. The default workflow is: grant a source-package folder once, select only the ZIP, and let Forge locate and verify the exact sibling checksum.

## Implemented

- Added **Auto-match ZIP + SHA-256**, enabled by default.
- Added persistent Storage Access Framework source-folder selection.
- Persisted the granted tree URI and the toggle preference.
- Selecting a ZIP searches the approved folder for the exact `<base>.sha256` sibling.
- Automatically matched checksum files are merged into existing staging without replacing prior files.
- Matching is exact and does not guess similar names.
- Existing manual multi-file selection remains supported when the toggle is disabled.
- Local integrity validation applies to any staged ZIP/checksum pair, while CLIENT and SERVER routing behavior remains unchanged.
- Missing folder access and missing checksum matches are reported truthfully.

## Security and Correctness

- Directory access is user-granted and persisted through Android's Storage Access Framework.
- The feature never claims a checksum is selected when the document cannot be resolved.
- Commit remains blocked until every ZIP has a readable, valid, matching SHA-256 file.
- Persisted UI preferences do not bypass integrity validation.

## Migration

No database migration is required. Existing Forge users will see auto-matching enabled by default and can connect a source folder from the Forge screen.
