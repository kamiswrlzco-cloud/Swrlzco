# CLIENT CFv2.0.70 — Forge Chat Diagnostics and Closure

**Recorded:** 2026-07-25  
**Baseline:** CLIENT CFv2.0.69  
**Status:** Source/static implementation complete; GitHub Android build and device acceptance pending.

## Purpose
This pass closes the conversational loop around Forge. Forge remains the authoritative build/upload subsystem; Council Chat becomes the human-readable operational surface for meaningful upload and workflow lifecycle events, including evidence-grounded failure analysis.

## Implemented

### 1. Upload success announcement
After GitHub confirms the commit, SWRLZ posts a durable chat milestone:

`Upload from Forge officially Swurlzed! ✅🐉`

The message includes the confirmed commit prefix and immediately states that SWRLZ is checking for workflows tied to that upload.

### 2. Upload failure analysis
Chat Forge now opens an upload diagnostic session before source preflight. Validation, upload, repository, authentication, and related failures therefore have a transaction-local diagnostic record rather than falling back to a prior session.

On failure SWRLZ:
- records the exception into the current redacted upload log;
- closes the diagnostic session as failed;
- extracts verified error evidence from the upload log;
- classifies a likely cause only when the evidence supports one;
- returns a recommended next step in Council Chat.

### 3. Workflow start announcements
Workflow polling remains scoped to the commit SHA produced by the Forge upload. When a matching run first appears queued or in progress, SWRLZ posts `Workflow started` with the workflow name and keeps monitoring it.

### 4. Workflow success announcements
When a tracked run transitions to completed/success, SWRLZ posts `Workflow succeeded` and continues into artifact discovery.

### 5. Workflow failure log analysis
When a tracked run transitions to a failing conclusion, SWRLZ retrieves:
- workflow jobs and failed steps;
- the GitHub workflow log archive;
- verified error lines from the archive.

`ForgeFailureAnalyzer` separates:
- **Verified evidence** from GitHub/job/log data;
- **Likely cause** inferred from that evidence;
- **Recommended next step**.

Initial deterministic classifications cover Kotlin compilation, Gradle build failure, SHA mismatch, authentication, permission/policy rejection, missing resources, and network/timeout failure. Unsupported cases remain explicitly unclassified rather than inventing a cause.

### 6. ChatRuntimeBus integration
Forge operational announcements publish through the existing `ChatRuntimeBus`, which is already collected by Council Chat. This avoids a second transcript state and prevents rapid independent workflow transitions from being lost through a conflated UI-state field.

### 7. Existing Forge presentation preserved
High-frequency upload percentages and run status remain in the inline Forge card. Chat receives meaningful milestones and diagnoses, not progress-spam. Full Forge and bubble Forge remain presentation surfaces over the same authority.

## Architecture alignment
This update extends the accepted Forge event-routing model: source/upload/workflow authority remains in Forge/GitHub primitives, while Chat is an event consumer and operator surface. It does not simulate taps on the Forge screen and does not create a second upload implementation.

## Package identity

```text
versionCode: 96
versionName: 2.0.70-forge-chat-diagnostics-v1
```

## Verification performed
- Source ZIP baseline extracted successfully.
- Modified Kotlin sources preserve balanced braces and parentheses under static structural checks.
- Forge upload log analysis operates only on the current redacted diagnostic session.
- Workflow analysis consumes jobs + workflow log ZIP bytes through the existing GitHubForgeClient APIs.
- Gradle compilation attempted through `android/gradlew`; wrapper distribution retrieval was blocked because this execution environment has no outbound access to `services.gradle.org`.
- GitHub Android compilation remains the authoritative build gate.

## Device acceptance
1. Start a valid Chat Forge upload and confirm `Upload from Forge officially Swurlzed!` appears only after commit confirmation.
2. Confirm a matching queued/in-progress GitHub run produces a `Workflow started` chat milestone.
3. Confirm a successful run produces `Workflow succeeded` and artifact discovery continues.
4. Force a source/credential/upload failure and confirm SWRLZ posts verified upload-log evidence, likely-cause classification, and next-step guidance.
5. Force a GitHub workflow compilation failure and confirm SWRLZ retrieves jobs/logs and reports the failed job/step plus evidence-grounded analysis.
6. Confirm repeated workflow polling does not repeat announcements for a run whose state has not changed.
7. Confirm inline Forge progress remains live while Council Chat records only meaningful lifecycle milestones.
8. Confirm natural-language `stop forge` still cancels the chat Forge flow without later stale callbacks advancing it.
