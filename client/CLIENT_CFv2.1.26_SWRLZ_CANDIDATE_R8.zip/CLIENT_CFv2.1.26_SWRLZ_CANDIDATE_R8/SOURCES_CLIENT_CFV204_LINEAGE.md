# CLIENT CFv2.0.4 Lineage

- Baseline: CLIENT_CFv2.0.3_SWRLZ.zip
- Baseline SHA-256: d54c96590c1c65b4c89433f4cba8b90d9c04649376b6fdc74bf3c9a2db9fe3ae
- Checkpoint: INT-UI-013A
- Android identity: versionCode 35 / versionName 0.2.7.9-cfv2.0.4-int-ui-013a
- Build: NOT RUN
- Integration law: Integrate, do not overwrite.
