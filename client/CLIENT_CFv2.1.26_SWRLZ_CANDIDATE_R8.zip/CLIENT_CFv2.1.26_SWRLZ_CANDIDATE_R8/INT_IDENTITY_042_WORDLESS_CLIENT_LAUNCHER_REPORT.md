# INT-IDENTITY-042 — Wordless SWRLZ Client Launcher Identity

## Scope

Corrects the Android launcher identity so the default CLIENT launcher and the enabled GlitchDragon launcher alias use the wordless cyan/blue crystal-dragon artwork rather than a named or stale icon.

## Locked identity mapping

- SWRLZ CLIENT: cyan/blue wordless crystal dragon
- SWURLZER SERVER: purple crystal guardian
- SWURVER ADMIN: cyan/purple fusion identity inside the authenticated bubble surface

## Resource changes

- Added `swrlz_client_launcher_wordless.png`.
- Added adaptive foreground `swrlz_client_launcher_wordless_foreground.png`.
- Replaced default `ic_launcher` density resources.
- Replaced the enabled `ic_launcher_glitch_dragon` density resources.
- Updated default and GlitchDragon adaptive-icon XML to the wordless foreground.
- Preserved launcher theme aliases while correcting the default CLIENT identity.

## Version

- versionCode: 70
- versionName: `2.0.42-wordless-client-launcher`
