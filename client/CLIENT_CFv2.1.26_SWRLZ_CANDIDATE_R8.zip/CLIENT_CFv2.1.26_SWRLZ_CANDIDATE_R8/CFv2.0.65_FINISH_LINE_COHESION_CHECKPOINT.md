# CLIENT CFv2.0.65 — Finish-Line Cohesion

**Status:** Source/static verification complete; GitHub build and device acceptance pending.

## Scope

This patch connects the final Forge and bubble surfaces without changing the established authority model.

- Accepts Android download-copy suffixes such as ` (1)`, ` (2)`, or ` (37)` before `.zip`, `.sha256`, or `.manifest.json`.
- Source validity remains content-based. A local copy suffix never makes a valid Android source tree invalid.
- Canonical repository routing removes the copy suffix, so `CLIENT_CFv2.0.65_SWRLZ (2).zip` uploads as `SOURCES/CLIENT/CLIENT_CFv2.0.65_SWRLZ.zip`.
- ZIP/SHA pairing accepts either the locally suffixed checksum or the canonical exact-basename checksum.
- Adds a first-class **FORGE** destination to the CLIENT bubble and embeds the same Forge composable used by the full application.
- Adds an app-process credential revision bus so the full CLIENT and CLIENT bubble observe one Keystore-backed GitHub credential state immediately.
- Preserves credential preflight, refresh/retry, repeated uploads, commit notifications, generated checksum receipts, collapsible Forge panels, and Dragon Kamileon Theme Armor.

## Android identity

- versionCode: `92`
- versionName: `2.0.65-finish-line-cohesion-v1`

## Evidence

- Kotlin PSI syntax parsing passed across both prepared packages.
- XML and image-resource verification passed.
- Canonical duplicate-suffix pairing and repository destinations are source/static verified.
- Full-app/bubble credential propagation is source/static verified and pending device acceptance.
- GitHub compilation remains pending.

## Acceptance gate

1. Install CLIENT CFv2.0.65.
2. Connect GitHub in the full CLIENT, open the CLIENT bubble Forge, and confirm the same account is immediately available.
3. Select a source ZIP renamed with ` (1)` or another integer suffix and confirm it remains valid.
4. Confirm the staged repository destination uses the canonical unsuffixed name.
5. Confirm its real or generated checksum pairs automatically.
6. Open Forge directly from the CLIENT bubble menu and complete an upload/build observation cycle.
