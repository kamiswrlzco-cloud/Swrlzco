# CLIENT CFv2.0.62 — Manual Token Validation State Repair

**Status:** Source/static implementation and ZIP/SHA verification complete; GitHub APK build and device acceptance pending.

## Problem

The manual fine-grained token field reused the same Compose state as the active validated GitHub runtime token. As soon as the user typed the first character, `token.isNotBlank()` switched the UI into the connected/saved-authorization branch and `LaunchedEffect(token)` attempted validation against an incomplete token. This caused the token-entry surface to disappear or loop before the complete value could be submitted.

## Repair

- Added a separate `manualTokenInput` state for unverified text.
- Typing never changes the active runtime token.
- Automatic saved-token validation observes only the validated runtime token.
- `VALIDATE TOKEN` snapshots the trimmed complete candidate and calls GitHub `/user` once.
- The candidate is persisted to the Android Keystore-backed secret store only after GitHub accepts it.
- Validation failure leaves the candidate visible for correction and does not overwrite or arm the active session.
- Device-code authorization now validates and persists a local token snapshot before publishing connected state.
- Disconnect clears both validated and unverified token state after approval.

## Android identity

- versionCode: `89`
- versionName: `2.0.62-manual-token-validation-state-v1`

## Acceptance gate

1. Open the manual fine-grained token fallback.
2. Type a complete token and confirm the field remains visible while typing.
3. Press `VALIDATE TOKEN` once and verify a single validation attempt.
4. Confirm an invalid token remains editable and is not saved.
5. Confirm a valid token switches to Connected only after GitHub accepts it.
6. Restart, switch Theme Armor, and reopen Forge without another token prompt.
