# CLIENT CFv2.1.21 SWRLZ — Candidate R2

Checkpoint: `INT-CMD-039P-R2`

- versionCode: 119
- versionName: `2.1.21-command-palette-parent-child-cursor-follow-candidate-r2`
- status: SOURCE/STATIC VERIFIED CANDIDATE; Android compile/build evidence pending
- parent: CLIENT CFv2.1.21 CANDIDATE_R1
- parent checkpoint: `INT-CMD-039P`

Refines the Chat Command Center around the preferred `/parent (child) [instructions]` grammar. Command categories lead to clear action/subcommand choices, selection inserts the structured prefix (plus any deliberate preset) for editable Chat review, and the composer places the caret after inserted text. The Chat response-top follow target now reserves sufficient trailing layout space and verifies a zero-offset anchor so the selected SWRLZ response can land at the actual top of the conversation viewport.

No execution authority, filesystem capability, provider enablement, protocol, trust, Truth Firewall, Forge authority, release/deployment authority, or repository source authority is changed by this candidate.
