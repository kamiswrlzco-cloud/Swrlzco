# CLIENT CFv2.1.14 SWRLZ Source Receipt

Checkpoint: `INT-CHAT-FORGE-038C`

Android identity:
- versionCode: `112`
- versionName: `2.1.14-command-center-package-forge-v1`

This source successor extends CLIENT CFv2.1.13 with Command Center discovery and package-aware Forge automation. Exact ZIP SHA-256 is recorded by the external package sidecar generated at handoff.
