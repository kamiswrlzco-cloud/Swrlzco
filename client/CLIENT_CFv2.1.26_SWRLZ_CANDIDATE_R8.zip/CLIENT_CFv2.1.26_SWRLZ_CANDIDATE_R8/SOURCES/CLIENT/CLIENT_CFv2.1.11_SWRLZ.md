# CLIENT CFv2.1.11 SWRLZ

Checkpoint: `INT-CHAT-037A`
Parent: `CLIENT CFv2.1.10`
Version code: `109`
Version name: `2.1.11-chat-control-center-v1`

Adds the Chat Control Center, response-top auto-follow option/default, live-event focus preference, and persistent SWRLZ personality/response profile. Preserves protocol, authority, trust, Truth Firewall, permissions, missions, Forge authority, and offline-first behavior.

Build/device verification remains separately gated.
