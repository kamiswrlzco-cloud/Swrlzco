# CLIENT CFv2.1.18 SWRLZ Source Note

- Checkpoint: `INT-FIX-039G`
- versionCode: `116`
- versionName: `2.1.18-forge-rescue-profile-store-compile-repair-v1`
- Parent: CLIENT CFv2.1.17, SHA-256 `fb3f2b0323bfc2c315ab1b4d4c5d1d5963798aa19327cbc1db0a0013bddf120d`.
- Role: temporary default-theme Forge rescue successor with the confirmed profile-store compile blocker repaired.
- Full ThemePack art remains intentionally omitted from this transport edition and recoverable from CFv2.1.16 lineage.
- SERVER CFv2.1.7 was audited and required no equivalent repair.
- Source-only; build/device/GitHub promotion not claimed.
