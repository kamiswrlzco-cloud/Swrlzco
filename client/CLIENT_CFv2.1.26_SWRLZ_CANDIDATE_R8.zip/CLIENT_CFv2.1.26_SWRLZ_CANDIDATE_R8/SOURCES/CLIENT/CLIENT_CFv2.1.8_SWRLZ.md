# CLIENT CFv2.1.8 Source Identity

Checkpoint: `INT-THEME-035C`  
Source package: `CLIENT_CFv2.1.8_SWRLZ.zip`  
Android versionCode: `106`  
Android versionName: `2.1.8-theme-chrome-runtime-repair-v1`

Parent:

- `CLIENT_CFv2.1.7_SWRLZ.zip`
- SHA-256 `bc5b941e9b0c86e28581d8f6019b6c54722243279ef666aa3c35c4f97745fe76`

Scope:

- CLIENT presentation/theme contract and renderer extensions;
- default launcher resource repair;
- full-shell selected-theme chrome and Kapanion integration;
- clipped/calibrated layered progress;
- staged Jester startup;
- source documentation and deterministic CLIENT chrome derivatives.

Preserved:

- SERVER source;
- protocol, trust, Truth Firewall, identity proof, permissions, missions, Forge authority, local/remote distinctions, accessibility automation, and offline-first behavior.

Verification status:

- source-only integrity complete;
- build, APK, unit/instrumentation, device, workflow, release, and deployment verification pending the next explicit gate.
