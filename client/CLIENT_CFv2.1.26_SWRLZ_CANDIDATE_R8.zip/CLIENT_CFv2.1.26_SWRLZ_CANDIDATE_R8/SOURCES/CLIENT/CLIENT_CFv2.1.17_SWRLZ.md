# CLIENT CFv2.1.17 SWRLZ Source Note

- Checkpoint: `INT-FORGE-039E`
- versionCode: `115`
- versionName: `2.1.17-forge-rescue-default-theme-v1`
- Role: temporary default-theme Forge rescue/bootstrap successor.
- Parent: CLIENT CFv2.1.16.
- Full ThemePack art is intentionally omitted from this transport edition and remains recoverable from parent lineage.
- Source-only; build/device/GitHub promotion not claimed.
