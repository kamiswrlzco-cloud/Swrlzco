# CLIENT CFv2.1.24 SWRLZ Candidate R1

Parent: CLIENT_CFv2.1.23_SWRLZ_CANDIDATE_R1.zip
Parent SHA-256: fac19c20f6bc6170e28066ccab6754c587e13c5ecf4dda7b36d428892506e088
Checkpoint: INT-FORGE-042B

Compose compile repair + Forge Transport V2. Source candidate only.
