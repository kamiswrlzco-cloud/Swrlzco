# CLIENT CFv2.1.20 SWRLZ — Candidate R1

Checkpoint: `INT-FORGE-039F + INT-FORGE-039N`

- versionCode: 118
- versionName: `2.1.20-forge-chunked-transport-optional-evidence-candidate-r1`
- status: SOURCE CANDIDATE; Android build pending
- parent: CLIENT CFv2.1.19 CANDIDATE_R2

Implements chunked protected-source transport and separates build eligibility from optional package evidence. See the checkpoint, evidence, and handoff documents for the exact trust and validation boundaries.
