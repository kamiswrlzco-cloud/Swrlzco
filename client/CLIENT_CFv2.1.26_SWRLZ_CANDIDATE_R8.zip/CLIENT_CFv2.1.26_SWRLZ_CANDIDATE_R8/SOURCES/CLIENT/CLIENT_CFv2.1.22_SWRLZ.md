# CLIENT CFv2.1.22 SWRLZ — Candidate R1

Checkpoint: `INT-UX-039Q`

- versionCode: 120
- versionName: `2.1.22-update-ledger-settings-theme-identity-candidate-r1`
- status: SOURCE/STATIC VERIFIED CANDIDATE; Android compile/build evidence pending
- parent: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R2.zip`
- parent SHA-256: `c4eb68554bc3c5bf95a0599c42da782ad3b948331cab3b08229eb73c3a9b089b`

Adds an interactive local Update Ledger and evidence-aware update Q&A, repairs hierarchical CLIENT/Settings Back behavior, reorganizes Brain & AI plus Messages & Bubble into their semantic parent settings categories, and adds primary/complementary role identity for SWRLZ-owned bubble surfaces.

The current rescue selectable ThemePack set remains Glitch Dragon Glass. Full multi-theme launcher/asset restoration is not claimed. Android/SystemUI badge styling is not claimed. INT-CMD-039P-R3 and INT-FILE-039M execution remain separate work.

No SERVER, protocol, trust, Truth Firewall, mission authority, Forge authority, repository source authority, release, deployment, or installation state is changed by this candidate.
