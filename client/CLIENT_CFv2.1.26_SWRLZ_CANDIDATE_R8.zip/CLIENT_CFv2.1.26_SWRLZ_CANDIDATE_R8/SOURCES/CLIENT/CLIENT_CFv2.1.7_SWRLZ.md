# CLIENT CFv2.1.7 SWRLZ Lineage Receipt

Parent source: `CLIENT_CFv2.1.6_SWRLZ.zip`  
Parent SHA-256: `bed74b9e4c85e180c2a709f5a48dece3e1abb0e3a9cdab948d80888077aafb94`  
New source: `CLIENT_CFv2.1.7_SWRLZ.zip`  
Android identity: versionCode `105` / versionName `2.1.7-theme-progress-compose-scope-repair-v1`  
Checkpoint: `INT-THEME-035B`

Bounded change: explicit `BoxWithConstraints.maxWidth` capture for nested themed progress fill rendering, plus synchronized checkpoint/evidence documentation. Build/device verification remains pending.
