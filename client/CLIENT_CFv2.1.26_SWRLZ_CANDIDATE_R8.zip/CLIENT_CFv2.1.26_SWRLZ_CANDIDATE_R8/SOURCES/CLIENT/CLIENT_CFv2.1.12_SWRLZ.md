# CLIENT CFv2.1.12 SWRLZ

Checkpoint: `INT-PROFILE-037B`
Parent: `CLIENT_CFv2.1.11_SWRLZ.zip`
Android versionCode: `110`
Android versionName: `2.1.12-distributed-profile-architecture-v1`

Adds the distributed declarative SWRLZ profile substrate, CLIENT profile persistence, Chat profile/routing controls, provider specialist assignments, and custom inherited profiles. Provider networking/credentials remain outside this checkpoint.
