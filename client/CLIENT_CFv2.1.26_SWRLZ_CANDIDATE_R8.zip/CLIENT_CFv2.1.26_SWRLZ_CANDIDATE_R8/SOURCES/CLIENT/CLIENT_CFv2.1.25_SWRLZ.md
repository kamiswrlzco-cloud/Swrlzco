# CLIENT CFv2.1.25 SWRLZ Candidate R1

Parent: CLIENT_CFv2.1.24_SWRLZ_CANDIDATE_R1.zip
Parent SHA-256: 6bfa4a4b1d7d31c9f3ef3469d869c4fa35d50c4568ec2ba155ee6848cdd9fa55
Checkpoint: INT-AI-041F-C2

Adds paired Model Rack protocol V2 contract support for `BEHAVIOR_SHARD` / `behavior_shard_v1` and updates CLIENT Model Rack presentation/Update Ledger text to reflect SERVER-owned behavior routing. The legacy direct-device Gemini planner/key path is removed. GPT/OpenAI implementation compatibility remains beneath the surface, but public GPT controls, commands, status, and routing choices are hidden for now. No new CLIENT execution authority is introduced.

No local-time injection, output validator, model verifier, model/weight modification, training, Android build, GitHub write, promotion, release, deployment, or installation.
