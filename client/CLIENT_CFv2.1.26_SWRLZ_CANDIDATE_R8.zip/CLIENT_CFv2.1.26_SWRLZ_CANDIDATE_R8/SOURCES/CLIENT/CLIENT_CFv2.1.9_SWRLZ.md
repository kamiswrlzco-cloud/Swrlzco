# CLIENT CFv2.1.9 Source Identity

Checkpoint: `INT-THEME-035D`  
Source package: `CLIENT_CFv2.1.9_SWRLZ.zip`  
Android versionCode: `107`  
Android versionName: `2.1.9-package-pair-repair-v1`

Parent:

- `CLIENT_CFv2.1.8_SWRLZ.zip`
- SHA-256 `d344e683cc76756020b1a02e118b2417c03d6552eeb032dd5dd91058c0f7f055`
- Merge commit `bc80d7a4d28d656f640ac1a511b9ae340e8b45ee`

Repair:

- preserves the complete CFv2.1.8 ThemePack implementation;
- adds the canonical ZIP basename, byte-size, and verified fields required by
  the repository package-pair verifier;
- preserves failed workflow runs `30222384992` and `30222384996` as lineage;
- advances package/application identity without changing presentation behavior.

Preserved:

- SERVER source;
- protocol, trust, Truth Firewall, identity proof, permissions, missions,
  Forge authority, local/remote distinctions, accessibility automation, and
  offline-first behavior.

Verification status:

- source behavior diff is limited to build/package identity and documentation;
- final ZIP/checksum/manifest verification is required after packaging;
- Android compilation, APK artifact, and device acceptance remain evidence-gated.
