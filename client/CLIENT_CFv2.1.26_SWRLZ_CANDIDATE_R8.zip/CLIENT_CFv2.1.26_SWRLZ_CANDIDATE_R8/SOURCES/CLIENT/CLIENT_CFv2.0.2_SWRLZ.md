# CLIENT CFv2.0.2 SWRLZ Lineage Receipt

**Canonical baseline:** `CLIENT_CFv2.0.1_SWRLZ.zip`  
**New source:** `CLIENT_CFv2.0.2_SWRLZ.zip`  
**Android identity:** `versionCode 33` / `versionName 0.2.7.7-cfv2.0.2-verified-baseline`

## Evidence carried forward

CLIENT CFv2.0.1 compiled successfully through the owner's GitHub workflow after removal of these invalid explicit imports from `ClientShellScreen.kt`:

```kotlin
import androidx.compose.foundation.layout.calculateTopPadding
import androidx.compose.foundation.layout.weight
```

The valid call sites remain receiver- and scope-resolved:

```kotlin
WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
Modifier.weight(...)
```

## Scope of CFv2.0.2

This checkpoint advances the source and Android version identity and records the verified baseline.

It does not add the proposed Living Glitch Dragon effects. Those remain a separately authorized implementation checkpoint.

## Preserved boundaries

No intentional change was made to:

- User Mode or SWRLZ Dev Mode behavior
- Truth Firewall
- local-first routing
- local-versus-remote identity
- trust or pairing semantics
- protocols
- database schema
- NODE_HOST behavior
- CLIENT-to-NODE_HOST connectivity

Core law: integrate, do not overwrite.
