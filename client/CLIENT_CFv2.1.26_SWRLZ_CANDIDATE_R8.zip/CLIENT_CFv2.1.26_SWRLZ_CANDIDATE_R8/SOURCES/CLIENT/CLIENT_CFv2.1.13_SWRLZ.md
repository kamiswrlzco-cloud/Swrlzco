# CLIENT CFv2.1.13 SWRLZ Source Receipt

Checkpoint: `INT-AI-038A`
Parent: `CLIENT_CFv2.1.12_SWRLZ.zip`
Parent SHA-256: `4c9d44a174a488655ad44c6bb0e2120d994e6e2dbd7d7cc9e8287931e35fc774`
Android: versionCode `111`; versionName `2.1.13-provider-mesh-v1`
Status: source-only implementation; final ZIP SHA-256 is recorded by the external sidecar manifest/receipt after deterministic packaging.
