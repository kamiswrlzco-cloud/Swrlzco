# CLIENT CFv2.1.23 SWRLZ Source Note

Candidate: `CLIENT_CFv2.1.23_SWRLZ_CANDIDATE_R1`

Checkpoint: `INT-AI-041F-A-R8`

Parent: `CLIENT_CFv2.1.22_SWRLZ_CANDIDATE_R1.zip`  
Parent SHA-256: `49284e9a57d30a2b37912c32ac9a85fbb333d4a6ed620687c855469363d0ecd5`

This candidate adds the CLIENT control half of the modular model rack: model selection, per-model Speed/Reasoning Depth/Expression EQ, module toggles and rollback through the paired SERVER authority.

The optimized GGUF remains external to CLIENT. Source/static evidence passes; Android compilation and APK/device evidence are pending.
