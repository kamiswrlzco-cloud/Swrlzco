package sh.swrlz.provider

import kotlinx.serialization.Serializable

/**
 * Shared provider-mesh contract. No secret material is represented here.
 * SWRLZ remains the conversation/authority owner; providers are advisory reasoning specialists.
 */
@Serializable
enum class ProviderId(val wireId: String) {
    LOCAL_CLIENT("local_client"),
    LOCAL_SERVER("local_server"),
    OPENAI("openai"),
    GEMINI("gemini");

    companion object {
        fun fromWire(value: String?): ProviderId? = entries.firstOrNull {
            it.wireId.equals(value?.trim(), ignoreCase = true)
        } ?: when (value?.trim()?.lowercase()) {
            "gpt", "chatgpt" -> OPENAI
            "local" -> LOCAL_CLIENT
            "server_local" -> LOCAL_SERVER
            else -> null
        }
    }
}

@Serializable
enum class ProviderStrategy {
    SWRLZ_AUTO,
    LOCAL_ONLY,
    OPENAI,
    GEMINI,
    COUNCIL,
    COMPARE,
}

@Serializable
enum class ProviderHealthStatus {
    UNCONFIGURED,
    STORED,
    PROBING,
    READY,
    DEGRADED,
    AUTH_FAILED,
    OFFLINE,
    ERROR,
}

@Serializable
data class ProviderModelV1(
    val providerId: String,
    val id: String,
    val displayName: String = id,
    val supportsReasoning: Boolean = true,
    val supportsFiles: Boolean = false,
    val supportsVision: Boolean = false,
    val metadata: Map<String, String> = emptyMap(),
)

@Serializable
data class ProviderHealthV1(
    val providerId: String,
    val status: ProviderHealthStatus = ProviderHealthStatus.UNCONFIGURED,
    val credentialConfigured: Boolean = false,
    val selectedModel: String? = null,
    val lastProbeEpochMs: Long? = null,
    val latencyMs: Long? = null,
    val detail: String = "Not configured",
    val discoveredModels: List<ProviderModelV1> = emptyList(),
)

@Serializable
data class ProviderMeshSnapshotV1(
    val protocolVersion: Int = 1,
    val swrlzIdentity: String = "SWRLZ",
    val localFirst: Boolean = true,
    val providers: List<ProviderHealthV1> = emptyList(),
)

@Serializable
data class ProviderContributionV1(
    val providerId: String,
    val modelId: String,
    val text: String,
    val latencyMs: Long? = null,
    val profileId: String? = null,
)

@Serializable
data class ProviderReasonRequestV1(
    val strategy: ProviderStrategy = ProviderStrategy.SWRLZ_AUTO,
    val prompt: String,
    val systemDirective: String = "",
    val openAiModelOverride: String? = null,
    val geminiModelOverride: String? = null,
    val sourceReceipts: List<ProviderFileReceiptV1> = emptyList(),
    val sanitizedSourceContext: String? = null,
    val allowPaidProviders: Boolean = false,
    val requestSynthesis: Boolean = true,
)

@Serializable
data class ProviderReasonResponseV1(
    val ok: Boolean,
    val strategy: ProviderStrategy,
    val swrlzText: String? = null,
    val contributions: List<ProviderContributionV1> = emptyList(),
    val errors: List<String> = emptyList(),
    val providerSnapshot: ProviderMeshSnapshotV1? = null,
)

@Serializable
data class ProviderFileDescriptorV1(
    val displayName: String,
    val mimeType: String = "application/octet-stream",
    val sizeBytes: Long,
    val sha256: String,
)

@Serializable
data class ProviderFileReceiptV1(
    val dispatchId: String,
    val original: ProviderFileDescriptorV1,
    val sanitized: Boolean,
    val includedFileCount: Int = 0,
    val omittedFileCount: Int = 0,
    val sanitizedBytes: Long = 0,
    val bundleSha256: String? = null,
    val detail: String = "",
)

@Serializable
data class ProviderDispatchRequestV1(
    val strategy: ProviderStrategy,
    val prompt: String,
    val receipts: List<ProviderFileReceiptV1>,
    val allowPaidProviders: Boolean = false,
)


@Serializable
data class ProviderProbeRequestV1(
    val providerId: String? = null,
    val deep: Boolean = true,
)

@Serializable
data class ProviderModelSelectionV1(
    val providerId: String,
    val modelId: String,
)

@Serializable
data class ProviderSourceAnalyzeRequestV1(
    val component: String,
    val strategy: ProviderStrategy = ProviderStrategy.SWRLZ_AUTO,
    val prompt: String,
    val allowPaidProviders: Boolean = false,
)

@Serializable
data class ProviderTagResolutionV1(
    val strategy: ProviderStrategy,
    val cleanedPrompt: String,
    val explicit: Boolean,
    val matchedTags: List<String> = emptyList(),
)

object ProviderTagParser {
    private val tagRegex = Regex("(?i)(?<![\\w])@(gpt|openai|chatgpt|gemini|both|council|compare|local)(?![\\w])")

    fun resolve(text: String, defaultStrategy: ProviderStrategy = ProviderStrategy.SWRLZ_AUTO): ProviderTagResolutionV1 {
        val matches = tagRegex.findAll(text).toList()
        if (matches.isEmpty()) return ProviderTagResolutionV1(defaultStrategy, text.trim(), false)
        val tags = matches.map { it.groupValues[1].lowercase() }
        val hasOpenAi = tags.any { it in setOf("gpt", "openai", "chatgpt") }
        val hasGemini = "gemini" in tags
        val strategy = when {
            "compare" in tags -> ProviderStrategy.COMPARE
            "council" in tags || "both" in tags || (hasOpenAi && hasGemini) -> ProviderStrategy.COUNCIL
            "local" in tags -> ProviderStrategy.LOCAL_ONLY
            hasOpenAi -> ProviderStrategy.OPENAI
            hasGemini -> ProviderStrategy.GEMINI
            else -> defaultStrategy
        }
        val cleaned = tagRegex.replace(text, " ").replace(Regex("\\s+"), " ").trim()
        return ProviderTagResolutionV1(strategy, cleaned, true, tags.distinct())
    }
}
