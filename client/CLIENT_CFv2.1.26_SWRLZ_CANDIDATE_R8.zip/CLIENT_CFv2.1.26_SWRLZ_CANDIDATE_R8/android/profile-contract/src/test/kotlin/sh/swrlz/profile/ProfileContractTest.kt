package sh.swrlz.profile

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProfileContractTest {
    @Test fun builtInsValidate() {
        assertTrue(ProfileResolverV1.validate(ProfileDocumentV1()).isEmpty())
    }

    @Test fun endpointRelationshipProviderPrecedenceIsDeterministic() {
        val doc = ProfileDocumentV1()
        val resolved = ProfileResolverV1.resolve(
            document = doc,
            endpointProfileId = BuiltInProfiles.CLIENT_MAIN_ID,
            relationshipProfileId = BuiltInProfiles.CLIENT_TO_SERVER_ID,
            providerProfileId = BuiltInProfiles.OPENAI_ENGINEER_ID,
        )
        assertEquals("Engineer", resolved.baseStyle)
        assertEquals("Deep", resolved.reasoningDepth)
        assertEquals("Extended", resolved.contextAllowance)
        assertTrue(resolved.directive().contains("canonical truth"))
    }

    @Test fun cyclesAreRejected() {
        val a = SwrlzProfileV1("custom.a", "A", ProfileScope.SESSION, parentId = "custom.b")
        val b = SwrlzProfileV1("custom.b", "B", ProfileScope.SESSION, parentId = "custom.a")
        val doc = ProfileDocumentV1(profiles = BuiltInProfiles.all + a + b)
        assertTrue(ProfileResolverV1.validate(doc).any { it.contains("cycle") })
    }
}
