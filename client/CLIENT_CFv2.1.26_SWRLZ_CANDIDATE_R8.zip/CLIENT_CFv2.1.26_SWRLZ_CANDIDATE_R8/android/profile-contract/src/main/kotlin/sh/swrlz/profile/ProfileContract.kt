package sh.swrlz.profile

import kotlinx.serialization.Serializable

/**
 * Declarative SWRLZ profile contract.
 *
 * Profiles shape presentation, reasoning emphasis, context allowance, and provider preference.
 * They never own protocol truth, trust, permissions, approval policy, mission authority,
 * Forge authority, or Truth Firewall behavior.
 */
@Serializable
enum class ProfileLifecycle { STABLE, TEST, DRAFT }

@Serializable
enum class ProfileScope {
    FOUNDATION,
    CLIENT_ENDPOINT,
    SERVER_ENDPOINT,
    CLIENT_TO_SERVER,
    SERVER_TO_CLIENT,
    SERVER_TO_SERVER,
    PROVIDER,
    SESSION,
}

@Serializable
data class ProfileOverridesV1(
    val baseStyle: String? = null,
    val detail: String? = null,
    val warmth: String? = null,
    val energy: String? = null,
    val humor: String? = null,
    val formatting: String? = null,
    val emoji: String? = null,
    val technicalDepth: String? = null,
    val reasoningDepth: String? = null,
    val contextAllowance: String? = null,
    val returnStyle: String? = null,
    val providerStrategy: String? = null,
    val customInstruction: String? = null,
)

@Serializable
data class SwrlzProfileV1(
    val id: String,
    val displayName: String,
    val scope: ProfileScope,
    val parentId: String? = null,
    val providerId: String? = null,
    val overrides: ProfileOverridesV1 = ProfileOverridesV1(),
    val builtIn: Boolean = false,
    val lifecycle: ProfileLifecycle = ProfileLifecycle.STABLE,
    val favorite: Boolean = false,
)

@Serializable
data class ProfileAssignmentsV1(
    val clientEndpointProfileId: String = BuiltInProfiles.CLIENT_MAIN_ID,
    val serverEndpointProfileId: String = BuiltInProfiles.SERVER_ARCHITECT_ID,
    val clientToServerProfileId: String = BuiltInProfiles.CLIENT_TO_SERVER_ID,
    val serverToClientProfileId: String = BuiltInProfiles.SERVER_TO_CLIENT_ID,
    val serverToServerProfileId: String = BuiltInProfiles.SERVER_TO_SERVER_ID,
    val openAiProviderProfileId: String = BuiltInProfiles.OPENAI_ENGINEER_ID,
    val geminiProviderProfileId: String = BuiltInProfiles.GEMINI_EXPLORER_ID,
    val localProviderProfileId: String = BuiltInProfiles.LOCAL_GROUNDED_ID,
    val sessionProfileId: String? = null,
)

@Serializable
data class ProfileDocumentV1(
    val manifestVersion: Int = 1,
    val profiles: List<SwrlzProfileV1> = BuiltInProfiles.all,
    val assignments: ProfileAssignmentsV1 = ProfileAssignmentsV1(),
)

@Serializable
data class ResolvedProfileV1(
    val baseStyle: String = "Adaptive SWRLZ",
    val detail: String = "Balanced",
    val warmth: String = "High",
    val energy: String = "High",
    val humor: String = "Adaptive",
    val formatting: String = "Structured",
    val emoji: String = "Adaptive",
    val technicalDepth: String = "Adaptive",
    val reasoningDepth: String = "Balanced",
    val contextAllowance: String = "Normal",
    val returnStyle: String = "Conversational",
    val providerStrategy: String = "AUTO",
    val instructions: List<String> = emptyList(),
) {
    fun directive(): String = buildString {
        append("SWRLZ profile: style=$baseStyle; detail=$detail; warmth=$warmth; energy=$energy; humor=$humor; formatting=$formatting; emoji=$emoji; technicalDepth=$technicalDepth; reasoningDepth=$reasoningDepth; contextAllowance=$contextAllowance; returnStyle=$returnStyle; providerStrategy=$providerStrategy.")
        if (instructions.isNotEmpty()) append(" Profile instructions: ${instructions.joinToString(" ")}")
        append(" Profiles may shape presentation and reasoning emphasis only; canonical truth, trust, permissions, approvals, mission authority, Forge authority, and Truth Firewall remain authoritative.")
    }
}

object BuiltInProfiles {
    const val BASE_ID = "swrlz.base"
    const val CLIENT_MAIN_ID = "swrlz.client.main"
    const val CLIENT_ENGINEER_ID = "swrlz.client.engineer"
    const val SERVER_ARCHITECT_ID = "swrlz.server.architect"
    const val CLIENT_TO_SERVER_ID = "swrlz.link.client_to_server.deep_reason"
    const val SERVER_TO_CLIENT_ID = "swrlz.link.server_to_client.conversational"
    const val SERVER_TO_SERVER_ID = "swrlz.link.server_to_server.node_coordination"
    const val OPENAI_ENGINEER_ID = "swrlz.provider.openai.engineer"
    const val GEMINI_EXPLORER_ID = "swrlz.provider.gemini.explorer"
    const val LOCAL_GROUNDED_ID = "swrlz.provider.local.grounded"

    val all: List<SwrlzProfileV1> = listOf(
        SwrlzProfileV1(
            id = BASE_ID,
            displayName = "SWRLZ Base",
            scope = ProfileScope.FOUNDATION,
            builtIn = true,
            overrides = ProfileOverridesV1(
                baseStyle = "Adaptive SWRLZ",
                detail = "Balanced",
                warmth = "High",
                energy = "High",
                humor = "Adaptive",
                formatting = "Structured",
                emoji = "Adaptive",
                technicalDepth = "Adaptive",
                reasoningDepth = "Balanced",
                contextAllowance = "Normal",
                returnStyle = "Conversational",
                providerStrategy = "AUTO",
                customInstruction = "Preserve one continuous SWRLZ identity while adapting presentation to the active endpoint, relationship, provider, session, and message context.",
            ),
        ),
        SwrlzProfileV1(
            id = CLIENT_MAIN_ID,
            displayName = "CLIENT Main",
            scope = ProfileScope.CLIENT_ENDPOINT,
            parentId = BASE_ID,
            builtIn = true,
        ),
        SwrlzProfileV1(
            id = CLIENT_ENGINEER_ID,
            displayName = "CLIENT Engineer",
            scope = ProfileScope.CLIENT_ENDPOINT,
            parentId = CLIENT_MAIN_ID,
            builtIn = true,
            overrides = ProfileOverridesV1(
                baseStyle = "Engineer",
                technicalDepth = "High",
                reasoningDepth = "Deep",
                customInstruction = "Favor implementation details, evidence, explicit assumptions, and bounded next actions.",
            ),
        ),
        SwrlzProfileV1(
            id = SERVER_ARCHITECT_ID,
            displayName = "SERVER Architect",
            scope = ProfileScope.SERVER_ENDPOINT,
            parentId = BASE_ID,
            builtIn = true,
            overrides = ProfileOverridesV1(
                baseStyle = "Architect",
                technicalDepth = "High",
                reasoningDepth = "Deep",
                humor = "Light",
                customInstruction = "Emphasize orchestration, node state, provenance, architecture boundaries, and operational clarity.",
            ),
        ),
        SwrlzProfileV1(
            id = CLIENT_TO_SERVER_ID,
            displayName = "CLIENT → SERVER Deep Reason",
            scope = ProfileScope.CLIENT_TO_SERVER,
            parentId = BASE_ID,
            builtIn = true,
            overrides = ProfileOverridesV1(
                technicalDepth = "High",
                reasoningDepth = "Deep",
                contextAllowance = "Extended",
                providerStrategy = "AUTO",
                customInstruction = "Interpret CLIENT requests with rich technical context while preserving CLIENT authority and explicit approval boundaries.",
            ),
        ),
        SwrlzProfileV1(
            id = SERVER_TO_CLIENT_ID,
            displayName = "SERVER → CLIENT Conversational",
            scope = ProfileScope.SERVER_TO_CLIENT,
            parentId = BASE_ID,
            builtIn = true,
            overrides = ProfileOverridesV1(
                returnStyle = "SWRLZ conversational",
                detail = "Balanced",
                customInstruction = "Return SERVER results as clear SWRLZ conversation with provider/provenance detail available without dumping raw internal traces.",
            ),
        ),
        SwrlzProfileV1(
            id = SERVER_TO_SERVER_ID,
            displayName = "SERVER → SERVER Node Coordination",
            scope = ProfileScope.SERVER_TO_SERVER,
            parentId = BASE_ID,
            builtIn = true,
            overrides = ProfileOverridesV1(
                baseStyle = "Machine-clear",
                detail = "Compact",
                warmth = "Low",
                energy = "Low",
                humor = "Off",
                formatting = "Schema-first",
                emoji = "Off",
                technicalDepth = "High",
                reasoningDepth = "Deep",
                contextAllowance = "Operational",
                returnStyle = "Canonical structured",
                customInstruction = "Prefer canonical identifiers, compact evidence, and machine-clear coordination between SERVER nodes.",
            ),
        ),
        SwrlzProfileV1(
            id = OPENAI_ENGINEER_ID,
            displayName = "GPT Engineer",
            scope = ProfileScope.PROVIDER,
            parentId = BASE_ID,
            providerId = "openai",
            builtIn = true,
            overrides = ProfileOverridesV1(
                baseStyle = "Engineer",
                technicalDepth = "High",
                reasoningDepth = "Deep",
                customInstruction = "Use OpenAI as a reasoning specialist; challenge weak assumptions and return evidence-oriented recommendations to SWRLZ for final synthesis.",
            ),
        ),
        SwrlzProfileV1(
            id = GEMINI_EXPLORER_ID,
            displayName = "Gemini Explorer",
            scope = ProfileScope.PROVIDER,
            parentId = BASE_ID,
            providerId = "gemini",
            builtIn = true,
            overrides = ProfileOverridesV1(
                baseStyle = "Explorer",
                technicalDepth = "High",
                reasoningDepth = "Deep",
                customInstruction = "Use Gemini as an alternate reasoning specialist with strong comparative and multimodal/context exploration; return proposals to SWRLZ for final synthesis.",
            ),
        ),
        SwrlzProfileV1(
            id = LOCAL_GROUNDED_ID,
            displayName = "Local Grounded",
            scope = ProfileScope.PROVIDER,
            parentId = BASE_ID,
            providerId = "local",
            builtIn = true,
            overrides = ProfileOverridesV1(
                baseStyle = "Grounded",
                detail = "Balanced",
                reasoningDepth = "Balanced",
                contextAllowance = "Local",
                providerStrategy = "LOCAL_ONLY",
                customInstruction = "Ground reasoning in local state and offline-first constraints; do not imply remote provider access.",
            ),
        ),
    )
}

object ProfileResolverV1 {
    /** Precedence: foundation → endpoint → relationship → provider → session → message. */
    val precedence: List<String> = listOf("foundation", "endpoint", "relationship", "provider", "session", "message")

    fun validate(document: ProfileDocumentV1): List<String> {
        val failures = mutableListOf<String>()
        if (document.manifestVersion != 1) failures += "Unsupported profile manifest version ${document.manifestVersion}"
        val byId = document.profiles.groupBy { it.id }
        byId.filterValues { it.size != 1 }.keys.forEach { failures += "Duplicate profile id: $it" }
        val profiles = document.profiles.associateBy { it.id }
        document.profiles.forEach { profile ->
            if (!profile.id.matches(Regex("[a-z0-9._-]{3,96}"))) failures += "Invalid profile id: ${profile.id}"
            if (profile.displayName.trim().length !in 1..80) failures += "Invalid profile display name: ${profile.id}"
            if (profile.scope == ProfileScope.PROVIDER && profile.providerId.isNullOrBlank()) failures += "Provider profile missing providerId: ${profile.id}"
            profile.parentId?.let { if (it !in profiles) failures += "Missing parent $it for ${profile.id}" }
            val seen = linkedSetOf<String>()
            var cursor: SwrlzProfileV1? = profile
            while (cursor != null) {
                if (!seen.add(cursor.id)) {
                    failures += "Profile inheritance cycle: ${seen.joinToString(" -> ")} -> ${cursor.id}"
                    break
                }
                cursor = cursor.parentId?.let(profiles::get)
            }
        }
        assignmentIds(document.assignments).filterNotNull().forEach { id ->
            if (id !in profiles) failures += "Assignment references missing profile: $id"
        }
        return failures.distinct()
    }

    fun resolve(
        document: ProfileDocumentV1,
        endpointProfileId: String? = null,
        relationshipProfileId: String? = null,
        providerProfileId: String? = null,
        sessionProfileId: String? = document.assignments.sessionProfileId,
        messageOverrides: ProfileOverridesV1? = null,
    ): ResolvedProfileV1 {
        require(validate(document).isEmpty()) { "Invalid profile document: ${validate(document).joinToString()}" }
        val profiles = document.profiles.associateBy { it.id }
        var resolved = ResolvedProfileV1()
        fun applyProfile(id: String?) {
            if (id == null) return
            inheritanceChain(profiles, id).forEach { profile -> resolved = apply(resolved, profile.overrides) }
        }
        applyProfile(BuiltInProfiles.BASE_ID)
        applyProfile(endpointProfileId)
        applyProfile(relationshipProfileId)
        applyProfile(providerProfileId)
        applyProfile(sessionProfileId)
        if (messageOverrides != null) resolved = apply(resolved, messageOverrides)
        return resolved
    }

    private fun inheritanceChain(profiles: Map<String, SwrlzProfileV1>, id: String): List<SwrlzProfileV1> {
        val reversed = mutableListOf<SwrlzProfileV1>()
        val seen = mutableSetOf<String>()
        var cursor = profiles[id]
        while (cursor != null && seen.add(cursor.id)) {
            if (cursor.id != BuiltInProfiles.BASE_ID) reversed += cursor
            cursor = cursor.parentId?.let(profiles::get)
        }
        return reversed.asReversed()
    }

    private fun apply(base: ResolvedProfileV1, next: ProfileOverridesV1): ResolvedProfileV1 = base.copy(
        baseStyle = next.baseStyle ?: base.baseStyle,
        detail = next.detail ?: base.detail,
        warmth = next.warmth ?: base.warmth,
        energy = next.energy ?: base.energy,
        humor = next.humor ?: base.humor,
        formatting = next.formatting ?: base.formatting,
        emoji = next.emoji ?: base.emoji,
        technicalDepth = next.technicalDepth ?: base.technicalDepth,
        reasoningDepth = next.reasoningDepth ?: base.reasoningDepth,
        contextAllowance = next.contextAllowance ?: base.contextAllowance,
        returnStyle = next.returnStyle ?: base.returnStyle,
        providerStrategy = next.providerStrategy ?: base.providerStrategy,
        instructions = base.instructions + listOfNotNull(next.customInstruction?.trim()?.takeIf { it.isNotEmpty() }),
    )

    private fun assignmentIds(a: ProfileAssignmentsV1): List<String?> = listOf(
        a.clientEndpointProfileId,
        a.serverEndpointProfileId,
        a.clientToServerProfileId,
        a.serverToClientProfileId,
        a.serverToServerProfileId,
        a.openAiProviderProfileId,
        a.geminiProviderProfileId,
        a.localProviderProfileId,
        a.sessionProfileId,
    )
}
