package sh.swrlz.modelrack

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelRackContractTest {
    @Test
    fun optimizedBaseIdentityIsPinned() {
        assertEquals(64, ModelRackProtocolV1.OPTIMIZED_BASE_SHA256.length)
        assertEquals(229_315_680L, ModelRackProtocolV1.OPTIMIZED_BASE_SIZE_BYTES)
    }

    @Test
    fun expressionEqIsBounded() {
        val normalized = ExpressionEqV1(warmth = -1, humor = 200).normalized()
        assertEquals(0, normalized.warmth)
        assertEquals(100, normalized.humor)
    }

    @Test
    fun loraManifestFailsClosedWithoutAdapterContract() {
        val manifest = ModelModuleManifestV1(
            id = "swrlz.test.lora",
            displayName = "Test adapter",
            version = "1.0.0",
            type = ModelModuleTypeV1.LORA_ADAPTER,
            requiredRuntimeContract = "prompt_capsule_v1",
            payloads = listOf(ModelModulePayloadV1("adapter.gguf", "a".repeat(64), 1024)),
        )
        assertTrue("LORA_RUNTIME_CONTRACT_INVALID" in ModelRackContractValidation.validateManifest(manifest))
    }

    @Test
    fun executableTraversalPayloadIsRejected() {
        val manifest = ModelModuleManifestV1(
            id = "swrlz.test.prompt",
            displayName = "Prompt",
            version = "1",
            type = ModelModuleTypeV1.PROMPT_CAPSULE,
            payloads = listOf(ModelModulePayloadV1("../evil.dex", "b".repeat(64), 12)),
        )
        assertTrue("PACK_PAYLOAD_PATH_INVALID" in ModelRackContractValidation.validateManifest(manifest))
    }

    @Test
    fun duplicatePayloadPathIsRejected() {
        val payload = ModelModulePayloadV1("prompt.json", "c".repeat(64), 12)
        val manifest = ModelModuleManifestV1(
            id = "swrlz.test.duplicate",
            displayName = "Duplicate",
            version = "1",
            type = ModelModuleTypeV1.PROMPT_CAPSULE,
            payloads = listOf(payload, payload),
        )
        assertTrue("PACK_PAYLOAD_DUPLICATE" in ModelRackContractValidation.validateManifest(manifest))
    }

    @Test
    fun expressionEqRequiresItsRuntimeContract() {
        val manifest = ModelModuleManifestV1(
            id = "swrlz.test.eq",
            displayName = "EQ",
            version = "1",
            type = ModelModuleTypeV1.EXPRESSION_EQ,
            requiredRuntimeContract = "prompt_capsule_v1",
            payloads = listOf(ModelModulePayloadV1("eq.json", "d".repeat(64), 12)),
        )
        assertTrue("EQ_RUNTIME_CONTRACT_INVALID" in ModelRackContractValidation.validateManifest(manifest))
    }

    @Test
    fun traversalVersionIsRejected() {
        val manifest = ModelModuleManifestV1(
            id = "swrlz.test.version",
            displayName = "Version",
            version = "../../escape",
            type = ModelModuleTypeV1.PROMPT_CAPSULE,
            payloads = listOf(ModelModulePayloadV1("prompt.json", "e".repeat(64), 12)),
        )
        assertTrue("PACK_VERSION_INVALID" in ModelRackContractValidation.validateManifest(manifest))
    }

    @Test
    fun behaviorShardRequiresV1RuntimeContract() {
        val manifest = ModelModuleManifestV1(
            id = "swrlz.behavior.test",
            displayName = "Behavior",
            version = "1.0.0",
            type = ModelModuleTypeV1.BEHAVIOR_SHARD,
            requiredRuntimeContract = "prompt_capsule_v1",
            payloads = listOf(ModelModulePayloadV1("behavior.json", "f".repeat(64), 128)),
        )
        assertTrue("BEHAVIOR_RUNTIME_CONTRACT_INVALID" in ModelRackContractValidation.validateManifest(manifest))
        assertEquals(2, ModelRackProtocolV2.PROTOCOL_VERSION)
    }

    @Test
    fun protocolV2UsesVersionedRoute() {
        assertEquals("/ai/model-rack/v2", ModelRackProtocolV2.PREFIX)
        assertTrue(ModelRackProtocolV2.STATUS.startsWith(ModelRackProtocolV2.PREFIX))
        assertTrue(ModelRackProtocolV2.PREFIX != ModelRackProtocolV1.PREFIX)
    }
}
