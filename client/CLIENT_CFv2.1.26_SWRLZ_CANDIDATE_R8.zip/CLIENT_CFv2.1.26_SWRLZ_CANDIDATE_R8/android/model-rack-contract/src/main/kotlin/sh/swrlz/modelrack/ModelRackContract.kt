package sh.swrlz.modelrack

import kotlinx.serialization.Serializable

/**
 * Shared CLIENT ↔ SERVER wire contract for the bounded SWRLZ modular model rack.
 *
 * This contract controls inference configuration and declarative expression modules only.
 * It never represents mission, file, Forge, tool, approval, trust, or execution authority.
 */
object ModelRackProtocolV1 {
    const val PROTOCOL_VERSION = 1
    const val SCHEMA_VERSION = 1
    const val PREFIX = "/ai/model-rack"
    const val STATUS = "$PREFIX/status"
    const val PROFILE = "$PREFIX/profile"
    const val ACTIVATE_MODEL = "$PREFIX/model/activate"
    const val ACTIVATE_MODULE = "$PREFIX/module/activate"
    const val ROLLBACK = "$PREFIX/rollback"
    const val OPTIMIZED_BASE_SHA256 = "651cd5c40e4ef24de2ff12c2b53b257d15816ddd4346e2575e6768a6ec1d8590"
    const val OPTIMIZED_BASE_SIZE_BYTES = 229_315_680L
    const val OPTIMIZED_BASE_NAME = "SWRLZ-LFM-OPT-001A"
}

/**
 * Protocol V2 adds BEHAVIOR_SHARD on a versioned route surface while V1 remains available for legacy peers.
 * CLIENT/SERVER candidates that understand Behavior Shard V1 advertise protocolVersion=2.
 */
object ModelRackProtocolV2 {
    const val PROTOCOL_VERSION = 2
    const val SCHEMA_VERSION = ModelRackProtocolV1.SCHEMA_VERSION
    const val PREFIX = "${ModelRackProtocolV1.PREFIX}/v2"
    const val STATUS = "$PREFIX/status"
    const val PROFILE = "$PREFIX/profile"
    const val ACTIVATE_MODEL = "$PREFIX/model/activate"
    const val ACTIVATE_MODULE = "$PREFIX/module/activate"
    const val ROLLBACK = "$PREFIX/rollback"
    const val OPTIMIZED_BASE_SHA256 = ModelRackProtocolV1.OPTIMIZED_BASE_SHA256
    const val OPTIMIZED_BASE_SIZE_BYTES = ModelRackProtocolV1.OPTIMIZED_BASE_SIZE_BYTES
    const val OPTIMIZED_BASE_NAME = ModelRackProtocolV1.OPTIMIZED_BASE_NAME
    const val BEHAVIOR_RUNTIME_CONTRACT = "behavior_shard_v1"
}

@Serializable
enum class ModelSpeedV1 { ECO, BALANCED, FAST, QUALITY, CUSTOM }

@Serializable
enum class ReasoningDepthV1 { QUICK, BALANCED, DEEP }

@Serializable
enum class ModelModuleTypeV1 {
    PROMPT_CAPSULE,
    EXPRESSION_EQ,
    LORA_ADAPTER,
    KNOWLEDGE_PACK,
    TOOL_PACK,
    BEHAVIOR_SHARD,
}

@Serializable
enum class ModelModuleStateV1 {
    INSTALLED,
    ACTIVE,
    BLOCKED_INCOMPATIBLE,
    BLOCKED_RUNTIME,
    INVALID,
}

@Serializable
enum class ModelModuleTrustV1 { BUILTIN, LOCAL_HASH_VERIFIED }

@Serializable
enum class ModelRackRollbackKindV1 { PROFILE, MODEL }

/**
 * Presentation and response-shaping controls. Values are 0..100.
 * These controls cannot modify deterministic truth, approval, permission, or execution gates.
 */
@Serializable
data class ExpressionEqV1(
    val warmth: Int = 55,
    val energy: Int = 50,
    val humor: Int = 35,
    val directness: Int = 65,
    val creativity: Int = 45,
    val technicalDepth: Int = 60,
    val skepticism: Int = 65,
    val verbosity: Int = 45,
    val mythicExpression: Int = 30,
) {
    fun normalized(): ExpressionEqV1 = copy(
        warmth = warmth.coerceIn(0, 100),
        energy = energy.coerceIn(0, 100),
        humor = humor.coerceIn(0, 100),
        directness = directness.coerceIn(0, 100),
        creativity = creativity.coerceIn(0, 100),
        technicalDepth = technicalDepth.coerceIn(0, 100),
        skepticism = skepticism.coerceIn(0, 100),
        verbosity = verbosity.coerceIn(0, 100),
        mythicExpression = mythicExpression.coerceIn(0, 100),
    )
}

@Serializable
data class ModelRuntimeProfileV1(
    val schemaVersion: Int = 1,
    val modelSha256: String,
    val generation: Long = 0,
    val speed: ModelSpeedV1 = ModelSpeedV1.BALANCED,
    val reasoningDepth: ReasoningDepthV1 = ReasoningDepthV1.BALANCED,
    val contextTokens: Int = 0,
    val maxOutputTokens: Int = 512,
    val temperature: Float = 0.1f,
    val topP: Float = 0.9f,
    val topK: Int = 50,
    val threads: Int = 0,
    val keepModelLoaded: Boolean = true,
    val autoUnloadOnMemoryPressure: Boolean = true,
    val expressionEq: ExpressionEqV1 = ExpressionEqV1(),
    val activeModuleIds: List<String> = emptyList(),
) {
    fun normalized(): ModelRuntimeProfileV1 = copy(
        modelSha256 = modelSha256.trim().lowercase().take(64),
        generation = generation.coerceAtLeast(0),
        contextTokens = if (contextTokens == 0) 0 else contextTokens.coerceIn(1_024, 32_768),
        maxOutputTokens = maxOutputTokens.coerceIn(32, 2_048),
        temperature = temperature.coerceIn(0f, 2f),
        topP = topP.coerceIn(0.05f, 1f),
        topK = topK.coerceIn(1, 200),
        threads = if (threads == 0) 0 else threads.coerceIn(1, 12),
        expressionEq = expressionEq.normalized(),
        activeModuleIds = activeModuleIds.map { it.trim() }.filter { it.isNotBlank() }.distinct().take(16),
    )
}

@Serializable
data class ModelRackModelV1(
    val sha256: String,
    val displayName: String,
    val sizeBytes: Long,
    val architecture: String? = null,
    val quantization: String? = null,
    val compatibility: String,
    val compatibilityDetail: String? = null,
    val selected: Boolean = false,
    val lastKnownGood: Boolean = false,
    val optimizedSwrlzBase: Boolean = false,
    val moduleInterfaces: List<String> = emptyList(),
    val metadata: Map<String, String> = emptyMap(),
)

@Serializable
data class ModelModulePayloadV1(
    val path: String,
    val sha256: String,
    val sizeBytes: Long,
    val mediaType: String = "application/octet-stream",
)

@Serializable
data class ModelModuleManifestV1(
    val schemaVersion: Int = 1,
    val id: String,
    val displayName: String,
    val version: String,
    val type: ModelModuleTypeV1,
    val description: String = "",
    val compatibleBaseSha256: List<String> = emptyList(),
    val requiredRuntimeContract: String = "prompt_capsule_v1",
    val payloads: List<ModelModulePayloadV1> = emptyList(),
    val conflicts: List<String> = emptyList(),
    val licenseId: String = "LicenseRef-User-Provided",
)

@Serializable
data class ModelRackModuleV1(
    val id: String,
    val displayName: String,
    val version: String,
    val type: ModelModuleTypeV1,
    val description: String = "",
    val state: ModelModuleStateV1,
    val trust: ModelModuleTrustV1,
    val active: Boolean,
    val compatible: Boolean,
    val blockedReason: String? = null,
    val compatibleBaseSha256: List<String> = emptyList(),
    val requiredRuntimeContract: String = "",
)

@Serializable
data class ModelRackSnapshotV1(
    val protocolVersion: Int = ModelRackProtocolV2.PROTOCOL_VERSION,
    val schemaVersion: Int = ModelRackProtocolV1.SCHEMA_VERSION,
    val rackGeneration: Long = 0,
    val selectedModelSha256: String? = null,
    val lastKnownGoodModelSha256: String? = null,
    val models: List<ModelRackModelV1> = emptyList(),
    val activeProfile: ModelRuntimeProfileV1? = null,
    val modules: List<ModelRackModuleV1> = emptyList(),
    val profileRollbackAvailable: Boolean = false,
    val modelRollbackAvailable: Boolean = false,
    val loraActivationAvailable: Boolean = false,
    val controlAuthority: String = "paired_lan_model_rack_only",
    val immutableSafeguards: List<String> = listOf(
        "truth_firewall",
        "permissions",
        "approvals",
        "provenance",
        "node_trust",
        "mission_authority",
        "forge_authority",
        "execution",
    ),
    val detail: String = "",
)

@Serializable
data class ModelProfileUpdateRequestV1(
    val expectedGeneration: Long,
    val profile: ModelRuntimeProfileV1,
)

@Serializable
data class ModelActivationRequestV1(
    val sha256: String,
    val deepCompatibilityTest: Boolean = true,
)

@Serializable
data class ModelModuleActivationRequestV1(
    val expectedGeneration: Long,
    val moduleId: String,
    val enabled: Boolean,
)

@Serializable
data class ModelRackRollbackRequestV1(
    val expectedGeneration: Long,
    val kind: ModelRackRollbackKindV1,
)

object ModelRackContractValidation {
    private val safeId = Regex("[a-z0-9][a-z0-9._-]{2,79}")
    private val safeVersion = Regex("[0-9A-Za-z][0-9A-Za-z._+-]{0,39}")
    private val sha256 = Regex("[a-f0-9]{64}")
    private val safePayload = Regex("[a-zA-Z0-9][a-zA-Z0-9._/-]{0,159}")

    fun validateProfile(profile: ModelRuntimeProfileV1): List<String> = buildList {
        if (!sha256.matches(profile.modelSha256.lowercase())) add("MODEL_SHA256_INVALID")
        if (profile != profile.normalized()) add("PROFILE_OUT_OF_RANGE")
    }

    fun validateManifest(manifest: ModelModuleManifestV1): List<String> = buildList {
        if (manifest.schemaVersion != 1) add("PACK_SCHEMA_UNSUPPORTED")
        if (!safeId.matches(manifest.id)) add("PACK_ID_INVALID")
        if (manifest.displayName.isBlank() || manifest.displayName.length > 80) add("PACK_NAME_INVALID")
        if (!safeVersion.matches(manifest.version)) add("PACK_VERSION_INVALID")
        if (manifest.description.length > 500) add("PACK_DESCRIPTION_TOO_LONG")
        if (manifest.compatibleBaseSha256.any { !sha256.matches(it.lowercase()) }) add("PACK_BASE_SHA_INVALID")
        if (manifest.compatibleBaseSha256.map { it.lowercase() }.distinct().size != manifest.compatibleBaseSha256.size) {
            add("PACK_BASE_DUPLICATE")
        }
        if (manifest.payloads.isEmpty()) add("PACK_PAYLOAD_REQUIRED")
        if (manifest.payloads.size > 16) add("PACK_TOO_MANY_PAYLOADS")
        if (manifest.payloads.map { it.path }.distinct().size != manifest.payloads.size) add("PACK_PAYLOAD_DUPLICATE")
        manifest.payloads.forEach { payload ->
            if (!safePayload.matches(payload.path) || payload.path.startsWith("/") || ".." in payload.path.split('/')) {
                add("PACK_PAYLOAD_PATH_INVALID")
            }
            if (!sha256.matches(payload.sha256.lowercase())) add("PACK_PAYLOAD_SHA_INVALID")
            if (payload.sizeBytes !in 1..536_870_912L) add("PACK_PAYLOAD_SIZE_INVALID")
        }
        if (manifest.conflicts.size > 16 || manifest.conflicts.any { !safeId.matches(it) }) add("PACK_CONFLICT_INVALID")
        when (manifest.type) {
            ModelModuleTypeV1.PROMPT_CAPSULE -> {
                if (manifest.requiredRuntimeContract != "prompt_capsule_v1") add("PROMPT_RUNTIME_CONTRACT_INVALID")
            }
            ModelModuleTypeV1.EXPRESSION_EQ -> {
                if (manifest.requiredRuntimeContract != "expression_eq_v1") add("EQ_RUNTIME_CONTRACT_INVALID")
            }
            ModelModuleTypeV1.LORA_ADAPTER -> {
                if (manifest.requiredRuntimeContract != "lora_adapter_v1") add("LORA_RUNTIME_CONTRACT_INVALID")
            }
            ModelModuleTypeV1.BEHAVIOR_SHARD -> {
                if (manifest.requiredRuntimeContract != ModelRackProtocolV2.BEHAVIOR_RUNTIME_CONTRACT) {
                    add("BEHAVIOR_RUNTIME_CONTRACT_INVALID")
                }
            }
            else -> Unit
        }
    }.distinct()
}
