package sh.swrlz.theme

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ThemeContractTest {
    @Test
    fun builtInCatalogHasUniqueValidIdsAndAResolvableDefault() {
        val ids = BuiltInThemePacks.all.map(ThemePack::id)
        assertEquals(ids.size, ids.toSet().size)
        assertEquals(DEFAULT_THEME_ID, BuiltInThemePacks.registry.resolve(null, ThemeTarget.CLIENT).id)
        BuiltInThemePacks.all.forEach { pack ->
            val result = ThemeValidator.validatePack(pack, ThemeTarget.CLIENT)
            assertTrue("${pack.id}: ${result.errors}", result.isValid)
        }
    }

    @Test
    fun bootstrapRegistryFallsBackRemovedThemeSelectorsToDefault() {
        val registry = BuiltInThemePacks.registry
        assertEquals(DEFAULT_THEME_ID, registry.resolve("Glitch Teal", ThemeTarget.CLIENT).id)
        assertEquals(DEFAULT_THEME_ID, registry.resolve("Ice", ThemeTarget.CLIENT).id)
        assertEquals(DEFAULT_THEME_ID, registry.resolve("Jester", ThemeTarget.CLIENT).id)
    }

    @Test
    fun everySelectableThemeDeclaresResolvableChromeAndKapanionIdentity() {
        val registry = BuiltInThemePacks.registry
        fun resolves(pack: ThemePack, roleName: String): Boolean {
            val role = SemanticAssetRole.fromWireName(roleName) ?: return false
            val visited = mutableSetOf<String>()
            var current = pack
            while (visited.add(current.id)) {
                if (current.asset(role) != null) return true
                current = current.fallbacks.asSequence().mapNotNull(registry::find).firstOrNull()
                    ?: return false
            }
            return false
        }

        registry.selectable(ThemeTarget.CLIENT).forEach { pack ->
            assertTrue("${pack.id} background", resolves(pack, pack.chromeStyle.backgroundArtRole))
            assertTrue("${pack.id} kapanion", resolves(pack, pack.chromeStyle.kapanionRole))
            assertTrue("${pack.id} voice core", resolves(pack, pack.chromeStyle.voiceCoreRole))
            val launcherRole = pack.launcherIdentity?.clientRole
            assertTrue(
                "${pack.id} CLIENT launcher",
                launcherRole != null && resolves(pack, launcherRole)
            )
        }
        assertTrue(
            BuiltInThemePacks.glitchDragonGlass
                .asset(SemanticAssetRole.LauncherClient)
                ?.path
                ?.contains("swrlz_glitch_dragon_launcher") == true
        )
    }


    @Test
    fun suppliedIgnitionFamiliesDeclareAllEightStartupRoles() {
        val expected = listOf(
            BuiltInThemePacks.jesterGlitchDragon,
            BuiltInThemePacks.dragonKamileon,
            BuiltInThemePacks.jade,
            BuiltInThemePacks.frost,
            BuiltInThemePacks.crystalCyber,
            BuiltInThemePacks.inferno,
        )
        val required = setOf(
            SemanticAssetRole.StartupDormant,
            SemanticAssetRole.StartupSpark,
            SemanticAssetRole.StartupPartial,
            SemanticAssetRole.StartupAwakened,
            SemanticAssetRole.StartupShockwave,
            SemanticAssetRole.StartupParticles,
            SemanticAssetRole.StartupRadial,
            SemanticAssetRole.StartupResidual,
        )
        expected.forEach { pack ->
            assertTrue("${pack.id} startup sequence", pack.startupSequence != null)
            required.forEach { role ->
                assertTrue("${pack.id} missing ${role.wireName}", pack.asset(role) != null)
            }
        }
    }

    @Test
    fun themedProgressGeometryKeepsEveryLayerInsideItsTrack() {
        BuiltInThemePacks.all.forEach { pack ->
            assertTrue("${pack.id} start inset", pack.progressStyle.trackStartInsetDp >= 0f)
            assertTrue("${pack.id} end inset", pack.progressStyle.trackEndInsetDp >= 0f)
            assertTrue(
                "${pack.id} vertical inset",
                pack.progressStyle.trackVerticalInsetDp * 2f < pack.dimensions.progressHeightDp
            )
        }
    }

    @Test
    fun archiveValidationRejectsTraversalLinksAndExecutables() {
        val result = ThemeValidator.validateArchiveEntries(
            listOf(
                ThemeArchiveEntry("../escape.png", 10, 10),
                ThemeArchiveEntry("images/link.png", 10, 10, isSymlink = true),
                ThemeArchiveEntry("scripts/run.sh", 10, 10),
            )
        )
        assertFalse(result.isValid)
        assertTrue(result.errors.any { it.code == "unsafe_path" })
        assertTrue(result.errors.any { it.code == "link_entry" })
        assertTrue(result.errors.any { it.code == "unsupported_entry" })
    }

    @Test
    fun archiveValidationAcceptsOneRootManifestAndDeclarativeImages() {
        val result = ThemeValidator.validateArchiveEntries(
            listOf(
                ThemeArchiveEntry("manifest.json", 300, 900),
                ThemeArchiveEntry("images/", 0, 0, isDirectory = true),
                ThemeArchiveEntry("images/progress.webp", 100, 200),
            )
        )
        assertTrue(result.errors.toString(), result.isValid)
    }

    @Test
    fun customAssetsRequireIntegrityAndDimensionMetadata() {
        val pack = BuiltInThemePacks.inferno.copy(
            id = "sh.swrlz.custom.incomplete",
            status = ThemePackStatus.CUSTOM,
            assets = mapOf(
                SemanticAssetRole.ProgressFrame.wireName to ThemeAssetSpec("progress/frame.webp"),
                SemanticAssetRole.ProgressFill.wireName to ThemeAssetSpec("progress/fill.webp"),
            ),
        )
        val result = ThemeValidator.validatePack(pack, ThemeTarget.CLIENT)
        assertFalse(result.isValid)
        assertTrue(result.errors.any { it.code == "asset_checksum" })
        assertTrue(result.errors.any { it.code == "asset_dimensions" })
    }
}
