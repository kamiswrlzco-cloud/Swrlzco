package sh.swrlz.theme

import java.util.Locale

/**
 * Immutable registry. CLIENT and SERVER instantiate this same catalog but keep
 * their selected IDs in separate local preference stores.
 */
class ThemeRegistry(packs: Iterable<ThemePack>) {
    private val ordered = packs.toList()
    private val byId = ordered.associateBy(ThemePack::id)
    private val selectors: Map<String, String> = buildMap {
        ordered.forEach { pack ->
            put(pack.id.selectorKey(), pack.id)
            put(pack.displayName.selectorKey(), pack.id)
            pack.aliases.forEach { put(it.selectorKey(), pack.id) }
        }
    }

    init {
        require(DEFAULT_THEME_ID in byId) { "Default theme is missing" }
        require(byId.size == ordered.size) { "Theme IDs must be unique" }
        ordered.forEach { pack ->
            require(pack.fallbacks.all(byId::containsKey)) {
                "Theme ${pack.id} references an unknown fallback"
            }
            require(!hasFallbackCycle(pack)) { "Theme fallback cycle starts at ${pack.id}" }
        }
    }

    fun all(): List<ThemePack> = ordered

    fun selectable(target: ThemeTarget): List<ThemePack> =
        ordered.filter { it.selectable && it.supports(target) }

    fun find(selector: String?): ThemePack? {
        val value = selector?.trim().orEmpty()
        if (value.isEmpty()) return null
        return byId[value] ?: selectors[value.selectorKey()]?.let(byId::get)
    }

    fun resolve(selector: String?, target: ThemeTarget): ThemePack {
        val requested = find(selector) ?: byId.getValue(DEFAULT_THEME_ID)
        if (requested.supports(target)) return requested
        return resolveFallback(requested, target)
    }

    fun resolveFallback(pack: ThemePack, target: ThemeTarget): ThemePack {
        val visited = linkedSetOf<String>()
        var current = pack
        while (visited.add(current.id)) {
            val next = current.fallbacks.asSequence()
                .mapNotNull(byId::get)
                .firstOrNull { it.supports(target) }
                ?: break
            if (next.supports(target)) return next
            current = next
        }
        return byId.getValue(DEFAULT_THEME_ID)
    }

    private fun String.selectorKey(): String =
        trim().lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_')

    private fun hasFallbackCycle(start: ThemePack): Boolean {
        fun visit(id: String, path: MutableSet<String>): Boolean {
            if (!path.add(id)) return true
            val cyclic = byId[id]?.fallbacks.orEmpty().any { visit(it, path) }
            path.remove(id)
            return cyclic
        }
        return visit(start.id, mutableSetOf())
    }
}
