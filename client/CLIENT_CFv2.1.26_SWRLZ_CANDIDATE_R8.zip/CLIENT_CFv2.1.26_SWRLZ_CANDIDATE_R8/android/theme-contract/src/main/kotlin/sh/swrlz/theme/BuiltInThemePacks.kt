package sh.swrlz.theme

object BuiltInThemePacks {
    private const val SPLIT_PACK_01 = "adfffaa46a72f241f0dfe036278b0b1e9264db3e489041d93c1a61876f8c06e3"
    private const val SPLIT_PACK_05 = "a2581366f10e324277e6f79c5680d81bb4df51824ffe43e1546ade0e7277d01b"
    private const val SPLIT_PACK_06 = "6e98f0f65124d89d31afe0c556ee693f0816af40cbece4ac03faaf897f45ae96"
    private const val JESTER_PROGRESS = "b8a8b57be01ca95327a9604616dd26836719eb822b14b0e2782809d8381fe9ef"
    private const val JESTER_STARTUP = "8499f5aaab30540076a4c99bfc967bc8d18fd65bedbd22d0701ede06a0a6ecef"
    private const val IGNITION_RESOURCE_PACK = "fc5e41188e429cf5b088f8da47ead713ba0e39849b75e79e6f5011e532d58c3c"

    private fun palette(
        background: String,
        surface: String,
        panel: String,
        elevated: String,
        primary: String,
        secondary: String,
        tertiary: String,
        text: String,
        secondaryText: String,
        mutedText: String,
    ) = ThemePalette(background, surface, panel, elevated, primary, secondary, tertiary, text, secondaryText, mutedText)

    private fun asset(
        name: String,
        mode: ThemeAssetScaleMode = ThemeAssetScaleMode.FIT,
        extension: String = "webp",
    ): ThemeAssetSpec = ThemeAssetSpec(path = "images/$name.$extension", scaleMode = mode)

    private fun progressAssets(slug: String): Map<String, ThemeAssetSpec> = mapOf(
        SemanticAssetRole.ProgressFrame.wireName to asset("theme_progress_${slug}_frame", ThemeAssetScaleMode.STRETCH),
        SemanticAssetRole.ProgressFill.wireName to asset("theme_progress_${slug}_fill", ThemeAssetScaleMode.TILE_X),
        SemanticAssetRole.ProgressHead.wireName to asset("theme_progress_${slug}_head"),
        SemanticAssetRole.ProgressParticles.wireName to asset("theme_progress_${slug}_particles", ThemeAssetScaleMode.STRETCH),
        SemanticAssetRole.ProgressEmblem.wireName to asset("theme_progress_${slug}_emblem"),
        SemanticAssetRole.ProgressComplete.wireName to asset("theme_progress_${slug}_complete"),
        SemanticAssetRole.ProgressFailureInterruption.wireName to asset("theme_progress_${slug}_failure", ThemeAssetScaleMode.STRETCH),
        SemanticAssetRole.ProgressAmbient.wireName to asset("theme_progress_${slug}_ambient", ThemeAssetScaleMode.STRETCH),
        SemanticAssetRole.ProgressHighlight.wireName to asset("theme_progress_${slug}_highlight", ThemeAssetScaleMode.STRETCH),
    )

    private fun identityAssets(slug: String): Map<String, ThemeAssetSpec> = mapOf(
        SemanticAssetRole.LauncherClient.wireName to asset("theme_launcher_client_$slug"),
        SemanticAssetRole.LauncherServer.wireName to asset("theme_launcher_server_$slug"),
        SemanticAssetRole.KapanionShared.wireName to asset("theme_kapanion_$slug"),
        SemanticAssetRole.BackgroundApp.wireName to asset(
            "theme_kapanion_$slug",
            ThemeAssetScaleMode.CENTER_CROP,
        ),
    )

    private fun legacyIdentityAssets(
        launcherResource: String,
        kapanionResource: String,
        backgroundResource: String = kapanionResource,
    ): Map<String, ThemeAssetSpec> = mapOf(
        SemanticAssetRole.LauncherClient.wireName to asset(launcherResource, extension = "png"),
        SemanticAssetRole.KapanionShared.wireName to asset(kapanionResource, extension = "png"),
        SemanticAssetRole.BackgroundApp.wireName to asset(
            backgroundResource,
            ThemeAssetScaleMode.CENTER_CROP,
            extension = "png",
        ),
    )

    private fun startupAssets(
        slug: String,
        extension: String = "webp",
    ): Map<String, ThemeAssetSpec> = mapOf(
        SemanticAssetRole.StartupDormant.wireName to asset("theme_startup_${slug}_dormant", extension = extension),
        SemanticAssetRole.StartupSpark.wireName to asset("theme_startup_${slug}_spark", extension = extension),
        SemanticAssetRole.StartupPartial.wireName to asset("theme_startup_${slug}_partial", extension = extension),
        SemanticAssetRole.StartupAwakened.wireName to asset("theme_startup_${slug}_awakened", extension = extension),
        SemanticAssetRole.StartupShockwave.wireName to asset("theme_startup_${slug}_shockwave", extension = extension),
        SemanticAssetRole.StartupParticles.wireName to asset("theme_startup_${slug}_particles", extension = extension),
        SemanticAssetRole.StartupRadial.wireName to asset(
            "theme_startup_${slug}_radial",
            ThemeAssetScaleMode.FILL,
            extension,
        ),
        SemanticAssetRole.StartupResidual.wireName to asset("theme_startup_${slug}_residual", extension = extension),
    )

    private fun progressStyle(
        startInsetDp: Float = 14f,
        endInsetDp: Float = 14f,
        verticalInsetDp: Float = 8f,
        headWidthDp: Float = 58f,
        segmentFraction: Float = .32f,
    ) = ThemeProgressStyle(
        trackStartInsetDp = startInsetDp,
        trackEndInsetDp = endInsetDp,
        trackVerticalInsetDp = verticalInsetDp,
        headWidthDp = headWidthDp,
        indeterminateSegmentFraction = segmentFraction,
    )

    private fun chrome(
        motif: ThemeChromeMotif,
        backgroundArtRole: SemanticAssetRole = SemanticAssetRole.BackgroundApp,
        kapanionRole: SemanticAssetRole = SemanticAssetRole.KapanionShared,
        backgroundArtAlpha: Float = .22f,
        ornamentAlpha: Float = .34f,
        edgeComplexity: Int = 3,
        ambientTiltDegrees: Float = 1.5f,
    ) = ThemeChromeStyle(
        motif = motif,
        backgroundArtRole = backgroundArtRole.wireName,
        kapanionRole = kapanionRole.wireName,
        voiceCoreRole = kapanionRole.wireName,
        backgroundArtAlpha = backgroundArtAlpha,
        panelOrnamentAlpha = ornamentAlpha,
        edgeComplexity = edgeComplexity,
        ambientTiltDegrees = ambientTiltDegrees,
    )

    private fun pack(
        id: String,
        displayName: String,
        aliases: Set<String>,
        palette: ThemePalette,
        personality: String,
        assets: Map<String, ThemeAssetSpec> = emptyMap(),
        provenance: Map<String, String> = emptyMap(),
        status: ThemePackStatus = ThemePackStatus.BUILT_IN,
        selectable: Boolean = true,
        startup: ThemeStartupSequence? = null,
        launcher: ThemeLauncherIdentity? = null,
        kapanion: ThemeKapanionIdentity? = null,
        typography: ThemeTypography = ThemeTypography(),
        shapes: ThemeShapes = ThemeShapes(),
        dimensions: ThemeDimensions = ThemeDimensions(),
        progressStyle: ThemeProgressStyle = ThemeProgressStyle(),
        chromeStyle: ThemeChromeStyle = ThemeChromeStyle(),
        motionBaseDurationMs: Int = 280,
        pulseScale: Float = 1.035f,
        particleSpeedMultiplier: Float = 1f,
    ) = ThemePack(
        id = id,
        displayName = displayName,
        themeVersion = ThemeSemVer(1, 0, 0),
        status = status,
        selectable = selectable,
        aliases = aliases,
        palette = palette,
        typography = typography,
        shapes = shapes,
        dimensions = dimensions,
        progressStyle = progressStyle,
        chromeStyle = chromeStyle,
        motionProfile = ThemeMotionProfile(
            personality,
            motionBaseDurationMs,
            pulseScale,
            particleSpeedMultiplier,
        ),
        particleStyle = ThemeParticleStyle(1f, .74f, .35f),
        assets = assets,
        provenance = provenance,
        startupSequence = startup,
        launcherIdentity = launcher,
        kapanionIdentity = kapanion,
        fallbacks = if (id == DEFAULT_THEME_ID) emptyList() else listOf(DEFAULT_THEME_ID),
    )

    val glitchDragonGlass = pack(
        id = DEFAULT_THEME_ID,
        displayName = "Glitch Dragon Glass",
        aliases = setOf("Glitch Dragon Glass / Dark"),
        palette = palette("#03030B", "#081020", "#0A1020", "#151C36", "#38E8FF", "#9A55FF", "#4DFFCF", "#F7FBFF", "#D7E7F5", "#91A9C0"),
        personality = "glass pulse",
        assets = legacyIdentityAssets(
            launcherResource = "swrlz_glitch_dragon_launcher",
            kapanionResource = "swrlz_client_bubble_glitch_dragon",
        ) + mapOf(
            SemanticAssetRole.BackgroundApp.wireName to asset(
                "theme_background_glitch_dragon_glass",
                ThemeAssetScaleMode.CENTER_CROP,
            )
        ),
        launcher = ThemeLauncherIdentity(clientRole = SemanticAssetRole.LauncherClient.wireName),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.KapanionShared.wireName),
        chromeStyle = chrome(
            ThemeChromeMotif.GLASS_SHARD,
            backgroundArtAlpha = .28f,
            ornamentAlpha = .42f,
            edgeComplexity = 4,
        ),
    )

    val dragonKamileon = pack(
        id = "sh.swrlz.theme.dragon_kamileon",
        displayName = "Dragon Kamileon",
        aliases = setOf("Kamileon", "Dragon Kamileon / Dark"),
        palette = palette("#05030A", "#0C0914", "#171026", "#21163A", "#22E4D5", "#FF4FC8", "#FFD43B", "#FFFBFF", "#EADFFC", "#A99AB9"),
        personality = "prismatic drift",
        motionBaseDurationMs = 260,
        pulseScale = 1.04f,
        particleSpeedMultiplier = 1.1f,
        assets = progressAssets("kamileon") + identityAssets("kamileon") + startupAssets("kamileon"),
        provenance = mapOf("progressPackSha256" to SPLIT_PACK_06, "identityPackSha256" to SPLIT_PACK_01, "startupPackSha256" to IGNITION_RESOURCE_PACK),
        startup = ThemeStartupSequence(),
        launcher = ThemeLauncherIdentity(SemanticAssetRole.LauncherClient.wireName, SemanticAssetRole.LauncherServer.wireName),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.KapanionShared.wireName),
        dimensions = ThemeDimensions(progressHeightDp = 56f),
        progressStyle = progressStyle(18f, 18f, 10f, 64f, .28f),
        chromeStyle = chrome(
            ThemeChromeMotif.PRISMATIC,
            backgroundArtAlpha = .24f,
            ornamentAlpha = .48f,
            edgeComplexity = 5,
            ambientTiltDegrees = 2.4f,
        ),
    )

    val originalCore = pack(
        id = "sh.swrlz.theme.original_core",
        displayName = "Original Core",
        aliases = setOf("Original Core / Dark"),
        palette = palette("#050607", "#090D10", "#0D1216", "#11181D", "#40EFFF", "#FFD75A", "#C95DFF", "#F5F7FA", "#D5DDE5", "#8A969F"),
        personality = "measured core",
        assets = legacyIdentityAssets(
            "ic_launcher_original_core_foreground",
            "swrlz_client_bubble_original_core",
        ),
        launcher = ThemeLauncherIdentity(clientRole = SemanticAssetRole.LauncherClient.wireName),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.KapanionShared.wireName),
        chromeStyle = chrome(
            ThemeChromeMotif.CORE_CIRCUIT,
            backgroundArtAlpha = .18f,
            ornamentAlpha = .28f,
            edgeComplexity = 2,
            ambientTiltDegrees = 0f,
        ),
    )

    val glitchNeon = pack(
        id = "sh.swrlz.theme.glitch_neon",
        displayName = "Glitch Neon",
        aliases = setOf("Glitch Teal", "Glitch Neon / Dark"),
        palette = palette("#03020A", "#070513", "#100A24", "#171033", "#00EFFF", "#FF2DFF", "#7B3CFF", "#F8F6FF", "#D7D2FF", "#8A7DAD"),
        personality = "electric scan",
        assets = legacyIdentityAssets(
            "ic_launcher_glitch_neon_foreground",
            "swrlz_client_bubble_glitch_neon",
        ),
        launcher = ThemeLauncherIdentity(clientRole = SemanticAssetRole.LauncherClient.wireName),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.KapanionShared.wireName),
        chromeStyle = chrome(
            ThemeChromeMotif.NEON_SCAN,
            backgroundArtAlpha = .22f,
            ornamentAlpha = .44f,
            edgeComplexity = 4,
            ambientTiltDegrees = -1.5f,
        ),
    )

    val pharaohEmerald = pack(
        id = "sh.swrlz.theme.pharaoh_emerald",
        displayName = "Pharaoh Emerald",
        aliases = setOf("Pharaoh Gold", "Pharaoh Emerald / Dark"),
        palette = palette("#030807", "#06100D", "#0C1A14", "#12271E", "#00E6B0", "#FFD166", "#0E8F72", "#FFF7E0", "#E8DDBF", "#9E9274"),
        personality = "royal orbit",
        assets = legacyIdentityAssets(
            "ic_launcher_pharaoh_emerald_foreground",
            "swrlz_client_bubble_pharaoh_emerald",
        ),
        launcher = ThemeLauncherIdentity(clientRole = SemanticAssetRole.LauncherClient.wireName),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.KapanionShared.wireName),
        typography = ThemeTypography(displayFamily = "serif", bodyFamily = "sans-serif"),
        shapes = ThemeShapes(controlCornerDp = 6f, cardCornerDp = 10f, dialogCornerDp = 16f),
        chromeStyle = chrome(
            ThemeChromeMotif.PHARAOH_GLYPH,
            backgroundArtAlpha = .21f,
            ornamentAlpha = .46f,
            edgeComplexity = 4,
            ambientTiltDegrees = 0f,
        ),
    )

    val voidJester = pack(
        id = "sh.swrlz.theme.void_jester",
        displayName = "Void Jester",
        aliases = setOf("Void Jester / Dark"),
        palette = palette("#05000B", "#0D0418", "#190A2A", "#24103C", "#9B5CFF", "#FFC857", "#FF3DDA", "#FFF8FF", "#E6D7FF", "#9C86B8"),
        personality = "mischief flicker",
        assets = legacyIdentityAssets(
            "ic_launcher_void_jester_foreground",
            "swrlz_client_bubble_void_jester",
        ),
        launcher = ThemeLauncherIdentity(clientRole = SemanticAssetRole.LauncherClient.wireName),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.KapanionShared.wireName),
        shapes = ThemeShapes(controlCornerDp = 7f, cardCornerDp = 12f, dialogCornerDp = 18f),
        chromeStyle = chrome(
            ThemeChromeMotif.VOID_JESTER,
            backgroundArtAlpha = .23f,
            ornamentAlpha = .48f,
            edgeComplexity = 5,
            ambientTiltDegrees = 2f,
        ),
    )

    val inferno = pack(
        id = "sh.swrlz.theme.inferno",
        displayName = "Inferno",
        aliases = setOf("Inferno Dragon"),
        palette = palette("#080302", "#160807", "#22100A", "#32170D", "#FF6A00", "#FFB000", "#E23716", "#FFF3E8", "#E6C0A2", "#9C6F55"),
        personality = "magma surge",
        motionBaseDurationMs = 220,
        pulseScale = 1.055f,
        particleSpeedMultiplier = 1.25f,
        typography = ThemeTypography(displayFamily = "serif", bodyFamily = "sans-serif"),
        shapes = ThemeShapes(controlCornerDp = 8f, cardCornerDp = 12f, dialogCornerDp = 18f),
        assets = progressAssets("inferno") + identityAssets("inferno") + startupAssets("inferno"),
        provenance = mapOf("progressPackSha256" to SPLIT_PACK_05, "identityPackSha256" to SPLIT_PACK_01, "startupPackSha256" to IGNITION_RESOURCE_PACK),
        startup = ThemeStartupSequence(),
        launcher = ThemeLauncherIdentity(SemanticAssetRole.LauncherClient.wireName, SemanticAssetRole.LauncherServer.wireName),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.KapanionShared.wireName),
        dimensions = ThemeDimensions(progressHeightDp = 54f),
        progressStyle = progressStyle(14f, 14f, 9f, 62f, .30f),
        chromeStyle = chrome(
            ThemeChromeMotif.MAGMA,
            backgroundArtAlpha = .25f,
            ornamentAlpha = .48f,
            edgeComplexity = 4,
            ambientTiltDegrees = 1f,
        ),
    )

    val frost = pack(
        id = "sh.swrlz.theme.frost",
        displayName = "Frost",
        aliases = setOf("Ice", "Ice Dragon"),
        palette = palette("#02080E", "#061523", "#0B2438", "#10344D", "#75DFFF", "#B8F4FF", "#7F8DFF", "#F2FCFF", "#D7F2FA", "#86A9B7"),
        personality = "crystal glide",
        motionBaseDurationMs = 360,
        pulseScale = 1.018f,
        particleSpeedMultiplier = .72f,
        typography = ThemeTypography(displayFamily = "sans-serif", bodyFamily = "sans-serif"),
        shapes = ThemeShapes(controlCornerDp = 16f, cardCornerDp = 22f, dialogCornerDp = 26f),
        assets = progressAssets("frost") + identityAssets("frost") + startupAssets("frost"),
        provenance = mapOf("progressPackSha256" to SPLIT_PACK_05, "identityPackSha256" to SPLIT_PACK_01, "startupPackSha256" to IGNITION_RESOURCE_PACK),
        startup = ThemeStartupSequence(),
        launcher = ThemeLauncherIdentity(SemanticAssetRole.LauncherClient.wireName, SemanticAssetRole.LauncherServer.wireName),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.KapanionShared.wireName),
        dimensions = ThemeDimensions(progressHeightDp = 54f),
        progressStyle = progressStyle(16f, 16f, 9f, 60f, .32f),
        chromeStyle = chrome(
            ThemeChromeMotif.FROST,
            backgroundArtAlpha = .22f,
            ornamentAlpha = .40f,
            edgeComplexity = 4,
            ambientTiltDegrees = -.6f,
        ),
    )

    val jade = pack(
        id = "sh.swrlz.theme.jade",
        displayName = "Jade",
        aliases = setOf("Jade Dragon", "Emerald Dragon"),
        palette = palette("#020B07", "#061A12", "#0B291C", "#123A27", "#19E38C", "#A8FF58", "#16B8A1", "#F2FFF8", "#D1F0DE", "#79A28B"),
        personality = "jade current",
        motionBaseDurationMs = 300,
        pulseScale = 1.025f,
        particleSpeedMultiplier = .85f,
        typography = ThemeTypography(displayFamily = "serif", bodyFamily = "sans-serif"),
        shapes = ThemeShapes(controlCornerDp = 12f, cardCornerDp = 16f, dialogCornerDp = 22f),
        assets = progressAssets("jade") + identityAssets("jade") + startupAssets("jade"),
        provenance = mapOf("progressPackSha256" to SPLIT_PACK_05, "identityPackSha256" to SPLIT_PACK_01, "startupPackSha256" to IGNITION_RESOURCE_PACK),
        startup = ThemeStartupSequence(),
        launcher = ThemeLauncherIdentity(SemanticAssetRole.LauncherClient.wireName, SemanticAssetRole.LauncherServer.wireName),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.KapanionShared.wireName),
        dimensions = ThemeDimensions(progressHeightDp = 54f),
        progressStyle = progressStyle(15f, 15f, 9f, 60f, .31f),
        chromeStyle = chrome(
            ThemeChromeMotif.JADE_VINE,
            backgroundArtAlpha = .23f,
            ornamentAlpha = .44f,
            edgeComplexity = 4,
            ambientTiltDegrees = 1.2f,
        ),
    )

    val digitalGlitch = pack(
        id = "sh.swrlz.theme.digital_glitch",
        displayName = "Digital Glitch",
        aliases = setOf("Digital Glitch Green Magenta"),
        palette = palette("#050208", "#11081A", "#1B0D28", "#29123B", "#31FF9D", "#FF3BD4", "#6C5CFF", "#FFF7FF", "#E9D6F2", "#A58BAF"),
        personality = "packet stutter",
        motionBaseDurationMs = 170,
        pulseScale = 1.045f,
        particleSpeedMultiplier = 1.4f,
        typography = ThemeTypography(displayFamily = "monospace", bodyFamily = "sans-serif"),
        shapes = ThemeShapes(controlCornerDp = 4f, cardCornerDp = 8f, dialogCornerDp = 12f),
        assets = progressAssets("digital_glitch") + identityAssets("digital_glitch"),
        provenance = mapOf("progressPackSha256" to SPLIT_PACK_06, "identityPackSha256" to SPLIT_PACK_01),
        launcher = ThemeLauncherIdentity(SemanticAssetRole.LauncherClient.wireName, SemanticAssetRole.LauncherServer.wireName),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.KapanionShared.wireName),
        dimensions = ThemeDimensions(progressHeightDp = 54f),
        progressStyle = progressStyle(12f, 12f, 8f, 58f, .26f),
        chromeStyle = chrome(
            ThemeChromeMotif.DIGITAL_GLITCH,
            backgroundArtAlpha = .24f,
            ornamentAlpha = .50f,
            edgeComplexity = 5,
            ambientTiltDegrees = -2.2f,
        ),
    )

    val crystalCyber = pack(
        id = "sh.swrlz.theme.crystal_cyber",
        displayName = "Crystal Cyber",
        aliases = setOf("Crystal Cyber Blue Purple"),
        palette = palette("#040511", "#0A0D22", "#11183A", "#1A2450", "#58D7FF", "#A86CFF", "#FF6DEB", "#F7F8FF", "#DAE0F7", "#8D96BA"),
        personality = "faceted resonance",
        motionBaseDurationMs = 320,
        pulseScale = 1.03f,
        particleSpeedMultiplier = .82f,
        typography = ThemeTypography(displayFamily = "sans-serif", bodyFamily = "sans-serif"),
        shapes = ThemeShapes(controlCornerDp = 10f, cardCornerDp = 18f, dialogCornerDp = 24f),
        assets = progressAssets("crystal_cyber") + identityAssets("crystal_cyber") + startupAssets("crystal_cyber"),
        provenance = mapOf("progressPackSha256" to SPLIT_PACK_06, "identityPackSha256" to SPLIT_PACK_01, "startupPackSha256" to IGNITION_RESOURCE_PACK),
        startup = ThemeStartupSequence(),
        launcher = ThemeLauncherIdentity(SemanticAssetRole.LauncherClient.wireName, SemanticAssetRole.LauncherServer.wireName),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.KapanionShared.wireName),
        dimensions = ThemeDimensions(progressHeightDp = 56f),
        progressStyle = progressStyle(16f, 16f, 9f, 62f, .30f),
        chromeStyle = chrome(
            ThemeChromeMotif.CYBER_CRYSTAL,
            backgroundArtAlpha = .24f,
            ornamentAlpha = .46f,
            edgeComplexity = 5,
            ambientTiltDegrees = 1.8f,
        ),
    )

    val tealSerpent = pack(
        id = "sh.swrlz.theme.teal_serpent",
        displayName = "Teal Serpent",
        aliases = setOf("Teal"),
        palette = palette("#02100F", "#06201E", "#0B302D", "#12443F", "#32E6D0", "#74FFF0", "#2F8FAA", "#F2FFFD", "#CFF4EF", "#79A6A0"),
        personality = "serpent current",
        motionBaseDurationMs = 340,
        pulseScale = 1.022f,
        particleSpeedMultiplier = .78f,
        typography = ThemeTypography(displayFamily = "serif", bodyFamily = "sans-serif"),
        shapes = ThemeShapes(controlCornerDp = 18f, cardCornerDp = 24f, dialogCornerDp = 28f),
        assets = progressAssets("teal_serpent") + mapOf(
            SemanticAssetRole.LauncherClient.wireName to asset(
                "theme_launcher_client_teal_serpent",
            )
        ),
        provenance = mapOf("progressPackSha256" to SPLIT_PACK_06),
        status = ThemePackStatus.PARTIAL,
        launcher = ThemeLauncherIdentity(
            clientRole = SemanticAssetRole.LauncherClient.wireName,
            genericFallback = true,
        ),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.ProgressEmblem.wireName),
        dimensions = ThemeDimensions(progressHeightDp = 54f),
        progressStyle = progressStyle(16f, 16f, 9f, 60f, .31f),
        chromeStyle = chrome(
            ThemeChromeMotif.TEAL_SERPENT,
            backgroundArtRole = SemanticAssetRole.ProgressEmblem,
            kapanionRole = SemanticAssetRole.ProgressEmblem,
            backgroundArtAlpha = .20f,
            ornamentAlpha = .42f,
            edgeComplexity = 4,
            ambientTiltDegrees = .8f,
        ),
    )

    val jesterGlitchDragon = pack(
        id = "sh.swrlz.theme.jester_glitch_dragon",
        displayName = "Jester Glitch Dragon",
        aliases = setOf("Jester", "Jester Glitch"),
        palette = palette("#08020D", "#15071F", "#24102E", "#341842", "#B66CFF", "#FFD34E", "#FF3ED6", "#FFF8FF", "#EADAF5", "#A78AB3"),
        personality = "chaos ignition",
        motionBaseDurationMs = 190,
        pulseScale = 1.06f,
        particleSpeedMultiplier = 1.35f,
        typography = ThemeTypography(displayFamily = "monospace", bodyFamily = "sans-serif"),
        shapes = ThemeShapes(controlCornerDp = 6f, cardCornerDp = 10f, dialogCornerDp = 16f),
        assets = progressAssets("jester") + identityAssets("jester") + startupAssets("jester"),
        provenance = mapOf(
            "progressPackSha256" to JESTER_PROGRESS,
            "startupPackSha256" to JESTER_STARTUP,
            "identityPackSha256" to SPLIT_PACK_01,
        ),
        startup = ThemeStartupSequence(),
        launcher = ThemeLauncherIdentity(SemanticAssetRole.LauncherClient.wireName, SemanticAssetRole.LauncherServer.wireName),
        kapanion = ThemeKapanionIdentity(sharedRole = SemanticAssetRole.KapanionShared.wireName),
        dimensions = ThemeDimensions(progressHeightDp = 58f),
        progressStyle = progressStyle(28f, 20f, 10f, 68f, .27f),
        chromeStyle = chrome(
            ThemeChromeMotif.JESTER_CHAOS,
            backgroundArtAlpha = .25f,
            ornamentAlpha = .56f,
            edgeComplexity = 6,
            ambientTiltDegrees = 3.4f,
        ),
    )

    val all: List<ThemePack> = listOf(
        glitchDragonGlass,
    )

    val registry = ThemeRegistry(all)
}
