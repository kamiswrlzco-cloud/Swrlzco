package sh.swrlz.theme

import java.util.Locale

data class ThemeValidationIssue(
    val code: String,
    val detail: String,
)

data class ThemeValidationResult(
    val errors: List<ThemeValidationIssue>,
    val warnings: List<ThemeValidationIssue>,
) {
    val isValid: Boolean get() = errors.isEmpty()
}

data class ThemeArchiveEntry(
    val path: String,
    val compressedBytes: Long,
    val unpackedBytes: Long,
    val isDirectory: Boolean = false,
    val isEncrypted: Boolean = false,
    val isSymlink: Boolean = false,
)

data class ThemeValidationLimits(
    val maxCompressedBytes: Long = 64L * 1024L * 1024L,
    val maxUnpackedBytes: Long = 160L * 1024L * 1024L,
    val maxFileBytes: Long = 16L * 1024L * 1024L,
    val maxEntries: Int = 512,
    val maxImageEdge: Int = 4096,
    val maxImagePixels: Long = 16_000_000L,
    val maxCompressionRatio: Long = 120L,
)

/**
 * Declarative validation only. It does not execute pack content and it does not
 * grant assets application permissions, network access, or application state.
 */
object ThemeValidator {
    private val idPattern = Regex("^[a-z][a-z0-9]*(?:\\.[a-z0-9_]+){2,}$")
    private val shaPattern = Regex("^[a-fA-F0-9]{64}$")
    private val colorPattern = Regex("^#[a-fA-F0-9]{6}(?:[a-fA-F0-9]{2})?$")
    private val supportedExtensions = setOf("png", "webp")

    fun validatePack(
        pack: ThemePack,
        target: ThemeTarget,
        engineVersion: ThemeSemVer = ThemeSemVer(1, 0, 0),
        existingIds: Set<String> = emptySet(),
        limits: ThemeValidationLimits = ThemeValidationLimits(),
    ): ThemeValidationResult {
        val errors = mutableListOf<ThemeValidationIssue>()
        val warnings = mutableListOf<ThemeValidationIssue>()

        if (pack.manifestVersion != THEME_MANIFEST_VERSION) {
            errors += issue("manifest_version", "Unsupported manifest version ${pack.manifestVersion}")
        }
        if (!idPattern.matches(pack.id)) errors += issue("theme_id", "Theme ID is not a stable reverse-domain ID")
        if (pack.id in existingIds) errors += issue("duplicate_theme_id", "Theme ID already exists")
        if (pack.displayName.isBlank()) errors += issue("display_name", "Display name is required")
        if (engineVersion < pack.compatibility.minEngineVersion ||
            engineVersion.major > pack.compatibility.maxEngineMajor
        ) {
            errors += issue("engine_compatibility", "Theme is not compatible with engine $engineVersion")
        }
        if (!pack.supports(target)) errors += issue("target", "Theme does not support $target")
        if (pack.soundProfile != null) warnings += issue("sound_deferred", "Sound profiles are reserved and ignored in manifest v1")
        validatePalette(pack.palette, errors)
        validatePresentationValues(pack, errors)

        pack.assets.forEach { (roleName, asset) ->
            if (SemanticAssetRole.fromWireName(roleName) == null) {
                errors += issue("asset_role", "Unsupported semantic role: $roleName")
            }
            validateAsset(roleName, asset, limits, errors)
            if (pack.status == ThemePackStatus.CUSTOM) {
                if (asset.sha256 == null) errors += issue("asset_checksum", "Custom asset requires SHA-256: $roleName")
                if (asset.bytes == null) errors += issue("asset_size", "Custom asset requires a declared byte size: $roleName")
                if (asset.width == null || asset.height == null) {
                    errors += issue("asset_dimensions", "Custom asset requires decoded dimensions: $roleName")
                }
            }
        }
        validateFallbacks(pack, errors)
        val requiredProgress = setOf(
            SemanticAssetRole.ProgressFrame.wireName,
            SemanticAssetRole.ProgressFill.wireName,
        )
        if (pack.status == ThemePackStatus.CUSTOM &&
            requiredProgress.any { it !in pack.assets } &&
            pack.fallbacks.isEmpty()
        ) {
            errors += issue("missing_required_asset", "Missing progress roles require a known-good fallback")
        }

        return ThemeValidationResult(errors.distinct(), warnings.distinct())
    }

    fun validateArchiveEntries(
        entries: List<ThemeArchiveEntry>,
        limits: ThemeValidationLimits = ThemeValidationLimits(),
    ): ThemeValidationResult {
        val errors = mutableListOf<ThemeValidationIssue>()
        val warnings = mutableListOf<ThemeValidationIssue>()
        if (entries.size > limits.maxEntries) errors += issue("entry_count", "Archive has too many entries")

        val seen = mutableSetOf<String>()
        var compressedTotal = 0L
        var unpackedTotal = 0L
        var manifestCount = 0
        entries.forEach { entry ->
            if (entry.compressedBytes < 0 || entry.unpackedBytes < 0) {
                errors += issue("negative_size", "Archive entry has a negative size: ${entry.path}")
            }
            compressedTotal = safeAdd(compressedTotal, entry.compressedBytes)
            unpackedTotal = safeAdd(unpackedTotal, entry.unpackedBytes)
            val path = entry.path
            val normalizedPath = if (entry.isDirectory) path.trimEnd('/') else path
            val folded = normalizedPath.lowercase(Locale.ROOT)
            if (!isSafeRelativePath(normalizedPath)) errors += issue("unsafe_path", "Unsafe archive path: $path")
            if (!seen.add(folded)) errors += issue("path_collision", "Duplicate or case-folding path collision: $path")
            if (entry.isEncrypted) errors += issue("encrypted_entry", "Encrypted archive entries are not supported")
            if (entry.isSymlink) errors += issue("link_entry", "Links are not supported")
            if (!entry.isDirectory) {
                if (normalizedPath == "manifest.json") manifestCount += 1
                val extension = folded.substringAfterLast('.', "")
                if (normalizedPath != "manifest.json" && extension !in supportedExtensions) {
                    errors += issue("unsupported_entry", "Unsupported theme-package entry: $path")
                }
            }
            if (!entry.isDirectory && entry.unpackedBytes > limits.maxFileBytes) {
                errors += issue("file_size", "Archive entry exceeds the per-file limit: $path")
            }
            if (entry.compressedBytes > 0 &&
                entry.unpackedBytes / entry.compressedBytes.coerceAtLeast(1L) > limits.maxCompressionRatio
            ) {
                errors += issue("compression_ratio", "Suspicious compression ratio: $path")
            }
        }
        if (manifestCount != 1) errors += issue("manifest_entry", "Archive must contain exactly one root manifest.json")
        if (compressedTotal > limits.maxCompressedBytes) errors += issue("archive_size", "Compressed archive exceeds limit")
        if (unpackedTotal > limits.maxUnpackedBytes) errors += issue("unpacked_size", "Unpacked archive exceeds limit")
        return ThemeValidationResult(errors.distinct(), warnings)
    }

    fun isSafeRelativePath(path: String): Boolean {
        if (path.isBlank() || path.startsWith('/') || path.startsWith('\\') || '\\' in path || ':' in path) return false
        val segments = path.split('/')
        return segments.none { it.isBlank() || it == "." || it == ".." }
    }

    private fun validateAsset(
        roleName: String,
        asset: ThemeAssetSpec,
        limits: ThemeValidationLimits,
        errors: MutableList<ThemeValidationIssue>,
    ) {
        if (!isSafeRelativePath(asset.path)) errors += issue("asset_path", "Unsafe path for $roleName")
        val extension = asset.path.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (extension !in supportedExtensions) errors += issue("asset_type", "Unsupported asset type for $roleName")
        if (asset.sha256 != null && !shaPattern.matches(asset.sha256)) errors += issue("asset_checksum", "Invalid SHA-256 for $roleName")
        if (asset.bytes != null && asset.bytes > limits.maxFileBytes) errors += issue("asset_size", "Asset exceeds per-file limit: $roleName")
        if (asset.width != null && asset.height != null) {
            if (asset.width <= 0 || asset.height <= 0) errors += issue("asset_dimensions", "Invalid dimensions for $roleName")
            if (asset.width > limits.maxImageEdge || asset.height > limits.maxImageEdge ||
                asset.width.toLong() * asset.height.toLong() > limits.maxImagePixels
            ) {
                errors += issue("asset_dimensions", "Image dimensions exceed limits for $roleName")
            }
        }
    }

    private fun validateFallbacks(pack: ThemePack, errors: MutableList<ThemeValidationIssue>) {
        if (pack.id in pack.fallbacks) errors += issue("fallback_cycle", "Theme cannot fall back to itself")
        if (pack.fallbacks.size != pack.fallbacks.distinct().size) errors += issue("fallback_duplicate", "Fallback IDs must be unique")
    }

    private fun validatePalette(
        palette: ThemePalette,
        errors: MutableList<ThemeValidationIssue>,
    ) {
        val values = listOf(
            palette.background,
            palette.surface,
            palette.panel,
            palette.elevated,
            palette.primary,
            palette.secondary,
            palette.tertiary,
            palette.text,
            palette.secondaryText,
            palette.mutedText,
            palette.success,
            palette.warning,
            palette.danger,
            palette.info,
            palette.admin,
        )
        if (values.any { !colorPattern.matches(it) }) {
            errors += issue("palette_color", "Palette colors must use #RRGGBB or #AARRGGBB")
        }
    }

    private fun validatePresentationValues(
        pack: ThemePack,
        errors: MutableList<ThemeValidationIssue>,
    ) {
        if (pack.shapes.controlCornerDp !in 0f..64f ||
            pack.shapes.cardCornerDp !in 0f..64f ||
            pack.shapes.dialogCornerDp !in 0f..64f
        ) {
            errors += issue("shape_range", "Corner dimensions must be between 0 and 64 dp")
        }
        if (pack.dimensions.touchTargetDp < 48f) {
            errors += issue("touch_target", "Theme touch targets cannot be smaller than 48 dp")
        }
        if (pack.dimensions.progressHeightDp !in 16f..160f) {
            errors += issue("progress_height", "Progress height must be between 16 and 160 dp")
        }
        if (pack.buttonStyle.pressScale !in .8f..1f ||
            pack.buttonStyle.disabledAlpha !in 0f..1f
        ) {
            errors += issue("button_style", "Button scale or alpha is outside the supported range")
        }
        if (pack.progressStyle.ambientPeriodMs !in 200..10_000 ||
            pack.progressStyle.highlightPeriodMs !in 200..10_000 ||
            pack.progressStyle.indeterminateSegmentFraction !in .1f..0.9f ||
            pack.progressStyle.trackStartInsetDp !in 0f..96f ||
            pack.progressStyle.trackEndInsetDp !in 0f..96f ||
            pack.progressStyle.trackVerticalInsetDp !in 0f..64f ||
            pack.progressStyle.headWidthDp !in 16f..160f
        ) {
            errors += issue("progress_style", "Progress animation values are outside supported bounds")
        }
        if (pack.chromeStyle.backgroundArtAlpha !in 0f..1f ||
            pack.chromeStyle.panelOrnamentAlpha !in 0f..1f ||
            pack.chromeStyle.edgeComplexity !in 1..8 ||
            pack.chromeStyle.ambientTiltDegrees !in -12f..12f
        ) {
            errors += issue("chrome_style", "Theme chrome values are outside supported bounds")
        }
        listOf(
            pack.chromeStyle.backgroundArtRole,
            pack.chromeStyle.kapanionRole,
            pack.chromeStyle.voiceCoreRole,
        ).forEach { role ->
            if (SemanticAssetRole.fromWireName(role) == null) {
                errors += issue("chrome_role", "Unsupported semantic chrome role: $role")
            }
        }
        if (pack.particleStyle.density !in 0f..2f ||
            pack.particleStyle.opacity !in 0f..1f ||
            pack.particleStyle.qualityFallbackDensity !in 0f..1f
        ) {
            errors += issue("particle_style", "Particle values are outside supported bounds")
        }
        if (pack.motionProfile.baseDurationMs !in 100..5_000 ||
            pack.motionProfile.pulseScale !in 1f..1.2f ||
            pack.motionProfile.particleSpeedMultiplier !in .25f..4f
        ) {
            errors += issue("motion_profile", "Motion profile values are outside supported bounds")
        }
        pack.startupSequence?.let {
            if (it.durationMs !in 100..5_000 ||
                it.loadingTransitionMs !in 100..10_000 ||
                it.reducedMotionFadeMs !in 0..500
            ) {
                errors += issue("startup_timing", "Startup timing is outside supported bounds")
            }
        }
    }

    private fun safeAdd(left: Long, right: Long): Long =
        if (right > Long.MAX_VALUE - left) Long.MAX_VALUE else left + right

    private fun issue(code: String, detail: String) = ThemeValidationIssue(code, detail)
}
