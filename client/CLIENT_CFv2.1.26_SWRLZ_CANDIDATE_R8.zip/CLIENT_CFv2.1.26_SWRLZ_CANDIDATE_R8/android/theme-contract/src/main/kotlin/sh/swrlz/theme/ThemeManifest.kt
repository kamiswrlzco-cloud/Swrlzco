package sh.swrlz.theme

import kotlinx.serialization.Serializable

const val THEME_MANIFEST_VERSION = 1
const val THEME_ENGINE_VERSION_MAJOR = 1
const val DEFAULT_THEME_ID = "sh.swrlz.theme.glitch_dragon_glass"

@Serializable
enum class ThemeTarget {
    CLIENT,
    SERVER,
}

@Serializable
enum class ThemePackStatus {
    BUILT_IN,
    PARTIAL,
    CUSTOM,
}

@Serializable
enum class ThemeAssetScaleMode {
    FIT,
    FILL,
    STRETCH,
    TILE_X,
    CENTER_CROP,
}

@Serializable
enum class ThemeChromeMotif {
    GLASS_SHARD,
    PRISMATIC,
    CORE_CIRCUIT,
    NEON_SCAN,
    PHARAOH_GLYPH,
    VOID_JESTER,
    MAGMA,
    FROST,
    JADE_VINE,
    DIGITAL_GLITCH,
    CYBER_CRYSTAL,
    TEAL_SERPENT,
    JESTER_CHAOS,
}

@Serializable
data class ThemeSemVer(
    val major: Int,
    val minor: Int,
    val patch: Int,
) : Comparable<ThemeSemVer> {
    override fun compareTo(other: ThemeSemVer): Int =
        compareValuesBy(this, other, ThemeSemVer::major, ThemeSemVer::minor, ThemeSemVer::patch)

    override fun toString(): String = "$major.$minor.$patch"
}

@Serializable
data class ThemeCompatibility(
    val minEngineVersion: ThemeSemVer = ThemeSemVer(1, 0, 0),
    val maxEngineMajor: Int = THEME_ENGINE_VERSION_MAJOR,
    val targets: Set<ThemeTarget> = ThemeTarget.entries.toSet(),
)

@Serializable
data class ThemePalette(
    val background: String,
    val surface: String,
    val panel: String,
    val elevated: String,
    val primary: String,
    val secondary: String,
    val tertiary: String,
    val text: String,
    val secondaryText: String,
    val mutedText: String,
    val success: String = "#4DFF88",
    val warning: String = "#FFD45A",
    val danger: String = "#FF4D68",
    val info: String = "#38E8FF",
    val admin: String = "#B468FF",
)

@Serializable
data class ThemeTypography(
    val displayFamily: String = "serif",
    val bodyFamily: String = "sans-serif",
    val labelFamily: String = "monospace",
    val titleLetterSpacingSp: Float = 1.6f,
    val labelLetterSpacingSp: Float = 1.4f,
)

@Serializable
data class ThemeShapes(
    val controlCornerDp: Float = 12f,
    val cardCornerDp: Float = 18f,
    val dialogCornerDp: Float = 24f,
)

@Serializable
data class ThemeDimensions(
    val borderDp: Float = 1f,
    val selectedBorderDp: Float = 2f,
    val progressHeightDp: Float = 46f,
    val touchTargetDp: Float = 48f,
)

@Serializable
data class ThemeButtonStyle(
    val pressScale: Float = 0.97f,
    val disabledAlpha: Float = 0.42f,
    val focusedGlowMultiplier: Float = 1.15f,
    val selectedGlowMultiplier: Float = 1.3f,
)

@Serializable
data class ThemeProgressStyle(
    val trackInsetDp: Float = 12f,
    val trackStartInsetDp: Float = trackInsetDp,
    val trackEndInsetDp: Float = trackInsetDp,
    val trackVerticalInsetDp: Float = 8f,
    val headWidthDp: Float = 56f,
    val ambientPeriodMs: Int = 1_800,
    val highlightPeriodMs: Int = 1_350,
    val indeterminateSegmentFraction: Float = 0.34f,
)

@Serializable
data class ThemeChromeStyle(
    val motif: ThemeChromeMotif = ThemeChromeMotif.GLASS_SHARD,
    val backgroundArtRole: String = SemanticAssetRole.BackgroundApp.wireName,
    val kapanionRole: String = SemanticAssetRole.KapanionShared.wireName,
    val voiceCoreRole: String = SemanticAssetRole.KapanionShared.wireName,
    val backgroundArtAlpha: Float = 0.22f,
    val panelOrnamentAlpha: Float = 0.34f,
    val edgeComplexity: Int = 3,
    val ambientTiltDegrees: Float = 1.5f,
)

@Serializable
data class ThemeStartupSequence(
    val durationMs: Int = 950,
    val loadingTransitionMs: Int = 1_200,
    val reducedMotionFadeMs: Int = 90,
)

@Serializable
data class ThemeMotionProfile(
    val personality: String,
    val baseDurationMs: Int,
    val pulseScale: Float,
    val particleSpeedMultiplier: Float,
)

@Serializable
data class ThemeParticleStyle(
    val density: Float,
    val opacity: Float,
    val qualityFallbackDensity: Float,
)

@Serializable
data class ThemeLauncherIdentity(
    val clientRole: String? = null,
    val serverRole: String? = null,
    val genericFallback: Boolean = true,
)

@Serializable
data class ThemeKapanionIdentity(
    val sharedRole: String? = null,
    val clientRole: String? = null,
    val serverRole: String? = null,
)

@Serializable
data class ThemeAssetSpec(
    val path: String,
    val sha256: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    val bytes: Long? = null,
    val scaleMode: ThemeAssetScaleMode = ThemeAssetScaleMode.FIT,
    val decorative: Boolean = true,
)

@Serializable
data class ThemePack(
    val manifestVersion: Int = THEME_MANIFEST_VERSION,
    val id: String,
    val displayName: String,
    val themeVersion: ThemeSemVer,
    val status: ThemePackStatus = ThemePackStatus.BUILT_IN,
    val selectable: Boolean = true,
    val aliases: Set<String> = emptySet(),
    val compatibility: ThemeCompatibility = ThemeCompatibility(),
    val palette: ThemePalette,
    val typography: ThemeTypography = ThemeTypography(),
    val shapes: ThemeShapes = ThemeShapes(),
    val dimensions: ThemeDimensions = ThemeDimensions(),
    val buttonStyle: ThemeButtonStyle = ThemeButtonStyle(),
    val progressStyle: ThemeProgressStyle = ThemeProgressStyle(),
    val chromeStyle: ThemeChromeStyle = ThemeChromeStyle(),
    val startupSequence: ThemeStartupSequence? = null,
    val motionProfile: ThemeMotionProfile,
    val particleStyle: ThemeParticleStyle,
    val launcherIdentity: ThemeLauncherIdentity? = null,
    val kapanionIdentity: ThemeKapanionIdentity? = null,
    val soundProfile: String? = null,
    val assets: Map<String, ThemeAssetSpec> = emptyMap(),
    val fallbacks: List<String> = listOf(DEFAULT_THEME_ID),
    val provenance: Map<String, String> = emptyMap(),
) {
    fun asset(role: SemanticAssetRole): ThemeAssetSpec? = assets[role.wireName]
    fun supports(target: ThemeTarget): Boolean = target in compatibility.targets
}

@Serializable
data class ThemeManifestEnvelope(
    val pack: ThemePack,
)
