package sh.swrlz.theme

import kotlinx.serialization.Serializable

/**
 * Stable presentation vocabulary shared by CLIENT and SERVER.
 *
 * Screens expose semantic application state. Theme packs map these roles to
 * declarative assets; screen code never refers to a theme-specific filename.
 */
@Serializable
enum class SemanticAssetRole(val wireName: String) {
    BackgroundApp("background.app"),
    BackgroundPanel("background.panel"),
    SurfaceCard("surface.card"),
    SurfaceDialog("surface.dialog"),
    BorderPanel("border.panel"),
    SeparatorPrimary("separator.primary"),
    GlowAmbient("glow.ambient"),
    IconConfirm("icon.confirm"),
    IconReject("icon.reject"),

    ButtonPrimary("button.frame.primary"),
    ButtonSecondary("button.frame.secondary"),
    ButtonDestructive("button.frame.destructive"),
    ButtonConfirm("button.frame.confirm"),
    ButtonReject("button.frame.reject"),

    ActionContinue("actionPresentation.continue"),
    ActionInstall("actionPresentation.install"),
    ActionAllow("actionPresentation.allow"),
    ActionCancel("actionPresentation.cancel"),
    ActionAbort("actionPresentation.abort"),

    ProgressFrame("progress.frame"),
    ProgressFill("progress.fill"),
    ProgressHead("progress.head"),
    ProgressParticles("progress.particles"),
    ProgressEmblem("progress.emblem"),
    ProgressComplete("progress.complete"),
    ProgressFailureInterruption("progress.failure_interruption"),
    ProgressAmbient("progress.ambient"),
    ProgressHighlight("progress.highlight"),

    StartupDormant("startup.dormant"),
    StartupSpark("startup.spark"),
    StartupPartial("startup.partial"),
    StartupAwakened("startup.awakened"),
    StartupShockwave("startup.shockwave"),
    StartupParticles("startup.particles"),
    StartupRadial("startup.radial"),
    StartupResidual("startup.residual"),

    LauncherClient("launcher.client"),
    LauncherServer("launcher.server"),
    KapanionShared("kapanion.shared"),
    KapanionClient("kapanion.client"),
    KapanionServer("kapanion.server");

    companion object {
        private val byWireName = entries.associateBy(SemanticAssetRole::wireName)
        fun fromWireName(value: String): SemanticAssetRole? = byWireName[value]
    }
}

@Serializable
enum class ThemeProgressState {
    IDLE,
    STARTING,
    ACTIVE,
    PAUSED,
    COMPLETING,
    SUCCESS,
    FAILED,
    INTERRUPTED,
    CANCELLED,
}
