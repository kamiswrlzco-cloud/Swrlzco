package sh.swrlz.command

/**
 * Discoverable SWRLZ command catalog. UI surfaces may insert these natural-language templates
 * into Chat or copy them for review. Canonical capability IDs remain the execution authority.
 *
 * INT-CMD-039P adds hierarchy, typed prompt resolution, context ranking, and truthful approval /
 * availability metadata. None of those fields grant execution authority by themselves.
 */
enum class CommandCategory { FORGE, AI, PROFILES, MISSIONS, CONNECTIONS, FILES, UPDATES, CHAT, SYSTEM }

enum class CommandApproval {
    READ_ONLY,
    REVIEW,
    CONFIRM,
    SENSITIVE,
}

enum class CommandAvailability {
    AVAILABLE,
    REQUIRES_CONFIGURATION,
    PLANNED,
}

enum class CommandContext {
    CHAT,
    FORGE,
    FILES,
    MISSIONS,
    CONNECTIONS,
    SYSTEM,
    PROVIDERS,
    PROFILES,
    UPDATES,
}

data class SwrlzCommandV1(
    val id: String,
    val title: String,
    val category: CommandCategory,
    val template: String,
    val description: String,
    val aliases: List<String> = emptyList(),
    val capabilityId: String? = null,
    val safeForImmediateInsert: Boolean = true,
    val approval: CommandApproval = CommandApproval.REVIEW,
    val availability: CommandAvailability = CommandAvailability.AVAILABLE,
    val contexts: Set<CommandContext> = setOf(CommandContext.CHAT),
    val keywords: List<String> = emptyList(),
    val syntaxAction: String? = null,
    val instructionSeed: String = "",
)

data class CommandPromptResolution(
    val exact: SwrlzCommandV1?,
    val suggestions: List<SwrlzCommandV1>,
)

object SwrlzCommandCatalog {
    val all: List<SwrlzCommandV1> = listOf(
        SwrlzCommandV1(
            id = "forge.start",
            title = "Start Forge",
            category = CommandCategory.FORGE,
            template = "start Forge",
            description = "Open the canonical Forge flow.",
            aliases = listOf("initiate forge", "begin forge"),
            capabilityId = "forge.start",
            approval = CommandApproval.REVIEW,
            contexts = setOf(CommandContext.CHAT, CommandContext.FORGE),
        ),
        SwrlzCommandV1(
            id = "forge.client.latest",
            title = "Forge latest CLIENT",
            category = CommandCategory.FORGE,
            template = "forge latest SWRLZ CLIENT source",
            description = "Stage the latest canonical CLIENT source package unit for Forge review.",
            capabilityId = "forge.source.client.latest",
            approval = CommandApproval.CONFIRM,
            contexts = setOf(CommandContext.CHAT, CommandContext.FORGE),
            keywords = listOf("source", "client", "latest", "package"),
            syntaxAction = "latest",
            instructionSeed = "CLIENT source",
        ),
        SwrlzCommandV1(
            id = "forge.server.latest",
            title = "Forge latest SERVER",
            category = CommandCategory.FORGE,
            template = "forge latest SWRLZ SERVER source",
            description = "Stage the latest canonical SERVER source package unit for Forge review.",
            capabilityId = "forge.source.server.latest",
            approval = CommandApproval.CONFIRM,
            contexts = setOf(CommandContext.CHAT, CommandContext.FORGE),
            keywords = listOf("source", "server", "latest", "package"),
            syntaxAction = "latest",
            instructionSeed = "SERVER source",
        ),
        SwrlzCommandV1(
            id = "forge.combo.latest",
            title = "Forge CLIENT + SERVER",
            category = CommandCategory.FORGE,
            template = "forge latest SWRLZ CLIENT and SERVER sources",
            description = "Stage both canonical package units without merging their identities.",
            capabilityId = "forge.source.combo.latest",
            approval = CommandApproval.CONFIRM,
            contexts = setOf(CommandContext.CHAT, CommandContext.FORGE),
            keywords = listOf("both", "combo", "client", "server", "latest"),
            syntaxAction = "latest",
            instructionSeed = "CLIENT and SERVER sources",
        ),
        SwrlzCommandV1(
            id = "forge.stop",
            title = "Stop Forge",
            category = CommandCategory.FORGE,
            template = "stop Forge",
            description = "Request cancellation of the active Chat Forge operation.",
            capabilityId = "forge.stop",
            approval = CommandApproval.CONFIRM,
            contexts = setOf(CommandContext.CHAT, CommandContext.FORGE),
        ),

        // Commercial provider entries remain discoverable for explicitly configured use, but 039O
        // makes them non-default capabilities. The catalog does not enable a provider.

        SwrlzCommandV1(
            id = "profile.switch.client",
            title = "Switch CLIENT profile",
            category = CommandCategory.PROFILES,
            template = "switch CLIENT SWRLZ profile to ",
            description = "Select a saved CLIENT endpoint profile.",
            capabilityId = "profile.client.select",
            approval = CommandApproval.CONFIRM,
            syntaxAction = "switch",
            instructionSeed = "CLIENT profile to ",
            contexts = setOf(CommandContext.CHAT, CommandContext.PROFILES),
        ),
        SwrlzCommandV1(
            id = "profile.switch.server",
            title = "Switch SERVER profile",
            category = CommandCategory.PROFILES,
            template = "switch SERVER SWRLZ profile to ",
            description = "Select a saved SERVER endpoint profile.",
            capabilityId = "profile.server.select",
            approval = CommandApproval.CONFIRM,
            syntaxAction = "switch",
            instructionSeed = "SERVER profile to ",
            contexts = setOf(CommandContext.CHAT, CommandContext.PROFILES),
        ),

        SwrlzCommandV1(
            id = "mission.start",
            title = "Start mission",
            category = CommandCategory.MISSIONS,
            template = "make this a mission: ",
            description = "Promote an intent into the normal mission planning/approval path.",
            capabilityId = "mission.plan",
            approval = CommandApproval.CONFIRM,
            contexts = setOf(CommandContext.CHAT, CommandContext.MISSIONS),
        ),
        SwrlzCommandV1(
            id = "mission.pause",
            title = "Pause mission",
            category = CommandCategory.MISSIONS,
            template = "pause mission",
            description = "Pause the active mission without changing its authority model.",
            capabilityId = "mission.pause",
            approval = CommandApproval.CONFIRM,
            contexts = setOf(CommandContext.CHAT, CommandContext.MISSIONS),
        ),
        SwrlzCommandV1(
            id = "mission.resume",
            title = "Resume mission",
            category = CommandCategory.MISSIONS,
            template = "resume mission",
            description = "Resume a paused mission.",
            capabilityId = "mission.resume",
            approval = CommandApproval.CONFIRM,
            contexts = setOf(CommandContext.CHAT, CommandContext.MISSIONS),
        ),

        SwrlzCommandV1(
            id = "connection.status",
            title = "Connection status",
            category = CommandCategory.CONNECTIONS,
            template = "show SWRLZ connection status",
            description = "Show CLIENT/SERVER/node reachability and trust state.",
            capabilityId = "connection.status",
            approval = CommandApproval.READ_ONLY,
            contexts = setOf(CommandContext.CHAT, CommandContext.CONNECTIONS, CommandContext.SYSTEM),
        ),

        SwrlzCommandV1(
            id = "files.attach",
            title = "Attach file",
            category = CommandCategory.FILES,
            template = "analyze this attached file: ",
            description = "Stage a file for local/SWRLZ analysis before any remote-sharing approval.",
            capabilityId = "files.attach",
            approval = CommandApproval.REVIEW,
            contexts = setOf(CommandContext.CHAT, CommandContext.FILES),
        ),

        // 039M vocabulary is registered now so the command palette has stable parent/action
        // prefixes. Everything after /files (child) remains freeform user instruction text.
        // Availability remains PLANNED until the Local Artifact Resolver / organizer checkpoint lands.
        SwrlzCommandV1(
            id = "files.scan",
            title = "Scan files",
            category = CommandCategory.FILES,
            template = "scan a user-selected local folder and show what you found",
            description = "Planned 039M local folder scan with progress and classification; no moves. Add the folder and scan request after /files (scan).",
            aliases = listOf("files.scan.downloads", "/files scan downloads", "scan Downloads"),
            capabilityId = "files.scan",
            safeForImmediateInsert = false,
            approval = CommandApproval.READ_ONLY,
            availability = CommandAvailability.PLANNED,
            contexts = setOf(CommandContext.CHAT, CommandContext.FILES),
            keywords = listOf("downloads", "folder", "scan", "classify"),
        ),
        SwrlzCommandV1(
            id = "files.organize",
            title = "Organize files",
            category = CommandCategory.FILES,
            template = "organize a user-selected local folder with approval before changes",
            description = "Planned 039M scan → proposal → approval → verified organization flow. Describe the folder and desired grouping after /files (organize).",
            aliases = listOf("files.organize.downloads", "files.organize.selected", "/files organize downloads", "organize Downloads"),
            capabilityId = "files.organize",
            safeForImmediateInsert = false,
            approval = CommandApproval.CONFIRM,
            availability = CommandAvailability.PLANNED,
            contexts = setOf(CommandContext.CHAT, CommandContext.FILES),
            keywords = listOf("downloads", "organize", "cleanup", "folders", "subfolders"),
        ),
        SwrlzCommandV1(
            id = "files.duplicates",
            title = "Review duplicates",
            category = CommandCategory.FILES,
            template = "find probable duplicate files and let me review them",
            description = "Planned 039M duplicate review; deletion is never implied by organize.",
            aliases = listOf("files.duplicates.review", "/files duplicates review"),
            capabilityId = "files.duplicates.review",
            safeForImmediateInsert = false,
            approval = CommandApproval.REVIEW,
            availability = CommandAvailability.PLANNED,
            contexts = setOf(CommandContext.CHAT, CommandContext.FILES),
        ),
        SwrlzCommandV1(
            id = "files.undo",
            title = "Undo organization",
            category = CommandCategory.FILES,
            template = "undo a reversible file organization run",
            description = "Planned 039M journal-backed reversal. Describe the run to undo after /files (undo).",
            aliases = listOf("files.undo.last", "/files undo last"),
            capabilityId = "files.undo",
            safeForImmediateInsert = false,
            approval = CommandApproval.CONFIRM,
            availability = CommandAvailability.PLANNED,
            contexts = setOf(CommandContext.CHAT, CommandContext.FILES),
        ),
        SwrlzCommandV1(
            id = "files.keep-organized",
            title = "Keep Organized",
            category = CommandCategory.FILES,
            template = "configure Keep Organized for selected folders",
            description = "Planned 039M watched-folder, cadence, clutter threshold, notification, and known-rule controls.",
            aliases = listOf("files.keep.organized", "keep organized settings"),
            capabilityId = "files.keep.organized",
            safeForImmediateInsert = false,
            approval = CommandApproval.REVIEW,
            availability = CommandAvailability.PLANNED,
            contexts = setOf(CommandContext.CHAT, CommandContext.FILES, CommandContext.SYSTEM),
            syntaxAction = "keep-organized",
        ),

        SwrlzCommandV1(
            id = "updates.latest",
            title = "Latest update summary",
            category = CommandCategory.UPDATES,
            template = "summarize the latest SWRLZ update",
            description = "Ask the local Update Ledger for the newest recorded CLIENT patch summary and evidence boundary.",
            aliases = listOf("latest patch notes", "what's new", "latest update review"),
            capabilityId = "updates.latest",
            approval = CommandApproval.READ_ONLY,
            contexts = setOf(CommandContext.CHAT, CommandContext.UPDATES),
            syntaxAction = "latest",
            instructionSeed = "give me the highlights",
        ),
        SwrlzCommandV1(
            id = "updates.ask",
            title = "Ask about an update",
            category = CommandCategory.UPDATES,
            template = "answer a question from the SWRLZ patch notes: ",
            description = "Ask a local evidence-aware question about a recorded patch or checkpoint.",
            aliases = listOf("patch notes question", "ask swrlz about update"),
            capabilityId = "updates.ask",
            approval = CommandApproval.READ_ONLY,
            contexts = setOf(CommandContext.CHAT, CommandContext.UPDATES),
            syntaxAction = "ask",
        ),
        SwrlzCommandV1(
            id = "updates.compare",
            title = "Compare updates",
            category = CommandCategory.UPDATES,
            template = "compare two SWRLZ updates: ",
            description = "Compare two recorded Update Ledger entries without inventing unrecorded runtime evidence.",
            aliases = listOf("compare patch notes", "compare releases"),
            capabilityId = "updates.compare",
            approval = CommandApproval.READ_ONLY,
            contexts = setOf(CommandContext.CHAT, CommandContext.UPDATES),
            syntaxAction = "compare",
        ),

        SwrlzCommandV1(
            id = "chat.settings",
            title = "Open Chat settings",
            category = CommandCategory.CHAT,
            template = "open Chat settings",
            description = "Open conversation, provider, profile, terminology, and context controls.",
            capabilityId = "settings.chat",
            approval = CommandApproval.REVIEW,
            contexts = setOf(CommandContext.CHAT, CommandContext.SYSTEM),
        ),
        SwrlzCommandV1(
            id = "system.settings",
            title = "Open Android settings",
            category = CommandCategory.SYSTEM,
            template = "open device settings",
            description = "Request the existing Settings quick action.",
            capabilityId = "system.settings",
            approval = CommandApproval.REVIEW,
            contexts = setOf(CommandContext.CHAT, CommandContext.SYSTEM),
        ),
    )

    fun rootSegment(category: CommandCategory): String = when (category) {
        CommandCategory.FORGE -> "forge"
        CommandCategory.AI -> "ai"
        CommandCategory.PROFILES -> "profile"
        CommandCategory.MISSIONS -> "mission"
        CommandCategory.CONNECTIONS -> "connection"
        CommandCategory.FILES -> "files"
        CommandCategory.UPDATES -> "updates"
        CommandCategory.CHAT -> "chat"
        CommandCategory.SYSTEM -> "system"
    }

    fun pathSegments(command: SwrlzCommandV1): List<String> = command.id.split('.').filter { it.isNotBlank() }

    fun syntaxAction(command: SwrlzCommandV1): String = command.syntaxAction
        ?.trim()
        ?.takeIf { it.isNotBlank() }
        ?: pathSegments(command).getOrNull(1)
        ?: "run"

    /** Preferred visible grammar: /parent (child) [freeform instructions]. */
    fun canonicalPrefix(command: SwrlzCommandV1): String =
        "/${rootSegment(command.category)} (${syntaxAction(command)})"

    fun syntaxDisplay(command: SwrlzCommandV1): String = canonicalPrefix(command) + " [instructions]"

    /** Text inserted into Chat. A specific preset may seed instructions, but the cursor stays after them. */
    fun insertionPrompt(command: SwrlzCommandV1): String = buildString {
        append(canonicalPrefix(command))
        append(' ')
        if (command.instructionSeed.isNotBlank()) append(command.instructionSeed)
    }

    /** Retained API name; now returns the preferred structured prefix rather than the legacy dotted token path. */
    fun canonicalPrompt(command: SwrlzCommandV1): String = canonicalPrefix(command)

    private fun menuPathSegments(command: SwrlzCommandV1): List<String> {
        val root = rootSegment(command.category)
        val action = syntaxAction(command)
        val siblings = all.filter { rootSegment(it.category) == root && syntaxAction(it) == action }
        if (siblings.size <= 1) return listOf(root, action)

        val selector = pathSegments(command)
            .drop(1)
            .filterNot { it == action }
            .joinToString("-")
            .ifBlank { command.id.substringAfterLast('.') }
        return listOf(root, action, selector)
    }

    fun commandsUnder(prefix: List<String>): List<SwrlzCommandV1> {
        if (prefix.isEmpty()) return all
        return all.filter { command -> menuPathSegments(command).startsWith(prefix) }
    }

    fun childSegments(prefix: List<String>): List<String> = commandsUnder(prefix)
        .mapNotNull { command -> menuPathSegments(command).getOrNull(prefix.size) }
        .distinct()
        .sorted()

    fun leafAt(path: List<String>): SwrlzCommandV1? = all.firstOrNull { menuPathSegments(it) == path }

    fun contextual(context: CommandContext, limit: Int = 6): List<SwrlzCommandV1> = all
        .asSequence()
        .filter { context in it.contexts }
        .sortedWith(
            compareBy<SwrlzCommandV1> { availabilityRank(it.availability) }
                .thenBy { approvalRank(it.approval) }
                .thenBy { it.title },
        )
        .take(limit.coerceAtLeast(0))
        .toList()

    fun search(
        query: String,
        category: CommandCategory? = null,
        context: CommandContext? = null,
    ): List<SwrlzCommandV1> {
        val needle = normalize(query)
        return all
            .asSequence()
            .filter { category == null || it.category == category }
            .map { command -> command to score(command, needle, context) }
            .filter { (_, score) -> needle.isBlank() || score > 0 }
            .sortedWith(
                compareByDescending<Pair<SwrlzCommandV1, Int>> { it.second }
                    .thenBy { availabilityRank(it.first.availability) }
                    .thenBy { it.first.title },
            )
            .map { it.first }
            .toList()
    }

    fun resolvePrompt(
        input: String,
        category: CommandCategory? = null,
        context: CommandContext? = null,
        limit: Int = 8,
    ): CommandPromptResolution {
        val needle = normalize(input)
        if (needle.isBlank()) {
            val defaults = if (context == null) search("", category).take(limit) else contextual(context, limit)
            return CommandPromptResolution(exact = null, suggestions = defaults)
        }

        val candidates = all.filter { category == null || it.category == category }
        val structured = parseStructuredPrompt(input)
        val structuredMatches = structured?.let { parsed ->
            candidates.filter { command ->
                normalize(rootSegment(command.category)) == normalize(parsed.parent) &&
                    normalize(syntaxAction(command)) == normalize(parsed.child)
            }
        }.orEmpty()
        val exact = when {
            structuredMatches.size == 1 -> structuredMatches.first()
            structuredMatches.size > 1 && !structured?.instructions.isNullOrBlank() -> structuredMatches
                .maxByOrNull { score(it, normalize(structured!!.instructions), context) }
            else -> candidates.firstOrNull { command ->
                commandKeys(command).any { normalize(it) == needle }
            }
        }
        val suggestionPool = if (structuredMatches.isNotEmpty()) structuredMatches else candidates
        val suggestionNeedle = structured?.instructions?.takeIf { it.isNotBlank() }?.let(::normalize) ?: needle
        val suggestions = suggestionPool
            .asSequence()
            .map { command -> command to score(command, suggestionNeedle, context) }
            .filter { (_, score) -> structuredMatches.isNotEmpty() || score > 0 }
            .sortedWith(compareByDescending<Pair<SwrlzCommandV1, Int>> { it.second }.thenBy { it.first.title })
            .map { it.first }
            .filter { it.id != exact?.id }
            .take(limit.coerceAtLeast(0))
            .toList()

        return CommandPromptResolution(exact = exact, suggestions = suggestions)
    }

    private fun commandKeys(command: SwrlzCommandV1): List<String> = buildList {
        add(command.id)
        add(command.id.replace('.', ' '))
        add("/" + pathSegments(command).joinToString(" ")) // legacy tokenized syntax
        add(canonicalPrefix(command))
        add(syntaxDisplay(command))
        add(insertionPrompt(command))
        add(command.title)
        add(command.template)
        addAll(command.aliases)
        addAll(command.keywords)
        command.capabilityId?.let(::add)
    }

    private data class StructuredPrompt(val parent: String, val child: String, val instructions: String)

    private fun parseStructuredPrompt(raw: String): StructuredPrompt? {
        val match = Regex("^\\s*/([A-Za-z0-9_-]+)\\s*\\(([^)]+)\\)\\s*(.*)$").matchEntire(raw) ?: return null
        return StructuredPrompt(
            parent = match.groupValues[1],
            child = match.groupValues[2],
            instructions = match.groupValues[3].trim(),
        )
    }

    private fun score(command: SwrlzCommandV1, needle: String, context: CommandContext?): Int {
        if (needle.isBlank()) {
            var base = 1
            if (context != null && context in command.contexts) base += 20
            if (command.availability == CommandAvailability.AVAILABLE) base += 5
            return base
        }

        val keys = commandKeys(command).map(::normalize)
        var best = 0
        keys.forEach { key ->
            val value = when {
                key == needle -> 100
                key.startsWith(needle) -> 80
                needle.startsWith(key) -> 70
                needle in key -> 55
                tokenOverlap(needle, key) > 0 -> 30 + tokenOverlap(needle, key) * 5
                else -> 0
            }
            if (value > best) best = value
        }
        if (context != null && context in command.contexts) best += 12
        if (command.availability == CommandAvailability.AVAILABLE) best += 3
        return best
    }

    private fun tokenOverlap(a: String, b: String): Int {
        val left = a.split(' ').filter { it.isNotBlank() }.toSet()
        val right = b.split(' ').filter { it.isNotBlank() }.toSet()
        return left.intersect(right).size
    }

    private fun normalize(raw: String): String = raw
        .trim()
        .removePrefix("/")
        .lowercase()
        .replace(Regex("[\\s._-]+"), " ")
        .trim()

    private fun availabilityRank(value: CommandAvailability): Int = when (value) {
        CommandAvailability.AVAILABLE -> 0
        CommandAvailability.REQUIRES_CONFIGURATION -> 1
        CommandAvailability.PLANNED -> 2
    }

    private fun approvalRank(value: CommandApproval): Int = when (value) {
        CommandApproval.READ_ONLY -> 0
        CommandApproval.REVIEW -> 1
        CommandApproval.CONFIRM -> 2
        CommandApproval.SENSITIVE -> 3
    }

    private fun <T> List<T>.startsWith(prefix: List<T>): Boolean =
        prefix.size <= size && prefix.indices.all { index -> this[index] == prefix[index] }
}
