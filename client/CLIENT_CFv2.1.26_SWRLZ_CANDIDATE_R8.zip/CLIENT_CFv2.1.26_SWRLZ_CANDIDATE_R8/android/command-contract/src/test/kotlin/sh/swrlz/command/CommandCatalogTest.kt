package sh.swrlz.command

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandCatalogTest {
    @Test
    fun canonicalPromptUsesParentChildInstructionGrammar() {
        val command = SwrlzCommandCatalog.all.first { it.id == "files.scan" }
        assertEquals("/files (scan)", SwrlzCommandCatalog.canonicalPrompt(command))
        assertEquals("/files (scan) [instructions]", SwrlzCommandCatalog.syntaxDisplay(command))
        assertEquals("/files (scan) ", SwrlzCommandCatalog.insertionPrompt(command))
    }

    @Test
    fun structuredPromptWithFreeformInstructionsResolvesExactly() {
        val resolution = SwrlzCommandCatalog.resolvePrompt(
            "/files (scan) inspect Downloads for SWRLZ artifacts",
            context = CommandContext.CHAT,
        )
        assertEquals("files.scan", resolution.exact?.id)
    }

    @Test
    fun hierarchyExposesActionFirstFileOrganizerPath() {
        val first = SwrlzCommandCatalog.childSegments(listOf("files"))
        assertTrue("scan" in first)
        assertTrue("organize" in first)
        assertTrue("duplicates" in first)
        assertTrue("undo" in first)
        assertTrue("keep-organized" in first)
        assertEquals("files.organize", SwrlzCommandCatalog.leafAt(listOf("files", "organize"))?.id)
    }

    @Test
    fun sharedActionUsesSelectorOnlyWhereNeeded() {
        val latest = SwrlzCommandCatalog.childSegments(listOf("forge", "latest"))
        assertTrue("client" in latest)
        assertTrue("server" in latest)
        assertTrue("combo" in latest)
        assertEquals("forge.client.latest", SwrlzCommandCatalog.leafAt(listOf("forge", "latest", "client"))?.id)
    }

    @Test
    fun specificPresetSeedsInstructionAfterStructuredPrefix() {
        val command = SwrlzCommandCatalog.all.first { it.id == "forge.client.latest" }
        assertEquals("/forge (latest) CLIENT source", SwrlzCommandCatalog.insertionPrompt(command))
        assertEquals(
            "forge.client.latest",
            SwrlzCommandCatalog.resolvePrompt("/forge (latest) CLIENT source", context = CommandContext.CHAT).exact?.id,
        )
    }

    @Test
    fun legacyTokenizedSyntaxStillResolves() {
        val resolution = SwrlzCommandCatalog.resolvePrompt("/forge client latest", context = CommandContext.CHAT)
        assertEquals("forge.client.latest", resolution.exact?.id)
    }

    @Test
    fun plannedOrganizerCommandsStayTruthfullyUnavailable() {
        val command = SwrlzCommandCatalog.all.first { it.id == "files.organize" }
        assertEquals(CommandAvailability.PLANNED, command.availability)
        assertEquals(CommandApproval.CONFIRM, command.approval)
        assertFalse(command.safeForImmediateInsert)
    }

    @Test
    fun brandedRemoteProviderCommandsStayOutOfPublicCatalog() {
        val hiddenIds = setOf("ai.gpt", "ai.gemini", "ai.council", "ai.compare", "ai.probe", "files.client.gpt", "files.combo.council")
        assertTrue(SwrlzCommandCatalog.all.none { it.id in hiddenIds })
    }

    @Test
    fun naturalLanguageSearchStillFindsExistingCommands() {
        val result = SwrlzCommandCatalog.search("connection status", context = CommandContext.CHAT)
        assertTrue(result.isNotEmpty())
        assertEquals("connection.status", result.first().id)
    }

    @Test
    fun blankPromptReturnsContextualSuggestions() {
        val resolution = SwrlzCommandCatalog.resolvePrompt("", context = CommandContext.CHAT, limit = 5)
        assertEquals(null, resolution.exact)
        assertTrue(resolution.suggestions.isNotEmpty())
        assertTrue(resolution.suggestions.size <= 5)
        assertNotNull(resolution.suggestions.first().capabilityId)
    }
}
