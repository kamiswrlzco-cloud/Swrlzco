package sh.swurlz.core.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatSettingsTest {
    @Test
    fun invalidStoredValuesFallBackToSafeDefaults() {
        val normalized = ChatSettings(
            followTarget = "teleport",
            baseStyle = "unknown",
            detailLevel = "infinite",
            warmth = "maximum-ish",
            energy = "warp",
            humor = "mandatory",
            formatting = "chaotic",
            emoji = "all",
        ).normalized()

        assertEquals(ChatSettings.FOLLOW_RESPONSE_TOP, normalized.followTarget)
        assertEquals(ChatSettings.STYLE_ADAPTIVE, normalized.baseStyle)
        assertEquals(ChatSettings.DETAIL_BALANCED, normalized.detailLevel)
        assertEquals(ChatSettings.TRAIT_HIGH, normalized.warmth)
        assertEquals(ChatSettings.TRAIT_HIGH, normalized.energy)
        assertEquals(ChatSettings.HUMOR_ADAPTIVE, normalized.humor)
        assertEquals(ChatSettings.FORMAT_STRUCTURED, normalized.formatting)
        assertEquals(ChatSettings.EMOJI_ADAPTIVE, normalized.emoji)
    }

    @Test
    fun reasoningDirectiveKeepsStyleSeparateFromAuthority() {
        val directive = ChatSettings(baseStyle = ChatSettings.STYLE_GLITCH_MUSE, humor = ChatSettings.HUMOR_CHAOS).reasoningDirective()
        assertTrue(directive.contains("playful", ignoreCase = true))
        assertTrue(directive.contains("truthful", ignoreCase = true))
    }
}
