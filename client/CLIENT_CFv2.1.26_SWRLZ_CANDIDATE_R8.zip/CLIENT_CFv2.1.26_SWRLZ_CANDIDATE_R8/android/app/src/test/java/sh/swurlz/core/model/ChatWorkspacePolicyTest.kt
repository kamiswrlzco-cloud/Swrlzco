package sh.swurlz.core.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatWorkspacePolicyTest {
    @Test
    fun emptyChatKeepsOnboardingAndNavigation() {
        val layout = ChatWorkspacePolicy.resolve(false, false, true)
        assertTrue(layout.showOnboarding)
        assertTrue(layout.showBottomNavigation)
        assertTrue(layout.showSecondaryTelemetry)
        assertTrue(layout.showProviderCompactBar)
        assertEquals(5, layout.composerMaxLines)
    }

    @Test
    fun conversationCollapsesSecondaryChrome() {
        val layout = ChatWorkspacePolicy.resolve(false, true, true)
        assertFalse(layout.showOnboarding)
        assertFalse(layout.showSecondaryTelemetry)
        assertTrue(layout.showBottomNavigation)
    }

    @Test
    fun keyboardPrioritizesConversationAndComposer() {
        val layout = ChatWorkspacePolicy.resolve(true, true, true)
        assertFalse(layout.showOnboarding)
        assertFalse(layout.showBottomNavigation)
        assertFalse(layout.showSecondaryTelemetry)
        assertTrue(layout.showProviderCompactBar)
        assertEquals(4, layout.composerMaxLines)
    }

    @Test
    fun providerStatusCanBeHiddenWithoutChangingWorkspaceBehavior() {
        val layout = ChatWorkspacePolicy.resolve(true, true, false)
        assertFalse(layout.showProviderCompactBar)
        assertFalse(layout.showBottomNavigation)
    }
}
