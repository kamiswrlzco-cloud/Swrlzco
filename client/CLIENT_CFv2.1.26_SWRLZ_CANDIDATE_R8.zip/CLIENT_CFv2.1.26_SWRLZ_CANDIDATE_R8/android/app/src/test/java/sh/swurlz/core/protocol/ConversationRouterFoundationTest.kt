package sh.swurlz.core.protocol

import org.junit.Assert.assertTrue
import org.junit.Test

class ConversationRouterFoundationTest {
    private fun envelope(type: CommunicationRequestType, missionId: String? = null) = CommunicationEnvelopeV1(
        messageId="m1", correlationId="c1", conversationId="chat1", missionId=missionId, eventId="e1",
        source=CommunicationEndpoint("CLIENT", "device-1", interfaceMode=InterfaceProjection.USER),
        destination=CommunicationEndpoint("SWURLZER"), requestType=type, route=CommunicationRoute.LOCAL, createdAtEpochMs=1L
    )
    @Test fun ordinaryChatIsNotMission() { assertTrue(ConversationRouterFoundation.classify(envelope(CommunicationRequestType.CHAT)) is ConversationRouteDecision.OrdinaryChat) }
    @Test fun promotionRequiresApproval() { assertTrue(ConversationRouterFoundation.classify(envelope(CommunicationRequestType.CHAT), true, false) is ConversationRouteDecision.ApprovalRequired) }
    @Test fun approvedPromotionRequiresMissionIdentity() { assertTrue(ConversationRouterFoundation.classify(envelope(CommunicationRequestType.CHAT, "mission-1"), true, true) is ConversationRouteDecision.ExistingMission) }
    @Test fun missionWithoutIdIsRejected() { assertTrue(ConversationRouterFoundation.classify(envelope(CommunicationRequestType.MISSION)) is ConversationRouteDecision.Rejected) }
}
