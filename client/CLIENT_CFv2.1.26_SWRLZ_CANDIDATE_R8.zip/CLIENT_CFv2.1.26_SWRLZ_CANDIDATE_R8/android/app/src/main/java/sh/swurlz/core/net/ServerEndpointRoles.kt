package sh.swurlz.core.net

import java.net.URI

/**
 * Canonical listener-role resolver.
 *
 * The current SERVER contract exposes discovery, registration, heartbeat, groups,
 * and compatibility routes on the advertised operational listener (normally 8787).
 * The loopback-only 8080 listener is a minimal private compatibility surface and
 * must not be inferred as the operational API endpoint.
 */
object ServerEndpointRoles {
    private const val DISCOVERY_PORT = 8787
    private const val PRIVATE_COMPATIBILITY_PORT = 8080

    /** Operational API traffic stays on the endpoint actually advertised by discovery. */
    fun operationalApiBase(configuredBase: String): String = configuredBase.trim().trimEnd('/')

    /** Explicit private compatibility endpoint, used only for diagnostics that require it. */
    fun privateCompatibilityBase(configuredBase: String): String {
        val clean = configuredBase.trim().trimEnd('/')
        val uri = runCatching { URI(clean) }.getOrNull() ?: return clean
        if (uri.host.isNullOrBlank()) return clean
        val targetPort = if (uri.port == DISCOVERY_PORT) PRIVATE_COMPATIBILITY_PORT else uri.port
        val authority = buildString {
            append(uri.host)
            if (targetPort >= 0) append(':').append(targetPort)
        }
        return URI(uri.scheme ?: "http", authority, uri.path?.takeIf { it != "/" }, null, null).toString().trimEnd('/')
    }

    fun isDiscoveryBase(configuredBase: String): Boolean =
        runCatching { URI(configuredBase.trim()).port == DISCOVERY_PORT }.getOrDefault(false)
}
