package sh.swurlz.core.github

import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile

data class ForgeEvidenceDocument(
    val archivePath: String,
    val repositoryPath: String,
    val sha256: String,
    val sizeBytes: Long,
)

data class ForgeEvidenceBundleContents(
    val checkpoint: String,
    val deliveryManifestPath: String,
    val documents: List<ForgeEvidenceDocument>,
)

/** Strict allowlisted repository-document routing for combined checkpoint evidence packs. */
object ForgeEvidenceBundle {
    private const val MAX_DOCUMENTS = 64
    private const val MAX_DOCUMENT_BYTES = 2L * 1024L * 1024L
    private const val MAX_TOTAL_DOCUMENT_BYTES = 16L * 1024L * 1024L
    private val allowedPrefixes = listOf("docs/", "reports/", "swrlz-core/docs/", "swrlz-core/reports/")
    private val allowedRootFiles = setOf("README.md", "CHANGELOG.md", "SECURITY.md", "CONTRIBUTING.md")
    private val allowedCiFiles = setOf(
        ".github/workflows/swrlz-apk-router.yml",
        "scripts/ci/resolve_swrlz_source.py",
        "scripts/ci/verify_swrlz_package_pair.py",
        "scripts/ci/test_resolve_swrlz_source.py",
        "scripts/ci/test_verify_swrlz_package_pair.py",
        "swrlz-core/.github/workflows/swrlz-apk-router.yml",
        "swrlz-core/scripts/ci/resolve_swrlz_source.py",
        "swrlz-core/scripts/ci/verify_swrlz_package_pair.py",
        "swrlz-core/scripts/ci/test_resolve_swrlz_source.py",
        "swrlz-core/scripts/ci/test_verify_swrlz_package_pair.py",
        "swrlz-core/tools/ci/resolve_swrlz_source.py",
        "swrlz-core/tools/ci/verify_swrlz_package_pair.py",
        "swrlz-core/tools/ci/test_resolve_swrlz_source.py",
        "swrlz-core/tools/ci/test_verify_swrlz_package_pair.py",
    )

    fun isEvidenceBundleName(fileName: String): Boolean {
        val name = fileName.trim().replace(Regex("\\s*\\(\\d+\\)(?=\\.zip$)", RegexOption.IGNORE_CASE), "")
        return name.startsWith("INT_", ignoreCase = true) && name.endsWith("_EVIDENCE.zip", ignoreCase = true)
    }

    fun inspect(cacheFile: File, displayName: String): ForgeEvidenceBundleContents {
        require(isEvidenceBundleName(displayName)) { "Not a canonical checkpoint evidence bundle: $displayName" }
        val canonicalOuter = displayName.trim().replace(Regex("\\s*\\(\\d+\\)(?=\\.zip$)", RegexOption.IGNORE_CASE), "")
        val expectedCheckpoint = canonicalOuter.dropLast(4).replace(Regex("(?i)_EVIDENCE$"), "")
            .replace(Regex("[^A-Za-z0-9]+"), "-").trim('-').uppercase()
        ZipFile(cacheFile).use { zip ->
            val manifestEntries = zip.entries().asSequence().filter { !it.isDirectory }
                .filter { it.name.matches(Regex("delivery/INT_[A-Za-z0-9_-]+_DELIVERY\\.manifest\\.json")) }
                .toList()
            require(manifestEntries.size == 1) { "Evidence bundle must contain exactly one delivery manifest under delivery/." }
            val manifestEntry = manifestEntries.single()
            require(manifestEntry.size in 1..MAX_DOCUMENT_BYTES) { "Delivery manifest size is invalid." }
            val payload = zip.getInputStream(manifestEntry).bufferedReader().use { it.readText() }
            val json = JSONObject(payload)
            val checkpoint = json.optString("checkpoint").ifBlank { error("Delivery manifest checkpoint is missing.") }
            val normalizedCheckpoint = checkpoint.replace(Regex("[^A-Za-z0-9]+"), "-").trim('-').uppercase()
            require(normalizedCheckpoint == expectedCheckpoint) {
                "Evidence filename checkpoint $expectedCheckpoint does not match delivery manifest checkpoint $checkpoint."
            }
            val array = json.optJSONArray("repositoryFiles") ?: json.optJSONArray("repositoryDocuments") ?: error("Delivery manifest repositoryFiles array is missing.")
            require(array.length() <= MAX_DOCUMENTS) { "Too many repository documents." }
            val seenArchive = mutableSetOf<String>()
            val seenRepo = mutableSetOf<String>()
            val documents = mutableListOf<ForgeEvidenceDocument>()
            var total = 0L
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                val archivePath = safeArchivePath(item.getString("archivePath"))
                val repositoryPath = safeRepositoryPath(item.getString("repositoryPath"))
                require(archivePath.startsWith("repo-docs/") || archivePath.startsWith("repo-patches/")) { "Repository file must be stored under repo-docs/ or repo-patches/: $archivePath" }
                require(seenArchive.add(archivePath.lowercase())) { "Duplicate repository archive path: $archivePath" }
                require(seenRepo.add(repositoryPath.lowercase())) { "Duplicate repository destination: $repositoryPath" }
                val entry = zip.getEntry(archivePath) ?: error("Declared repository document is absent: $archivePath")
                require(!entry.isDirectory && entry.size in 0..MAX_DOCUMENT_BYTES) { "Repository document size is invalid: $archivePath" }
                total += entry.size
                require(total <= MAX_TOTAL_DOCUMENT_BYTES) { "Repository documents exceed the evidence routing limit." }
                val expectedSha = item.getString("sha256").lowercase()
                require(expectedSha.matches(Regex("[0-9a-f]{64}"))) { "Invalid repository document SHA-256: $archivePath" }
                val actualSha = zip.getInputStream(entry).use { input ->
                    val digest = MessageDigest.getInstance("SHA-256")
                    val buffer = ByteArray(8192)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (count > 0) digest.update(buffer, 0, count)
                    }
                    digest.digest().joinToString("") { "%02x".format(it) }
                }
                require(actualSha == expectedSha) { "Repository document SHA-256 mismatch: $archivePath" }
                documents += ForgeEvidenceDocument(archivePath, repositoryPath, expectedSha, entry.size)
            }
            return ForgeEvidenceBundleContents(checkpoint, manifestEntry.name, documents)
        }
    }

    private fun safeArchivePath(value: String): String {
        val path = value.replace('\\', '/').trim().trimStart('/')
        require(path.isNotBlank() && '\u0000' !in path) { "Unsafe empty archive path." }
        require(path.split('/').none { it.isBlank() || it == "." || it == ".." || it.equals(".git", true) }) { "Unsafe archive path: $value" }
        return path
    }

    private fun safeRepositoryPath(value: String): String {
        val path = value.replace('\\', '/').trim().trim('/')
        require(path.isNotBlank() && '\u0000' !in path) { "Unsafe repository path." }
        require(path.split('/').none { it.isBlank() || it == "." || it == ".." || it.equals(".git", true) }) { "Unsafe repository path: $value" }
        require(path in allowedRootFiles || path in allowedCiFiles || allowedPrefixes.any(path::startsWith)) {
            "Repository document destination is not allowlisted: $path"
        }
        return path
    }
}
