package sh.swurlz.core.ui.client

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sh.swrlz.command.CommandApproval
import sh.swrlz.command.CommandAvailability
import sh.swrlz.command.CommandCategory
import sh.swrlz.command.CommandContext
import sh.swrlz.command.SwrlzCommandCatalog
import sh.swrlz.command.SwrlzCommandV1
import sh.swurlz.core.ui.theme.LocalSwurlzTokens

private const val RECENT_COMMAND_LIMIT = 12

@Composable
internal fun ChatCommandQuickMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    onInsert: (String) -> Unit,
    onOpenCommandCenter: () -> Unit,
) {
    var path by remember { mutableStateOf<List<String>>(emptyList()) }

    LaunchedEffect(expanded) {
        if (!expanded) path = emptyList()
    }

    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        if (path.isEmpty()) {
            Text(
                "COMMAND",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
            )
            CommandCategory.values().forEach { category ->
                val root = SwrlzCommandCatalog.rootSegment(category)
                val count = SwrlzCommandCatalog.commandsUnder(listOf(root)).size
                DropdownMenuItem(
                    text = { Text("${categoryGlyph(category)} ${categoryLabel(category)}  ·  $count") },
                    onClick = { path = listOf(root) },
                )
            }
        } else {
            DropdownMenuItem(
                text = { Text("‹ ${path.joinToString(" / ").uppercase()}") },
                onClick = { path = path.dropLast(1) },
            )
            HorizontalDivider()
            val children = SwrlzCommandCatalog.childSegments(path)
            children.forEach { segment ->
                val next = path + segment
                val leaf = SwrlzCommandCatalog.leafAt(next)
                val descendants = SwrlzCommandCatalog.childSegments(next)
                val enabled = leaf?.availability != CommandAvailability.PLANNED
                DropdownMenuItem(
                    text = {
                        val suffix = when {
                            descendants.isNotEmpty() -> "  ›"
                            leaf?.availability == CommandAvailability.PLANNED -> "  · PLANNED"
                            leaf?.availability == CommandAvailability.REQUIRES_CONFIGURATION -> "  · CONFIG"
                            else -> ""
                        }
                        Column {
                            Text((leaf?.title ?: segment.replaceFirstChar { it.uppercase() }) + suffix)
                            if (leaf != null && descendants.isEmpty()) {
                                Text(SwrlzCommandCatalog.syntaxDisplay(leaf), fontSize = 9.sp)
                            }
                        }
                    },
                    enabled = descendants.isNotEmpty() || enabled,
                    onClick = {
                        if (descendants.isNotEmpty()) {
                            path = next
                        } else if (leaf != null && leaf.availability != CommandAvailability.PLANNED) {
                            onInsert(SwrlzCommandCatalog.insertionPrompt(leaf))
                            onDismiss()
                        }
                    },
                )
            }
        }

        HorizontalDivider()
        DropdownMenuItem(
            text = { Text("⌘ Command prompt + full palette") },
            onClick = { onDismiss(); onOpenCommandCenter() },
        )
    }
}

@Composable
internal fun ChatCommandCenterDialog(
    onDismiss: () -> Unit,
    onInsert: (String) -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val prefs = remember { context.getSharedPreferences("swrlz_command_center", Context.MODE_PRIVATE) }

    var prompt by remember { mutableStateOf("") }
    var path by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedCommandId by remember { mutableStateOf<String?>(null) }
    var favoriteRevision by remember { mutableIntStateOf(0) }
    var recentRevision by remember { mutableIntStateOf(0) }

    val favorites = remember(favoriteRevision) {
        prefs.getStringSet("favorites", emptySet()).orEmpty().toSet()
    }
    val recents = remember(recentRevision) { loadRecentIds(prefs) }
    val resolution = remember(prompt) {
        SwrlzCommandCatalog.resolvePrompt(prompt, context = CommandContext.CHAT, limit = 7)
    }
    val selected = remember(selectedCommandId) {
        selectedCommandId?.let { id -> SwrlzCommandCatalog.all.firstOrNull { it.id == id } }
    }

    fun recordRecent(command: SwrlzCommandV1) {
        val next = (listOf(command.id) + recents.filterNot { it == command.id }).take(RECENT_COMMAND_LIMIT)
        prefs.edit().putString("recent_ids", next.joinToString("|")).apply()
        recentRevision++
    }

    fun insert(command: SwrlzCommandV1) {
        recordRecent(command)
        onInsert(SwrlzCommandCatalog.insertionPrompt(command))
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("SWRLZ Command Center", color = tokens.text.primary, fontWeight = FontWeight.Bold)
                Text("/parent → (child) → instructions", color = tokens.text.muted, fontSize = 10.sp)
            }
        },
        text = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 620.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(9.dp),
            ) {
                Text(
                    "Menu taps, canonical command syntax, and natural-language templates all resolve to the same capability catalog. Selecting a command inserts /parent (child) plus any preset instruction into Chat with the cursor at the end; it does not bypass approval, trust, mission, Forge, or Truth Firewall gates.",
                    color = tokens.text.secondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                )

                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Command prompt") },
                    placeholder = { Text("/files (scan) check Downloads for SWRLZ artifacts") },
                    supportingText = { Text("Pick a parent and child below, then write normal instructions after the structured prefix.") },
                    singleLine = true,
                )

                if (prompt.isNotBlank()) {
                    resolution.exact?.let { command ->
                        Text("EXACT", color = tokens.accents.primary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        CommandCard(
                            command = command,
                            favorite = command.id in favorites,
                            onFavorite = {
                                toggleFavorite(prefs, favorites, command.id)
                                favoriteRevision++
                            },
                            onInsert = { insert(command) },
                        )
                    } ?: run {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("No exact canonical command", color = tokens.text.muted, fontSize = 10.sp)
                            TextButton(onClick = {
                                onInsert(prompt)
                                onDismiss()
                            }) { Text("INSERT TEXT") }
                        }
                    }

                    if (resolution.suggestions.isNotEmpty()) {
                        Text("SUGGESTIONS", color = tokens.text.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        resolution.suggestions.take(5).forEach { command ->
                            CommandCompactRow(
                                command = command,
                                onClick = { selectedCommandId = command.id },
                            )
                        }
                    }
                    HorizontalDivider()
                }

                if (selected != null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("COMMAND DETAIL", color = tokens.text.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { selectedCommandId = null }) { Text("BACK") }
                    }
                    CommandCard(
                        command = selected,
                        favorite = selected.id in favorites,
                        onFavorite = {
                            toggleFavorite(prefs, favorites, selected.id)
                            favoriteRevision++
                        },
                        onInsert = { insert(selected) },
                    )
                    HorizontalDivider()
                }

                if (path.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            path.joinToString("  ›  ") { it.uppercase() },
                            color = tokens.accents.primary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                        )
                        TextButton(onClick = {
                            path = path.dropLast(1)
                            selectedCommandId = null
                        }) { Text("‹ BACK") }
                    }

                    SwrlzCommandCatalog.childSegments(path).forEach { segment ->
                        val next = path + segment
                        val leaf = SwrlzCommandCatalog.leafAt(next)
                        val descendants = SwrlzCommandCatalog.childSegments(next)
                        ElevatedCard(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                if (leaf != null && descendants.isEmpty()) {
                                    selectedCommandId = leaf.id
                                } else {
                                    path = next
                                    selectedCommandId = null
                                }
                            },
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(leaf?.title ?: segment.replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.SemiBold)
                                    if (leaf != null && descendants.isEmpty()) {
                                        Text(SwrlzCommandCatalog.syntaxDisplay(leaf), color = tokens.text.muted, fontSize = 9.sp)
                                    } else {
                                        Text("(${segment}) subcommand", color = tokens.text.muted, fontSize = 9.sp)
                                    }
                                }
                                Text(
                                    when {
                                        descendants.isNotEmpty() -> "${SwrlzCommandCatalog.commandsUnder(next).size}  ›"
                                        leaf?.availability == CommandAvailability.PLANNED -> "PLANNED"
                                        leaf?.availability == CommandAvailability.REQUIRES_CONFIGURATION -> "CONFIG"
                                        else -> "OPEN"
                                    },
                                    color = tokens.text.muted,
                                    fontSize = 9.sp,
                                )
                            }
                        }
                    }
                } else {
                    Text("COMMANDS", color = tokens.text.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    CommandCategory.values().forEach { category ->
                        val root = SwrlzCommandCatalog.rootSegment(category)
                        ElevatedCard(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                path = listOf(root)
                                selectedCommandId = null
                            },
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text("${categoryGlyph(category)} ${categoryLabel(category)}", fontWeight = FontWeight.SemiBold)
                                Text("${SwrlzCommandCatalog.commandsUnder(listOf(root)).size}  ›", color = tokens.text.muted, fontSize = 9.sp)
                            }
                        }
                    }

                    val pinned = SwrlzCommandCatalog.all.filter { it.id in favorites }
                    if (pinned.isNotEmpty()) {
                        HorizontalDivider()
                        Text("PINNED", color = tokens.text.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        pinned.take(5).forEach { command ->
                            CommandCompactRow(command = command, onClick = { selectedCommandId = command.id })
                        }
                    }

                    val recentCommands = recents.mapNotNull { id -> SwrlzCommandCatalog.all.firstOrNull { it.id == id } }
                    if (recentCommands.isNotEmpty()) {
                        HorizontalDivider()
                        Text("RECENT", color = tokens.text.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        recentCommands.take(5).forEach { command ->
                            CommandCompactRow(command = command, onClick = { selectedCommandId = command.id })
                        }
                    }

                    HorizontalDivider()
                    Text("CHAT CONTEXT", color = tokens.text.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    SwrlzCommandCatalog.contextual(CommandContext.CHAT, limit = 5).forEach { command ->
                        CommandCompactRow(command = command, onClick = { selectedCommandId = command.id })
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("CLOSE") } },
    )
}

@Composable
private fun CommandCompactRow(
    command: SwrlzCommandV1,
    onClick: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    OutlinedCard(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(Modifier.weight(1f)) {
                Text(command.title, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                Text(SwrlzCommandCatalog.syntaxDisplay(command), color = tokens.text.muted, fontSize = 9.sp)
            }
            Text(availabilityLabel(command.availability), color = tokens.text.muted, fontSize = 8.sp)
        }
    }
}

@Composable
private fun CommandCard(
    command: SwrlzCommandV1,
    favorite: Boolean,
    onFavorite: () -> Unit,
    onInsert: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(command.title, fontWeight = FontWeight.SemiBold, color = tokens.text.primary, modifier = Modifier.weight(1f))
                TextButton(onClick = onFavorite) { Text(if (favorite) "★" else "☆") }
            }
            Text(command.description, color = tokens.text.secondary, fontSize = 10.sp, lineHeight = 14.sp)
            Text("Syntax · ${SwrlzCommandCatalog.syntaxDisplay(command)}", color = tokens.accents.primary, fontSize = 10.sp)
            if (command.instructionSeed.isNotBlank()) {
                Text("Preset · ${SwrlzCommandCatalog.insertionPrompt(command)}", color = tokens.text.muted, fontSize = 9.sp)
            } else {
                Text("After the prefix, type the instruction normally.", color = tokens.text.muted, fontSize = 9.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AssistChip(onClick = {}, label = { Text(approvalLabel(command.approval), fontSize = 8.sp) })
                AssistChip(onClick = {}, label = { Text(availabilityLabel(command.availability), fontSize = 8.sp) })
            }
            command.capabilityId?.let { capability ->
                Text("Capability · $capability", color = tokens.text.muted, fontSize = 8.sp)
            }
            if (command.aliases.isNotEmpty()) {
                Text("Aliases · ${command.aliases.joinToString()}", color = tokens.text.muted, fontSize = 8.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Button(
                    onClick = onInsert,
                    enabled = command.availability != CommandAvailability.PLANNED,
                ) {
                    Text(
                        when {
                            command.availability == CommandAvailability.PLANNED -> "PLANNED"
                            command.safeForImmediateInsert -> "INSERT"
                            else -> "INSERT FOR REVIEW"
                        },
                    )
                }
            }
        }
    }
}

private fun toggleFavorite(
    prefs: android.content.SharedPreferences,
    current: Set<String>,
    id: String,
) {
    val next = current.toMutableSet()
    if (!next.add(id)) next.remove(id)
    prefs.edit().putStringSet("favorites", next).apply()
}

private fun loadRecentIds(prefs: android.content.SharedPreferences): List<String> = prefs
    .getString("recent_ids", "")
    .orEmpty()
    .split('|')
    .map { it.trim() }
    .filter { it.isNotBlank() }
    .distinct()
    .take(RECENT_COMMAND_LIMIT)

private fun categoryLabel(category: CommandCategory): String = when (category) {
    CommandCategory.FORGE -> "Forge"
    CommandCategory.AI -> "AI / Providers"
    CommandCategory.PROFILES -> "Profiles"
    CommandCategory.MISSIONS -> "Missions"
    CommandCategory.CONNECTIONS -> "Connections / Nodes"
    CommandCategory.FILES -> "Files"
    CommandCategory.UPDATES -> "Updates / Patch Notes"
    CommandCategory.CHAT -> "Chat"
    CommandCategory.SYSTEM -> "System"
}

private fun categoryGlyph(category: CommandCategory): String = when (category) {
    CommandCategory.FORGE -> "🔥"
    CommandCategory.AI -> "✦"
    CommandCategory.PROFILES -> "🎭"
    CommandCategory.MISSIONS -> "🧭"
    CommandCategory.CONNECTIONS -> "🔗"
    CommandCategory.FILES -> "📂"
    CommandCategory.UPDATES -> "🧾"
    CommandCategory.CHAT -> "💬"
    CommandCategory.SYSTEM -> "⚙"
}

private fun approvalLabel(approval: CommandApproval): String = when (approval) {
    CommandApproval.READ_ONLY -> "READ-ONLY"
    CommandApproval.REVIEW -> "REVIEW"
    CommandApproval.CONFIRM -> "APPROVAL"
    CommandApproval.SENSITIVE -> "SENSITIVE"
}

private fun availabilityLabel(availability: CommandAvailability): String = when (availability) {
    CommandAvailability.AVAILABLE -> "READY"
    CommandAvailability.REQUIRES_CONFIGURATION -> "CONFIG REQUIRED"
    CommandAvailability.PLANNED -> "PLANNED"
}
