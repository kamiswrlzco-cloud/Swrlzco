package sh.swurlz.core.ui.theme

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin
import sh.swrlz.theme.ThemeChromeMotif

/**
 * Presentation-only application atmosphere resolved from the active ThemePack.
 * It never reads or mutates mission, trust, identity, permission, or protocol state.
 */
@Composable
fun ThemeAppBackdrop(
    motionEnabled: Boolean,
    modifier: Modifier = Modifier,
    artAlphaOverride: Float? = null,
) {
    val context = LocalContext.current
    val pack = LocalThemePack.current
    val tokens = LocalSwurlzTokens.current
    val motion = LocalThemeMotionPolicy.current
    val animate = motionEnabled && motion.enabled
    val transition = if (animate) rememberInfiniteTransition(label = "theme-app-atmosphere") else null
    val drift = transition?.animateFloat(
        initialValue = -8f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(
            tween(
                (
                    8_800 * motion.durationMultiplier /
                        pack.motionProfile.particleSpeedMultiplier
                    ).toInt().coerceAtLeast(1_600)
            ),
            RepeatMode.Reverse,
        ),
        label = "theme-art-drift",
    )?.value ?: 0f
    val phase = transition?.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(
                (
                    7_200 * motion.durationMultiplier /
                        pack.motionProfile.particleSpeedMultiplier
                    ).toInt().coerceAtLeast(1_400)
            ),
            RepeatMode.Restart,
        ),
        label = "theme-motif-phase",
    )?.value ?: .42f
    val artAlpha = (artAlphaOverride ?: pack.chromeStyle.backgroundArtAlpha).coerceIn(0f, .55f)
    val backgroundRole = ThemeAssetResolver.backgroundRole(pack)
    val backgroundId = backgroundRole?.let { ThemeAssetResolver.drawableId(context, pack, it) }

    Box(modifier.fillMaxSize()) {
        if (backgroundId != null) {
            Image(
                painter = painterResource(backgroundId),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        translationX = drift
                        translationY = drift * -.32f
                        rotationZ = pack.chromeStyle.ambientTiltDegrees * (drift / 8f)
                        scaleX = 1.10f
                        scaleY = 1.10f
                        alpha = artAlpha
                    },
            )
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            tokens.surfaces.bgTopBar.copy(alpha = .72f),
                            tokens.surfaces.bgApp.copy(alpha = .54f),
                            tokens.surfaces.bgApp.copy(alpha = .94f),
                        )
                    )
                )
        )
        ThemeMotifField(
            motif = pack.chromeStyle.motif,
            phase = phase,
            complexity = pack.chromeStyle.edgeComplexity,
            primary = tokens.accents.primary,
            secondary = tokens.accents.secondary,
            tertiary = tokens.accents.tertiary,
        )
    }
}

@Composable
fun ThemeKapanionAvatar(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    animated: Boolean = false,
    contentDescription: String? = null,
    statusTone: Color? = null,
) {
    val context = LocalContext.current
    val pack = LocalThemePack.current
    val motion = LocalThemeMotionPolicy.current
    val tokens = LocalSwurlzTokens.current
    val role = ThemeAssetResolver.kapanionRole(pack)
    val drawableId = role?.let { ThemeAssetResolver.drawableId(context, pack, it) }
    val transition = if (animated && motion.enabled) {
        rememberInfiniteTransition(label = "theme-kapanion-${pack.id}")
    } else {
        null
    }
    val pulse = transition?.animateFloat(
        initialValue = .975f,
        targetValue = 1.025f,
        animationSpec = infiniteRepeatable(
            tween((1_500 / pack.motionProfile.particleSpeedMultiplier).toInt().coerceAtLeast(520)),
            RepeatMode.Reverse,
        ),
        label = "theme-kapanion-pulse",
    )?.value ?: 1f
    val tone = statusTone ?: tokens.accents.primary
    val shape = CircleShape

    Box(
        modifier = modifier
            .size(size)
            .graphicsLayer {
                scaleX = pulse
                scaleY = pulse
            }
            .clip(shape)
            .background(
                Brush.radialGradient(
                    listOf(
                        tokens.accents.primary.copy(alpha = .28f),
                        tokens.accents.tertiary.copy(alpha = .18f),
                        tokens.surfaces.bgOverlay.copy(alpha = .82f),
                    )
                )
            )
            .border(
                1.5.dp,
                Brush.sweepGradient(
                    listOf(tone, tokens.accents.tertiary, tokens.accents.secondary, tone)
                ),
                shape,
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (drawableId != null) {
            Image(
                painter = painterResource(drawableId),
                contentDescription = contentDescription,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(2.dp),
            )
        } else {
            Text(
                "Ω",
                color = tokens.text.primary,
                fontSize = (size.value * .38f).sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
fun ThemeChromePanel(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    contentPadding: Dp = 15.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    val pack = LocalThemePack.current
    val tokens = LocalSwurlzTokens.current
    val shape = RoundedCornerShape(pack.shapes.cardCornerDp.dp)
    val borderWidth = if (highlighted) pack.dimensions.selectedBorderDp.dp else pack.dimensions.borderDp.dp
    val borderBrush = Brush.linearGradient(
        if (highlighted) {
            listOf(tokens.accents.primary, tokens.accents.tertiary, tokens.accents.secondary)
        } else {
            listOf(
                tokens.accents.primary.copy(alpha = .54f),
                tokens.borders.neutral.copy(alpha = .52f),
                tokens.accents.tertiary.copy(alpha = .46f),
            )
        }
    )
    Box(
        modifier
            .background(borderBrush, shape)
            .padding(borderWidth.coerceAtLeast(1.dp)),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(
                    Brush.linearGradient(
                        listOf(
                            tokens.cards.bg.copy(alpha = .88f),
                            tokens.cards.bgAlt.copy(alpha = .72f),
                            tokens.surfaces.bgPanel.copy(alpha = .78f),
                        )
                    )
                )
                .padding(contentPadding),
            content = content,
        )
        ThemePanelOrnaments(
            modifier = Modifier.matchParentSize(),
            motif = pack.chromeStyle.motif,
            alpha = pack.chromeStyle.panelOrnamentAlpha * if (highlighted) 1f else .72f,
            complexity = pack.chromeStyle.edgeComplexity,
            primary = tokens.accents.primary,
            secondary = tokens.accents.secondary,
        )
    }
}

@Composable
fun ThemeChromeBox(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    innerPadding: Dp = 1.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val pack = LocalThemePack.current
    val tokens = LocalSwurlzTokens.current
    val shape = RoundedCornerShape(pack.shapes.controlCornerDp.dp)
    val brush = Brush.linearGradient(
        listOf(
            tokens.accents.primary.copy(alpha = if (highlighted) .92f else .48f),
            tokens.accents.tertiary.copy(alpha = if (highlighted) .80f else .40f),
            tokens.accents.secondary.copy(alpha = if (highlighted) .78f else .34f),
        )
    )
    Box(
        modifier = modifier
            .background(brush, shape)
            .padding(innerPadding.coerceAtLeast(1.dp))
            .clip(shape)
            .background(tokens.cards.bg.copy(alpha = .82f)),
        content = content,
    )
}

@Composable
private fun ThemePanelOrnaments(
    modifier: Modifier,
    motif: ThemeChromeMotif,
    alpha: Float,
    complexity: Int,
    primary: Color,
    secondary: Color,
) {
    Canvas(modifier) {
        val reach = (18f + complexity * 3f).coerceAtMost(size.minDimension * .24f)
        val stroke = if (motif in angularMotifs) 2f else 1.5f
        val cornerColor = if (motif in warmMotifs) secondary else primary
        drawLine(cornerColor, Offset(0f, reach), Offset(0f, 0f), stroke, alpha = alpha)
        drawLine(cornerColor, Offset(0f, 0f), Offset(reach, 0f), stroke, alpha = alpha)
        drawLine(secondary, Offset(size.width - reach, size.height), Offset(size.width, size.height), stroke, alpha = alpha)
        drawLine(secondary, Offset(size.width, size.height), Offset(size.width, size.height - reach), stroke, alpha = alpha)
        if (motif in jewelMotifs) {
            val radius = 2.8f + complexity * .35f
            drawCircle(primary, radius, Offset(reach * .58f, 0f), alpha = alpha)
            drawCircle(secondary, radius, Offset(size.width - reach * .58f, size.height), alpha = alpha)
        }
    }
}

@Composable
private fun ThemeMotifField(
    motif: ThemeChromeMotif,
    phase: Float,
    complexity: Int,
    primary: Color,
    secondary: Color,
    tertiary: Color,
) {
    Canvas(Modifier.fillMaxSize()) {
        when (motif) {
            ThemeChromeMotif.CORE_CIRCUIT,
            ThemeChromeMotif.NEON_SCAN,
            ThemeChromeMotif.DIGITAL_GLITCH -> {
                val count = (complexity + 3).coerceAtMost(11)
                repeat(count) { index ->
                    val y = size.height * ((index.toFloat() / count + phase * .22f) % 1f)
                    val inset = (index % 3) * size.width * .06f
                    drawLine(
                        if (index % 2 == 0) primary else tertiary,
                        Offset(inset, y),
                        Offset(size.width - inset, y),
                        strokeWidth = if (index % 3 == 0) 2f else 1f,
                        alpha = .055f + (index % 3) * .018f,
                    )
                }
            }

            ThemeChromeMotif.GLASS_SHARD,
            ThemeChromeMotif.FROST,
            ThemeChromeMotif.CYBER_CRYSTAL,
            ThemeChromeMotif.PRISMATIC -> {
                val count = (complexity + 2).coerceAtMost(9)
                repeat(count) { index ->
                    val wave = sin(phase * 6.283f + index).toFloat()
                    val x = size.width * (.08f + (index * .83f / count))
                    val y = size.height * (.12f + ((index * .19f + phase * .13f) % .76f))
                    val h = 36f + (index % 3) * 16f
                    val w = 10f + (index % 2) * 7f
                    val path = Path().apply {
                        moveTo(x, y - h)
                        lineTo(x + w, y + wave * 7f)
                        lineTo(x, y + h)
                        lineTo(x - w, y + wave * 7f)
                        close()
                    }
                    drawPath(
                        path,
                        if (index % 2 == 0) primary else secondary,
                        alpha = .08f + (index % 3) * .025f,
                    )
                }
            }

            ThemeChromeMotif.MAGMA,
            ThemeChromeMotif.JADE_VINE,
            ThemeChromeMotif.TEAL_SERPENT -> {
                val count = (complexity + 2).coerceAtMost(9)
                repeat(count) { index ->
                    val path = Path()
                    val startX = size.width * index / count
                    path.moveTo(startX, size.height)
                    repeat(5) { step ->
                        val y = size.height * (1f - step / 4f)
                        val x = startX + sin(phase * 6.283f + index + step * .8f).toFloat() *
                            (12f + index * 1.4f)
                        path.lineTo(x, y)
                    }
                    drawPath(
                        path,
                        if (index % 2 == 0) primary else secondary,
                        alpha = .07f,
                        style = Stroke(width = 1.8f),
                    )
                }
            }

            ThemeChromeMotif.PHARAOH_GLYPH -> {
                val center = Offset(size.width * .5f, size.height * (.22f + phase * .05f))
                repeat((complexity + 1).coerceAtMost(7)) { index ->
                    val radius = 46f + index * 38f
                    val path = Path().apply {
                        moveTo(center.x, center.y - radius)
                        lineTo(center.x + radius * .86f, center.y + radius * .52f)
                        lineTo(center.x - radius * .86f, center.y + radius * .52f)
                        close()
                    }
                    drawPath(
                        path,
                        if (index % 2 == 0) secondary else primary,
                        alpha = .045f,
                        style = Stroke(width = 1.8f),
                    )
                }
            }

            ThemeChromeMotif.VOID_JESTER,
            ThemeChromeMotif.JESTER_CHAOS -> {
                val count = (complexity + 3).coerceAtMost(11)
                repeat(count) { index ->
                    val angle = phase * 6.283f + index * (6.283f / count)
                    val radius = size.minDimension * (.18f + (index % 3) * .08f)
                    val center = Offset(
                        size.width * .5f + cos(angle).toFloat() * radius,
                        size.height * .38f + sin(angle).toFloat() * radius,
                    )
                    drawCircle(
                        if (index % 2 == 0) secondary else tertiary,
                        radius = 3f + (index % 3) * 2f,
                        center = center,
                        alpha = .12f,
                    )
                }
            }
        }
    }
}

private val angularMotifs = setOf(
    ThemeChromeMotif.GLASS_SHARD,
    ThemeChromeMotif.CORE_CIRCUIT,
    ThemeChromeMotif.NEON_SCAN,
    ThemeChromeMotif.PHARAOH_GLYPH,
    ThemeChromeMotif.DIGITAL_GLITCH,
    ThemeChromeMotif.CYBER_CRYSTAL,
)

private val warmMotifs = setOf(
    ThemeChromeMotif.MAGMA,
    ThemeChromeMotif.PHARAOH_GLYPH,
    ThemeChromeMotif.VOID_JESTER,
    ThemeChromeMotif.JESTER_CHAOS,
)

private val jewelMotifs = setOf(
    ThemeChromeMotif.GLASS_SHARD,
    ThemeChromeMotif.PRISMATIC,
    ThemeChromeMotif.FROST,
    ThemeChromeMotif.JADE_VINE,
    ThemeChromeMotif.CYBER_CRYSTAL,
    ThemeChromeMotif.JESTER_CHAOS,
)
