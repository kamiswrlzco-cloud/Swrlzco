package sh.swurlz.core.github

import android.app.backup.BackupManager
import android.content.Context
import org.json.JSONObject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import sh.swurlz.core.data.SecretStore

/**
 * Durable, backup-aware GitHub Forge connection profile.
 *
 * Runtime secrets remain in [SecretStore]. A custom BackupAgent serializes a tiny
 * encrypted-transport-only restore envelope and re-imports the token into the new
 * install's Android Keystore store during restore.
 */
object GitHubConnectionStore {
    private val mutableRevision = MutableStateFlow(0L)
    val revision: StateFlow<Long> = mutableRevision.asStateFlow()

    private fun publishChange() {
        mutableRevision.value = mutableRevision.value + 1L
    }
    private const val PREFS = "swrlz_github_connection_profile"
    private const val KEY_OAUTH_CLIENT_ID = "oauth_client_id"
    private const val KEY_OWNER = "owner"
    private const val KEY_REPOSITORY = "repository"
    private const val KEY_BRANCH = "branch"
    private const val KEY_FINE_GRAINED_TOKEN_NAME = "fine_grained_token_name"
    private const val KEY_CLIENT_SOURCE_DIRECTORY = "client_source_directory"
    private const val KEY_SERVER_SOURCE_DIRECTORY = "server_source_directory"
    private const val KEY_GENERIC_UPLOAD_DIRECTORY = "generic_upload_directory"
    private const val KEY_CONNECTED_LOGIN = "connected_login"
    private const val KEY_AUTO_CONNECT = "auto_connect"
    private const val KEY_EXPLICITLY_DISCONNECTED = "explicitly_disconnected"
    private const val ENVELOPE_VERSION = 2

    const val DEFAULT_OWNER = "kamiswrlzco-cloud"
    const val DEFAULT_REPOSITORY = "Swrlzco"
    const val DEFAULT_BRANCH = "main"
    const val DEFAULT_FINE_GRAINED_TOKEN_NAME = "SWRLZ GitHub Forge"
    const val DEFAULT_CLIENT_SOURCE_DIRECTORY = "swrlz-core/sources/client"
    const val DEFAULT_SERVER_SOURCE_DIRECTORY = "swrlz-core/sources/server"
    const val DEFAULT_GENERIC_UPLOAD_DIRECTORY = "swrlz-core/requests/inbox"

    data class Profile(
        val oauthClientId: String,
        val owner: String,
        val repository: String,
        val branch: String,
        val fineGrainedTokenName: String,
        val clientSourceDirectory: String,
        val serverSourceDirectory: String,
        val genericUploadDirectory: String,
        val connectedLogin: String,
        val autoConnect: Boolean,
        val explicitlyDisconnected: Boolean,
    )

    fun profile(context: Context): Profile {
        migrateLegacyClientId(context)
        migrateLegacyRepositoryTarget(context)
        migrateLegacyForgeRouting(context)
        val prefs = prefs(context)
        return Profile(
            oauthClientId = prefs.getString(KEY_OAUTH_CLIENT_ID, "").orEmpty(),
            owner = prefs.getString(KEY_OWNER, DEFAULT_OWNER).orEmpty().ifBlank { DEFAULT_OWNER },
            repository = prefs.getString(KEY_REPOSITORY, DEFAULT_REPOSITORY).orEmpty().ifBlank { DEFAULT_REPOSITORY },
            branch = prefs.getString(KEY_BRANCH, DEFAULT_BRANCH).orEmpty().ifBlank { DEFAULT_BRANCH },
            fineGrainedTokenName = prefs.getString(KEY_FINE_GRAINED_TOKEN_NAME, DEFAULT_FINE_GRAINED_TOKEN_NAME).orEmpty().ifBlank { DEFAULT_FINE_GRAINED_TOKEN_NAME },
            clientSourceDirectory = prefs.getString(KEY_CLIENT_SOURCE_DIRECTORY, DEFAULT_CLIENT_SOURCE_DIRECTORY).orEmpty().ifBlank { DEFAULT_CLIENT_SOURCE_DIRECTORY },
            serverSourceDirectory = prefs.getString(KEY_SERVER_SOURCE_DIRECTORY, DEFAULT_SERVER_SOURCE_DIRECTORY).orEmpty().ifBlank { DEFAULT_SERVER_SOURCE_DIRECTORY },
            genericUploadDirectory = prefs.getString(KEY_GENERIC_UPLOAD_DIRECTORY, DEFAULT_GENERIC_UPLOAD_DIRECTORY).orEmpty().ifBlank { DEFAULT_GENERIC_UPLOAD_DIRECTORY },
            connectedLogin = prefs.getString(KEY_CONNECTED_LOGIN, "").orEmpty(),
            autoConnect = prefs.getBoolean(KEY_AUTO_CONNECT, true),
            explicitlyDisconnected = prefs.getBoolean(KEY_EXPLICITLY_DISCONNECTED, false),
        )
    }

    fun setOAuthClientId(context: Context, clientId: String) {
        prefs(context).edit()
            .putString(KEY_OAUTH_CLIENT_ID, clientId.trim())
            .putBoolean(KEY_EXPLICITLY_DISCONNECTED, false)
            .putBoolean(KEY_AUTO_CONNECT, true)
            .commitOrThrow("GitHub OAuth client ID")
        requestBackup(context)
        publishChange()
    }

    fun saveTarget(context: Context, owner: String, repository: String, branch: String) {
        prefs(context).edit()
            .putString(KEY_OWNER, owner.trim())
            .putString(KEY_REPOSITORY, repository.trim())
            .putString(KEY_BRANCH, branch.trim())
            .commitOrThrow("GitHub repository target")
        requestBackup(context)
        publishChange()
    }

    fun saveForgeRouting(
        context: Context,
        fineGrainedTokenName: String,
        clientSourceDirectory: String,
        serverSourceDirectory: String,
        genericUploadDirectory: String,
    ) {
        prefs(context).edit()
            .putString(KEY_FINE_GRAINED_TOKEN_NAME, fineGrainedTokenName.trim().take(40).ifBlank { DEFAULT_FINE_GRAINED_TOKEN_NAME })
            .putString(KEY_CLIENT_SOURCE_DIRECTORY, clientSourceDirectory.trim().trim('/').ifBlank { DEFAULT_CLIENT_SOURCE_DIRECTORY })
            .putString(KEY_SERVER_SOURCE_DIRECTORY, serverSourceDirectory.trim().trim('/').ifBlank { DEFAULT_SERVER_SOURCE_DIRECTORY })
            .putString(KEY_GENERIC_UPLOAD_DIRECTORY, genericUploadDirectory.trim().trim('/').ifBlank { DEFAULT_GENERIC_UPLOAD_DIRECTORY })
            .commitOrThrow("GitHub Forge routing profile")
        requestBackup(context)
        publishChange()
    }

    fun saveAuthorizedConnection(
        context: Context,
        token: String,
        connectedLogin: String,
        oauthClientId: String,
        owner: String,
        repository: String,
        branch: String,
        refreshToken: String = "",
        expiresInSeconds: Int? = null,
        refreshTokenExpiresInSeconds: Int? = null,
    ) {
        SecretStore.setGithubCredential(
            context,
            token = GitHubForgeClient.normalizeToken(token),
            refreshToken = GitHubForgeClient.normalizeToken(refreshToken),
            expiresInSeconds = expiresInSeconds,
            refreshTokenExpiresInSeconds = refreshTokenExpiresInSeconds,
        )
        prefs(context).edit()
            .putString(KEY_OAUTH_CLIENT_ID, oauthClientId.trim())
            .putString(KEY_OWNER, owner.trim())
            .putString(KEY_REPOSITORY, repository.trim())
            .putString(KEY_BRANCH, branch.trim())
            .putString(KEY_CONNECTED_LOGIN, connectedLogin.trim())
            .putBoolean(KEY_AUTO_CONNECT, true)
            .putBoolean(KEY_EXPLICITLY_DISCONNECTED, false)
            .commitOrThrow("GitHub connection profile")
        requestBackup(context)
        publishChange()
    }

    fun markValidated(context: Context, connectedLogin: String) {
        prefs(context).edit()
            .putString(KEY_CONNECTED_LOGIN, connectedLogin.trim())
            .putBoolean(KEY_AUTO_CONNECT, true)
            .putBoolean(KEY_EXPLICITLY_DISCONNECTED, false)
            .commitOrThrow("GitHub validation state")
        requestBackup(context)
        publishChange()
    }


    fun invalidateRejectedCredential(context: Context) {
        SecretStore.forgetGithubToken(context)
        prefs(context).edit()
            .putString(KEY_CONNECTED_LOGIN, "")
            .putBoolean(KEY_AUTO_CONNECT, false)
            .putBoolean(KEY_EXPLICITLY_DISCONNECTED, false)
            .commitOrThrow("GitHub rejected credential state")
        requestBackup(context)
        publishChange()
    }

    fun disconnect(context: Context) {
        SecretStore.forgetGithubToken(context)
        SecretStore.forgetGithubOAuthClientId(context)
        prefs(context).edit()
            .clear()
            .putBoolean(KEY_AUTO_CONNECT, false)
            .putBoolean(KEY_EXPLICITLY_DISCONNECTED, true)
            .commitOrThrow("GitHub disconnect state")
        requestBackup(context)
        publishChange()
    }

    fun shouldAutoConnect(context: Context): Boolean {
        val profile = profile(context)
        return profile.autoConnect && !profile.explicitlyDisconnected
    }

    /**
     * Payload consumed only by [sh.swurlz.core.backup.SwrlzBackupAgent].
     * The agent writes it only when the Android backup transport reports client-side
     * encryption or direct device-to-device transfer.
     */
    fun backupEnvelope(context: Context): ByteArray {
        val profile = profile(context)
        val token = SecretStore.githubToken(context)
        val refreshToken = SecretStore.githubRefreshToken(context)
        val accessExpiresAt = SecretStore.githubAccessExpiresAt(context)
        val refreshExpiresAt = SecretStore.githubRefreshExpiresAt(context)
        val payload = JSONObject()
            .put("version", ENVELOPE_VERSION)
            .put("oauthClientId", profile.oauthClientId)
            .put("owner", profile.owner)
            .put("repository", profile.repository)
                        .put("branch", profile.branch)
            .put("fineGrainedTokenName", profile.fineGrainedTokenName)
            .put("clientSourceDirectory", profile.clientSourceDirectory)
            .put("serverSourceDirectory", profile.serverSourceDirectory)
            .put("genericUploadDirectory", profile.genericUploadDirectory)
            .put("connectedLogin", profile.connectedLogin)
            .put("autoConnect", profile.autoConnect)
            .put("explicitlyDisconnected", profile.explicitlyDisconnected)
            .put("token", if (profile.autoConnect && !profile.explicitlyDisconnected) token else "")
            .put("refreshToken", if (profile.autoConnect && !profile.explicitlyDisconnected) refreshToken else "")
            .put("accessExpiresAt", if (profile.autoConnect && !profile.explicitlyDisconnected) accessExpiresAt else 0L)
            .put("refreshExpiresAt", if (profile.autoConnect && !profile.explicitlyDisconnected) refreshExpiresAt else 0L)
        return payload.toString().toByteArray(Charsets.UTF_8)
    }

    fun restoreEnvelope(context: Context, bytes: ByteArray): Boolean {
        val payload = runCatching { JSONObject(bytes.toString(Charsets.UTF_8)) }.getOrNull() ?: return false
        if (payload.optInt("version", 0) !in 1..ENVELOPE_VERSION) return false

        val disconnected = payload.optBoolean("explicitlyDisconnected", false)
        val autoConnect = payload.optBoolean("autoConnect", true) && !disconnected
        val token = payload.optString("token", "").trim()
        val refreshToken = payload.optString("refreshToken", "").trim()
        val accessExpiresAt = payload.optLong("accessExpiresAt", 0L)
        val refreshExpiresAt = payload.optLong("refreshExpiresAt", 0L)

        prefs(context).edit()
            .putString(KEY_OAUTH_CLIENT_ID, payload.optString("oauthClientId", "").trim())
            .putString(KEY_OWNER, payload.optString("owner", DEFAULT_OWNER).trim())
            .putString(KEY_REPOSITORY, payload.optString("repository", DEFAULT_REPOSITORY).trim())
            .putString(KEY_BRANCH, payload.optString("branch", DEFAULT_BRANCH).trim())
            .putString(KEY_FINE_GRAINED_TOKEN_NAME, payload.optString("fineGrainedTokenName", DEFAULT_FINE_GRAINED_TOKEN_NAME).trim())
            .putString(KEY_CLIENT_SOURCE_DIRECTORY, payload.optString("clientSourceDirectory", DEFAULT_CLIENT_SOURCE_DIRECTORY).trim())
            .putString(KEY_SERVER_SOURCE_DIRECTORY, payload.optString("serverSourceDirectory", DEFAULT_SERVER_SOURCE_DIRECTORY).trim())
            .putString(KEY_GENERIC_UPLOAD_DIRECTORY, payload.optString("genericUploadDirectory", DEFAULT_GENERIC_UPLOAD_DIRECTORY).trim())
            .putString(KEY_CONNECTED_LOGIN, payload.optString("connectedLogin", "").trim())
            .putBoolean(KEY_AUTO_CONNECT, autoConnect)
            .putBoolean(KEY_EXPLICITLY_DISCONNECTED, disconnected)
            .commitOrThrow("restored GitHub profile")

        if (autoConnect && token.isNotBlank()) {
            val now = System.currentTimeMillis()
            val accessSeconds = ((accessExpiresAt - now) / 1000L).takeIf { it > 0 }?.coerceAtMost(Int.MAX_VALUE.toLong())?.toInt()
            val refreshSeconds = ((refreshExpiresAt - now) / 1000L).takeIf { it > 0 }?.coerceAtMost(Int.MAX_VALUE.toLong())?.toInt()
            SecretStore.setGithubCredential(
                context,
                token = token,
                refreshToken = refreshToken,
                expiresInSeconds = accessSeconds,
                refreshTokenExpiresInSeconds = refreshSeconds,
            )
        } else {
            SecretStore.forgetGithubToken(context)
        }
        return true
    }

    private fun migrateLegacyRepositoryTarget(context: Context) {
        val prefs = prefs(context)
        val owner = prefs.getString(KEY_OWNER, "").orEmpty().trim()
        val repository = prefs.getString(KEY_REPOSITORY, "").orEmpty().trim()
        if (owner.equals("ahazus420-stack", ignoreCase = true) && repository.equals("Swrlzcore", ignoreCase = true)) {
            prefs.edit()
                .putString(KEY_OWNER, DEFAULT_OWNER)
                .putString(KEY_REPOSITORY, DEFAULT_REPOSITORY)
                .commit()
            requestBackup(context)
        }
    }

    private fun migrateLegacyForgeRouting(context: Context) {
        val prefs = prefs(context)
        val owner = prefs.getString(KEY_OWNER, DEFAULT_OWNER).orEmpty().trim()
        val repository = prefs.getString(KEY_REPOSITORY, DEFAULT_REPOSITORY).orEmpty().trim()
        if (!owner.equals(DEFAULT_OWNER, ignoreCase = true) || !repository.equals(DEFAULT_REPOSITORY, ignoreCase = true)) return

        val clientDirectory = prefs.getString(KEY_CLIENT_SOURCE_DIRECTORY, "").orEmpty().trim().trim('/')
        val serverDirectory = prefs.getString(KEY_SERVER_SOURCE_DIRECTORY, "").orEmpty().trim().trim('/')
        val genericDirectory = prefs.getString(KEY_GENERIC_UPLOAD_DIRECTORY, "").orEmpty().trim().trim('/')
        val edit = prefs.edit()
        var changed = false

        if (clientDirectory.isBlank() || clientDirectory.equals("SOURCES/CLIENT", ignoreCase = true)) {
            edit.putString(KEY_CLIENT_SOURCE_DIRECTORY, DEFAULT_CLIENT_SOURCE_DIRECTORY)
            changed = true
        }
        if (serverDirectory.isBlank() || serverDirectory.equals("SOURCES/SERVER", ignoreCase = true)) {
            edit.putString(KEY_SERVER_SOURCE_DIRECTORY, DEFAULT_SERVER_SOURCE_DIRECTORY)
            changed = true
        }
        if (genericDirectory.isBlank() || genericDirectory.equals("SOURCES/INBOX", ignoreCase = true)) {
            edit.putString(KEY_GENERIC_UPLOAD_DIRECTORY, DEFAULT_GENERIC_UPLOAD_DIRECTORY)
            changed = true
        }
        if (changed) {
            edit.commit()
            requestBackup(context)
            publishChange()
        }
    }

    private fun migrateLegacyClientId(context: Context) {
        val prefs = prefs(context)
        if (!prefs.getString(KEY_OAUTH_CLIENT_ID, "").isNullOrBlank()) return
        val legacy = SecretStore.githubOAuthClientId(context).trim()
        if (legacy.isBlank()) return
        prefs.edit().putString(KEY_OAUTH_CLIENT_ID, legacy).commit()
        requestBackup(context)
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun android.content.SharedPreferences.Editor.commitOrThrow(label: String) {
        check(commit()) { "Unable to persist $label." }
    }

    private fun requestBackup(context: Context) {
        runCatching { BackupManager(context.applicationContext).dataChanged() }
    }
}
