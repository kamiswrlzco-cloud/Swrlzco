package sh.swurlz.core.github

import android.content.Context
import org.json.JSONObject
import java.security.MessageDigest

/**
 * Reuses an unresolved Forge transaction ID for the same repository + staged package snapshot.
 * This prevents a transient GitHub 5xx/read-back failure from creating a duplicate commit when
 * the operator presses the one-action upload control again.
 */
object ForgePendingTransactionStore {
    private const val PREFS = "swrlz_forge_pending_transaction_v1"
    private const val KEY_RECORDS = "records"
    private const val MAX_AGE_MS = 24L * 60L * 60L * 1000L

    fun fingerprint(request: GitHubForgeClient.UploadRequest): String {
        val canonical = buildString {
            append(request.owner.trim().lowercase()).append('/')
            append(request.repository.trim().lowercase()).append('@')
            append(request.branch.trim()).append('|')
            request.files
                .sortedBy { GitHubForgeClient.logicalSourceKey(it.displayName) }
                .forEach { file ->
                    append(GitHubForgeClient.logicalSourceKey(file.displayName))
                    append(':').append(file.sizeBytes)
                    append(':').append(file.uri)
                    append('|')
                }
        }
        return MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    @Synchronized
    fun beginOrReuse(context: Context, fingerprint: String, requestedId: String): String {
        val now = System.currentTimeMillis()
        val records = load(context)
        val existing = records.optJSONObject(fingerprint)
        val existingId = existing?.optString("transactionId").orEmpty()
        val existingAt = existing?.optLong("recordedAt", 0L) ?: 0L
        val chosen = if (existingId.isNotBlank() && now - existingAt <= MAX_AGE_MS) existingId else requestedId
        records.put(
            fingerprint,
            JSONObject()
                .put("transactionId", chosen)
                .put("recordedAt", now),
        )
        save(context, records)
        return chosen
    }

    @Synchronized
    fun complete(context: Context, fingerprint: String, transactionId: String) {
        val records = load(context)
        val existing = records.optJSONObject(fingerprint)
        if (existing?.optString("transactionId") == transactionId) {
            records.remove(fingerprint)
            save(context, records)
        }
    }

    private fun load(context: Context): JSONObject = runCatching {
        JSONObject(preferences(context).getString(KEY_RECORDS, "{}").orEmpty())
    }.getOrDefault(JSONObject())

    private fun save(context: Context, records: JSONObject) {
        preferences(context).edit().putString(KEY_RECORDS, records.toString()).apply()
    }

    private fun preferences(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
