package sh.swurlz.core.net

import android.content.Context
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.CoreNodeConfig
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL
import java.time.Instant
import java.util.Collections

object CoreNodeAutoDiscovery {
    data class AutoResult(
        val connected: Boolean,
        val discoveryReachable: Boolean = false,
        val sessionOnline: Boolean = false,
        val foundUrl: String = "",
        val source: String = "none",
        val summary: String = "not checked",
        val detail: String = "",
        val candidatesTried: Int = 0,
    )

    private data class ProbeResult(
        val baseUrl: String,
        val ok: Boolean,
        val httpCode: Int = -1,
        val body: String = "",
        val error: String = "",
    )

    suspend fun connectOnLaunch(
        context: Context,
        scanWhenNeeded: Boolean = true,
        includeLoopbackRange: Boolean = false,
    ): AutoResult {
        val config = Prefs.coreNodeConfig(context)
        val savedUrl = normalizeBaseUrl(config.nodeUrl)
        val lastGoodUrl = loadLastGoodNodeUrl(context)
        val directTargets = listOf(savedUrl, lastGoodUrl).filter { it.isNotBlank() }.distinct()

        for ((index, target) in directTargets.withIndex()) {
            val source = if (index == 0 && target == savedUrl) "saved-core-node" else "last-good-node"
            val result = verifyAndPersist(context, target, config.pairingToken, source, candidatesTried = index + 1)
            if (result.connected) return result
        }

        if (!scanWhenNeeded) {
            val msg = if (directTargets.isEmpty()) {
                "No saved Core Node or last-good node to test."
            } else {
                "Saved/last-good nodes did not verify. Subnet scan was disabled."
            }
            Prefs.setCoreNodeAutoCheck(context, false, msg, directTargets.joinToString("\n"))
            return AutoResult(false, summary = msg, detail = msg, candidatesTried = directTargets.size)
        }

        val candidates = candidateUrls(
            primary = savedUrl,
            saved = lastGoodUrl,
            includeLoopbackSweep = includeLoopbackRange,
        )
        var tried = 0
        for (batch in candidates.chunked(28)) {
            val probes = coroutineScope {
                batch.map { candidate -> async { probeSignature(candidate, timeoutMs = 650) } }.awaitAll()
            }
            tried += batch.size
            val hit = probes.firstOrNull { it.ok }
            if (hit != null) {
                return verifyAndPersist(context, hit.baseUrl, config.pairingToken, "trimmed-subnet-scan", tried)
            }
        }

        val msg = "BOOT-SYNC did not find a valid SWRLZ node. Checked $tried candidate(s)."
        Prefs.setCoreNodeAutoCheck(context, false, msg, candidates.take(28).joinToString("\n"))
        return AutoResult(
            connected = false,
            summary = msg,
            detail = "Tried saved node, last-good node, same-device loopback, and current-device subnet candidates. Manual scan can still be run from Network Discovery.",
            candidatesTried = tried,
        )
    }

    private suspend fun verifyAndPersist(
        context: Context,
        target: String,
        token: String,
        source: String,
        candidatesTried: Int,
    ): AutoResult {
        val signature = probeSignature(target, timeoutMs = 900)
        if (!signature.ok) {
            return AutoResult(
                connected = false,
                foundUrl = normalizeBaseUrl(target),
                source = source,
                summary = "Signature failed for ${normalizeBaseUrl(target)}",
                detail = signature.describe(),
                candidatesTried = candidatesTried,
            )
        }
        val status = probeStatus(signature.baseUrl, token, timeoutMs = 1000)
        val registration = ClientPresenceRegistration.register(context, signature.baseUrl)
        val now = saveLastGoodNode(context, signature.baseUrl)
        Prefs.setCoreNodeConfig(context, CoreNodeConfig(nodeUrl = signature.baseUrl, pairingToken = token))
        val summary = if (status.ok) {
            "BOOT-SYNC connected via $source · /status OK"
        } else {
            "BOOT-SYNC connected via $source · signature OK · /status warning"
        }
        val detail = buildString {
            append("URL: ${signature.baseUrl}\n")
            append("Source: $source\n")
            append("Candidates tried: $candidatesTried\n")
            append("Last-good refreshed: $now\n")
            append("\n/discovery/signature:\n")
            append(signature.describe())
            append("\n\n/status:\n")
            append(status.describe())
            append("\n\n/registration:\n")
            append(registration.state).append(" · ").append(registration.detail)
        }
        Prefs.setCoreNodeAutoCheck(context, registration.ok, if (registration.ok) summary else "Discovery reachable; registration failed", detail)
        return AutoResult(
            connected = registration.ok,
            discoveryReachable = true,
            sessionOnline = registration.ok,
            foundUrl = signature.baseUrl,
            source = source,
            summary = if (registration.ok) "$summary · CLIENT online" else "Discovery reachable via $source · registration failed",
            detail = detail,
            candidatesTried = candidatesTried,
        )
    }

    private fun probeSignature(input: String, timeoutMs: Int = 1500): ProbeResult {
        val base = normalizeBaseUrl(input)
        if (base.isBlank()) return ProbeResult(base, false, error = "empty node URL")
        return probeUrl("$base/discovery/signature", base, timeoutMs) { body ->
            val lower = body.lowercase()
            lower.contains("swrlz-local-node") && lower.contains("discovery-signature")
        }
    }

    private fun probeStatus(base: String, token: String, timeoutMs: Int = 1500): ProbeResult {
        val normalized = normalizeBaseUrl(base)
        if (normalized.isBlank()) return ProbeResult(normalized, false, error = "empty node URL")
        return probeUrl("$normalized/status", normalized, timeoutMs, token) { body ->
            val lower = body.lowercase()
            lower.contains("\"ok\"") || lower.contains("swrlz") || lower.contains("local-node")
        }
    }

    private fun probeUrl(
        url: String,
        base: String,
        timeoutMs: Int,
        token: String = "",
        acceptBody: (String) -> Boolean,
    ): ProbeResult {
        var connection: HttpURLConnection? = null
        return try {
            connection = URL(url).openConnection() as HttpURLConnection
            connection.connectTimeout = timeoutMs
            connection.readTimeout = timeoutMs
            connection.requestMethod = "GET"
            connection.setRequestProperty("Accept", "application/json")
            if (token.isNotBlank()) connection.setRequestProperty("X-Swurlz-Token", token)
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            ProbeResult(base, code in 200..299 && acceptBody(body), code, body.take(1800))
        } catch (err: Throwable) {
            ProbeResult(base, false, error = "${err.javaClass.simpleName}: ${err.message}")
        } finally {
            connection?.disconnect()
        }
    }

    private fun ProbeResult.describe(): String = buildString {
        append("URL: $baseUrl\n")
        append("OK: $ok\n")
        if (httpCode >= 0) append("HTTP: $httpCode\n")
        if (body.isNotBlank()) append(body)
        if (error.isNotBlank()) append("Error: $error")
    }

    private fun candidateUrls(primary: String, saved: String = "", includeLoopbackSweep: Boolean = false): List<String> {
        val normalizedPrimary = normalizeBaseUrl(primary)
        val normalizedSaved = normalizeBaseUrl(saved)
        val candidates = mutableListOf<String>()
        val port = firstUsablePort(normalizedPrimary, normalizedSaved, defaultPort = 8787)

        // CF11 Discovery Authority Patch:
        // Prefer active interface subnets before historical/saved ranges.
        localIpv4Addresses().forEach { ip ->
            candidates += subnetSweepCandidatesFromIpv4(ip, port, includeLoopbackSweep)
        }

        if (normalizedPrimary.isNotBlank()) candidates += normalizedPrimary
        if (normalizedSaved.isNotBlank()) candidates += normalizedSaved

        candidates += inferredSubnetSweepCandidates(normalizedPrimary, port, includeLoopbackSweep)
        candidates += inferredSubnetSweepCandidates(normalizedSaved, port, includeLoopbackSweep)
        candidates += listOf(
            "http://127.0.0.1:$port",
            "http://localhost:$port",
            "http://10.0.2.2:$port",
            "http://192.168.0.1:$port",
            "http://192.168.1.1:$port",
            "http://192.168.4.1:$port",
        )
        return candidates.map { normalizeBaseUrl(it) }.filter { it.isNotBlank() }.distinct()
    }

    private fun firstUsablePort(vararg urls: String, defaultPort: Int): Int {
        urls.forEach { url ->
            runCatching { URL(normalizeBaseUrl(url)) }.getOrNull()?.let { parsed ->
                if (parsed.port in 1..65535) return parsed.port
            }
        }
        return defaultPort
    }

    private fun inferredSubnetSweepCandidates(baseUrl: String, fallbackPort: Int, includeLoopbackSweep: Boolean): List<String> {
        if (baseUrl.isBlank()) return emptyList()
        return runCatching {
            val parsed = URL(normalizeBaseUrl(baseUrl))
            val host = parsed.host ?: return emptyList()
            val port = if (parsed.port > 0) parsed.port else fallbackPort
            subnetSweepCandidatesFromIpv4(host, port, includeLoopbackSweep)
        }.getOrElse { emptyList() }
    }

    private fun subnetSweepCandidatesFromIpv4(ipv4: String, port: Int, includeLoopbackSweep: Boolean): List<String> {
        val parts = ipv4.split('.')
        if (parts.size != 4 || parts.any { it.toIntOrNull() !in 0..255 }) return emptyList()
        val prefix = parts.take(3).joinToString(".")
        if (prefix == "127.0.0" && !includeLoopbackSweep) return emptyList()
        return (1..254).map { last -> "http://$prefix.$last:$port" }
    }

    private fun localIpv4Addresses(): List<String> = try {
        Collections.list(NetworkInterface.getNetworkInterfaces())
            .filter { iface -> iface.isUp && !iface.isLoopback }
            .flatMap { iface -> Collections.list(iface.inetAddresses) }
            .filterIsInstance<Inet4Address>()
            .map { it.hostAddress ?: "" }
            .filter { ip -> ip.isNotBlank() && !ip.startsWith("127.") && !ip.startsWith("169.254.") }
            .distinct()
    } catch (_: Throwable) {
        emptyList()
    }

    private fun normalizeBaseUrl(input: String): String {
        val trimmed = input.trim().trimEnd('/')
        return when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.isNotBlank() -> "http://$trimmed"
            else -> ""
        }
    }

    private fun loadLastGoodNodeUrl(context: Context): String =
        context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LAST_GOOD_URL, "")
            .orEmpty()
            .trim()

    private fun saveLastGoodNode(context: Context, url: String): String {
        val normalized = normalizeBaseUrl(url)
        val now = Instant.now().toString()
        context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LAST_GOOD_URL, normalized)
            .putString(KEY_LAST_GOOD_AT, now)
            .apply()
        return now
    }

    private const val DISCOVERY_PREFS = "swrlz_discovery_settings"
    private const val KEY_LAST_GOOD_URL = "last_good_node_url"
    private const val KEY_LAST_GOOD_AT = "last_good_node_at"
}
