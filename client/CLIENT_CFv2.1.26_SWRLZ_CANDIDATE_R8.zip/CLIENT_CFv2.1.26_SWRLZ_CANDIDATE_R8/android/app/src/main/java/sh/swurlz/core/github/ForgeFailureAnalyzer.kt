package sh.swurlz.core.github

import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

/**
 * Redaction-safe, deterministic Forge failure summarizer.
 * It reports verified evidence from upload/workflow logs separately from likely causes and next actions.
 */
object ForgeFailureAnalyzer {
    fun analyzeUpload(logBytes: ByteArray?, failure: Throwable? = null): String {
        val text = logBytes?.toString(Charsets.UTF_8).orEmpty()
        val evidence = selectEvidence(text).ifEmpty {
            listOfNotNull(failure?.message?.takeIf { it.isNotBlank() }).take(3)
        }
        val classification = classify((evidence + text.takeLast(8_000)).joinToString("\n"))
        return format(
            verified = evidence.ifEmpty { listOf("Forge reported an upload failure, but the diagnostic log did not contain a specific error line.") },
            likely = classification.first,
            action = classification.second,
        )
    }

    fun analyzeWorkflow(
        run: GitHubForgeClient.WorkflowRun,
        jobs: List<GitHubForgeClient.WorkflowJob>,
        zippedLogs: ByteArray,
    ): String {
        val failedJobs = jobs.filter { it.conclusion !in setOf(null, "success", "skipped", "neutral") }
        val failedSteps = failedJobs.flatMap { job ->
            job.steps.filter { it.conclusion !in setOf(null, "success", "skipped", "neutral") }
                .map { step -> "${job.name} → ${step.name}: ${step.conclusion ?: "failed"}" }
        }
        val text = unzipText(zippedLogs)
        val evidence = (failedSteps + selectEvidence(text)).distinct().take(6)
        val classification = classify((evidence + text.takeLast(20_000)).joinToString("\n"))
        return format(
            verified = listOf("${run.name} concluded ${run.conclusion ?: "failure"}.") + evidence,
            likely = classification.first,
            action = classification.second,
        )
    }

    private fun unzipText(bytes: ByteArray): String {
        val out = StringBuilder()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            var entry = zip.nextEntry
            while (entry != null && out.length < 250_000) {
                if (!entry.isDirectory) {
                    val name = entry.name.lowercase()
                    if (name.endsWith(".txt") || name.endsWith(".log") || name.contains("job") || name.contains("step")) {
                        val buffer = ByteArray(8192)
                        while (out.length < 250_000) {
                            val n = zip.read(buffer)
                            if (n <= 0) break
                            out.append(String(buffer, 0, n, Charsets.UTF_8))
                        }
                        out.append('\n')
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        return out.toString()
    }

    private fun selectEvidence(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val markers = listOf("error", "exception", "failed", "failure", "fatal", "denied", "forbidden", "unauthorized", "checksum mismatch", "not found", "unresolved reference")
        return text.lineSequence()
            .map { it.trim() }
            .filter { line -> line.length in 8..500 && markers.any { marker -> line.contains(marker, ignoreCase = true) } }
            .map { it.replace(Regex("(?i)(github_pat_|gh[pousr]_)[A-Za-z0-9_]+"), "[REDACTED]") }
            .distinct()
            .take(5)
            .toList()
    }

    private fun classify(text: String): Pair<String, String> {
        val lower = text.lowercase()
        return when {
            "missing manifest" in lower || ("manifest.json" in lower && "missing" in lower) ->
                "Likely cause: the source package is missing its canonical metadata ZIP, or the metadata ZIP checksum/manifest disagree with the source identity. Legacy loose checksum + manifest sidecars are accepted only during bootstrap." to "Keep the source ZIP unchanged. Provide the matching metadata ZIP or a complete bootstrap legacy sidecar pair, repair any identity mismatch, and retry the same source lineage."
            "unresolved reference" in lower || "compiledebugkotlin" in lower || "compilation error" in lower ->
                "Likely cause: Kotlin compilation failed." to "Open the failing source/step, correct the compiler error, then retry the failed workflow or upload the corrected source package."
            "checksum mismatch" in lower || "sha-256" in lower && "mismatch" in lower ->
                "Likely cause: the source ZIP and SHA receipt do not describe the same bytes." to "Regenerate the SHA-256 receipt from the exact ZIP being uploaded, pair them again, and retry."
            "401" in lower || "unauthorized" in lower || "bad credentials" in lower ->
                "Likely cause: GitHub rejected the saved credential." to "Reconnect or replace the fine-grained token, validate Forge access, then retry."
            "403" in lower || "forbidden" in lower || "permission" in lower && "denied" in lower ->
                "Likely cause: GitHub permissions or repository policy blocked the operation." to "Check token repository access and required Contents/Actions permissions, then retry after validation."
            "404" in lower || "not found" in lower ->
                "Likely cause: Forge could not resolve a required repository path, run, artifact, or API resource." to "Refresh repository/workflow state and verify the configured owner, repository, branch, and target path."
            "timeout" in lower || "timed out" in lower || "connection" in lower && "failed" in lower ->
                "Likely cause: the network/API operation did not complete reliably." to "Confirm connectivity, refresh Forge state, and retry. The source should not be treated as uploaded until GitHub confirms it."
            "gradle" in lower && ("failed" in lower || "error" in lower) ->
                "Likely cause: the Gradle build failed during CI." to "Use the failed job/step and log evidence above to repair the build, then retry the failed job."
            else ->
                "Likely cause: Forge recorded a failure, but the available evidence does not support a narrower classification yet." to "Open the full Forge log for the exact failing phase, correct the verified error, and retry only after the underlying cause is addressed."
        }
    }

    private fun format(verified: List<String>, likely: String, action: String): String = buildString {
        append("Verified evidence:\n")
        verified.take(6).forEach { append("• ").append(it.take(420)).append('\n') }
        append('\n').append(likely)
        append("\n\nRecommended next step: ").append(action)
    }.trim()
}
