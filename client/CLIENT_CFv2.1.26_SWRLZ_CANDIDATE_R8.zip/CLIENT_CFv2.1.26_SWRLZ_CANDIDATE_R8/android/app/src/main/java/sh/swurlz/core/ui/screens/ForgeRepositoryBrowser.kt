package sh.swurlz.core.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.github.GitHubConnectionStore
import sh.swurlz.core.github.GitHubForgeClient
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import sh.swurlz.core.ui.theme.ProgressSnapshot
import sh.swurlz.core.ui.theme.ThemedProgressBar
import sh.swrlz.theme.ThemeProgressState

@Composable
internal fun ForgeModeSelector(selected: String, onSelected: (String) -> Unit) {
    val tokens = LocalSwurlzTokens.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        listOf("FORGE" to "🔥 FORGE", "FILES" to "🧭 FILE LAB", "REPOSITORY" to "📁 REPOSITORY").forEach { (id, label) ->
            OutlinedButton(
                onClick = { onSelected(id) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (selected == id) tokens.accents.primary else tokens.borders.neutral),
            ) {
                Text(label, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = if (selected == id) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}

@Composable
internal fun ForgeWorkflowLauncher(
    owner: String,
    repository: String,
    branch: String,
    token: String,
    connected: Boolean,
    onStatus: (String) -> Unit,
    onDispatched: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val tokens = LocalSwurlzTokens.current
    var expanded by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var workflows by remember { mutableStateOf(emptyList<GitHubForgeClient.WorkflowDescriptor>()) }
    var selected by remember { mutableStateOf<GitHubForgeClient.WorkflowDescriptor?>(null) }
    var inputs by remember { mutableStateOf(emptyList<GitHubForgeClient.WorkflowInput>()) }
    val values = remember { mutableStateMapOf<String, String>() }
    var ref by rememberSaveable(branch) { mutableStateOf(branch) }

    fun loadWorkflows() {
        if (!connected || token.isBlank()) return
        busy = true
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.listRepositoryWorkflows(owner, repository, token) } }
                .onSuccess { list ->
                    workflows = list
                    onStatus("Loaded ${list.size} GitHub Actions workflow(s).")
                }
                .onFailure { onStatus("Workflow discovery failed: ${it.message}") }
            busy = false
        }
    }

    LaunchedEffect(owner, repository, token, connected) {
        if (connected && token.isNotBlank()) loadWorkflows()
    }

    Column(
        Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bg).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ACTIONS LAUNCHER", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.4.sp)
                Text("Discover repository workflows and run workflow_dispatch without touching source files.", color = tokens.text.secondary, fontSize = 11.sp)
            }
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "CLOSE ▲" else "OPEN ▼") }
        }
        if (!expanded) return@Column
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search actions") })
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled = connected && !busy, onClick = { loadWorkflows() }, modifier = Modifier.weight(1f)) { Text("REFRESH") }
            OutlinedTextField(ref, { ref = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Ref") })
        }
        val filtered = workflows.filter { query.isBlank() || it.name.contains(query, true) || it.path.contains(query, true) }
        filtered.forEach { workflow ->
            val active = workflow.state.equals("active", true)
            Column(
                Modifier.fillMaxWidth().border(1.dp, if (selected?.id == workflow.id) tokens.accents.primary else tokens.borders.neutral).clickable(enabled = active) {
                    selected = workflow
                    values.clear()
                    inputs = emptyList()
                    busy = true
                    scope.launch {
                        runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.readRepositoryText(owner, repository, ref.ifBlank { branch }, token, workflow.path) } }
                            .onSuccess { yaml ->
                                inputs = GitHubForgeClient.parseWorkflowDispatchInputs(yaml)
                                inputs.forEach { input -> values[input.name] = input.defaultValue }
                                onStatus("Loaded dispatch contract for ${workflow.name}: ${inputs.size} input(s).")
                            }
                            .onFailure { onStatus("Unable to read ${workflow.path}: ${it.message}") }
                        busy = false
                    }
                }.padding(10.dp),
            ) {
                Text(workflow.name, fontWeight = FontWeight.Bold, color = tokens.text.primary, fontSize = 12.sp)
                Text("${workflow.state} · ${workflow.path}", color = tokens.text.secondary, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
            }
        }
        selected?.let { workflow ->
            HorizontalDivider()
            Text("RUN · ${workflow.name}", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            if (inputs.isEmpty()) Text("No workflow_dispatch inputs detected; defaults will be used.", color = tokens.text.secondary, fontSize = 10.sp)
            inputs.forEach { input ->
                Text("${input.name}${if (input.required) " *" else ""}", color = tokens.text.primary, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                if (input.description.isNotBlank()) Text(input.description, color = tokens.text.secondary, fontSize = 10.sp)
                when {
                    input.type == "boolean" -> {
                        val checked = values[input.name].equals("true", true)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (checked) "TRUE" else "FALSE", modifier = Modifier.weight(1f), color = tokens.text.secondary)
                            Switch(checked, { values[input.name] = it.toString() })
                        }
                    }
                    input.options.isNotEmpty() -> {
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            input.options.forEach { option ->
                                OutlinedButton(
                                    onClick = { values[input.name] = option },
                                    border = BorderStroke(1.dp, if (values[input.name] == option) tokens.accents.primary else tokens.borders.neutral),
                                ) { Text(option, fontSize = 9.sp) }
                            }
                        }
                    }
                    else -> OutlinedTextField(values[input.name].orEmpty(), { values[input.name] = it }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
            }
            val missing = inputs.filter { it.required && values[it.name].isNullOrBlank() }
            Button(
                enabled = connected && !busy && ref.isNotBlank() && missing.isEmpty(),
                onClick = {
                    busy = true
                    onStatus("Dispatching ${workflow.name} on ${ref.trim()}…")
                    scope.launch {
                        runCatching {
                            withContext(Dispatchers.IO) {
                                GitHubForgeClient.dispatchWorkflow(owner, repository, workflow.id, ref.trim(), values.toMap(), token)
                            }
                        }.onSuccess { result ->
                            onStatus(result.runId?.let { "Workflow dispatched · run $it." } ?: "Workflow dispatch accepted. Refreshing run observer…")
                            delay(900)
                            onDispatched()
                        }.onFailure { onStatus("Workflow dispatch failed: ${it.message}") }
                        busy = false
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (busy) "DISPATCHING…" else "RUN ACTION") }
        }
    }
}

@Composable
internal fun ForgeRepositoryBrowserScreen() {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    val profileRevision by GitHubConnectionStore.revision.collectAsState()
    val profile = remember(profileRevision) { GitHubConnectionStore.profile(context) }
    val token = remember(profileRevision) { if (GitHubConnectionStore.shouldAutoConnect(context)) SecretStore.githubToken(context) else "" }

    var branch by rememberSaveable(profileRevision) { mutableStateOf(profile.branch) }
    var path by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    var items by remember { mutableStateOf(emptyList<GitHubForgeClient.RepositoryItem>()) }
    var branches by remember { mutableStateOf(emptyList<GitHubForgeClient.RepositoryBranch>()) }
    val selected = remember { mutableStateMapOf<String, GitHubForgeClient.RepositoryItem>() }
    var showBranches by rememberSaveable { mutableStateOf(false) }
    var createBranch by remember { mutableStateOf(false) }
    var branchDraft by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Repository browser ready.") }

    var createFile by remember { mutableStateOf(false) }
    var createFolder by remember { mutableStateOf(false) }
    var moveDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    var editItem by remember { mutableStateOf<GitHubForgeClient.RepositoryItem?>(null) }
    var editText by remember { mutableStateOf("") }
    var draftName by rememberSaveable { mutableStateOf("") }
    var draftText by rememberSaveable { mutableStateOf("") }
    var commitMessage by rememberSaveable { mutableStateOf("") }
    var moveDestination by rememberSaveable { mutableStateOf("") }
    var pendingDownload by remember { mutableStateOf<ByteArray?>(null) }
    var pendingDownloadName by remember { mutableStateOf("repository-file.bin") }

    fun refresh() {
        if (token.isBlank()) { status = "Connect GitHub in Forge/Settings first."; return }
        busy = true
        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    GitHubForgeClient.listRepositoryPath(profile.owner, profile.repository, branch, token, path)
                }
            }.onSuccess { loaded ->
                items = loaded.sortedWith(compareBy<GitHubForgeClient.RepositoryItem> { it.type != "dir" }.thenBy { it.name.lowercase() })
                selected.clear()
                status = "${loaded.size} item(s) · ${if (path.isBlank()) "/" else path}"
            }.onFailure { status = "Repository refresh failed: ${it.message}" }
            busy = false
        }
    }

    fun refreshBranches() {
        if (token.isBlank()) return
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.listRepositoryBranches(profile.owner, profile.repository, token) } }
                .onSuccess { branches = it }
                .onFailure { status = "Branch discovery failed: ${it.message}" }
        }
    }

    LaunchedEffect(profile.owner, profile.repository, branch, path, token) { refresh(); refreshBranches() }

    val uploadPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        busy = true
        scope.launch {
            runCatching {
                val files = uris.map { GitHubForgeClient.describe(context, it) }
                withContext(Dispatchers.IO) {
                    GitHubForgeClient.upload(
                        context,
                        GitHubForgeClient.UploadRequest(
                            owner = profile.owner,
                            repository = profile.repository,
                            branch = branch,
                            destinationDirectory = path,
                            commitMessage = "Upload ${files.size} repository file(s) through SWRLZ Forge",
                            token = token,
                            files = files,
                            autoRouteSourcePackages = false,
                        ),
                    )
                }
            }.onSuccess { result -> status = "Uploaded ${result.uploadedPaths.size} path(s) · ${result.commitSha.take(12)}"; refresh() }
                .onFailure { status = "Repository upload failed: ${it.message}" }
            busy = false
        }
    }
    val downloadSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val bytes = pendingDownload
        if (uri != null && bytes != null) {
            runCatching { GitHubForgeClient.writeArtifact(context, uri, bytes) }
                .onSuccess { status = "Saved $pendingDownloadName." }
                .onFailure { status = "Save failed: ${it.message}" }
        }
        pendingDownload = null
    }

    fun fullPath(name: String) = if (path.isBlank()) name else "$path/$name"
    fun parentPath() = path.substringBeforeLast('/', "")
    fun isTextFile(item: GitHubForgeClient.RepositoryItem): Boolean = item.name.substringAfterLast('.', "").lowercase() in setOf("md","txt","json","yml","yaml","kt","kts","java","xml","gradle","properties","toml","py","sh","html","css","js","ts","csv")

    if (createBranch) AlertDialog(
        onDismissRequest = { createBranch = false },
        title = { Text("Create branch") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Create from $branch")
                OutlinedTextField(branchDraft, { branchDraft = it }, label = { Text("New branch name") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(enabled = branchDraft.isNotBlank(), onClick = {
            busy = true
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.createRepositoryBranch(profile.owner, profile.repository, token, branchDraft, branch) } }
                    .onSuccess { ref ->
                        val created = ref.removePrefix("refs/heads/")
                        status = "Created $ref from $branch."
                        branch = created
                        path = ""
                        createBranch = false
                        branchDraft = ""
                        refreshBranches()
                    }
                    .onFailure { status = "Branch creation failed: ${it.message}" }
                busy = false
            }
        }) { Text("CREATE") } },
        dismissButton = { TextButton(onClick = { createBranch = false }) { Text("CANCEL") } },
    )

    if (createFile) RepositoryTextDialog(
        title = "Create file",
        name = draftName,
        text = draftText,
        commit = commitMessage,
        onName = { draftName = it },
        onText = { draftText = it },
        onCommit = { commitMessage = it },
        onDismiss = { createFile = false },
        onConfirm = {
            val target = fullPath(draftName.trim())
            busy = true
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.writeRepositoryText(profile.owner, profile.repository, branch, token, target, draftText, commitMessage) } }
                    .onSuccess { status = "Created $target · ${it.commitSha.take(12)}"; createFile = false; draftName = ""; draftText = ""; commitMessage = ""; refresh() }
                    .onFailure { status = "Create failed: ${it.message}" }
                busy = false
            }
        },
    )
    if (createFolder) AlertDialog(
        onDismissRequest = { createFolder = false },
        title = { Text("Create folder marker") },
        text = { OutlinedTextField(draftName, { draftName = it }, label = { Text("Folder name") }, singleLine = true) },
        confirmButton = { TextButton(enabled = draftName.isNotBlank(), onClick = {
            val marker = fullPath(draftName.trim().trim('/')) + "/.gitkeep"
            busy = true
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.writeRepositoryText(profile.owner, profile.repository, branch, token, marker, "", "Create ${draftName.trim()} folder through SWRLZ Forge") } }
                    .onSuccess { status = "Created folder marker · ${it.commitSha.take(12)}"; createFolder = false; draftName = ""; refresh() }
                    .onFailure { status = "Folder create failed: ${it.message}" }
                busy = false
            }
        }) { Text("CREATE") } },
        dismissButton = { TextButton(onClick = { createFolder = false }) { Text("CANCEL") } },
    )
    if (moveDialog) AlertDialog(
        onDismissRequest = { moveDialog = false },
        title = { Text(if (selected.size == 1) "Move / rename file" else "Move ${selected.size} files") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (selected.size == 1) "Enter the full destination path. Change the filename here to rename it." else "Destination directory. Filenames are preserved.")
                OutlinedTextField(moveDestination, { moveDestination = it }, label = { Text(if (selected.size == 1) "Destination path" else "Directory") }, singleLine = true)
                OutlinedTextField(commitMessage, { commitMessage = it }, label = { Text("Commit message") })
            }
        },
        confirmButton = { TextButton(enabled = selected.size > 1 || moveDestination.isNotBlank(), onClick = {
            val destinationRoot = moveDestination.trim().trim('/')
            val moves = if (selected.size == 1) {
                val item = selected.values.first()
                listOf(GitHubForgeClient.RepositoryMove(item.path, destinationRoot, item.sha))
            } else {
                selected.values.map { item -> GitHubForgeClient.RepositoryMove(item.path, if (destinationRoot.isBlank()) item.name else "$destinationRoot/${item.name}", item.sha) }
            }
            busy = true
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.moveRepositoryFiles(profile.owner, profile.repository, branch, token, moves, commitMessage) } }
                    .onSuccess { status = "Moved ${moves.size} file(s) atomically · ${it.commitSha.take(12)}"; moveDialog = false; moveDestination = ""; commitMessage = ""; refresh() }
                    .onFailure { status = "Move failed: ${it.message}" }
                busy = false
            }
        }) { Text("MOVE") } },
        dismissButton = { TextButton(onClick = { moveDialog = false }) { Text("CANCEL") } },
    )
    if (deleteDialog) AlertDialog(
        onDismissRequest = { deleteDialog = false },
        title = { Text("Delete ${selected.size} file(s)?") },
        text = { Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) { Text("One repository commit will remove these paths:"); selected.keys.sorted().forEach { Text("• $it", fontFamily = FontFamily.Monospace, fontSize = 10.sp) } } },
        confirmButton = { TextButton(onClick = {
            val paths = selected.keys.toList()
            busy = true
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.deleteRepositoryFiles(profile.owner, profile.repository, branch, token, paths, "Delete ${paths.size} file(s) through SWRLZ Forge") } }
                    .onSuccess { status = "Deleted ${paths.size} file(s) atomically · ${it.commitSha.take(12)}"; deleteDialog = false; refresh() }
                    .onFailure { status = "Delete failed: ${it.message}" }
                busy = false
            }
        }) { Text("DELETE") } },
        dismissButton = { TextButton(onClick = { deleteDialog = false }) { Text("CANCEL") } },
    )
    editItem?.let { item ->
        RepositoryTextDialog(
            title = "Edit ${item.name}", name = item.path, text = editText, commit = commitMessage,
            onName = {}, onText = { editText = it }, onCommit = { commitMessage = it }, nameEditable = false,
            onDismiss = { editItem = null },
            onConfirm = {
                busy = true
                scope.launch {
                    runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.writeRepositoryText(profile.owner, profile.repository, branch, token, item.path, editText, commitMessage) } }
                        .onSuccess { status = "Updated ${item.path} · ${it.commitSha.take(12)}"; editItem = null; commitMessage = ""; refresh() }
                        .onFailure { status = "Edit failed: ${it.message}" }
                    busy = false
                }
            },
        )
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("▸ REPOSITORY", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Text("${profile.owner}/${profile.repository}", color = tokens.text.primary, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { showBranches = !showBranches }, modifier = Modifier.weight(1f)) { Text("$branch ▾", fontSize = 10.sp) }
            OutlinedButton(onClick = { createBranch = true }, modifier = Modifier.weight(1f)) { Text("+ BRANCH", fontSize = 9.sp) }
            OutlinedButton(enabled = !busy, onClick = { refresh() }, modifier = Modifier.weight(1f)) { Text("REFRESH", fontSize = 9.sp) }
        }
        if (showBranches) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                branches.forEach { b -> OutlinedButton(onClick = { branch = b.name; showBranches = false; path = "" }, border = BorderStroke(1.dp, if (branch == b.name) tokens.accents.primary else tokens.borders.neutral)) { Text(b.name, fontSize = 9.sp) } }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(enabled = path.isNotBlank(), onClick = { path = parentPath() }, modifier = Modifier.weight(1f)) { Text("↑ UP") }
            OutlinedButton(onClick = { path = "" }, modifier = Modifier.weight(1f)) { Text("/ ROOT") }
        }
        Text("/${path}", color = tokens.text.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Search this directory") }, singleLine = true)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { draftName = ""; draftText = ""; commitMessage = ""; createFile = true }) { Text("+ FILE") }
            OutlinedButton(onClick = { draftName = ""; createFolder = true }) { Text("+ FOLDER") }
            OutlinedButton(enabled = token.isNotBlank(), onClick = { uploadPicker.launch(arrayOf("*/*")) }) { Text("UPLOAD") }
        }
        if (selected.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("${selected.size} SELECTED", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, modifier = Modifier.align(Alignment.CenterVertically))
                OutlinedButton(onClick = {
                    moveDestination = if (selected.size == 1) selected.values.first().path else path
                    commitMessage = if (selected.size == 1) "Move or rename ${selected.values.first().path} through SWRLZ Forge" else "Move ${selected.size} files through SWRLZ Forge"
                    moveDialog = true
                }) { Text(if (selected.size == 1) "MOVE / RENAME" else "MOVE") }
                OutlinedButton(onClick = { deleteDialog = true }) { Text("DELETE") }
                TextButton(onClick = { selected.clear() }) { Text("CLEAR") }
            }
        }
        val visible = items.filter { query.isBlank() || it.name.contains(query, true) || it.path.contains(query, true) }
        visible.forEach { item ->
            val isDir = item.type == "dir"
            Row(
                Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).clickable {
                    if (isDir) path = item.path else if (isTextFile(item)) {
                        busy = true
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.readRepositoryText(profile.owner, profile.repository, branch, token, item.path) } }
                                .onSuccess { editText = it; commitMessage = "Update ${item.path} through SWRLZ Forge"; editItem = item }
                                .onFailure { status = "Read failed: ${it.message}" }
                            busy = false
                        }
                    }
                }.padding(9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (!isDir) Checkbox(selected.containsKey(item.path), { checked -> if (checked) selected[item.path] = item else selected.remove(item.path) })
                Text(if (isDir) "📁" else "📄", fontSize = 18.sp)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.name, color = tokens.text.primary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Text(if (isDir) "folder" else "${item.sizeBytes} bytes · ${item.sha.take(10)}", color = tokens.text.secondary, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                }
                if (!isDir) {
                    TextButton(onClick = {
                        busy = true
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.downloadRepositoryFile(profile.owner, profile.repository, token, item.sha) } }
                                .onSuccess { bytes -> pendingDownload = bytes; pendingDownloadName = item.name; downloadSaver.launch(item.name) }
                                .onFailure { status = "Download failed: ${it.message}" }
                            busy = false
                        }
                    }) { Text("↓") }
                }
            }
        }
        if (busy) {
            ThemedProgressBar(
                snapshot = ProgressSnapshot(
                    operationId = "client-repository-operation",
                    value = null,
                    state = ThemeProgressState.ACTIVE,
                    label = "Repository operation",
                    statusText = "REPOSITORY OPERATION ACTIVE · EXACT PERCENTAGE UNKNOWN",
                ),
            )
        }
        Text(status, color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun RepositoryTextDialog(
    title: String,
    name: String,
    text: String,
    commit: String,
    onName: (String) -> Unit,
    onText: (String) -> Unit,
    onCommit: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    nameEditable: Boolean = true,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, onName, enabled = nameEditable, modifier = Modifier.fillMaxWidth(), label = { Text("Repository path / name") }, singleLine = true)
                OutlinedTextField(text, onText, modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp), label = { Text("Text content") })
                OutlinedTextField(commit, onCommit, modifier = Modifier.fillMaxWidth(), label = { Text("Commit message") })
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = onConfirm) { Text("COMMIT") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("CANCEL") } },
    )
}
