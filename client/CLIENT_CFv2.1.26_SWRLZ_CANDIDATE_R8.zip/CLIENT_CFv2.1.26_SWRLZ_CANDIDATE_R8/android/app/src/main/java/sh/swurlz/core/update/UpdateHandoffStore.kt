package sh.swurlz.core.update

import android.content.Context
import sh.swurlz.core.BuildConfig

object UpdateHandoffStore {
    private const val PREFS = "swrlz_update_handoff"
    private const val TARGET = "target"
    private const val SOURCE = "source"
    private const val EXPECTED = "expected"
    private const val CREATED = "created"
    private const val PENDING = "pending"

    data class Handoff(val target: String, val source: String, val expectedVersion: String, val createdAt: Long)

    fun write(context: Context, target: String, source: String, expectedVersion: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(PENDING, true)
            .putString(TARGET, target)
            .putString(SOURCE, source)
            .putString(EXPECTED, expectedVersion)
            .putLong(CREATED, System.currentTimeMillis())
            .commit()
    }

    fun consumeIfSatisfied(context: Context): Handoff? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!p.getBoolean(PENDING, false)) return null
        val handoff = Handoff(p.getString(TARGET, "").orEmpty(), p.getString(SOURCE, "").orEmpty(), p.getString(EXPECTED, "").orEmpty(), p.getLong(CREATED, 0L))
        if (handoff.target.equals("CLIENT", true) && handoff.expectedVersion.isNotBlank() && !BuildConfig.VERSION_NAME.startsWith(handoff.expectedVersion)) return null
        p.edit().putBoolean(PENDING, false).apply()
        return handoff
    }
}
