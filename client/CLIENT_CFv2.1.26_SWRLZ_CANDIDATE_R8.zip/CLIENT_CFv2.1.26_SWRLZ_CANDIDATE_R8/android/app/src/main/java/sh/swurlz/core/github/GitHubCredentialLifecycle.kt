package sh.swurlz.core.github

import android.content.Context
import sh.swurlz.core.data.SecretStore

/** Resolves one validated credential snapshot for a Forge operation. */
object GitHubCredentialLifecycle {
    private const val REFRESH_SKEW_MILLIS = 5L * 60L * 1000L

    data class ActiveCredential(
        val token: String,
        val login: String,
        val kind: String,
        val refreshed: Boolean,
    )

    suspend fun ensureValid(
        context: Context,
        oauthClientId: String,
        owner: String,
        repository: String,
        branch: String,
        currentToken: String,
    ): ActiveCredential {
        val normalized = GitHubForgeClient.normalizeToken(currentToken)
        require(normalized.isNotBlank()) { "GitHub authorization is missing. Reconnect before uploading." }

        val refreshToken = GitHubForgeClient.normalizeToken(SecretStore.githubRefreshToken(context))
        val accessExpiresAt = SecretStore.githubAccessExpiresAt(context)
        val refreshExpiresAt = SecretStore.githubRefreshExpiresAt(context)
        val now = System.currentTimeMillis()

        if (
            refreshToken.isNotBlank() &&
            oauthClientId.isNotBlank() &&
            accessExpiresAt > 0L &&
            accessExpiresAt <= now + REFRESH_SKEW_MILLIS
        ) {
            return refresh(
                context,
                oauthClientId,
                owner,
                repository,
                branch,
                refreshToken,
                refreshExpiresAt,
            )
        }

        return try {
            val account = GitHubForgeClient.validateForgeCredential(owner, repository, branch, normalized)
            GitHubConnectionStore.markValidated(context, account.login)
            ActiveCredential(normalized, account.login, GitHubForgeClient.credentialKind(normalized), false)
        } catch (error: Throwable) {
            if (
                GitHubForgeClient.isBadCredentials(error) &&
                refreshToken.isNotBlank() &&
                oauthClientId.isNotBlank()
            ) {
                refresh(
                    context,
                    oauthClientId,
                    owner,
                    repository,
                    branch,
                    refreshToken,
                    refreshExpiresAt,
                )
            } else {
                if (GitHubForgeClient.isBadCredentials(error)) {
                    GitHubConnectionStore.invalidateRejectedCredential(context)
                }
                throw error
            }
        }
    }

    suspend fun forceRefreshIfAvailable(
        context: Context,
        oauthClientId: String,
        owner: String,
        repository: String,
        branch: String,
    ): ActiveCredential? {
        val refreshToken = GitHubForgeClient.normalizeToken(SecretStore.githubRefreshToken(context))
        if (refreshToken.isBlank() || oauthClientId.isBlank()) return null
        return refresh(
            context,
            oauthClientId,
            owner,
            repository,
            branch,
            refreshToken,
            SecretStore.githubRefreshExpiresAt(context),
        )
    }

    private suspend fun refresh(
        context: Context,
        oauthClientId: String,
        owner: String,
        repository: String,
        branch: String,
        currentRefreshToken: String,
        refreshExpiresAt: Long,
    ): ActiveCredential {
        if (refreshExpiresAt > 0L && refreshExpiresAt <= System.currentTimeMillis()) {
            GitHubConnectionStore.invalidateRejectedCredential(context)
            error("GitHub refresh authorization expired. Reconnect GitHub once before uploading.")
        }

        val refreshed = try {
            GitHubForgeClient.refreshDeviceAuthorization(oauthClientId, currentRefreshToken)
        } catch (error: Throwable) {
            if (
                GitHubForgeClient.isBadCredentials(error) ||
                error.message.orEmpty().contains("bad_refresh_token", ignoreCase = true)
            ) {
                GitHubConnectionStore.invalidateRejectedCredential(context)
            }
            throw error
        }
        val nextRefreshToken = refreshed.refreshToken.ifBlank { currentRefreshToken }
        val account = GitHubForgeClient.validateForgeCredential(owner, repository, branch, refreshed.token)
        GitHubConnectionStore.saveAuthorizedConnection(
            context = context,
            token = refreshed.token,
            connectedLogin = account.login,
            oauthClientId = oauthClientId,
            owner = owner,
            repository = repository,
            branch = branch,
            refreshToken = nextRefreshToken,
            expiresInSeconds = refreshed.expiresInSeconds,
            refreshTokenExpiresInSeconds = refreshed.refreshTokenExpiresInSeconds,
        )
        return ActiveCredential(
            token = refreshed.token,
            login = account.login,
            kind = GitHubForgeClient.credentialKind(refreshed.token),
            refreshed = true,
        )
    }
}
