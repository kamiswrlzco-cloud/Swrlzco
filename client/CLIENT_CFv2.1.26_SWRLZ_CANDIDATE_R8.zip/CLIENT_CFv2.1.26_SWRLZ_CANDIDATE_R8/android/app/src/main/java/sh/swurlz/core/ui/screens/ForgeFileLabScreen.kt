package sh.swurlz.core.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sh.swurlz.core.github.ForgeArchiveMap
import sh.swurlz.core.github.ForgeAutomationPreferences
import sh.swurlz.core.github.ForgeContentHit
import sh.swurlz.core.github.ForgeFileInfo
import sh.swurlz.core.github.ForgeFileLab
import sh.swurlz.core.github.ForgeFolderSlot
import sh.swurlz.core.github.ForgeTextEditStage

@Composable
internal fun ForgeFileLabScreen() {
    val context = LocalContext.current
    val tokens = sh.swurlz.core.ui.theme.LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    var sourceUri by remember { mutableStateOf<Uri?>(null) }
    var sourceName by rememberSaveable { mutableStateOf("") }
    var fileInfo by remember { mutableStateOf<ForgeFileInfo?>(null) }
    var archiveMap by remember { mutableStateOf<ForgeArchiveMap?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    var editorText by rememberSaveable { mutableStateOf("") }
    var previewEntry by rememberSaveable { mutableStateOf("") }
    var stagedEdit by remember { mutableStateOf<ForgeTextEditStage?>(null) }
    var contentHits by remember { mutableStateOf(emptyList<ForgeContentHit>()) }
    val selected = remember { mutableStateListOf<String>() }
    var busy by remember { mutableStateOf(false) }
    var status by rememberSaveable { mutableStateOf("Select a file or ZIP. Source content remains read-only until an explicit staged commit creates a new output.") }

    fun persistRead(uri: Uri) {
        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    }

    val sourcePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            persistRead(uri)
            sourceUri = uri
            sourceName = uri.lastPathSegment?.substringAfterLast('/') ?: "selected-file"
            fileInfo = null
            archiveMap = null
            selected.clear()
            editorText = ""
            previewEntry = ""
            stagedEdit = null
            contentHits = emptyList()
            status = "Source selected. MAP + HASH establishes deterministic file facts; ZIP mapping does not extract entries to storage."
        }
    }
    val manifestPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            persistRead(uri)
            busy = true
            status = "Validating shard manifest and recombining…"
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { ForgeFileLab.recombineFromManifest(context, uri) } }
                    .onSuccess { status = "Recombined ${it.displayName} · ${fileLabSize(it.sizeBytes)} · SHA ${it.sha256.take(16)}…" }
                    .onFailure { status = "Recombine failed: ${it.message}" }
                busy = false
            }
        }
    }

    val filteredEntries = remember(archiveMap, query) {
        archiveMap?.let { ForgeFileLab.searchEntries(it, query) }.orEmpty()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("FORGE FILE LAB · CARTOGRAPHER", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text("Deterministic file/ZIP analysis, selective extraction, staged text revision, byte-exact binary splitting, and logical sharding. Originals are not modified in place.", color = tokens.text.secondary, fontSize = 10.sp, lineHeight = 14.sp)

        Surface(
            modifier = Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral, RoundedCornerShape(12.dp)),
            shape = RoundedCornerShape(12.dp),
            color = tokens.cards.bg,
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Storage lanes", color = tokens.text.primary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                listOf(ForgeFolderSlot.FILELAB_WORKING, ForgeFolderSlot.FILELAB_OUTPUT, ForgeFolderSlot.FILELAB_SHARDS).forEach { slot ->
                    Text("${slot.label}: ${ForgeAutomationPreferences.displayPath(context, slot)}", color = tokens.text.secondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
                Text("Select/override these SAF folders in Settings. Android Downloads fallback is used where supported when no override is selected.", color = tokens.text.secondary, fontSize = 9.sp)
            }
        }

        Button(onClick = { sourcePicker.launch(arrayOf("*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("SELECT FILE / ZIP") }
        if (sourceUri != null) {
            OutlinedButton(
                onClick = {
                    val uri = sourceUri ?: return@OutlinedButton
                    busy = true
                    status = "Hashing and mapping $sourceName…"
                    scope.launch {
                        runCatching {
                            withContext(Dispatchers.IO) {
                                val info = ForgeFileLab.inspectFile(context, uri)
                                val isZip = info.displayName.endsWith(".zip", true) || info.displayName.endsWith(".apk", true) || info.displayName.endsWith(".jar", true) || info.displayName.endsWith(".aab", true)
                                info to if (isZip) ForgeFileLab.mapZip(context, uri) else null
                            }
                        }.onSuccess { (info, map) ->
                            fileInfo = info
                            sourceName = info.displayName
                            archiveMap = map
                            status = if (map != null) {
                                "Mapped ${map.entries.size} entries (${map.fileCount} files) · source SHA ${info.sha256.take(16)}…"
                            } else {
                                "Mapped file ${info.displayName} · ${fileLabSize(info.sizeBytes)} · SHA ${info.sha256.take(16)}…"
                            }
                        }.onFailure { status = "Map/hash failed: ${it.message}" }
                        busy = false
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("MAP + HASH") }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(status, color = tokens.text.secondary, fontSize = 10.sp, lineHeight = 14.sp)

        fileInfo?.let { info ->
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), color = tokens.cards.bg) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(info.displayName, color = tokens.text.primary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    Text("${fileLabSize(info.sizeBytes)} · ${info.category} · ${info.mimeType ?: "unknown MIME"}", color = tokens.text.secondary, fontSize = 10.sp)
                    Text("SHA-256 ${info.sha256}", color = tokens.text.secondary, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                }
            }
        }

        archiveMap?.let { map ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = {
                        busy = true
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { ForgeFileLab.exportMap(context, map) } }
                                .onSuccess { status = "Archive map exported: ${it.displayName}" }
                                .onFailure { status = "Map export failed: ${it.message}" }
                            busy = false
                        }
                    }, modifier = Modifier.weight(1f), enabled = !busy,
                ) { Text("EXPORT MAP", fontSize = 9.sp) }
                OutlinedButton(
                    onClick = {
                        val uri = sourceUri ?: return@OutlinedButton
                        if (query.isBlank()) { status = "Enter a content-search term first."; return@OutlinedButton }
                        busy = true
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { ForgeFileLab.searchTextContents(context, uri, query) } }
                                .onSuccess { contentHits = it; status = "Content search found ${it.size} bounded text hit(s)." }
                                .onFailure { status = "Content search failed: ${it.message}" }
                            busy = false
                        }
                    }, modifier = Modifier.weight(1f), enabled = !busy,
                ) { Text("SEARCH TEXT", fontSize = 9.sp) }
            }
            OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Search paths/types/content") }, singleLine = true)
            Text("${filteredEntries.size} matching entries · showing first 100", color = tokens.text.secondary, fontSize = 9.sp)
            filteredEntries.take(100).forEach { entry ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Checkbox(
                        checked = entry.name in selected,
                        onCheckedChange = { checked -> if (checked) { if (entry.name !in selected) selected.add(entry.name) } else selected.remove(entry.name) },
                        enabled = !entry.directory,
                    )
                    Column(Modifier.weight(1f)) {
                        Text(entry.name, color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 9.sp, maxLines = 2)
                        Text("${entry.category} · ${fileLabSize(entry.uncompressedSize)}", color = tokens.text.secondary, fontSize = 8.sp)
                    }
                }
            }
            if (contentHits.isNotEmpty()) {
                Text("Content hits", color = tokens.text.primary, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                contentHits.take(30).forEach { hit ->
                    Text("${hit.entryName}: ${hit.preview}", color = tokens.text.secondary, fontSize = 9.sp, maxLines = 3)
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = {
                        val uri = sourceUri ?: return@OutlinedButton
                        val names = selected.toSet()
                        busy = true
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { ForgeFileLab.extractSelected(context, uri, names) } }
                                .onSuccess { status = "Extracted ${it.size} selected entries into File Lab output." }
                                .onFailure { status = "Selective extract failed: ${it.message}" }
                            busy = false
                        }
                    }, modifier = Modifier.weight(1f), enabled = selected.isNotEmpty() && !busy,
                ) { Text("EXTRACT SELECTED", fontSize = 9.sp) }
                OutlinedButton(
                    onClick = {
                        val uri = sourceUri ?: return@OutlinedButton
                        val name = selected.firstOrNull() ?: return@OutlinedButton
                        busy = true
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { ForgeFileLab.previewTextEntry(context, uri, name) } }
                                .onSuccess { editorText = it; previewEntry = name; stagedEdit = null; status = "Loaded bounded text preview for $name. Editing here is staged only." }
                                .onFailure { status = "Text preview failed: ${it.message}" }
                            busy = false
                        }
                    }, modifier = Modifier.weight(1f), enabled = selected.size == 1 && !busy,
                ) { Text("PREVIEW TEXT", fontSize = 9.sp) }
            }

            if (previewEntry.isNotBlank()) {
                Text("Staged editor · $previewEntry", color = tokens.text.primary, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                OutlinedTextField(editorText, { editorText = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp, max = 360.dp), label = { Text("Working copy") }, minLines = 6)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = {
                            val uri = sourceUri ?: return@OutlinedButton
                            val info = fileInfo ?: return@OutlinedButton
                            busy = true
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { ForgeFileLab.stageTextEdit(context, uri, info.displayName, info.sha256, previewEntry, editorText) } }
                                    .onSuccess { stagedEdit = it; status = "Edit staged as ${it.id.take(8)}. Original archive remains unchanged. Commit creates a new archive." }
                                    .onFailure { status = "Stage failed: ${it.message}" }
                                busy = false
                            }
                        }, modifier = Modifier.weight(1f), enabled = !busy,
                    ) { Text("STAGE EDIT", fontSize = 9.sp) }
                    OutlinedButton(
                        onClick = {
                            val stage = stagedEdit ?: return@OutlinedButton
                            busy = true
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { ForgeFileLab.commitTextRevision(context, stage) } }
                                    .onSuccess { status = "Committed revised archive ${it.displayName} · SHA ${it.sha256.take(16)}… Original unchanged."; stagedEdit = null }
                                    .onFailure { status = "Revision commit failed: ${it.message}" }
                                busy = false
                            }
                        }, modifier = Modifier.weight(1f), enabled = stagedEdit != null && !busy,
                    ) { Text("COMMIT NEW ARCHIVE", fontSize = 9.sp) }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = {
                        val uri = sourceUri ?: return@OutlinedButton
                        val info = fileInfo ?: return@OutlinedButton
                        busy = true
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { ForgeFileLab.createLogicalShards(context, uri, map) } }
                                .onSuccess { status = "Logical ~500 MiB shards created. Manifest: ${it.displayName}" }
                                .onFailure { status = "Logical sharding failed: ${it.message}" }
                            busy = false
                        }
                    }, modifier = Modifier.weight(1f), enabled = !busy,
                ) { Text("LOGICAL 500 MiB SHARDS", fontSize = 8.sp) }
                OutlinedButton(onClick = { manifestPicker.launch(arrayOf("application/json", "text/plain", "*/*")) }, modifier = Modifier.weight(1f), enabled = !busy) { Text("RECOMBINE MANIFEST", fontSize = 8.sp) }
            }
        }

        fileInfo?.let { info ->
            OutlinedButton(
                onClick = {
                    val uri = sourceUri ?: return@OutlinedButton
                    busy = true
                    scope.launch {
                        runCatching { withContext(Dispatchers.IO) { ForgeFileLab.splitBinary(context, uri, info.displayName) } }
                            .onSuccess { status = "Byte-exact 500 MiB split created. Manifest: ${it.displayName}" }
                            .onFailure { status = "Binary split failed: ${it.message}" }
                        busy = false
                    }
                }, modifier = Modifier.fillMaxWidth(), enabled = !busy,
            ) { Text("SPLIT SOURCE INTO 500 MiB BYTE-EXACT PARTS") }

            if (archiveMap == null && info.category == "text") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = {
                            val uri = sourceUri ?: return@OutlinedButton
                            busy = true
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { ForgeFileLab.previewPlainText(context, uri) } }
                                    .onSuccess { editorText = it; previewEntry = info.displayName; status = "Plain-text working copy loaded. Save creates a new revision." }
                                    .onFailure { status = "Text preview failed: ${it.message}" }
                                busy = false
                            }
                        }, modifier = Modifier.weight(1f), enabled = !busy,
                    ) { Text("EDIT TEXT COPY", fontSize = 9.sp) }
                    OutlinedButton(
                        onClick = {
                            val uri = sourceUri ?: return@OutlinedButton
                            busy = true
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { ForgeFileLab.commitPlainTextRevision(context, uri, info.displayName, info.sha256, editorText) } }
                                    .onSuccess { status = "Saved revised text file ${it.displayName}; original unchanged." }
                                    .onFailure { status = "Text revision failed: ${it.message}" }
                                busy = false
                            }
                        }, modifier = Modifier.weight(1f), enabled = editorText.isNotBlank() && !busy,
                    ) { Text("SAVE NEW REVISION", fontSize = 9.sp) }
                }
                if (previewEntry == info.displayName) {
                    OutlinedTextField(editorText, { editorText = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp, max = 360.dp), label = { Text("Text working copy") }, minLines = 6)
                }
            }
        }

        Text("Safety boundary: browse/map/hash/search/preview are read-only. Edit, replacement, sharding and recombination write only to configured File Lab outputs after explicit taps; no AI-driven write commit is performed here.", color = tokens.text.secondary, fontSize = 9.sp, lineHeight = 13.sp)
    }
}

private fun fileLabSize(bytes: Long): String = when {
    bytes < 0L -> "size unknown"
    bytes >= 1024L * 1024L * 1024L -> "%.2f GiB".format(bytes.toDouble() / (1024.0 * 1024.0 * 1024.0))
    bytes >= 1024L * 1024L -> "%.2f MiB".format(bytes.toDouble() / (1024.0 * 1024.0))
    bytes >= 1024L -> "%.1f KiB".format(bytes.toDouble() / 1024.0)
    else -> "$bytes B"
}
