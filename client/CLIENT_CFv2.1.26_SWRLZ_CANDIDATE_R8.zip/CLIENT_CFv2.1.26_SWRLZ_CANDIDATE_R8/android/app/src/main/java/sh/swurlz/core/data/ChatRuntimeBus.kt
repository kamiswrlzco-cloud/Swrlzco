package sh.swurlz.core.data

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/** Human-readable runtime milestones emitted by subsystems back into Council Chat. */
object ChatRuntimeBus {
    private val mutableEvents = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val events = mutableEvents.asSharedFlow()
    fun post(message: String) { mutableEvents.tryEmit(message) }
}
