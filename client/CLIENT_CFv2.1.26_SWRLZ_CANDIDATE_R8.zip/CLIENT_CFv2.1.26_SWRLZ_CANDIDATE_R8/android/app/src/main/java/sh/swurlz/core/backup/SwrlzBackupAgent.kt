package sh.swurlz.core.backup

import android.app.backup.BackupAgent
import android.app.backup.BackupDataInput
import android.app.backup.BackupDataOutput
import android.app.backup.FullBackupDataOutput
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.File
import sh.swurlz.core.github.GitHubConnectionStore

/**
 * Preserves normal Auto Backup while adding a transport-gated GitHub connection envelope.
 * The token envelope is emitted only for client-side encrypted cloud backup or direct
 * device-to-device transfer, then imported into a freshly-created Android Keystore store.
 */
class SwrlzBackupAgent : BackupAgent() {
    override fun onBackup(
        oldState: ParcelFileDescriptor?,
        data: BackupDataOutput,
        newState: ParcelFileDescriptor,
    ) = Unit

    override fun onRestore(
        data: BackupDataInput,
        appVersionCode: Int,
        newState: ParcelFileDescriptor,
    ) = Unit

    override fun onFullBackup(data: FullBackupDataOutput) {
        super.onFullBackup(data)

        val secureTransport = if (Build.VERSION.SDK_INT >= 28) {
            val flags = data.transportFlags
            (flags and FLAG_CLIENT_SIDE_ENCRYPTION_ENABLED) != 0 ||
                (flags and FLAG_DEVICE_TO_DEVICE_TRANSFER) != 0
        } else {
            false
        }
        if (!secureTransport) return

        val restoreFile = File(filesDir, RESTORE_FILE)
        runCatching {
            restoreFile.writeBytes(GitHubConnectionStore.backupEnvelope(this))
            fullBackupFile(restoreFile, data)
        }
        restoreFile.delete()
    }

    override fun onRestoreFinished() {
        super.onRestoreFinished()
        val restoreFile = File(filesDir, RESTORE_FILE)
        if (!restoreFile.isFile) return
        runCatching { GitHubConnectionStore.restoreEnvelope(this, restoreFile.readBytes()) }
        restoreFile.delete()
    }

    companion object {
        const val RESTORE_FILE = ".swrlz_github_connection_restore.json"
    }
}
