package sh.swurlz.core.github

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.result.contract.ActivityResultContract

/**
 * Opens Android's document picker at the selected ZIP location when direct sibling
 * access is blocked by the provider. This replaces the old directory-tree grant.
 */
data class SiblingDocumentRequest(
    val initialDocument: Uri,
    val expectedDisplayName: String,
)

class OpenSiblingDocumentContract : ActivityResultContract<SiblingDocumentRequest, Uri?>() {
    override fun createIntent(context: Context, input: SiblingDocumentRequest): Intent =
        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            putExtra(DocumentsContract.EXTRA_INITIAL_URI, input.initialDocument)
            putExtra(Intent.EXTRA_TITLE, input.expectedDisplayName)
        }

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
        if (resultCode == Activity.RESULT_OK) intent?.data else null
}
