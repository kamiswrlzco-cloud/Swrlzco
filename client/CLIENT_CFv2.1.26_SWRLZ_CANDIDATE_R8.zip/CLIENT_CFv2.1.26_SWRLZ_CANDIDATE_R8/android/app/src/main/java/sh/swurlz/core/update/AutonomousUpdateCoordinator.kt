package sh.swurlz.core.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.delay
import sh.swurlz.core.data.ChatRuntimeBus
import sh.swurlz.core.github.ChatForgeCoordinator
import sh.swurlz.core.github.GitHubForgeClient
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.Locale
import java.util.zip.ZipInputStream

/**
 * CFv2.1.0 autonomous update control loop.
 * Keeps GitHub/Forge authoritative, uses local deterministic diagnosis first, and persists
 * an install handoff before replacing CLIENT. Android still owns final install approval.
 */
object AutonomousUpdateCoordinator {
    enum class Target { CLIENT, SERVER }
    data class Request(val target: Target, val zipName: String, val expectedVersion: String = "")

    private fun say(text: String) = ChatRuntimeBus.post(text)

    fun parse(text: String): Request? {
        val target = when {
            Regex("(?i)\\b(server|swurlzer)\\b").containsMatchIn(text) -> Target.SERVER
            Regex("(?i)\\b(client|swrlz)\\b").containsMatchIn(text) -> Target.CLIENT
            else -> return null
        }
        val zip = Regex("(?i)(CLIENT|SERVER)_CFv[0-9.]+_[A-Za-z0-9_() -]+\\.zip").find(text)?.value
            ?: Regex("(?i)[A-Za-z0-9_.() -]+\\.zip").find(text)?.value?.trim()
            ?: return null
        val version = Regex("(?i)CFv([0-9]+\\.[0-9]+\\.[0-9]+)").find(zip)?.groupValues?.getOrNull(1).orEmpty()
        return Request(target, zip, version)
    }

    suspend fun start(context: Context, raw: String) {
        val req = parse(raw)
        if (req == null) {
            say("I can run the autonomous update loop, but I need the target and source ZIP name, for example: Update SERVER using SERVER_CFv2.1.0_SWRLZ.zip")
            return
        }
        say("🐉 Update loop started for ${req.target}. I’m looking for ${req.zipName} and its SHA-256 receipt in Downloads.")
        val zipUri = findDownload(context, req.zipName)
        val shaName = req.zipName.removeSuffix(".zip") + ".sha256"
        val shaUri = findDownload(context, shaName)
        if (zipUri == null || shaUri == null) {
            say("I couldn’t resolve the exact ZIP/SHA pair from Downloads. I won’t guess similar filenames. Open Forge file selection and choose ${req.zipName} plus $shaName, then I can continue from the verified pair.")
            ChatForgeCoordinator.begin(context)
            ChatForgeCoordinator.chooseShaPairing(true)
            return
        }

        val zip = GitHubForgeClient.describe(context, zipUri)
        val sha = GitHubForgeClient.describe(context, shaUri)
        val pair = GitHubForgeClient.validateSourcePairs(context, listOf(zip, sha))
        if (!pair.valid) {
            say("🔐 The downloaded pair failed local integrity validation: ${pair.message}. I’m stopping before GitHub mutation.")
            return
        }
        say("🔐 Source pair verified locally. Starting Forge upload with the same source lineage.")
        ChatForgeCoordinator.begin(context)
        ChatForgeCoordinator.chooseShaPairing(true)
        ChatForgeCoordinator.stageFiles(context, listOf(zipUri, shaUri))
        val uploaded = ChatForgeCoordinator.upload(context)
        if (uploaded.isFailure) return

        var transientRetries = 0
        repeat(180) {
            delay(4_000)
            ChatForgeCoordinator.refresh(context)
            when (ChatForgeCoordinator.state.value.step) {
                ChatForgeCoordinator.Step.ARTIFACTS_READY -> {
                    val artifact = ChatForgeCoordinator.state.value.artifacts.firstOrNull() ?: return@repeat
                    say("📦 Build artifact is ready. I’m downloading it for update handoff.")
                    ChatForgeCoordinator.requestDownload(artifact)
                    val payload = ChatForgeCoordinator.downloadPending(context).getOrElse { e ->
                        say("Artifact download failed: ${e.message ?: e::class.java.simpleName}")
                        return
                    }
                    val apk = extractApk(context, payload.first, payload.second, req.target)
                    if (apk == null) {
                        say("The workflow artifact downloaded, but I could not find an APK inside it. I’m leaving the artifact intact for review.")
                        return
                    }
                    val digest = sha256(apk)
                    say("✅ APK extracted and verified readable · SHA-256 ${digest.take(16)}… Preparing Android install handoff.")
                    UpdateHandoffStore.write(context, req.target.name, req.zipName, req.expectedVersion)
                    launchInstall(context, apk)
                    say(if (req.target == Target.SERVER) "🔄 Android install handoff opened for SWURLZER. After installation I’ll expect the Client to reconnect and verify the Server version/capabilities." else "🔄 Android install handoff opened for SWRLZ Client. The handoff is persisted so the updated Client can resume verification after relaunch.")
                    return
                }
                ChatForgeCoordinator.Step.FAILED -> {
                    val detail = ChatForgeCoordinator.state.value.detail
                    val transient = listOf("timeout", "network", "connection", "temporar", "rate limit").any { detail.lowercase(Locale.US).contains(it) }
                    if (transient && transientRetries < 2) {
                        transientRetries++
                        say("🔁 Failure looks transient. Automatic retry $transientRetries/2 will refresh the same commit-bound workflow state; I won’t create a duplicate source commit.")
                        return@repeat
                    }
                    say("🧠 The build/update loop stopped on a non-transient failure. I’ve preserved the source lineage and Forge analysis so Swurver or an external coding provider can repair the exact source instead of generating a mystery replacement.")
                    return
                }
                ChatForgeCoordinator.Step.CANCELLED -> return
                else -> Unit
            }
        }
        say("Forge is still unresolved after the autonomous watch window. I preserved the transaction so it can be resumed instead of starting over.")
    }

    private fun findDownload(context: Context, exactName: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
        val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} = ?"
        context.contentResolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection, arrayOf(exactName), "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            if (c.moveToFirst()) {
                val id = c.getLong(c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID))
                return Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id.toString())
            }
        }
        return null
    }

    private fun extractApk(context: Context, artifactName: String, bytes: ByteArray, target: Target): File? {
        val dir = File(context.cacheDir, "update-installer").apply { mkdirs() }
        val out = File(dir, "${target.name.lowercase()}-${System.currentTimeMillis()}.apk")
        if (artifactName.endsWith(".apk", true)) {
            out.writeBytes(bytes); return out
        }
        ZipInputStream(bytes.inputStream()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name.endsWith(".apk", true)) {
                    FileOutputStream(out).use { fos -> zip.copyTo(fos) }
                    return out
                }
                zip.closeEntry(); entry = zip.nextEntry
            }
        }
        return null
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val b = ByteArray(64 * 1024)
            while (true) { val n = input.read(b); if (n <= 0) break; md.update(b, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun launchInstall(context: Context, apk: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", apk)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    }
}
