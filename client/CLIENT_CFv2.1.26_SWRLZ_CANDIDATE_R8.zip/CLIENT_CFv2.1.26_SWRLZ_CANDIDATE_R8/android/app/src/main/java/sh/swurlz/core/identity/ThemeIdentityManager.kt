package sh.swurlz.core.identity

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import sh.swrlz.theme.BuiltInThemePacks
import sh.swrlz.theme.DEFAULT_THEME_ID
import sh.swrlz.theme.ThemeTarget
import sh.swurlz.core.R

/**
 * Keeps launcher, bubble, shortcut, and notification identity synchronized
 * with the active local CLIENT ThemePack.
 *
 * Theme selection changes presentation identity only. It does not grant
 * registration, trust, connection, authorization, or mission capability.
 */
object ThemeIdentityManager {
    private enum class Alias(
        val componentClass: String,
        val iconRes: Int,
        val themeId: String,
    ) {
        GlitchDragon(
            "sh.swurlz.core.launcher.GlitchDragon",
            R.mipmap.ic_launcher_glitch_dragon,
            DEFAULT_THEME_ID,
        ),
    }

    private val registry get() = BuiltInThemePacks.registry

    fun requestApply(context: Context, selector: String) {
        val pack = registry.resolve(selector, ThemeTarget.CLIENT)
        context.getSharedPreferences("theme_identity", Context.MODE_PRIVATE)
            .edit()
            .putString("current_theme_id", pack.id)
            .putString("current_theme", pack.displayName)
            .putString("pending_theme_id", pack.id)
            .apply()
    }

    fun currentThemeId(context: Context): String {
        val prefs = context.getSharedPreferences("theme_identity", Context.MODE_PRIVATE)
        return registry.resolve(
            prefs.getString("current_theme_id", null)
                ?: prefs.getString("current_theme", null)
                ?: activeAlias(context).themeId,
            ThemeTarget.CLIENT,
        ).id
    }

    fun currentThemeFamily(context: Context): String =
        registry.resolve(currentThemeId(context), ThemeTarget.CLIENT).displayName

    /** Reasserts the selected launcher alias after an APK update. */
    fun reconcileLauncherIdentity(context: Context) {
        applyNow(context, currentThemeId(context))
    }

    fun applyPending(context: Context) {
        val prefs = context.getSharedPreferences("theme_identity", Context.MODE_PRIVATE)
        val selector = prefs.getString("pending_theme_id", null)
            ?: prefs.getString("pending_theme", null)
            ?: return
        applyNow(context, selector)
        prefs.edit().remove("pending_theme_id").remove("pending_theme").apply()
    }

    private fun applyNow(context: Context, selector: String) {
        val themeId = registry.resolve(selector, ThemeTarget.CLIENT).id
        val selected = Alias.entries.firstOrNull { it.themeId == themeId } ?: Alias.GlitchDragon
        context.packageManager.setComponentEnabledSetting(
            ComponentName(context.packageName, selected.componentClass),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP,
        )
        Alias.entries.filter { it != selected }.forEach { alias ->
            context.packageManager.setComponentEnabledSetting(
                ComponentName(context.packageName, alias.componentClass),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP,
            )
        }
    }

    private fun activeAlias(context: Context): Alias =
        Alias.entries.firstOrNull { alias ->
            context.packageManager.getComponentEnabledSetting(
                ComponentName(context.packageName, alias.componentClass),
            ) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
        } ?: Alias.GlitchDragon

    fun activeIconResource(context: Context): Int = activeAlias(context).iconRes

    /** Bubble/shortcut identity follows the selected theme before launcher cache refresh. */
    fun currentThemeIconResource(context: Context): Int = iconResource(currentThemeId(context))

    fun iconResource(selector: String): Int {
        val id = registry.resolve(selector, ThemeTarget.CLIENT).id
        return Alias.entries.firstOrNull { it.themeId == id }?.iconRes ?: Alias.GlitchDragon.iconRes
    }

    fun clientBubbleIconResource(context: Context): Int =
        roleBubbleIconResource("client", currentThemeId(context))

    fun serverBubbleIconResource(context: Context): Int =
        roleBubbleIconResource("server", currentThemeId(context))

    fun fusionBubbleIconResource(context: Context): Int =
        roleBubbleIconResource("fusion", currentThemeId(context))

    private fun roleBubbleIconResource(role: String, selector: String): Int {
        // Bootstrap transport edition exposes only the canonical default ThemePack.
        registry.resolve(selector, ThemeTarget.CLIENT)
        return when (role) {
            "server" -> R.drawable.swrlz_server_bubble_glitch_dragon
            "fusion" -> R.drawable.swrlz_fusion_bubble_glitch_dragon
            else -> R.drawable.swrlz_client_bubble_glitch_dragon
        }
    }


    /**
     * Theme role color intentionally stays separate from launcher identity. CLIENT conversation
     * bubbles use the ThemePack secondary accent as a complementary role, SERVER uses tertiary,
     * and fusion blends both. Android/SystemUI may still add its own launcher/app badge.
     */
    fun roleBubbleColor(selector: String, role: String): Int {
        val palette = registry.resolve(selector, ThemeTarget.CLIENT).palette
        val color = when (role.lowercase()) {
            "server" -> palette.tertiary
            "fusion" -> blendHex(palette.secondary, palette.tertiary)
            else -> palette.secondary
        }
        return colorInt(color)
    }

    fun clientBubbleBitmap(context: Context): Bitmap = roleBubbleBitmap(context, "client")
    fun serverBubbleBitmap(context: Context): Bitmap = roleBubbleBitmap(context, "server")
    fun fusionBubbleBitmap(context: Context): Bitmap = roleBubbleBitmap(context, "fusion")

    fun roleBubbleBitmap(context: Context, role: String): Bitmap {
        val selector = currentThemeId(context)
        val sourceRes = roleBubbleIconResource(role, selector)
        val decoded = BitmapFactory.decodeResource(context.resources, sourceRes)
            ?: Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
        val bitmap = decoded.copy(Bitmap.Config.ARGB_8888, true)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = roleBubbleColor(selector, role)
            alpha = when (role.lowercase()) {
                "fusion" -> 92
                "server" -> 78
                else -> 68
            }
            xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
        }
        Canvas(bitmap).drawRect(0f, 0f, bitmap.width.toFloat(), bitmap.height.toFloat(), paint)
        paint.xfermode = null
        return bitmap
    }

    private fun colorInt(hexValue: String): Int {
        val hex = hexValue.removePrefix("#")
        return (0xFF000000L or hex.toLong(16)).toInt()
    }

    private fun blendHex(first: String, second: String): String {
        val a = colorInt(first)
        val b = colorInt(second)
        fun channel(shift: Int): Int = (((a shr shift) and 0xFF) + ((b shr shift) and 0xFF)) / 2
        return "#%02X%02X%02X".format(channel(16), channel(8), channel(0))
    }

    fun accentColor(selector: String): Int = colorInt(
        registry.resolve(selector, ThemeTarget.CLIENT).palette.primary,
    )
}
