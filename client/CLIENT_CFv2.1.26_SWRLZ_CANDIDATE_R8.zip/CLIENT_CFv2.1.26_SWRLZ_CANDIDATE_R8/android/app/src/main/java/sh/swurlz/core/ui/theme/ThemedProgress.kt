package sh.swurlz.core.ui.theme

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import sh.swrlz.theme.SemanticAssetRole
import sh.swrlz.theme.ThemeAssetScaleMode
import sh.swrlz.theme.ThemePack
import sh.swrlz.theme.ThemeProgressState

data class ProgressSnapshot(
    val operationId: String,
    /** Null means the application does not know a trustworthy percentage. */
    val value: Float?,
    val state: ThemeProgressState,
    val label: String,
    val statusText: String,
)

@Composable
fun ThemedProgressBar(
    snapshot: ProgressSnapshot,
    modifier: Modifier = Modifier,
    themePack: ThemePack = LocalThemePack.current,
    motionPolicy: ThemeMotionPolicy = LocalThemeMotionPolicy.current,
    showStatusText: Boolean = true,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val knownValue = snapshot.value?.coerceIn(0f, 1f)
    val motionEnabled = motionPolicy.enabled && snapshot.state != ThemeProgressState.PAUSED
    val speed = themePack.motionProfile.particleSpeedMultiplier.coerceIn(.25f, 4f)
    val transition = if (motionEnabled) rememberInfiniteTransition(label = "theme-progress") else null
    val animatedAmbientPhase = transition?.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(
                durationMillis = (
                    themePack.progressStyle.ambientPeriodMs * motionPolicy.durationMultiplier / speed
                ).toInt().coerceAtLeast(200),
                easing = LinearEasing,
            )
        ),
        label = "ambient-phase",
    )?.value ?: .35f
    val animatedPulse = transition?.animateFloat(
        initialValue = .38f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween((760 / speed).toInt().coerceAtLeast(200), easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "particle-pulse",
    )?.value ?: .5f
    val ambientPhase = if (motionEnabled) animatedAmbientPhase else .35f
    val pulse = if (motionEnabled) animatedPulse else .5f
    val terminalAlpha = remember { Animatable(0f) }
    var lastTerminalKey by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(snapshot.operationId, snapshot.state, motionEnabled) {
        val terminalRole = snapshot.state.terminalRole()
        val key = terminalRole?.let { "${snapshot.operationId}:${snapshot.state}" }
        if (key == null || key == lastTerminalKey) return@LaunchedEffect
        lastTerminalKey = key
        terminalAlpha.snapTo(if (motionEnabled) 0f else 1f)
        if (motionEnabled) {
            terminalAlpha.animateTo(1f, tween(170))
            delay(260)
            terminalAlpha.animateTo(0f, tween(520))
        }
    }

    Column(modifier) {
        val semanticsText = buildString {
            append(snapshot.statusText)
            knownValue?.let { append(". ").append((it * 100).toInt()).append(" percent") }
        }
        val shape = RoundedCornerShape(themePack.shapes.controlCornerDp.dp.coerceAtLeast(8.dp))
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .height(themePack.dimensions.progressHeightDp.dp.coerceAtLeast(40.dp))
                .clip(shape)
                .clipToBounds()
                .semantics(mergeDescendants = true) {
                    contentDescription = snapshot.label
                    stateDescription = semanticsText
                    progressBarRangeInfo = knownValue?.let {
                        ProgressBarRangeInfo(it, 0f..1f, 0)
                    } ?: ProgressBarRangeInfo.Indeterminate
                },
        ) {
            val density = LocalDensity.current
            val declaredStartInset = themePack.progressStyle.trackStartInsetDp.dp
            val declaredEndInset = themePack.progressStyle.trackEndInsetDp.dp
            val declaredVerticalInset = themePack.progressStyle.trackVerticalInsetDp.dp

            // INT-THEME-039C: Progress geometry is resolved through one theme-aware
            // semantic geometry layer. Every ThemePack therefore uses the same renderer;
            // packs with visually meaningful landmarks may calibrate the progress channel
            // without adding screen-specific layout code. Legacy dp insets remain the safe
            // fallback for packs that do not yet need artwork-specific calibration.
            val geometry = themeProgressGeometry(themePack)
            val startInset = geometry.trackStartFraction?.let { maxWidth * it }
                ?.coerceAtLeast(declaredStartInset)
                ?: declaredStartInset
            val endInset = geometry.trackEndFraction?.let { maxWidth * (1f - it) }
                ?.coerceAtLeast(declaredEndInset)
                ?: declaredEndInset
            val topInset = geometry.trackTopFraction?.let { maxHeight * it }
                ?.coerceAtLeast(declaredVerticalInset)
                ?: declaredVerticalInset
            val bottomInset = geometry.trackBottomFraction?.let { maxHeight * (1f - it) }
                ?.coerceAtLeast(declaredVerticalInset)
                ?: declaredVerticalInset

            val trackWidth = (maxWidth - startInset - endInset).coerceAtLeast(1.dp)
            val trackWidthPx = with(density) { trackWidth.toPx() }.coerceAtLeast(1f)
            val headWidth = themePack.progressStyle.headWidthDp.dp
            val headWidthPx = with(density) { headWidth.toPx() }
            val segmentFraction = themePack.progressStyle.indeterminateSegmentFraction.coerceIn(.15f, .7f)
            val indeterminateStart = ambientPhase * (1f - segmentFraction)
            val visualHead = knownValue ?: (indeterminateStart + segmentFraction)
            val frameId = ThemeAssetResolver.drawableId(context, themePack, SemanticAssetRole.ProgressFrame)
            val fillId = ThemeAssetResolver.drawableId(context, themePack, SemanticAssetRole.ProgressFill)
            val trackShape = RoundedCornerShape(
                (themePack.shapes.controlCornerDp * .72f).dp.coerceAtLeast(6.dp)
            )

            if (frameId == null || fillId == null) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(tokens.cards.bgAlt)
                        .border(1.dp, tokens.borders.neutral, shape),
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(start = startInset, end = endInset, top = topInset, bottom = bottomInset)
                        .clip(trackShape)
                        .clipToBounds(),
                ) {
                    val fraction = knownValue ?: segmentFraction
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(fraction)
                            .graphicsLayer {
                                if (knownValue == null) translationX = trackWidthPx * indeterminateStart
                            }
                            .background(
                                Brush.horizontalGradient(
                                    listOf(tokens.accents.primary, tokens.accents.secondary, tokens.accents.tertiary)
                                )
                            ),
                    )
                }
            } else {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(start = startInset, end = endInset, top = topInset, bottom = bottomInset)
                        .clip(trackShape)
                        .clipToBounds(),
                ) {
                    // Ambient energy is the only full-track decorative layer. It is drawn
                    // first so it stays behind the active fill and behind the frame shell.
                    ThemeRoleImage(
                        themePack,
                        SemanticAssetRole.ProgressAmbient,
                        Modifier.fillMaxSize(),
                        alpha = .18f + pulse * .12f,
                    )

                    val activeStartFraction = if (knownValue == null) {
                        indeterminateStart
                    } else {
                        0f
                    }
                    val activeEndFraction = if (knownValue == null) {
                        indeterminateStart + segmentFraction
                    } else {
                        knownValue
                    }.coerceIn(activeStartFraction, 1f)
                    val activeStartPx = trackWidthPx * activeStartFraction
                    val activeEndPx = trackWidthPx * activeEndFraction
                    val activeWidthPx = (activeEndPx - activeStartPx).coerceAtLeast(0f)
                    val highlightWidth = trackWidth * .36f
                    val highlightWidthPx = with(density) { highlightWidth.toPx() }

                    // Keep every active artwork layer at full track geometry. A draw-time
                    // clip reveals only the truthful determinate/indeterminate window, so
                    // Compose constraints can never squeeze the texture into the percentage.
                    Box(
                        Modifier
                            .fillMaxSize()
                            .drawWithContent {
                                clipRect(left = activeStartPx, right = activeEndPx) {
                                    this@drawWithContent.drawContent()
                                }
                            },
                    ) {
                        Image(
                            painter = painterResource(fillId),
                            contentDescription = null,
                            contentScale = contentScale(themePack, SemanticAssetRole.ProgressFill),
                            modifier = Modifier.fillMaxSize(),
                        )

                        if (motionPolicy.particleFraction > 0f) {
                            ThemeRoleImage(
                                themePack,
                                SemanticAssetRole.ProgressParticles,
                                Modifier.fillMaxSize(),
                                alpha = pulse * motionPolicy.particleFraction *
                                    themePack.particleStyle.density.coerceIn(0f, 2f) *
                                    themePack.particleStyle.opacity.coerceIn(0f, 1f) * .54f,
                            )
                        }

                        if (motionEnabled && activeWidthPx > 0f) {
                            ThemeRoleImage(
                                themePack,
                                SemanticAssetRole.ProgressHighlight,
                                Modifier
                                    .width(highlightWidth)
                                    .fillMaxHeight()
                                    .graphicsLayer {
                                        translationX =
                                            activeStartPx +
                                                (activeWidthPx + highlightWidthPx) * ambientPhase -
                                                highlightWidthPx
                                    },
                                alpha = .46f,
                            )
                        }
                    }
                }

                // The shell is intentionally above every streaming/fill layer so animated
                // energy can never paint over the ornamental progress-bar chrome.
                ThemeRoleImage(themePack, SemanticAssetRole.ProgressFrame, Modifier.fillMaxSize())
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(start = startInset, end = endInset, top = topInset, bottom = bottomInset)
                        .clipToBounds(),
                ) {
                    ThemeRoleImage(
                        themePack,
                        SemanticAssetRole.ProgressHead,
                        Modifier
                            .width(headWidth)
                            .fillMaxHeight()
                            .align(Alignment.CenterStart)
                            .graphicsLayer {
                                // The head carries a semantic anchor (normally its center)
                                // that follows the exact truthful progress boundary. This avoids
                                // the former edge-to-edge travel formula where 100% could stop
                                // short of a frame landmark such as Jester's green emerald.
                                translationX =
                                    trackWidthPx * visualHead.coerceIn(0f, 1f) -
                                        headWidthPx * geometry.headAnchorFraction
                                val scale = if (motionEnabled) {
                                    1f + ((pulse - .38f) / .62f).coerceIn(0f, 1f) *
                                        (themePack.motionProfile.pulseScale - 1f)
                                } else {
                                    1f
                                }
                                scaleX = scale
                                scaleY = scale
                            },
                    )
                }
                snapshot.state.terminalRole()?.let { role ->
                    ThemeRoleImage(
                        themePack,
                        role,
                        Modifier.fillMaxSize(),
                        alpha = if (motionEnabled) terminalAlpha.value else 1f,
                    )
                }
            }
        }
        if (showStatusText) {
            Text(
                text = snapshot.statusText,
                color = snapshot.state.tone(tokens),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                lineHeight = 14.sp,
            )
        }
    }
}

@Composable
fun ThemeRoleImage(
    pack: ThemePack,
    role: SemanticAssetRole,
    modifier: Modifier = Modifier,
    alpha: Float = 1f,
) {
    val context = LocalContext.current
    val id = ThemeAssetResolver.drawableId(context, pack, role) ?: return
    Image(
        painter = painterResource(id),
        contentDescription = null,
        contentScale = contentScale(pack, role),
        alpha = alpha.coerceIn(0f, 1f),
        modifier = modifier,
    )
}

/**
 * Theme-specific semantic progress geometry expressed in fractions of the outer component.
 *
 * This runtime catalog intentionally keeps ThemePack manifest v1 byte-compatible with SERVER.
 * A later paired contract checkpoint may promote these hints into the shared manifest schema.
 * Until then, unlisted packs remain fully supported through their declarative dp insets.
 */
private data class ThemeProgressGeometry(
    val trackStartFraction: Float? = null,
    val trackEndFraction: Float? = null,
    val trackTopFraction: Float? = null,
    val trackBottomFraction: Float? = null,
    val headAnchorFraction: Float = .5f,
)

private fun themeProgressGeometry(pack: ThemePack): ThemeProgressGeometry =
    when (pack.id) {
        "sh.swrlz.theme.jester_glitch_dragon" -> ThemeProgressGeometry(
            // Calibrated against theme_progress_jester_frame.webp.
            // 100% terminates at the center of the right green emerald landmark.
            trackStartFraction = .205f,
            trackEndFraction = .895f,
            trackTopFraction = .30f,
            trackBottomFraction = .75f,
            headAnchorFraction = .5f,
        )
        else -> ThemeProgressGeometry()
    }

private fun contentScale(pack: ThemePack, role: SemanticAssetRole): ContentScale =
    when (ThemeAssetResolver.resolve(pack, role)?.spec?.scaleMode) {
        ThemeAssetScaleMode.FILL, ThemeAssetScaleMode.CENTER_CROP -> ContentScale.Crop
        ThemeAssetScaleMode.STRETCH, ThemeAssetScaleMode.TILE_X -> ContentScale.FillBounds
        else -> ContentScale.Fit
    }

private fun ThemeProgressState.terminalRole(): SemanticAssetRole? = when (this) {
    ThemeProgressState.SUCCESS -> SemanticAssetRole.ProgressComplete
    ThemeProgressState.FAILED,
    ThemeProgressState.INTERRUPTED,
    ThemeProgressState.CANCELLED -> SemanticAssetRole.ProgressFailureInterruption
    else -> null
}

private fun ThemeProgressState.tone(tokens: SwurlzThemeTokens): Color = when (this) {
    ThemeProgressState.SUCCESS -> tokens.status.success
    ThemeProgressState.FAILED,
    ThemeProgressState.INTERRUPTED,
    ThemeProgressState.CANCELLED -> tokens.status.danger
    ThemeProgressState.PAUSED -> tokens.status.warning
    ThemeProgressState.STARTING,
    ThemeProgressState.ACTIVE,
    ThemeProgressState.COMPLETING -> tokens.status.info
    ThemeProgressState.IDLE -> tokens.text.muted
}
