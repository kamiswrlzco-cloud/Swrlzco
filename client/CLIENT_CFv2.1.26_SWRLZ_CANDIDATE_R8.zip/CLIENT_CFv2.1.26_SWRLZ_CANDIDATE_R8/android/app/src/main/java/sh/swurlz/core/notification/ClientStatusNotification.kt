package sh.swurlz.core.notification

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.graphics.BitmapFactory
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import sh.swurlz.core.MainActivity
import sh.swurlz.core.R
import sh.swurlz.core.identity.ThemeIdentityManager
import sh.swurlz.core.bubble.ClientBubbleController
import sh.swurlz.core.data.MissionBus
import sh.swurlz.core.model.CoreNodeTruthState
import sh.swurlz.core.model.UiStyleSettings

object ClientStatusNotification {
    const val NOTIFICATION_ID = 4102
    private const val CHANNEL_ID = "swurlz_client_status_v2"

    fun canPost(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED

    fun build(
        context: Context,
        mission: MissionBus.MissionLive,
        ambient: MissionBus.Ambient,
        truth: CoreNodeTruthState,
        style: UiStyleSettings,
    ): Notification {
        ensureChannel(context)

        val launchIntent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pending = PendingIntent.getActivity(
            context,
            4102,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val connected = truth.auto.success || truth.manual.success
        val title = "SWRLZ Client · ${ambient.name.uppercase()}"
        val serverLine = if (connected) {
            "Server: CONNECTED"
        } else {
            "Server: OFFLINE · local-first ready"
        }
        val endpoint = truth.config.nodeUrl.ifBlank { "approved discovery" }
        val evidence = truth.auto.summary
            .ifBlank { truth.manual.summary }
            .ifBlank { if (connected) "registered session online" else "waiting for server" }
        val missionLine = when {
            mission.goal.isNotBlank() -> "Mission: ${mission.goal.take(96)}"
            connected -> "Node: $endpoint"
            else -> "Mission: READY"
        }
        val theme = "${style.themePack} · ${style.displayMode}"

        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_crystal)
            .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.drawable.swrlz_client_identity))
            .setColor(ThemeIdentityManager.accentColor(style.themePack))
            .setColorized(false)
            .setContentTitle(title)
            .setContentText(serverLine)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .setBigContentTitle("Ω  $title")
                    .bigText(
                        "$serverLine\n" +
                            "$missionLine\n" +
                            "Session: $evidence\n" +
                            "Theme armor: $theme"
                    )
            )
            .setSubText("Glitch Dragon Client")
            .setContentIntent(pending)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .build()
    }

    fun update(
        context: Context,
        enabled: Boolean,
        mission: MissionBus.MissionLive,
        ambient: MissionBus.Ambient,
        truth: CoreNodeTruthState,
        style: UiStyleSettings,
    ) {
        if (!enabled) {
            cancel(context)
            return
        }
        if (!canPost(context)) return

        val notification = build(context, mission, ambient, truth, style)
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)

        val connected = truth.auto.success || truth.manual.success
        val bubbleDetail = when {
            mission.goal.isNotBlank() -> "Mission: ${mission.goal.take(96)}"
            connected -> "Server connected · ${truth.config.nodeUrl.ifBlank { "approved discovery" }}"
            else -> "Server offline · local-first ready"
        }
        ClientBubbleController.publish(
            context = context,
            title = "SWRLZ Client",
            detail = bubbleDetail,
        )
    }

    fun cancel(context: Context) {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
        ClientBubbleController.cancel(context)
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "SWRLZ Client Status",
                    NotificationManager.IMPORTANCE_LOW,
                ).apply {
                    description = "Persistent client, mission, and connected-server status."
                    setShowBadge(false)
                    lockscreenVisibility = Notification.VISIBILITY_PRIVATE
                }
            )
        }
    }
}
