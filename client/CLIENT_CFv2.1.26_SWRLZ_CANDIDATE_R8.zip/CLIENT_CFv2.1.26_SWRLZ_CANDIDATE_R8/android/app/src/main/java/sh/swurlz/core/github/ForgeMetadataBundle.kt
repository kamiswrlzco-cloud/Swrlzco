package sh.swurlz.core.github

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.security.MessageDigest
import java.util.zip.ZipInputStream

data class ForgeMetadataBundleContents(
    val outerName: String,
    val sourceZipName: String,
    val component: String,
    val versionCode: Int,
    val revision: String,
    val sha256: String,
    val sizeBytes: Long,
    val checksumEntryName: String,
    val manifestEntryName: String,
    val bundleSha256: String,
)

/**
 * Strict reader for CLIENT/SERVER metadata bundles.
 *
 * Contract:
 * - outer name: <SOURCE_STEM>_METADATA.zip
 * - archive root contains exactly one <SOURCE_STEM>.sha256 and one
 *   <SOURCE_STEM>.manifest.json authoritative entry
 * - no nested paths, traversal, duplicate names, oversized entries, or unrelated payloads
 * - checksum, manifest and source identity must agree before the source can become build eligible
 */
object ForgeMetadataBundle {
    private const val MAX_BUNDLE_BYTES = 4 * 1024 * 1024
    private const val MAX_ENTRY_BYTES = 1024 * 1024
    private const val MAX_TOTAL_BYTES = 2 * 1024 * 1024
    private val shaRegex = Regex("(?i)\\b[0-9a-f]{64}\\b")
    private val candidateRegex = Regex("(?i)^(CLIENT|SERVER)_CFv[^/]+_CANDIDATE_R(\\d+)$")

    fun isMetadataBundleName(fileName: String): Boolean {
        val canonical = canonicalName(fileName)
        val upper = canonical.uppercase()
        return upper.endsWith("_METADATA.ZIP") && (upper.startsWith("CLIENT_") || upper.startsWith("SERVER_"))
    }

    fun bundleNameForSource(sourceZipName: String): String {
        val canonical = canonicalName(sourceZipName)
        require(canonical.endsWith(".zip", ignoreCase = true)) { "Source package must be a ZIP." }
        return canonical.dropLast(4) + "_METADATA.zip"
    }

    fun sourceNameForBundle(bundleName: String): String {
        val canonical = canonicalName(bundleName)
        require(isMetadataBundleName(canonical)) { "Not a CLIENT/SERVER metadata bundle: $bundleName" }
        return canonical.dropLast("_METADATA.zip".length) + ".zip"
    }

    fun inspect(context: Context, uri: Uri, displayName: String): ForgeMetadataBundleContents =
        context.contentResolver.openInputStream(uri)?.use { input ->
            val bundleDigest = MessageDigest.getInstance("SHA-256")
            val bytes = input.readBounded(MAX_BUNDLE_BYTES)
            bundleDigest.update(bytes)
            inspectBytes(displayName, bytes, bundleDigest.digest().toHex())
        } ?: error("Unable to read metadata bundle $displayName")

    fun inspectBytes(displayName: String, bytes: ByteArray, bundleSha256: String = sha256(bytes)): ForgeMetadataBundleContents {
        require(isMetadataBundleName(displayName)) { "Metadata bundle name is not canonical: $displayName" }
        val expectedSource = sourceNameForBundle(displayName)
        val expectedStem = expectedSource.dropLast(4)
        val expectedChecksum = "$expectedStem.sha256"
        val expectedManifest = "$expectedStem.manifest.json"
        val entries = linkedMapOf<String, ByteArray>()
        var total = 0
        ZipInputStream(bytes.inputStream().buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.isDirectory) continue
                val name = entry.name.replace('\\', '/')
                require('/' !in name && name != "." && name != "..") { "Metadata entries must be at archive root: $name" }
                require(!name.startsWith("/") && !name.contains("../")) { "Unsafe metadata entry path: $name" }
                require(entries.keys.none { it.equals(name, ignoreCase = true) }) { "Duplicate metadata entry: $name" }
                val payload = zip.readBounded(MAX_ENTRY_BYTES)
                total += payload.size
                require(total <= MAX_TOTAL_BYTES) { "Metadata bundle exceeds $MAX_TOTAL_BYTES bytes." }
                entries[name] = payload
            }
        }
        require(entries.size == 2) { "Metadata bundle must contain exactly checksum + manifest; found ${entries.keys}." }
        val checksumEntry = entries.entries.singleOrNull { it.key.equals(expectedChecksum, ignoreCase = true) }
            ?: error("Missing canonical checksum entry $expectedChecksum")
        val manifestEntry = entries.entries.singleOrNull { it.key.equals(expectedManifest, ignoreCase = true) }
            ?: error("Missing canonical manifest entry $expectedManifest")

        val checksumText = checksumEntry.value.toString(Charsets.UTF_8).trim()
        val checksumSha = shaRegex.find(checksumText)?.value?.lowercase()
            ?: error("Checksum entry does not contain a SHA-256 value.")
        val declaredTarget = checksumText.split(Regex("\\s+")).drop(1).joinToString(" ").trim().trimStart('*')
        if (declaredTarget.isNotBlank()) {
            require(canonicalName(declaredTarget).equals(expectedSource, ignoreCase = true)) {
                "Checksum names $declaredTarget instead of $expectedSource"
            }
        }

        val json = JSONObject(manifestEntry.value.toString(Charsets.UTF_8))
        val source = json.optJSONObject("sourceZip")
        val manifestSourceName = source?.optString("filename")?.takeIf { it.isNotBlank() }
            ?: json.optString("zip").takeIf { it.isNotBlank() }
            ?: error("Manifest is missing sourceZip.filename or zip.")
        val manifestSha = source?.optString("sha256")?.takeIf { it.isNotBlank() }
            ?: json.optString("sha256").takeIf { it.isNotBlank() }
            ?: error("Manifest is missing source SHA-256.")
        val sizeBytes = when {
            source?.has("sizeBytes") == true -> source.optLong("sizeBytes", -1L)
            source?.has("size_bytes") == true -> source.optLong("size_bytes", -1L)
            json.has("sizeBytes") -> json.optLong("sizeBytes", -1L)
            else -> json.optLong("size_bytes", -1L)
        }
        require(canonicalName(manifestSourceName).equals(expectedSource, ignoreCase = true)) {
            "Manifest names $manifestSourceName instead of $expectedSource"
        }
        require(manifestSha.matches(Regex("(?i)[0-9a-f]{64}"))) { "Manifest SHA-256 is malformed." }
        require(manifestSha.equals(checksumSha, ignoreCase = true)) { "Manifest and checksum SHA-256 disagree." }
        require(sizeBytes > 0L) { "Manifest source size is missing or invalid." }
        if (json.has("verified")) require(json.optBoolean("verified", false)) { "Manifest verified flag is false." }

        val component = json.optString("component", expectedSource.substringBefore('_')).uppercase()
        require(component == expectedSource.substringBefore('_').uppercase()) { "Manifest component does not match source filename." }
        val versionCode = json.optInt("versionCode", json.optInt("version_code", -1))
        require(versionCode > 0) { "Manifest versionCode is missing or invalid." }
        val expectedRevision = candidateRegex.matchEntire(expectedStem)?.groupValues?.getOrNull(2)?.let { "R$it" }.orEmpty()
        val revision = json.optString("revision").ifBlank { expectedRevision }
        require(revision.matches(Regex("(?i)R\\d+"))) { "Manifest revision is missing or malformed." }
        if (expectedRevision.isNotBlank()) {
            require(revision.equals(expectedRevision, ignoreCase = true)) {
                "Manifest revision $revision does not match source revision $expectedRevision."
            }
        }
        return ForgeMetadataBundleContents(
            outerName = canonicalName(displayName),
            sourceZipName = expectedSource,
            component = component,
            versionCode = versionCode,
            revision = revision,
            sha256 = checksumSha,
            sizeBytes = sizeBytes,
            checksumEntryName = checksumEntry.key,
            manifestEntryName = manifestEntry.key,
            bundleSha256 = bundleSha256.lowercase(),
        )
    }

    private fun canonicalName(value: String): String {
        val normalized = value.trim()
        val suffix = when {
            normalized.endsWith("_METADATA.zip", true) -> "_METADATA.zip"
            normalized.endsWith(".zip", true) -> ".zip"
            else -> return normalized
        }
        val stem = normalized.dropLast(suffix.length).replace(Regex("\\s*\\(\\d+\\)$"), "").trimEnd()
        return stem + suffix
    }

    private fun java.io.InputStream.readBounded(limit: Int): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = read(buffer)
            if (count < 0) break
            if (count == 0) continue
            total += count
            require(total <= limit) { "Metadata entry exceeds $limit bytes." }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).toHex()

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }
}
