package sh.swurlz.core.github

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.zip.ZipInputStream

/** Safely extracts the actual APK from a GitHub Actions artifact ZIP. */
object ForgeArtifactExtractor {
    private const val MAX_ENTRIES = 512
    private const val MAX_APK_BYTES = 768L * 1024L * 1024L

    data class ExtractedApk(
        val displayName: String,
        val bytes: ByteArray,
        val sha256: String,
        val artifactEntry: String,
    )

    fun extractApk(artifactName: String, artifactZip: ByteArray, componentHint: String = ""): ExtractedApk {
        val entries = mutableListOf<Pair<String, ByteArray>>()
        val seen = mutableSetOf<String>()
        ZipInputStream(ByteArrayInputStream(artifactZip)).use { zip ->
            var count = 0
            while (true) {
                val entry = zip.nextEntry ?: break
                count++
                require(count <= MAX_ENTRIES) { "Artifact ZIP contains too many entries." }
                val normalized = entry.name.replace('\\', '/').trim()
                require(normalized.isNotBlank() && !normalized.startsWith('/') && !normalized.matches(Regex("""^[A-Za-z]:/.*"""))) {
                    "Artifact ZIP contains an unsafe path: ${entry.name}"
                }
                val segments = normalized.split('/').filter { it.isNotBlank() && it != "." }
                require(segments.isNotEmpty() && segments.none { it == ".." }) { "Artifact ZIP path traversal rejected: ${entry.name}" }
                val key = segments.joinToString("/").lowercase()
                require(seen.add(key)) { "Artifact ZIP contains a duplicate entry: $normalized" }
                if (!entry.isDirectory && normalized.endsWith(".apk", ignoreCase = true)) {
                    val out = ByteArrayOutputStream()
                    val buffer = ByteArray(1024 * 1024)
                    var total = 0L
                    while (true) {
                        val read = zip.read(buffer)
                        if (read <= 0) break
                        total += read
                        require(total <= MAX_APK_BYTES) { "APK entry exceeds the 768 MiB safety limit." }
                        out.write(buffer, 0, read)
                    }
                    entries += normalized to out.toByteArray()
                }
                zip.closeEntry()
            }
        }
        require(entries.isNotEmpty()) { "GitHub artifact $artifactName contains no APK." }
        val stable = entries.filter { it.first.contains("stable-signed", ignoreCase = true) }
        val componentMatches = entries.filter { componentHint.isNotBlank() && it.first.contains(componentHint, ignoreCase = true) }
        val selected = when {
            stable.size == 1 -> stable.single()
            entries.size == 1 -> entries.single()
            componentMatches.size == 1 -> componentMatches.single()
            else -> error("GitHub artifact $artifactName contains multiple ambiguous APKs: ${entries.joinToString { it.first }}")
        }
        val displayName = selected.first.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]+"), "_")
            .ifBlank { "SWRLZ_${componentHint.ifBlank { "ANDROID" }}_DEBUG.apk" }
        val sha = MessageDigest.getInstance("SHA-256").digest(selected.second).joinToString("") { "%02x".format(it) }
        return ExtractedApk(displayName, selected.second, sha, selected.first)
    }
}
