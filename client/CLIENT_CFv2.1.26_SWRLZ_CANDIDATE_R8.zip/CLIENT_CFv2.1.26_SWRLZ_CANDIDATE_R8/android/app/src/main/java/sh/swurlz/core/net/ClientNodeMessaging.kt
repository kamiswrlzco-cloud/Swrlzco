package sh.swurlz.core.net

import android.content.Context
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.UUID
import org.json.JSONObject

/**
 * Protocol-2 CLIENT access to SERVER message send, durable inbox, and correlated replies.
 * This layer never implies trust: SERVER proof binding and capability admission remain authoritative.
 */
object ClientNodeMessaging {
    const val PROTOCOL_VERSION = 2

    data class Result(
        val ok: Boolean,
        val statusCode: Int,
        val body: String,
        val errorCode: String? = null,
    )

    fun sendText(
        context: Context,
        baseUrl: String,
        text: String,
        destinationNodeId: String? = null,
        destinationComponent: String = if (destinationNodeId == null) "SERVER" else "CLIENT",
        requestType: String = "CHAT",
        route: String = "LOCAL",
        conversationId: String = newId("conversation"),
        correlationId: String = newId("correlation"),
        missionId: String? = null,
        waitForReply: Boolean = true,
        timeoutMs: Long = 45_000L,
        messageId: String = newId("message"),
    ): Result {
        require(text.isNotBlank()) { "Message text is required" }
        require(text.length <= 1_000_000) { "Message text exceeds protocol bound" }
        val nodeId = currentNodeId(context)
        val eventId = newId("event")
        val destination = JSONObject().put("component", destinationComponent.uppercase()).also {
            if (!destinationNodeId.isNullOrBlank()) it.put("deviceId", destinationNodeId)
        }
        val envelope = JSONObject()
            .put("messageId", messageId)
            .put("correlationId", correlationId)
            .put("conversationId", conversationId)
            .put("eventId", eventId)
            .put("source", JSONObject().put("component", "CLIENT").put("deviceId", nodeId))
            .put("destination", destination)
            .put("requestType", requestType.uppercase())
            .put("route", route.uppercase())
            .put("status", "CREATED")
            .put("createdAtEpochMs", System.currentTimeMillis())
            .put("retryCount", 0)
            .put("payloadSummary", text.take(500))
        if (!missionId.isNullOrBlank()) envelope.put("missionId", missionId)
        val body = JSONObject()
            .put("protocolVersion", PROTOCOL_VERSION)
            .put("envelope", envelope)
            .put("payload", JSONObject().put("kind", "TEXT").put("text", text))
            .put("waitForReply", waitForReply)
            .put("timeoutMs", timeoutMs.coerceIn(1_000L, 300_000L))
            .toString()
        return request(
            context,
            "POST",
            "${ServerEndpointRoles.operationalApiBase(baseUrl)}/messages/send",
            body,
            requestId = eventId,
            idempotencyKey = messageId,
            readTimeoutMs = if (waitForReply) timeoutMs.coerceIn(1_000L, 300_000L).toInt() + 5_000 else 10_000,
        )
    }

    fun pollInbox(
        context: Context,
        baseUrl: String,
        after: String = "",
        limit: Int = 20,
        types: Set<String> = emptySet(),
        waitMs: Long = 0L,
    ): Result {
        val nodeId = currentNodeId(context)
        val query = buildList {
            if (after.isNotBlank()) add("after=${encode(after)}")
            add("limit=${limit.coerceIn(1, 100)}")
            if (types.isNotEmpty()) add("types=${encode(types.joinToString(",") { it.uppercase() })}")
            add("waitMs=${waitMs.coerceIn(0L, 55_000L)}")
        }.joinToString("&")
        val requestId = newId("inbox")
        return request(
            context,
            "GET",
            "${ServerEndpointRoles.operationalApiBase(baseUrl)}/nodes/$nodeId/inbox?$query",
            null,
            requestId,
            requestId,
            waitMs.coerceIn(0L, 55_000L).toInt() + 5_000,
        )
    }

    fun replyText(
        context: Context,
        baseUrl: String,
        messageId: String,
        correlationId: String,
        conversationId: String,
        text: String,
        status: String = "COMPLETED",
        eventId: String = newId("reply"),
    ): Result {
        val body = JSONObject()
            .put("sourceNodeId", currentNodeId(context))
            .put("correlationId", correlationId)
            .put("conversationId", conversationId)
            .put("status", status.uppercase())
            .put("eventId", eventId)
            .put("payload", JSONObject().put("kind", "TEXT").put("text", text))
            .toString()
        return request(
            context,
            "POST",
            "${ServerEndpointRoles.operationalApiBase(baseUrl)}/messages/$messageId/reply",
            body,
            eventId,
            eventId,
            15_000,
        )
    }

    fun currentNodeId(context: Context): String {
        val prefs = context.getSharedPreferences("swrlz_presence_identity", Context.MODE_PRIVATE)
        return prefs.getString("nodeId", null)
            ?: error("CLIENT must register with SERVER before using protocol-2 messaging")
    }

    private fun request(
        context: Context,
        method: String,
        url: String,
        body: String?,
        requestId: String,
        idempotencyKey: String,
        readTimeoutMs: Int,
    ): Result {
        var connection: HttpURLConnection? = null
        return try {
            connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = method
            connection.connectTimeout = 5_000
            connection.readTimeout = readTimeoutMs
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("X-SWRLZ-Device-Proof", ClientNodeProofStore.deviceProof(context))
            connection.setRequestProperty("X-Request-Id", requestId)
            connection.setRequestProperty("Idempotency-Key", idempotencyKey)
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                connection.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
            }
            val code = connection.responseCode
            val response = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }.orEmpty()
            val error = runCatching { JSONObject(response).optJSONObject("error")?.optString("code") }.getOrNull()
            Result(code in 200..299, code, response.take(2_000_000), error)
        } catch (failure: Throwable) {
            Result(false, 0, "${failure.javaClass.simpleName}: ${failure.message}", "TRANSPORT_UNAVAILABLE")
        } finally {
            connection?.disconnect()
        }
    }

    private fun newId(prefix: String): String = "$prefix-${UUID.randomUUID()}"
    private fun encode(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.name())
}
