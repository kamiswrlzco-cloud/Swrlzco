package sh.swurlz.core.ui.theme

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import sh.swrlz.theme.SemanticAssetRole
import sh.swrlz.theme.ThemeProgressState

/**
 * Presentation-only startup host. Application initialization runs in the content tree at the
 * same time; this overlay never owns readiness and never invents an initialization percentage.
 */
@Composable
fun ThemeStartupHost(
    ready: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val pack = LocalThemePack.current
    val motion = LocalThemeMotionPolicy.current
    val tokens = LocalSwurlzTokens.current
    val latestReady by rememberUpdatedState(ready)
    val timeline = remember { Animatable(0f) }
    val overlayAlpha = remember { Animatable(1f) }
    var visible by remember { mutableStateOf(true) }
    var showLoading by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        timeline.snapTo(0f)
        overlayAlpha.snapTo(1f)
        visible = true
        showLoading = false
        val startup = pack.startupSequence

        if (!motion.enabled) {
            if (!latestReady) snapshotFlow { latestReady }.first { it }
            overlayAlpha.animateTo(
                0f,
                tween(startup?.reducedMotionFadeMs ?: 90, easing = LinearEasing),
            )
            visible = false
            return@LaunchedEffect
        }

        val normalDuration = startup?.durationMs ?: (
            pack.motionProfile.baseDurationMs * 2.3f
        ).toInt().coerceIn(520, 900)
        val firstStageMs = (normalDuration * .24f).toInt().coerceAtLeast(120)
        timeline.animateTo(
            .24f,
            tween(firstStageMs, easing = LinearEasing),
        )
        if (latestReady) {
            // Preserve a legible ignition while accelerating a fast-ready application to the
            // lower edge of the 0.6–1.2 second startup target.
            timeline.animateTo(
                1f,
                tween((600 - firstStageMs - 120).coerceAtLeast(120), easing = LinearEasing),
            )
            overlayAlpha.animateTo(0f, tween(120, easing = LinearEasing))
            visible = false
            return@LaunchedEffect
        }

        timeline.animateTo(
            .55f,
            tween((normalDuration * .31f).toInt().coerceAtLeast(120), easing = LinearEasing),
        )
        if (latestReady) {
            timeline.animateTo(1f, tween(180, easing = LinearEasing))
            overlayAlpha.animateTo(0f, tween(120, easing = LinearEasing))
            visible = false
            return@LaunchedEffect
        }

        timeline.animateTo(
            .78f,
            tween((normalDuration * .23f).toInt().coerceAtLeast(120), easing = LinearEasing),
        )
        if (!latestReady) {
            val readinessWindow = (startup?.loadingTransitionMs ?: 1_200) -
                (normalDuration * .78f).toInt()
            withTimeoutOrNull(readinessWindow.coerceAtLeast(1).toLong()) {
                snapshotFlow { latestReady }.first { it }
            }
        }
        if (!latestReady) {
            showLoading = true
            snapshotFlow { latestReady }.first { it }
            showLoading = false
        }
        timeline.animateTo(
            1f,
            tween((normalDuration * .22f).toInt().coerceAtLeast(120), easing = LinearEasing),
        )
        overlayAlpha.animateTo(0f, tween(150, easing = LinearEasing))
        visible = false
    }

    Box(modifier.fillMaxSize()) {
        content()
        if (visible) {
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = overlayAlpha.value }
                    .background(
                        Brush.radialGradient(
                            listOf(tokens.surfaces.bgTopBar, tokens.surfaces.bgApp),
                        )
                    ),
            ) {
                ThemeAppBackdrop(
                    motionEnabled = motion.enabled,
                    modifier = Modifier.matchParentSize(),
                    artAlphaOverride = if (pack.startupSequence != null) .08f else .16f,
                )
                if (!motion.enabled) {
                    ThemeStartupStatic()
                } else if (pack.startupSequence != null) {
                    ThemeIgnitionLayers(timeline.value)
                } else {
                    ThemeStartupFallback(timeline.value)
                }
                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 28.dp, vertical = 30.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = "SWRLZ CLIENT",
                        color = tokens.text.primary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 2.sp,
                    )
                    if (showLoading) {
                        Spacer(Modifier.height(14.dp))
                        ThemedProgressBar(
                            snapshot = ProgressSnapshot(
                                operationId = "client-startup",
                                value = null,
                                state = ThemeProgressState.STARTING,
                                label = "Client initialization",
                                statusText = "INITIALIZING — WAITING FOR APPLICATION READINESS",
                            ),
                            showStatusText = true,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemeIgnitionLayers(t: Float) {
    val pack = LocalThemePack.current
    val dormant = 1f - ramp(t, .13f, .22f)
    val spark = window(t, .12f, .29f)
    val partial = window(t, .21f, .45f)
    val awakened = ramp(t, .38f, .56f)
    val shockwave = window(t, .52f, .70f)
    val radial = window(t, .49f, .80f)
    val particles = ramp(t, .42f, .61f) * (1f - ramp(t, .88f, 1f))
    val residual = ramp(t, .69f, .90f)
    val coreSize = 238.dp
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (radial > .01f) {
            ThemeRoleImage(
                pack,
                SemanticAssetRole.StartupRadial,
                Modifier
                    .size(360.dp)
                    .graphicsLayer {
                        scaleX = .72f + ramp(t, .49f, .78f) * .46f
                        scaleY = scaleX
                        rotationZ = (t - .49f).coerceAtLeast(0f) * 16f
                    },
                alpha = radial * .92f,
            )
        }
        if (particles > .01f) {
            ThemeRoleImage(
                pack,
                SemanticAssetRole.StartupParticles,
                Modifier
                    .size(338.dp)
                    .graphicsLayer {
                        rotationZ = t * -12f
                        scaleX = .90f + ramp(t, .42f, .84f) * .16f
                        scaleY = scaleX
                    },
                alpha = particles * .86f,
            )
        }
        if (dormant > .01f) {
            ThemeRoleImage(
                pack,
                SemanticAssetRole.StartupDormant,
                Modifier.size(coreSize),
                alpha = dormant,
            )
        }
        if (spark > .01f) {
            ThemeRoleImage(
                pack,
                SemanticAssetRole.StartupSpark,
                Modifier
                    .size(176.dp)
                    .graphicsLayer {
                        scaleX = .76f + ramp(t, .12f, .24f) * .32f
                        scaleY = scaleX
                    },
                alpha = spark,
            )
        }
        if (partial > .01f) {
            ThemeRoleImage(
                pack,
                SemanticAssetRole.StartupPartial,
                Modifier
                    .size(coreSize)
                    .graphicsLayer {
                        scaleX = .96f + ramp(t, .21f, .42f) * .04f
                        scaleY = scaleX
                    },
                alpha = partial,
            )
        }
        if (awakened > .01f) {
            ThemeRoleImage(
                pack,
                SemanticAssetRole.StartupAwakened,
                Modifier.size(coreSize).graphicsLayer {
                    scaleX = .96f + ramp(t, .34f, .72f) * .04f
                    scaleY = scaleX
                },
                alpha = awakened,
            )
        }
        if (shockwave > .01f) {
            ThemeRoleImage(
                pack,
                SemanticAssetRole.StartupShockwave,
                Modifier
                    .size(320.dp)
                    .graphicsLayer {
                        scaleX = .68f + ramp(t, .52f, .68f) * .58f
                        scaleY = scaleX
                    },
                alpha = shockwave,
            )
        }
        if (residual > .01f) {
            ThemeRoleImage(
                pack,
                SemanticAssetRole.StartupResidual,
                Modifier
                    .size(278.dp)
                    .graphicsLayer {
                        scaleX = 1f + ramp(t, .69f, 1f) * .06f
                        scaleY = scaleX
                    },
                alpha = residual * .72f,
            )
        }
    }
}

@Composable
private fun ThemeStartupStatic() {
    val pack = LocalThemePack.current
    val role = SemanticAssetRole.StartupAwakened.takeIf {
        ThemeAssetResolver.resolve(pack, it) != null
    } ?: ThemeAssetResolver.kapanionRole(pack)
    if (role != null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            ThemeRoleImage(pack, role, Modifier.size(236.dp))
        }
    } else {
        ThemeStartupFallback(1f)
    }
}

@Composable
private fun ThemeStartupFallback(t: Float) {
    val pack = LocalThemePack.current
    val tokens = LocalSwurlzTokens.current
    val role = ThemeAssetResolver.kapanionRole(pack)
        ?: SemanticAssetRole.ProgressHead.takeIf {
            ThemeAssetResolver.resolve(pack, it) != null
        }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (role != null) {
            Box(
                Modifier
                    .size(236.dp)
                    .graphicsLayer {
                        alpha = ramp(t, 0f, .72f) * .74f
                        scaleX = .82f + ramp(t, 0f, .82f) * .18f
                        scaleY = scaleX
                    }
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                tokens.accents.primary.copy(alpha = .34f),
                                tokens.accents.tertiary.copy(alpha = .16f),
                                tokens.surfaces.bgOverlay.copy(alpha = .04f),
                            )
                        )
                    )
                    .border(1.dp, tokens.accents.primary.copy(alpha = .62f), CircleShape),
            )
            ThemeRoleImage(
                pack,
                role,
                Modifier
                    .size(210.dp)
                    .graphicsLayer {
                        alpha = ramp(t, 0f, .55f)
                        scaleX = .90f + ramp(t, 0f, .72f) *
                            (pack.motionProfile.pulseScale - .90f)
                        scaleY = scaleX
                        rotationZ = pack.chromeStyle.ambientTiltDegrees * window(t, .15f, .92f)
                    },
            )
        } else {
            Box(
                Modifier
                    .size(126.dp)
                    .clip(CircleShape)
                    .background(tokens.cards.bgAlt)
                    .border(2.dp, tokens.accents.primary, CircleShape),
            )
        }
    }
}

private fun ramp(value: Float, start: Float, end: Float): Float =
    ((value - start) / (end - start).coerceAtLeast(.001f)).coerceIn(0f, 1f)

private fun window(value: Float, start: Float, end: Float): Float {
    val midpoint = (start + end) / 2f
    return if (value <= midpoint) ramp(value, start, midpoint) else 1f - ramp(value, midpoint, end)
}
