package sh.swurlz.core.update

/**
 * Local/offline patch-note knowledge used by the CLIENT Update Ledger and Chat.
 *
 * Entries intentionally describe only evidence recorded by the source lineage. Runtime/build/device
 * claims remain explicit instead of being inferred from a version number.
 */
data class UpdateLedgerSection(
    val title: String,
    val bullets: List<String>,
)

data class UpdateLedgerEntry(
    val version: String,
    val revision: String? = null,
    val versionCode: Int? = null,
    val checkpoint: String,
    val evidence: String,
    val summary: String,
    val sections: List<UpdateLedgerSection>,
    val aliases: Set<String> = emptySet(),
) {
    val label: String get() = buildString {
        append("CFv")
        append(version)
        revision?.takeIf { it.isNotBlank() }?.let { append(" ").append(it) }
    }

    fun searchableText(): String = buildString {
        append(label).append(' ')
        append(checkpoint).append(' ')
        append(summary).append(' ')
        sections.forEach { section ->
            append(section.title).append(' ')
            section.bullets.forEach { append(it).append(' ') }
        }
    }.lowercase()
}

object UpdateLedgerCatalog {
    val entries: List<UpdateLedgerEntry> = listOf(
        UpdateLedgerEntry(
            version = "2.1.25",
            revision = "R1",
            versionCode = 123,
            checkpoint = "INT-AI-041F-C2",
            evidence = "SOURCE/STATIC CANDIDATE",
            summary = "Integrates Behavior Shard V1 into the paired Model Rack with SERVER-side validation, deterministic 0–2 shard routing, source-to-inference compilation, and bounded prompt assembly.",
            sections = listOf(
                UpdateLedgerSection("Behavior Shards", listOf(
                    "CLIENT and SERVER advertise Model Rack protocol V2 with BEHAVIOR_SHARD and behavior_shard_v1 support.",
                    "SERVER validates hash-declared behavior.json payloads against the frozen C1 authoring contract shape before commit.",
                    "Active behavior modules are under-injected: zero, one, or two routed shards may contribute to a turn.",
                    "Authoring band labels and grounding reference IDs remain metadata and are not emitted into the model-facing prompt.",
                )),
                UpdateLedgerSection("Boundaries", listOf(
                    "The shared grounding foundation is injected once only when a behavior shard is routed.",
                    "Behavior cannot create runtime facts or override identity, Truth Firewall, approvals, permissions, trust, provenance, missions, Forge authority, files, tools, or execution.",
                    "Mirror Profile v1.0.2 and Harmonic Chaos EQ v1.0.0 remain unchanged baselines.",
                )),
                UpdateLedgerSection("Evidence", listOf(
                    "This is a source-only candidate; Android compilation, APK build, device execution, promotion, release, deployment, and installation are not claimed.",
                )),
            ),
            aliases = setOf("2.1.25", "2.1.25 r1", "041f c2", "behavior shard", "latest"),
        ),
        UpdateLedgerEntry(
            version = "2.1.23",
            revision = "R1",
            versionCode = 121,
            checkpoint = "INT-AI-041F-A-R8",
            evidence = "SOURCE/STATIC + MODEL IDENTITY CANDIDATE",
            summary = "Adds a paired modular model rack with exact optimized-GGUF recognition, per-model Speed/Reasoning Depth/Expression EQ, declarative prompt/EQ modules and rollback.",
            sections = listOf(
                UpdateLedgerSection("Added", listOf(
                    "Brain & AI now exposes SERVER model selection, per-model Speed and truthful Reasoning Depth.",
                    "Nine Expression EQ sliders shape response presentation without changing Truth Firewall or authority.",
                    "Prompt and EQ module state can be activated through the paired SERVER control plane.",
                    "Profile and model rollback are visible from CLIENT.",
                )),
                UpdateLedgerSection("Security and truth boundary", listOf(
                    "SERVER remains authoritative; LAN changes require the registered action-phone identity, same-subnet authorization and pairing token.",
                    "Truth Firewall, permissions, approvals, provenance, node trust, missions, Forge, files, tools and execution are not sliders.",
                    "LoRA activation remains blocked until the Android native adapter bridge is verified.",
                    "The optimized GGUF remains external and is never bundled in CLIENT.",
                )),
                UpdateLedgerSection("Evidence", listOf(
                    "Paired source/static/model-identity verification passes 36/36.",
                    "Android compilation did not begin because Gradle 8.7 was unavailable in the isolated workspace.",
                )),
            ),
            aliases = setOf("2.1.23", "2.1.23 r1", "041f", "041f a"),
        ),
        UpdateLedgerEntry(
            version = "2.1.22",
            revision = "R1",
            versionCode = 120,
            checkpoint = "INT-UX-039Q",
            evidence = "SOURCE/STATIC CANDIDATE",
            summary = "Interactive Update Ledger, evidence-aware local patch Q&A, hierarchical Settings Back behavior, Settings information-architecture cleanup, and primary/complementary theme identity roles.",
            sections = listOf(
                UpdateLedgerSection("Added", listOf(
                    "Top-left Kapanion opens a local/offline Update Ledger with a version rail and detailed notes.",
                    "Chat can answer informational patch-note questions locally, including latest-update summaries and version comparisons.",
                    "The command catalog exposes /updates (latest), /updates (ask), and /updates (compare) prompts.",
                )),
                UpdateLedgerSection("Changed", listOf(
                    "Chat & Commands now owns a Brain & AI subcategory; provider/profile controls live beneath that reasoning layer.",
                    "Activity & Notifications now owns Messages & Bubble controls; Theme & Interface retains presentation-only controls.",
                    "CLIENT bubble identity can use a complementary ThemePack role tint while launcher identity remains unchanged.",
                )),
                UpdateLedgerSection("Fixed", listOf(
                    "Android Back pops nested Settings pages one level at a time before leaving Settings.",
                    "Back from a top-level CLIENT tab returns to Core before Android receives a root-level Back action.",
                )),
                UpdateLedgerSection("Truth boundary", listOf(
                    "No SERVER, mission authority, protocol, Truth Firewall, Forge authority, filesystem authority, release, deployment, or installation behavior is changed by this checkpoint.",
                    "Android/SystemUI-owned bubble badges are not claimed as independently recolorable; SWRLZ changes only surfaces it owns.",
                )),
            ),
            aliases = setOf("2.1.22", "2.1.22 r1", "039q"),
        ),
        UpdateLedgerEntry(
            version = "2.1.21",
            revision = "R2",
            versionCode = 119,
            checkpoint = "INT-CMD-039P-R2",
            evidence = "SOURCE/STATIC CANDIDATE",
            summary = "Refines the hierarchical command palette to /parent (child) [instructions], fixes external command-caret placement, and tightens response-top following.",
            sections = listOf(
                UpdateLedgerSection("Changed", listOf(
                    "Preferred grammar is /parent (child) [instructions].",
                    "Command-list hierarchy is parent → action/subcommand → selector only when needed.",
                    "Legacy tokenized command syntax remains compatible.",
                )),
                UpdateLedgerSection("Fixed", listOf(
                    "External command insertion selects draft.length so the composer caret lands at the end.",
                    "Response-top follow reserves a full trailing viewport and verifies the anchor at zero offset.",
                )),
                UpdateLedgerSection("Known/Pending", listOf(
                    "039M file actions remain PLANNED in this candidate.",
                )),
            ),
            aliases = setOf("2.1.21 r2", "039p r2"),
        ),
        UpdateLedgerEntry(
            version = "2.1.21",
            revision = "R1",
            versionCode = 119,
            checkpoint = "INT-CMD-039P",
            evidence = "SOURCE/STATIC CANDIDATE",
            summary = "Introduces the hierarchical Chat Command Palette and capability registry while preserving insert-for-review safety semantics.",
            sections = listOf(
                UpdateLedgerSection("Added", listOf(
                    "Nested command/subcommand browsing.",
                    "Typed canonical command prompt resolution and context-ranked suggestions.",
                    "Local pinned/recent commands plus visible approval and availability metadata.",
                )),
                UpdateLedgerSection("Truth boundary", listOf(
                    "Command metadata does not grant execution authority.",
                    "039M organizer paths are registered as PLANNED rather than represented as active runtime features.",
                )),
            ),
            aliases = setOf("2.1.21 r1", "039p"),
        ),
        UpdateLedgerEntry(
            version = "2.1.20",
            revision = "R1",
            versionCode = 118,
            checkpoint = "INT-FORGE-039F + INT-FORGE-039N",
            evidence = "CANDIDATE LINEAGE",
            summary = "Hardens Forge transport for large source ZIPs and separates ZIP build eligibility from optional checksum/manifest evidence.",
            sections = listOf(
                UpdateLedgerSection("Forge", listOf(
                    "AUTO mode chunks protected sources above 4 MiB; DIRECT and CHUNKED remain explicit operator choices.",
                    "Chunk transport records per-part SHA-256 plus whole-ZIP identity and supports retry reuse of existing Git blobs.",
                    "A source ZIP is sufficient build input; supplied checksum/manifest contradictions still block.",
                )),
            ),
            aliases = setOf("2.1.20", "2.1.20 r1", "039f", "039n"),
        ),
        UpdateLedgerEntry(
            version = "2.1.19",
            revision = "R2",
            versionCode = 117,
            checkpoint = "INT-CHAT-039I",
            evidence = "CANDIDATE LINEAGE",
            summary = "Makes Chat conversation-first with keyboard-aware chrome, compact Reasoning Mesh, and response-top follow semantics.",
            sections = listOf(
                UpdateLedgerSection("Chat", listOf(
                    "Collapses onboarding after the first user message and while the keyboard is visible.",
                    "Converts Reasoning Mesh to a compact status strip with an expandable provider/routing sheet.",
                    "Hides bottom version/navigation chrome while typing and adds a compact ThemePack/Kapanion composer.",
                    "Preserves response-top follow and LATEST reattachment semantics.",
                )),
            ),
            aliases = setOf("2.1.19", "2.1.19 r2", "039i"),
        ),
        UpdateLedgerEntry(
            version = "2.1.18",
            revision = null,
            versionCode = 116,
            checkpoint = "INT-FIX-039G",
            evidence = "SOURCE/STATIC LINEAGE",
            summary = "Repairs the ClientProfileStore expression that blocked compileDebugKotlin while preserving the Forge-rescue payload.",
            sections = listOf(
                UpdateLedgerSection("Fixed", listOf(
                    "Changes the incorrect providerProfileId?.let function-symbol nullable access to the declared providerId?.let.",
                    "SERVER profile-store paths were audited and left unchanged because the corresponding SERVER code was already correct.",
                )),
            ),
            aliases = setOf("2.1.18", "039g"),
        ),
        UpdateLedgerEntry(
            version = "2.1.17",
            revision = null,
            versionCode = 115,
            checkpoint = "INT-FORGE-039E",
            evidence = "SOURCE/STATIC LINEAGE",
            summary = "Transport-light Forge rescue that temporarily exposes only Glitch Dragon Glass at runtime while repairing credential/write preflight behavior.",
            sections = listOf(
                UpdateLedgerSection("Forge", listOf(
                    "Preflight proves authentication, repository read, and Contents: write before a large transfer using a tiny unreferenced Git blob.",
                    "Later 401 errors trigger authentication re-probe instead of automatically discarding a still-valid credential.",
                    "422 input-too-large is classified as transport-size failure rather than authentication failure.",
                )),
                UpdateLedgerSection("Theme boundary", listOf(
                    "Runtime selectable set is temporarily Glitch Dragon Glass only and alternate launcher aliases/assets are omitted for transport bootstrap.",
                    "Full declarative ThemePack definitions remain lineage for restoration; this is explicitly not a design rollback.",
                )),
            ),
            aliases = setOf("2.1.17", "039e"),
        ),
        UpdateLedgerEntry(
            version = "2.1.16",
            revision = null,
            versionCode = 114,
            checkpoint = "INT-THEME-039C",
            evidence = "SOURCE/STATIC LINEAGE",
            summary = "Calibrates semantic progress geometry so the Jester progress endpoint and moving head align to the same evidence-backed boundary.",
            sections = listOf(
                UpdateLedgerSection("Theme progress", listOf(
                    "Jester resolved track ends at the right green emerald landmark at 89.5% of outer frame width.",
                    "The progress head uses its center as the semantic anchor for intermediate values and 100%.",
                    "The shared renderer remains theme-aware; uncalibrated themes retain their ThemeProgressStyle insets.",
                )),
            ),
            aliases = setOf("2.1.16", "039c"),
        ),
        UpdateLedgerEntry(
            version = "2.1.15",
            revision = null,
            versionCode = 113,
            checkpoint = "INT-THEME-039A",
            evidence = "SOURCE/STATIC LINEAGE",
            summary = "Completes ignition artwork coverage for Dragon Kamileon, Jade, Frost, Crystal Cyber, and Inferno while preserving Jester startup semantics.",
            sections = listOf(
                UpdateLedgerSection("Themes", listOf(
                    "Adds the remaining user-supplied ignition families without changing readiness or reduced-motion truth semantics.",
                )),
            ),
            aliases = setOf("2.1.15", "039a"),
        ),
        UpdateLedgerEntry(
            version = "2.1.14",
            revision = null,
            versionCode = 112,
            checkpoint = "INT-CHAT-FORGE-038C",
            evidence = "SOURCE/STATIC LINEAGE",
            summary = "Adds Command Center discovery and package-aware Forge staging for CLIENT, SERVER, and combo package units.",
            sections = listOf(
                UpdateLedgerSection("Added", listOf(
                    "Chat quick-action/Command Center discovery.",
                    "Package target selection and ZIP/checksum/manifest companion handling.",
                    "CLIENT + SERVER combo staging without merging their package identities.",
                )),
            ),
            aliases = setOf("2.1.14", "038c"),
        ),
        UpdateLedgerEntry(
            version = "2.1.11",
            revision = null,
            versionCode = 109,
            checkpoint = "Chat Control Center",
            evidence = "SOURCE-ONLY LINEAGE",
            summary = "Expands Chat & Commands settings, changes default auto-follow to the top of the newest SWRLZ response, and applies the selected response profile to optional outside reasoning.",
            sections = listOf(
                UpdateLedgerSection("Chat settings", listOf(
                    "Adds Conversation Flow, Personality & Response, and Privacy & Context controls.",
                    "Changes default auto-follow target to response top.",
                )),
            ),
            aliases = setOf("2.1.11"),
        ),
    )

    val latest: UpdateLedgerEntry get() = entries.first()

    fun displayVersion(versionName: String): String {
        val base = versionName.substringBefore('-')
        val revision = Regex("candidate-r(\\d+)", RegexOption.IGNORE_CASE)
            .find(versionName)
            ?.groupValues
            ?.getOrNull(1)
        return buildString {
            append("CFv").append(base)
            if (!revision.isNullOrBlank()) append(" R").append(revision)
        }
    }

    fun find(query: String): UpdateLedgerEntry? {
        val normalized = normalize(query)
        return entries.firstOrNull { entry ->
            entry.aliases.any { normalize(it) in normalized } || normalize(entry.label) in normalized
        }
    }

    fun shouldHandle(query: String): Boolean {
        val q = query.trim().lowercase()
        if (q.startsWith("/updates")) return true
        val informational = listOf(
            "patch note", "patch notes", "latest patch", "latest update", "update review",
            "update summary", "what's new", "whats new", "what changed", "anything cool",
            "release note", "release notes", "compare updates", "compare patches",
        ).any { it in q }
        val hasVersion = Regex("\\d+\\.\\d+\\.\\d+").containsMatchIn(q)
        val versionComparison = hasVersion && ("compare" in q || "difference" in q || "versus" in q || " vs " in q)
        return (informational || versionComparison) &&
            (hasVersion || "swrlz" in q || "update" in q || "patch" in q || "release" in q || "what's new" in q || "whats new" in q)
    }

    /** Returns null when the message is not an informational update/patch-note request. */
    fun answer(query: String): String? {
        if (!shouldHandle(query)) return null
        val q = query.lowercase()
        if ("compare" in q || "difference" in q || "versus" in q || " vs " in q) {
            val matches = entries.filter { entry ->
                entry.aliases.any { normalize(it) in normalize(q) } || normalize(entry.label) in normalize(q)
            }.distinct()
            if (matches.size >= 2) return compare(matches[0], matches[1])
        }

        val entry = find(query) ?: latest
        val focusTerms = listOf("command", "forge", "chat", "settings", "theme", "bubble", "provider", "file", "progress", "back")
            .filter { it in q }
        val focused = if (focusTerms.isEmpty()) emptyList() else entry.sections.flatMap { section ->
            section.bullets.filter { bullet -> focusTerms.any { term -> term in bullet.lowercase() || term in section.title.lowercase() } }
        }

        return buildString {
            append(entry.label).append(" · ").append(entry.checkpoint).append('\n')
            append(entry.summary).append('\n')
            if (focused.isNotEmpty()) {
                append('\n').append("Relevant changes:")
                focused.take(6).forEach { append("\n• ").append(it) }
            } else {
                val highlights = entry.sections.flatMap { it.bullets }.take(6)
                if (highlights.isNotEmpty()) {
                    append('\n').append("Highlights:")
                    highlights.forEach { append("\n• ").append(it) }
                }
            }
            append("\n\nEvidence: ").append(entry.evidence)
        }
    }

    private fun compare(a: UpdateLedgerEntry, b: UpdateLedgerEntry): String = buildString {
        append(a.label).append(" ↔ ").append(b.label).append('\n')
        append("• ").append(a.label).append(": ").append(a.summary).append('\n')
        append("• ").append(b.label).append(": ").append(b.summary).append('\n')
        append("\nEvidence: ").append(a.label).append(" = ").append(a.evidence)
        append("; ").append(b.label).append(" = ").append(b.evidence)
    }

    private fun normalize(value: String): String = value.lowercase()
        .replace("cfv", "")
        .replace('-', ' ')
        .replace('_', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()
}
