package sh.swurlz.core.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import sh.swurlz.core.model.UiNode
import sh.swurlz.core.data.MissionBus
import sh.swurlz.core.data.ChatRuntimeBus
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference

/**
 * The Local Operator's eyes + hands.
 *
 * - Snapshots the active window's accessibility node tree (text/desc/class/bounds/clickable/editable)
 * - Performs atomic actions: tap, scroll, type_text, back, home, wait, open_app
 * - Each visible node is fingerprinted as nX so the planner can address them by stable id.
 *
 * Important: the AccessibilityService is bound by the system once the user enables it
 * in Settings → Accessibility → Installed apps → SWRLZ-CORE Operator.
 */
class SwurlzAccessibilityService : AccessibilityService() {

    companion object {
        const val TAG = "SwurlzA11y"
        private val INSTANCE = AtomicReference<SwurlzAccessibilityService?>(null)
        fun get(): SwurlzAccessibilityService? = INSTANCE.get()
    }

    /** Map from synthetic node id -> live AccessibilityNodeInfo (only valid for current snapshot). */
    private val nodeIndex = mutableMapOf<String, AccessibilityNodeInfo>()
    private val nodeMetadata = mutableMapOf<String, UiNode>()
    private var currentSnapshotId: String? = null
    private var lastPackage: String? = null
    private var lastWindowClass: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        INSTANCE.set(this)
        Log.i(TAG, "Accessibility service connected")
    }

    override fun onDestroy() {
        INSTANCE.set(null)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event?.packageName?.toString()?.let { lastPackage = it }
        event?.className?.toString()?.let { lastWindowClass = it }
        when (event?.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> currentSnapshotId = null
        }
    }

    override fun onInterrupt() {}

    private val keyHandler = Handler(Looper.getMainLooper())
    private var volUpDown = false
    private var volDownDown = false
    private var chordArmedAt = 0L
    private var chordTriggered = false
    private val chordCheck = Runnable {
        if (volUpDown && volDownDown && !chordTriggered && MissionBus.mission.value.state == "running") {
            chordTriggered = true
            MissionBus.pauseRequest.value = true
            MissionBus.setAmbient(MissionBus.Ambient.Paused)
            ChatRuntimeBus.post("Mission paused by the Volume Up + Volume Down safety shortcut.")
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> volUpDown = event.action != KeyEvent.ACTION_UP
            KeyEvent.KEYCODE_VOLUME_DOWN -> volDownDown = event.action != KeyEvent.ACTION_UP
            else -> return super.onKeyEvent(event)
        }
        if (volUpDown && volDownDown) {
            if (chordArmedAt == 0L) {
                chordArmedAt = SystemClock.elapsedRealtime()
                chordTriggered = false
                keyHandler.removeCallbacks(chordCheck)
                keyHandler.postDelayed(chordCheck, 2200L)
            }
        } else {
            chordArmedAt = 0L
            chordTriggered = false
            keyHandler.removeCallbacks(chordCheck)
        }
        return false
    }


    /** Capture the current screen as a compact list of UiNode + meta. */
    fun snapshot(maxNodes: Int = 80): Snapshot {
        nodeIndex.values.forEach(AccessibilityNodeInfo::recycle)
        nodeIndex.clear()
        nodeMetadata.clear()
        val snapshotId = UUID.randomUUID().toString()
        currentSnapshotId = snapshotId
        val root = rootInActiveWindow ?: return Snapshot(snapshotId, emptyList(), null, lastWindowClass, "no root window")
        val nodes = mutableListOf<UiNode>()
        var counter = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null) return
            if (nodes.size >= maxNodes) return
            val text = n.text?.toString()
            val desc = n.contentDescription?.toString()
            val isInteractive = n.isClickable || n.isLongClickable || n.isEditable || (text != null) || (desc != null)
            if (isInteractive) {
                val id = "n${counter++}"
                val rect = Rect()
                n.getBoundsInScreen(rect)
                nodeIndex[id] = AccessibilityNodeInfo.obtain(n)
                val uiNode = UiNode(
                    id = id,
                    cls = n.className?.toString()?.substringAfterLast('.'),
                    text = text,
                    desc = desc,
                    pkg = n.packageName?.toString(),
                    clickable = n.isClickable,
                    editable = n.isEditable,
                    password = n.isPassword,
                    enabled = n.isEnabled,
                    checked = if (n.isCheckable) n.isChecked else null,
                    selected = n.isSelected,
                    scrollable = n.isScrollable,
                    bounds = listOf(rect.left, rect.top, rect.right, rect.bottom),
                )
                nodeMetadata[id] = uiNode
                nodes += uiNode
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        val summary = "pkg=${root.packageName ?: "?"} nodes=${nodes.size}"
        return Snapshot(snapshotId, nodes, root.packageName?.toString(), lastWindowClass, summary)
    }

    data class Snapshot(
        val id: String,
        val nodes: List<UiNode>,
        val pkg: String?,
        val windowClass: String?,
        val summary: String,
    )

    /**
     * Executes only when the planner action still targets the currently observed snapshot
     * and the node's semantic preconditions still match.
     */
    fun tapNode(
        nodeId: String,
        snapshotId: String?,
        expectedPackage: String?,
        expectedClass: String?,
        expectedText: String?,
        expectedDesc: String?,
        expectedBounds: List<Int>?,
    ): Boolean {
        val n = validatedNode(
            nodeId, snapshotId, expectedPackage, expectedClass,
            expectedText, expectedDesc, expectedBounds,
        ) ?: return false
        var cur: AccessibilityNodeInfo? = n
        while (cur != null && !cur.isClickable) cur = cur.parent
        val target = cur ?: n
        if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val rect = Rect()
        n.getBoundsInScreen(rect)
        if (rect.width() == 0 || rect.height() == 0) return false
        return tapPoint(rect.centerX().toFloat(), rect.centerY().toFloat())
    }

    fun tapPoint(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 60)
        val g = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(g, null, null)
    }

    fun typeText(
        nodeId: String,
        text: String,
        snapshotId: String?,
        expectedPackage: String?,
        expectedClass: String?,
        expectedText: String?,
        expectedDesc: String?,
        expectedBounds: List<Int>?,
    ): Boolean {
        val n = validatedNode(
            nodeId, snapshotId, expectedPackage, expectedClass,
            expectedText, expectedDesc, expectedBounds,
        ) ?: return false
        if (!n.isEditable || n.isPassword) return false
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun validatedNode(
        nodeId: String,
        snapshotId: String?,
        expectedPackage: String?,
        expectedClass: String?,
        expectedText: String?,
        expectedDesc: String?,
        expectedBounds: List<Int>?,
    ): AccessibilityNodeInfo? {
        if (snapshotId.isNullOrBlank() || snapshotId != currentSnapshotId) return null
        val node = nodeIndex[nodeId] ?: return null
        val metadata = nodeMetadata[nodeId] ?: return null
        val activePackage = rootInActiveWindow?.packageName?.toString()
        if (activePackage != metadata.pkg) return null
        if (expectedPackage != null && expectedPackage != metadata.pkg) return null
        if (expectedClass != null && expectedClass != metadata.cls) return null
        if (expectedText != null && expectedText != metadata.text) return null
        if (expectedDesc != null && expectedDesc != metadata.desc) return null
        if (expectedBounds != null && expectedBounds != metadata.bounds) return null

        val rect = Rect()
        node.getBoundsInScreen(rect)
        val liveBounds = listOf(rect.left, rect.top, rect.right, rect.bottom)
        val liveClass = node.className?.toString()?.substringAfterLast('.')
        if (liveClass != metadata.cls || liveBounds != metadata.bounds) return null
        if (node.packageName?.toString() != metadata.pkg) return null
        if (node.text?.toString() != metadata.text) return null
        if (node.contentDescription?.toString() != metadata.desc) return null
        if (!node.isEnabled || !node.isVisibleToUser) return null
        return node
    }

    fun scrollScreen(direction: String): Boolean {
        val root = rootInActiveWindow ?: return false
        // Prefer the largest visible scroll container. Settings-style screens often expose
        // nested scrollables and the first node in tree order is not necessarily the viewport.
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            if (n.isScrollable && n.isVisibleToUser) candidates += n
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        val node = candidates.maxByOrNull {
            val r = Rect(); it.getBoundsInScreen(r); r.width().toLong() * r.height().toLong()
        }
        if (node != null) {
            val action = when (direction.lowercase()) {
                "up", "left" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                else -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            }
            if (node.performAction(action)) return true
        }
        // Fallback: synthesize a long swipe in the central viewport. The Mission HUD
        // auto-collapses during acting, leaving the target surface unobstructed.
        val dm = resources.displayMetrics
        val cx = dm.widthPixels * 0.62f
        val cy = dm.heightPixels / 2f
        val d = dm.heightPixels * 0.42f
        val x1: Float; val y1: Float; val x2: Float; val y2: Float
        when (direction.lowercase()) {
            "up"    -> { x1 = cx; y1 = cy - d; x2 = cx; y2 = cy + d }
            "left"  -> { x1 = cx - d; y1 = cy; x2 = cx + d; y2 = cy }
            "right" -> { x1 = cx + d; y1 = cy; x2 = cx - d; y2 = cy }
            else    -> { x1 = cx; y1 = cy + d; x2 = cx; y2 = cy - d }
        }
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 280)
        val g = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(g, null, null)
    }

    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
}
