package sh.swurlz.core.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import sh.swrlz.modelrack.ModelActivationRequestV1
import sh.swrlz.modelrack.ModelModuleActivationRequestV1
import sh.swrlz.modelrack.ModelProfileUpdateRequestV1
import sh.swrlz.modelrack.ModelRackRollbackKindV1
import sh.swrlz.modelrack.ModelRackRollbackRequestV1
import sh.swrlz.modelrack.ModelRackSnapshotV1
import sh.swrlz.modelrack.ModelRuntimeProfileV1
import sh.swurlz.core.net.CoreNodeApi

/** CLIENT owns presentation and requests; SERVER remains authoritative for validation/persistence. */
object ModelRackClientRuntime {
    private val mutableSnapshot = MutableStateFlow(
        ModelRackSnapshotV1(detail = "Connect and pair with a SWRLZ SERVER to inspect its model rack."),
    )
    val snapshot: StateFlow<ModelRackSnapshotV1> = mutableSnapshot.asStateFlow()

    suspend fun refresh(context: Context): ModelRackSnapshotV1 = withContext(Dispatchers.IO) {
        val value = CoreNodeApi.modelRackStatus(context)
        mutableSnapshot.value = value
        value
    }

    suspend fun saveProfile(context: Context, profile: ModelRuntimeProfileV1): ModelRackSnapshotV1 =
        withContext(Dispatchers.IO) {
            val current = mutableSnapshot.value
            val value = CoreNodeApi.updateModelRackProfile(
                context,
                ModelProfileUpdateRequestV1(
                    expectedGeneration = current.rackGeneration,
                    profile = profile.copy(generation = current.rackGeneration).normalized(),
                ),
            )
            mutableSnapshot.value = value
            value
        }

    suspend fun activateModel(context: Context, sha256: String): ModelRackSnapshotV1 = withContext(Dispatchers.IO) {
        val value = CoreNodeApi.activateModelRackModel(
            context,
            ModelActivationRequestV1(sha256 = sha256, deepCompatibilityTest = true),
        )
        mutableSnapshot.value = value
        value
    }

    suspend fun setModule(context: Context, moduleId: String, enabled: Boolean): ModelRackSnapshotV1 =
        withContext(Dispatchers.IO) {
            val current = mutableSnapshot.value
            val value = CoreNodeApi.activateModelRackModule(
                context,
                ModelModuleActivationRequestV1(
                    expectedGeneration = current.rackGeneration,
                    moduleId = moduleId,
                    enabled = enabled,
                ),
            )
            mutableSnapshot.value = value
            value
        }

    suspend fun rollback(context: Context, kind: ModelRackRollbackKindV1): ModelRackSnapshotV1 =
        withContext(Dispatchers.IO) {
            val current = mutableSnapshot.value
            val value = CoreNodeApi.rollbackModelRack(
                context,
                ModelRackRollbackRequestV1(
                    expectedGeneration = current.rackGeneration,
                    kind = kind,
                ),
            )
            mutableSnapshot.value = value
            value
        }
}
