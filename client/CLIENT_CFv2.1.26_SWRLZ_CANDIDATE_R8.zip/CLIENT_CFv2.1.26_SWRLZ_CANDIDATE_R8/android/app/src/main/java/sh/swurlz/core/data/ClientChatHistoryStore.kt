package sh.swurlz.core.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class ClientChatStoredMessage(
    val fromUser: Boolean,
    val text: String,
    val createdAtEpochMs: Long,
)

data class ClientChatThreadSummary(
    val threadId: String,
    val title: String,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long,
    val messageCount: Int,
)

data class ClientChatHistoryDocument(
    val currentThreadId: String,
    val threads: List<ClientChatThreadSummary>,
)

/**
 * CLIENT-side chat continuity store. SERVER keeps its richer Room/evidence model; this
 * store gives the CLIENT its own local thread continuity without making SERVER state
 * authoritative for CLIENT-only UI history.
 */
object ClientChatHistoryStore {
    private const val SCHEMA = "swrlz-client-chat-history-v1"
    private const val DEFAULT_GREETING = "I’m ready. Tell me the outcome you want; I’ll keep local work local and pause before sensitive steps."

    private fun file(context: Context): File = File(context.applicationContext.filesDir, "chat/client-chat-history.json").also {
        it.parentFile?.mkdirs()
    }

    @Synchronized
    fun ensure(context: Context): ClientChatHistoryDocument {
        val root = readRoot(context)
        val threads = root.optJSONArray("threads") ?: JSONArray()
        if (threads.length() == 0) {
            val threadId = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            val thread = JSONObject()
                .put("threadId", threadId)
                .put("title", "New chat")
                .put("createdAtEpochMs", now)
                .put("updatedAtEpochMs", now)
                .put("messages", JSONArray().put(messageJson(false, DEFAULT_GREETING, now)))
            threads.put(thread)
            root.put("threads", threads).put("currentThreadId", threadId)
            writeRoot(context, root)
        } else if (root.optString("currentThreadId").isBlank()) {
            root.put("currentThreadId", threads.optJSONObject(0)?.optString("threadId").orEmpty())
            writeRoot(context, root)
        }
        return document(root)
    }

    @Synchronized
    fun listThreads(context: Context): List<ClientChatThreadSummary> = document(readEnsuredRoot(context)).threads

    @Synchronized
    fun currentThreadId(context: Context): String = readEnsuredRoot(context).optString("currentThreadId")

    @Synchronized
    fun messages(context: Context, threadId: String): List<ClientChatStoredMessage> {
        val thread = findThread(readEnsuredRoot(context), threadId) ?: return emptyList()
        val messages = thread.optJSONArray("messages") ?: JSONArray()
        return (0 until messages.length()).mapNotNull { index ->
            val item = messages.optJSONObject(index) ?: return@mapNotNull null
            ClientChatStoredMessage(
                fromUser = item.optBoolean("fromUser", false),
                text = item.optString("text", ""),
                createdAtEpochMs = item.optLong("createdAtEpochMs", 0L),
            )
        }
    }

    @Synchronized
    fun newThread(context: Context): String {
        val root = readEnsuredRoot(context)
        val now = System.currentTimeMillis()
        val threadId = UUID.randomUUID().toString()
        val thread = JSONObject()
            .put("threadId", threadId)
            .put("title", "New chat")
            .put("createdAtEpochMs", now)
            .put("updatedAtEpochMs", now)
            .put("messages", JSONArray().put(messageJson(false, DEFAULT_GREETING, now)))
        root.optJSONArray("threads")!!.put(thread)
        root.put("currentThreadId", threadId)
        writeRoot(context, root)
        return threadId
    }

    @Synchronized
    fun selectThread(context: Context, threadId: String): Boolean {
        val root = readEnsuredRoot(context)
        if (findThread(root, threadId) == null) return false
        root.put("currentThreadId", threadId)
        writeRoot(context, root)
        return true
    }

    @Synchronized
    fun saveMessages(context: Context, threadId: String, messages: List<ClientChatStoredMessage>) {
        val root = readEnsuredRoot(context)
        val thread = findThread(root, threadId) ?: return
        val array = JSONArray()
        messages.forEach { message -> array.put(messageJson(message.fromUser, message.text, message.createdAtEpochMs)) }
        val now = System.currentTimeMillis()
        thread.put("messages", array).put("updatedAtEpochMs", now)
        val currentTitle = thread.optString("title", "New chat")
        if (currentTitle == "New chat") {
            val firstUser = messages.firstOrNull { it.fromUser && it.text.isNotBlank() }?.text.orEmpty()
            if (firstUser.isNotBlank()) thread.put("title", deriveTitle(firstUser))
        }
        root.put("currentThreadId", threadId)
        writeRoot(context, root)
    }

    @Synchronized
    fun renameThread(context: Context, threadId: String, title: String) {
        val root = readEnsuredRoot(context)
        val thread = findThread(root, threadId) ?: return
        thread.put("title", title.trim().take(80).ifBlank { "New chat" }).put("updatedAtEpochMs", System.currentTimeMillis())
        writeRoot(context, root)
    }

    @Synchronized
    fun deleteThread(context: Context, threadId: String): String {
        val root = readEnsuredRoot(context)
        val source = root.optJSONArray("threads") ?: JSONArray()
        val kept = JSONArray()
        for (index in 0 until source.length()) {
            val thread = source.optJSONObject(index) ?: continue
            if (thread.optString("threadId") != threadId) kept.put(thread)
        }
        root.put("threads", kept)
        if (kept.length() == 0) {
            val now = System.currentTimeMillis()
            val replacementId = UUID.randomUUID().toString()
            kept.put(
                JSONObject()
                    .put("threadId", replacementId)
                    .put("title", "New chat")
                    .put("createdAtEpochMs", now)
                    .put("updatedAtEpochMs", now)
                    .put("messages", JSONArray().put(messageJson(false, DEFAULT_GREETING, now))),
            )
            root.put("threads", kept).put("currentThreadId", replacementId)
            writeRoot(context, root)
            return replacementId
        }
        val current = root.optString("currentThreadId")
        val next = if (current == threadId || findThread(root.put("threads", kept), current) == null) {
            kept.optJSONObject(0)?.optString("threadId").orEmpty()
        } else current
        root.put("currentThreadId", next)
        writeRoot(context, root)
        return next
    }

    private fun readEnsuredRoot(context: Context): JSONObject {
        ensure(context)
        return readRoot(context)
    }

    private fun readRoot(context: Context): JSONObject = runCatching {
        val source = file(context)
        if (!source.exists()) return@runCatching JSONObject().put("schema", SCHEMA).put("threads", JSONArray())
        JSONObject(source.readText())
    }.getOrElse { JSONObject().put("schema", SCHEMA).put("threads", JSONArray()) }

    private fun writeRoot(context: Context, root: JSONObject) {
        root.put("schema", SCHEMA)
        val target = file(context)
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeText(root.toString())
        check(tmp.renameTo(target) || runCatching { target.writeText(tmp.readText()); tmp.delete(); true }.getOrDefault(false)) {
            "Unable to persist CLIENT chat history."
        }
    }

    private fun document(root: JSONObject): ClientChatHistoryDocument {
        val threads = root.optJSONArray("threads") ?: JSONArray()
        val summaries = (0 until threads.length()).mapNotNull { index ->
            val thread = threads.optJSONObject(index) ?: return@mapNotNull null
            ClientChatThreadSummary(
                threadId = thread.optString("threadId"),
                title = thread.optString("title", "New chat"),
                createdAtEpochMs = thread.optLong("createdAtEpochMs", 0L),
                updatedAtEpochMs = thread.optLong("updatedAtEpochMs", 0L),
                messageCount = thread.optJSONArray("messages")?.length() ?: 0,
            )
        }.sortedByDescending { it.updatedAtEpochMs }
        return ClientChatHistoryDocument(root.optString("currentThreadId"), summaries)
    }

    private fun findThread(root: JSONObject, threadId: String): JSONObject? {
        val threads = root.optJSONArray("threads") ?: return null
        for (index in 0 until threads.length()) {
            val thread = threads.optJSONObject(index) ?: continue
            if (thread.optString("threadId") == threadId) return thread
        }
        return null
    }

    private fun messageJson(fromUser: Boolean, text: String, createdAt: Long) = JSONObject()
        .put("fromUser", fromUser)
        .put("text", text)
        .put("createdAtEpochMs", createdAt)

    private fun deriveTitle(text: String): String = text.trim().replace(Regex("\\s+"), " ").take(52).ifBlank { "New chat" }
}
