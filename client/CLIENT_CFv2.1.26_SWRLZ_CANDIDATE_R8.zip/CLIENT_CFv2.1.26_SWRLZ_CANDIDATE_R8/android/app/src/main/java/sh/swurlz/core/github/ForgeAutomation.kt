package sh.swurlz.core.github

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.time.Instant
import java.util.zip.ZipInputStream

enum class ForgeBuildTarget { ASK, CLIENT, SERVER, BOTH, FILES }

enum class ForgeFolderSlot(
    val preferenceKey: String,
    val label: String,
    val defaultRelativePath: String,
) {
    ROOT("folder_root_uri", "Project root", "Download/swrlz core"),
    DOWNLOADS_INBOX("folder_downloads_inbox_uri", "Downloads inbox", "Download"),
    CLIENT_SOURCE("folder_client_source_uri", "CLIENT source", "Download/swrlz core/sources/client"),
    SERVER_SOURCE("folder_server_source_uri", "SERVER source", "Download/swrlz core/sources/server"),
    APK_ARTIFACT("folder_apk_artifact_uri", "APK artifact", "Download/swrlz core/apk"),
    FAILED_BUILD_LOG("folder_failed_build_log_uri", "Failed build logs", "Download/swrlz core/artifact apk logs"),
    LLM_MODELS("folder_llm_models_uri", "LLM models", "Download/swrlz core/llm models"),
    SWRLZMODS("folder_swrlzmods_uri", "SWRLZMODs", "Download/swrlz core/swrlzmods"),
    EVIDENCE("folder_evidence_uri", "Evidence", "Download/swrlz core/evidence"),
    FILELAB_WORKING("folder_filelab_working_uri", "File Lab working", "Download/swrlz core/file lab/working"),
    FILELAB_OUTPUT("folder_filelab_output_uri", "File Lab output", "Download/swrlz core/file lab/output"),
    FILELAB_SHARDS("folder_filelab_shards_uri", "File Lab shards", "Download/swrlz core/file lab/shards"),
}

/** Shared Forge automation preferences. Secrets remain outside this store. */
object ForgeAutomationPreferences {
    private const val PREFS = "swrlz_forge_automation_v1"
    private const val KEY_AUTO_SELECT = "auto_select_latest_verified_source"
    private const val KEY_AUTO_APK = "auto_download_success_artifact"
    private const val KEY_AUTO_LOGS = "auto_download_failure_logs"
    private const val KEY_REMEMBER_TARGET = "remember_last_build_target"
    private const val KEY_LAST_TARGET = "last_build_target"
    private const val KEY_PROJECT_DIRECTORY_NAME = "project_directory_name"
    private const val KEY_KEEP_ARTIFACT_ZIP = "keep_downloaded_artifact_zip"
    const val DEFAULT_PROJECT_DIRECTORY_NAME = "swrlz core"

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun autoSelectLatest(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTO_SELECT, true)
    fun setAutoSelectLatest(context: Context, value: Boolean) { prefs(context).edit().putBoolean(KEY_AUTO_SELECT, value).apply() }

    fun autoDownloadArtifact(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTO_APK, true)
    fun setAutoDownloadArtifact(context: Context, value: Boolean) { prefs(context).edit().putBoolean(KEY_AUTO_APK, value).apply() }

    fun autoDownloadFailureLogs(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTO_LOGS, true)
    fun setAutoDownloadFailureLogs(context: Context, value: Boolean) { prefs(context).edit().putBoolean(KEY_AUTO_LOGS, value).apply() }

    fun keepArtifactZip(context: Context): Boolean = prefs(context).getBoolean(KEY_KEEP_ARTIFACT_ZIP, false)
    fun setKeepArtifactZip(context: Context, value: Boolean) { prefs(context).edit().putBoolean(KEY_KEEP_ARTIFACT_ZIP, value).apply() }

    fun rememberLastTarget(context: Context): Boolean = prefs(context).getBoolean(KEY_REMEMBER_TARGET, true)
    fun setRememberLastTarget(context: Context, value: Boolean) { prefs(context).edit().putBoolean(KEY_REMEMBER_TARGET, value).apply() }

    fun lastTarget(context: Context): ForgeBuildTarget = runCatching {
        ForgeBuildTarget.valueOf(prefs(context).getString(KEY_LAST_TARGET, ForgeBuildTarget.ASK.name).orEmpty())
    }.getOrDefault(ForgeBuildTarget.ASK)

    fun setLastTarget(context: Context, target: ForgeBuildTarget) {
        if (rememberLastTarget(context)) prefs(context).edit().putString(KEY_LAST_TARGET, target.name).apply()
    }

    fun projectDirectoryName(context: Context): String {
        val explicitRootName = treeUri(context, ForgeFolderSlot.ROOT)?.let { uri ->
            runCatching { DocumentFile.fromTreeUri(context, uri)?.name }.getOrNull()
        }
        return sanitizeProjectDirectoryName(
            explicitRootName ?: prefs(context).getString(KEY_PROJECT_DIRECTORY_NAME, DEFAULT_PROJECT_DIRECTORY_NAME).orEmpty(),
        )
    }

    fun sanitizeProjectDirectoryName(rawName: String): String = rawName
        .replace(Regex("[\\/:*?\"<>|]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(64)
        .ifBlank { DEFAULT_PROJECT_DIRECTORY_NAME }

    fun treeUri(context: Context, slot: ForgeFolderSlot): Uri? = prefs(context)
        .getString(slot.preferenceKey, null)
        ?.takeIf { it.isNotBlank() }
        ?.let(Uri::parse)

    fun saveTreeUri(context: Context, slot: ForgeFolderSlot, uri: Uri?) {
        val app = context.applicationContext
        if (uri != null) {
            runCatching {
                app.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
            val edit = prefs(app).edit().putString(slot.preferenceKey, uri.toString())
            if (slot == ForgeFolderSlot.ROOT) {
                val selectedName = DocumentFile.fromTreeUri(app, uri)?.name.orEmpty()
                if (selectedName.isNotBlank()) edit.putString(KEY_PROJECT_DIRECTORY_NAME, sanitizeProjectDirectoryName(selectedName))
            }
            edit.apply()
        } else {
            prefs(app).edit().remove(slot.preferenceKey).apply()
        }
    }

    fun customDownloadsInboxDirectory(context: Context): DocumentFile? = treeUri(context, ForgeFolderSlot.DOWNLOADS_INBOX)
        ?.let { DocumentFile.fromTreeUri(context, it) }
        ?.takeIf { it.isDirectory && it.canRead() }

    fun downloadsInboxDirectory(context: Context): DocumentFile? =
        customDownloadsInboxDirectory(context) ?: ForgePublicDownloadsAccess.directory(context.applicationContext)

    fun hasPublicDownloadsAccess(context: Context): Boolean = ForgePublicDownloadsAccess.hasDirectAccess(context.applicationContext)
    fun usesCustomDownloadsInbox(context: Context): Boolean = customDownloadsInboxDirectory(context) != null
    fun publicDownloadsAccessIntent(context: Context): Intent = ForgePublicDownloadsAccess.settingsIntent(context.applicationContext)

    fun effectiveSourceTree(context: Context, component: String): Uri? = when (component.uppercase()) {
        "CLIENT" -> treeUri(context, ForgeFolderSlot.CLIENT_SOURCE) ?: treeUri(context, ForgeFolderSlot.ROOT)
        "SERVER" -> treeUri(context, ForgeFolderSlot.SERVER_SOURCE) ?: treeUri(context, ForgeFolderSlot.ROOT)
        else -> treeUri(context, ForgeFolderSlot.ROOT)
    }

    fun displayPath(context: Context, slot: ForgeFolderSlot): String {
        val explicit = treeUri(context, slot)
        if (explicit != null) return explicit.toString()
        if (slot == ForgeFolderSlot.DOWNLOADS_INBOX) return "Public Download · ${ForgePublicDownloadsAccess.publicDirectory().absolutePath}"
        return slot.defaultRelativePath
    }
}

enum class ForgeCandidateFormat { METADATA_BUNDLE, LEGACY_TRIPLE }

data class ForgeVerifiedSourceCandidate(
    val component: String,
    val version: String,
    val versionCode: Int,
    val revision: String,
    val sourceZip: DocumentFile,
    val metadataBundle: DocumentFile? = null,
    val checksum: DocumentFile? = null,
    val manifest: DocumentFile? = null,
    val sha256: String,
    val sourceSizeBytes: Long,
) {
    val displayName: String get() = sourceZip.name.orEmpty()
    val format: ForgeCandidateFormat
        get() = if (metadataBundle != null) ForgeCandidateFormat.METADATA_BUNDLE else ForgeCandidateFormat.LEGACY_TRIPLE
    val stagedFileCount: Int get() = if (format == ForgeCandidateFormat.METADATA_BUNDLE) 2 else 3
    val companionNames: String get() = when (format) {
        ForgeCandidateFormat.METADATA_BUNDLE -> metadataBundle?.name.orEmpty()
        ForgeCandidateFormat.LEGACY_TRIPLE -> listOfNotNull(checksum?.name, manifest?.name).joinToString(" + ")
    }
    fun operatorDescription(repositoryLane: String = ""): String = buildString {
        append(component).append(" source ").append(displayName)
        append(" · CFv").append(version).append(' ').append(revision).append(" · VC").append(versionCode)
        append(" · ").append(format.name)
        append(" · SHA-256 ").append(sha256)
        append(" · ").append(sourceSizeBytes).append(" bytes")
        if (companionNames.isNotBlank()) append(" · evidence ").append(companionNames)
        if (repositoryLane.isNotBlank()) append(" · repository ").append(repositoryLane)
        append(" · build ").append(component).append(" APK")
    }
}

data class ForgeProjectDiscovery(
    val requestedTarget: ForgeBuildTarget,
    val effectiveTarget: ForgeBuildTarget,
    val candidates: List<ForgeVerifiedSourceCandidate>,
    val evidenceBundle: DocumentFile? = null,
    val conflicts: List<String> = emptyList(),
    val detail: String = "",
) {
    val ready: Boolean
        get() = conflicts.isEmpty() && effectiveTarget in setOf(ForgeBuildTarget.CLIENT, ForgeBuildTarget.SERVER, ForgeBuildTarget.BOTH) &&
            candidates.size == if (effectiveTarget == ForgeBuildTarget.BOTH) 2 else 1
}

/**
 * Downloads-inbox resolver. Source ZIPs are selected only from the configured public Downloads
 * root. Preferred metadata ZIPs are paired in-place; legacy loose sidecars are accepted either in
 * the root or one extractor-created child directory. Manifest identity and SHA-256 remain authoritative.
 */
object ForgeSourceResolver {
    private data class ScanResult(
        val candidates: List<ForgeVerifiedSourceCandidate>,
        val rejections: List<String>,
    )

    private data class DownloadsSnapshot(
        val root: DocumentFile,
        val rootFiles: List<DocumentFile>,
        val childFileIndexes: List<Map<String, DocumentFile>>,
        val evidenceFiles: List<DocumentFile>,
    )

    private fun snapshotDownloads(root: DocumentFile): DownloadsSnapshot {
        val children = runCatching { root.listFiles().toList() }.getOrDefault(emptyList())
        val rootFiles = children.filter { it.isFile }
        val childFileIndexes = children.asSequence()
            .filter { it.isDirectory }
            .map { directory ->
                runCatching { directory.listFiles().filter { it.isFile } }.getOrDefault(emptyList())
                    .associateBy { GitHubForgeClient.logicalSourceKey(it.name.orEmpty()) }
            }
            .toList()
        val evidenceFiles = buildList {
            addAll(rootFiles.filter { ForgeEvidenceBundle.isEvidenceBundleName(it.name.orEmpty()) })
            childFileIndexes.forEach { index ->
                addAll(index.values.filter { ForgeEvidenceBundle.isEvidenceBundleName(it.name.orEmpty()) })
            }
        }
        return DownloadsSnapshot(root, rootFiles, childFileIndexes, evidenceFiles.distinctBy { it.uri.toString() })
    }

    fun latest(context: Context, component: String): ForgeVerifiedSourceCandidate? =
        discoverDownloads(context, ForgeBuildTarget.valueOf(component.uppercase())).candidates.firstOrNull()

    fun discoverProject(context: Context, requestedTarget: ForgeBuildTarget = ForgeBuildTarget.ASK): ForgeProjectDiscovery =
        discoverDownloads(context, requestedTarget)

    fun discoverDownloads(context: Context, requestedTarget: ForgeBuildTarget = ForgeBuildTarget.ASK): ForgeProjectDiscovery {
        val root = ForgeAutomationPreferences.downloadsInboxDirectory(context)
            ?: return ForgeProjectDiscovery(
                requestedTarget,
                ForgeBuildTarget.ASK,
                emptyList(),
                conflicts = listOf("Public Downloads access is not authorized and no custom inbox override is configured. Grant access or choose a custom inbox in Forge settings."),
            )

        val snapshot = snapshotDownloads(root)
        val clientScan = scanDownloads(context, snapshot, "CLIENT")
        val serverScan = scanDownloads(context, snapshot, "SERVER")
        val clientSelection = selectLatest(clientScan.candidates)
        val serverSelection = selectLatest(serverScan.candidates)
        val detected = when {
            clientSelection.first != null && serverSelection.first != null -> ForgeBuildTarget.BOTH
            clientSelection.first != null -> ForgeBuildTarget.CLIENT
            serverSelection.first != null -> ForgeBuildTarget.SERVER
            else -> ForgeBuildTarget.ASK
        }
        val effective = when (requestedTarget) {
            ForgeBuildTarget.ASK -> detected
            ForgeBuildTarget.CLIENT, ForgeBuildTarget.SERVER, ForgeBuildTarget.BOTH -> requestedTarget
            ForgeBuildTarget.FILES -> ForgeBuildTarget.FILES
        }
        val candidates = when (effective) {
            ForgeBuildTarget.CLIENT -> listOfNotNull(clientSelection.first)
            ForgeBuildTarget.SERVER -> listOfNotNull(serverSelection.first)
            ForgeBuildTarget.BOTH -> listOfNotNull(clientSelection.first, serverSelection.first)
            else -> emptyList()
        }
        val finalConflicts = mutableListOf<String>()
        when (effective) {
            ForgeBuildTarget.CLIENT -> {
                clientSelection.second?.let(finalConflicts::add)
                if (clientSelection.first == null) finalConflicts += clientScan.rejections.take(3)
            }
            ForgeBuildTarget.SERVER -> {
                serverSelection.second?.let(finalConflicts::add)
                if (serverSelection.first == null) finalConflicts += serverScan.rejections.take(3)
            }
            ForgeBuildTarget.BOTH -> {
                clientSelection.second?.let(finalConflicts::add)
                serverSelection.second?.let(finalConflicts::add)
                if (clientSelection.first == null) finalConflicts += clientScan.rejections.take(3)
                if (serverSelection.first == null) finalConflicts += serverScan.rejections.take(3)
            }
            ForgeBuildTarget.ASK -> {
                clientSelection.second?.let(finalConflicts::add)
                serverSelection.second?.let(finalConflicts::add)
                if (clientSelection.first == null && serverSelection.first == null) {
                    finalConflicts += (clientScan.rejections + serverScan.rejections).take(4)
                    if (finalConflicts.isEmpty()) finalConflicts += "No verified CLIENT or SERVER source package set was found in the Downloads inbox."
                }
            }
            else -> Unit
        }
        val expected = when (effective) {
            ForgeBuildTarget.BOTH -> 2
            ForgeBuildTarget.CLIENT, ForgeBuildTarget.SERVER -> 1
            else -> 0
        }
        if (expected > 0 && candidates.size != expected && finalConflicts.isEmpty()) {
            finalConflicts += "Requested ${effective.name} package set is incomplete in the Downloads inbox."
        }
        val evidence = if (candidates.isNotEmpty()) matchingEvidence(context, snapshot, candidates) else null
        val detail = buildString {
            append("Downloads inbox detected ").append(detected.name)
            if (candidates.isNotEmpty()) {
                append(": ")
                append(candidates.joinToString(" + ") { "${it.component} ${it.displayName} · VC${it.versionCode} ${it.revision} · ${it.format.name}" })
            }
            if (evidence != null) append(" + evidence ").append(evidence.name.orEmpty())
        }
        return ForgeProjectDiscovery(requestedTarget, effective, candidates, evidence, finalConflicts.filter { it.isNotBlank() }.distinct(), detail)
    }

    fun latestForTarget(context: Context, target: ForgeBuildTarget): List<ForgeVerifiedSourceCandidate> =
        discoverDownloads(context, target).candidates

    fun asLocalFiles(
        candidates: List<ForgeVerifiedSourceCandidate>,
        evidenceBundle: DocumentFile? = null,
    ): List<GitHubForgeClient.LocalFile> = buildList {
        candidates.forEach { candidate ->
            listOfNotNull(candidate.sourceZip, candidate.metadataBundle, candidate.checksum, candidate.manifest).forEach { doc ->
                val name = doc.name.orEmpty()
                if (name.isNotBlank()) add(GitHubForgeClient.LocalFile(doc.uri, name, doc.length()))
            }
        }
        evidenceBundle?.let { doc ->
            val name = doc.name.orEmpty()
            if (name.isNotBlank()) add(GitHubForgeClient.LocalFile(doc.uri, name, doc.length()))
        }
    }

    private fun selectLatest(candidates: List<ForgeVerifiedSourceCandidate>): Pair<ForgeVerifiedSourceCandidate?, String?> {
        if (candidates.isEmpty()) return null to null
        val highestVersionCode = candidates.maxOf { it.versionCode }
        val versionPeers = candidates.filter { it.versionCode == highestVersionCode }
        val highestRevision = versionPeers.maxOf { revisionOrdinal(it.revision) }
        val peers = versionPeers.filter { revisionOrdinal(it.revision) == highestRevision }
        val distinctHashes = peers.map { it.sha256.lowercase() }.distinct()
        if (distinctHashes.size > 1) {
            val component = peers.first().component
            return null to "$component has ${peers.size} conflicting Downloads candidates at VC$highestVersionCode ${peers.first().revision} with different SHA-256 values."
        }
        return peers.sortedWith(compareBy<ForgeVerifiedSourceCandidate> { it.format.ordinal }.thenBy { it.displayName.lowercase() }).first() to null
    }

    private fun scanDownloads(context: Context, snapshot: DownloadsSnapshot, component: String): ScanResult {
        val rootFiles = snapshot.rootFiles
        val byCanonical = rootFiles.associateBy { GitHubForgeClient.logicalSourceKey(it.name.orEmpty()) }
        val results = mutableListOf<ForgeVerifiedSourceCandidate>()
        val rejections = mutableListOf<String>()
        rootFiles.filter { doc ->
            val name = doc.name.orEmpty()
            GitHubForgeClient.isProtectedSourceZip(name) &&
                GitHubForgeClient.canonicalSourceFileName(name).startsWith("${component}_", ignoreCase = true)
        }.forEach { source ->
            val sourceName = source.name.orEmpty()
            val metadataName = GitHubForgeClient.metadataBundleNameForZip(sourceName)
            val checksumName = GitHubForgeClient.checksumNameForZip(sourceName)
            val manifestName = GitHubForgeClient.manifestNameForZip(sourceName)
            val metadata = byCanonical[metadataName.lowercase()]
            val rootChecksum = byCanonical[checksumName.lowercase()]
            val rootManifest = byCanonical[manifestName.lowercase()]
            val candidate = when {
                metadata != null -> validateCandidate(context, component, source, metadata, null, null)
                rootChecksum != null || rootManifest != null -> {
                    if (rootChecksum == null || rootManifest == null) null
                    else validateCandidate(context, component, source, null, rootChecksum, rootManifest)
                }
                else -> {
                    val fallbackPairs = snapshot.childFileIndexes.mapNotNull { index ->
                        val checksum = index[checksumName.lowercase()]
                        val manifest = index[manifestName.lowercase()]
                        if (checksum != null && manifest != null) checksum to manifest else null
                    }
                    when {
                        fallbackPairs.size == 1 -> validateCandidate(context, component, source, null, fallbackPairs[0].first, fallbackPairs[0].second)
                        fallbackPairs.size > 1 -> {
                            rejections += "$component source $sourceName has ambiguous legacy companions in multiple one-level extractor folders."
                            null
                        }
                        else -> null
                    }
                }
            }
            if (candidate != null) {
                results += candidate
            } else if (rejections.none { it.contains(sourceName) }) {
                val requirement = if (metadata != null) {
                    "matching metadata ZIP failed identity/hash validation"
                } else {
                    "requires $metadataName in Download root, or exact $checksumName + $manifestName in Download root/one extractor child folder"
                }
                rejections += "$component source $sourceName $requirement."
            }
        }
        return ScanResult(results.distinctBy { "${it.component}:${it.versionCode}:${it.revision}:${it.sha256}" }, rejections.distinct())
    }

    private fun matchingEvidence(
        context: Context,
        snapshot: DownloadsSnapshot,
        candidates: List<ForgeVerifiedSourceCandidate>,
    ): DocumentFile? {
        val requiredNames = candidates.flatMap { candidate ->
            listOfNotNull(candidate.sourceZip.name, candidate.metadataBundle?.name, candidate.checksum?.name, candidate.manifest?.name)
        }.map { GitHubForgeClient.canonicalSourceFileName(it).lowercase() }.toSet()
        if (requiredNames.isEmpty()) return null
        val matches = snapshot.evidenceFiles
            .filter { readEvidencePackageNames(context, it).containsAll(requiredNames) }
        return matches.maxWithOrNull(compareBy<DocumentFile> { it.lastModified() }.thenBy { it.name.orEmpty().lowercase() })
    }

    private fun readEvidencePackageNames(context: Context, evidence: DocumentFile): Set<String> = runCatching {
        context.contentResolver.openInputStream(evidence.uri)?.use { raw ->
            ZipInputStream(raw.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (!entry.isDirectory && entry.name.matches(Regex("""delivery/INT_[A-Za-z0-9_-]+_DELIVERY\.manifest\.json"""))) {
                        val bytes = zip.readBytes().also { require(it.size <= 2 * 1024 * 1024) }
                        val json = JSONObject(bytes.toString(Charsets.UTF_8))
                        val packages = json.optJSONArray("packages") ?: return@use emptySet<String>()
                        return@use buildSet {
                            for (index in 0 until packages.length()) {
                                val name = packages.optJSONObject(index)?.optString("filename").orEmpty()
                                if (name.isNotBlank()) add(GitHubForgeClient.canonicalSourceFileName(name).lowercase())
                            }
                        }
                    }
                }
                emptySet<String>()
            }
        } ?: emptySet()
    }.getOrDefault(emptySet())

    private fun validateCandidate(
        context: Context,
        component: String,
        zip: DocumentFile,
        metadataBundle: DocumentFile?,
        checksum: DocumentFile?,
        manifest: DocumentFile?,
        allowHashCache: Boolean = true,
    ): ForgeVerifiedSourceCandidate? = runCatching {
        val actualSha = ForgeDocumentHashCache.sha256(context, zip, allowHashCache)
        val actualSize = zip.length()
        if (metadataBundle != null) {
            val metadata = ForgeMetadataBundle.inspect(context, metadataBundle.uri, metadataBundle.name.orEmpty())
            if (metadata.component != component) return null
            if (!GitHubForgeClient.canonicalSourceFileName(metadata.sourceZipName)
                    .equals(GitHubForgeClient.canonicalSourceFileName(zip.name.orEmpty()), ignoreCase = true)) return null
            if (metadata.sha256 != actualSha) return null
            if (metadata.sizeBytes >= 0L && actualSize >= 0L && metadata.sizeBytes != actualSize) return null
            return ForgeVerifiedSourceCandidate(
                component = component,
                version = Regex("""(?i)CFv(\d+\.\d+\.\d+)""").find(metadata.sourceZipName)?.groupValues?.getOrNull(1) ?: "UNKNOWN",
                versionCode = metadata.versionCode,
                revision = metadata.revision.ifBlank { "R0" },
                sourceZip = zip,
                metadataBundle = metadataBundle,
                sha256 = actualSha,
                sourceSizeBytes = actualSize,
            )
        }
        if (checksum == null || manifest == null) return null
        val manifestJson = context.contentResolver.openInputStream(manifest.uri)?.bufferedReader()?.use { it.readText() } ?: return null
        val json = JSONObject(manifestJson)
        if (json.optString("component", "").trim().uppercase() != component) return null
        val versionCode = json.optInt("versionCode", -1)
        if (versionCode <= 0) return null
        val sourceJson = json.optJSONObject("sourceZip") ?: return null
        val manifestZipName = sourceJson.optString("filename", "")
        if (GitHubForgeClient.logicalSourceKey(manifestZipName) != GitHubForgeClient.logicalSourceKey(zip.name.orEmpty())) return null
        val expectedManifestSha = sourceJson.optString("sha256", "").lowercase()
        if (expectedManifestSha.length != 64) return null
        val checksumText = context.contentResolver.openInputStream(checksum.uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
        val expectedChecksumSha = Regex("""(?i)\b[0-9a-f]{64}\b""").find(checksumText)?.value?.lowercase() ?: return null
        if (expectedChecksumSha != expectedManifestSha || actualSha != expectedManifestSha) return null
        val expectedSize = sourceJson.optLong("sizeBytes", -1L)
        if (expectedSize >= 0L && actualSize >= 0L && expectedSize != actualSize) return null
        ForgeVerifiedSourceCandidate(
            component = component,
            version = json.optString("version", "UNKNOWN"),
            versionCode = versionCode,
            revision = json.optString("revision", "R0"),
            sourceZip = zip,
            checksum = checksum,
            manifest = manifest,
            sha256 = actualSha,
            sourceSizeBytes = actualSize,
        )
    }.getOrNull()

    fun revalidateCandidate(context: Context, candidate: ForgeVerifiedSourceCandidate): ForgeVerifiedSourceCandidate? =
        validateCandidate(
            context = context.applicationContext,
            component = candidate.component,
            zip = candidate.sourceZip,
            metadataBundle = candidate.metadataBundle,
            checksum = candidate.checksum,
            manifest = candidate.manifest,
            allowHashCache = false,
        )

    private fun revisionOrdinal(revision: String): Int = Regex("""(?i)R(\d+)""").find(revision)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
}

enum class ForgeLedgerState {
    SOURCE_FOUND,
    VERIFIED,
    UPLOADED,
    BUILD_REQUESTED,
    RUNNING,
    BUILD_SUCCEEDED,
    ARTIFACT_DOWNLOADED,
    INSTALL_PENDING,
    INSTALLED,
    BUILD_FAILED,
    LOGS_DOWNLOADED,
}

object ForgeBuildLedger {
    private fun file(context: Context): File = File(context.applicationContext.filesDir, "forge/build-ledger.jsonl").also { it.parentFile?.mkdirs() }

    @Synchronized
    fun record(
        context: Context,
        state: ForgeLedgerState,
        transactionId: String = "",
        component: String = "",
        sourceName: String = "",
        sourceSha256: String = "",
        sourceVersion: String = "",
        sourceRevision: String = "",
        versionCode: Int? = null,
        runId: Long? = null,
        commitSha: String = "",
        artifactName: String = "",
        artifactSha256: String = "",
        artifactSizeBytes: Long? = null,
        localUri: String = "",
        detail: String = "",
    ) {
        val payload = JSONObject()
            .put("schema", "swrlz-forge-build-ledger-v1")
            .put("recordedAt", Instant.now().toString())
            .put("state", state.name)
            .put("transactionId", transactionId)
            .put("component", component)
            .put("sourceName", sourceName)
            .put("sourceSha256", sourceSha256)
            .put("sourceVersion", sourceVersion)
            .put("sourceRevision", sourceRevision)
            .put("commitSha", commitSha)
            .put("artifactName", artifactName)
            .put("artifactSha256", artifactSha256)
            .put("localUri", localUri)
            .put("detail", detail)
        if (versionCode != null) payload.put("versionCode", versionCode)
        if (runId != null) payload.put("runId", runId)
        if (artifactSizeBytes != null) payload.put("artifactSizeBytes", artifactSizeBytes)
        file(context).appendText(payload.toString() + "\n")
    }

    fun hasState(context: Context, transactionId: String, state: ForgeLedgerState, runId: Long? = null): Boolean =
        recent(context, 500).any { record ->
            record.optString("transactionId") == transactionId &&
                record.optString("state") == state.name &&
                (runId == null || record.optLong("runId", Long.MIN_VALUE) == runId)
        }

    fun recent(context: Context, limit: Int = 50): List<JSONObject> = runCatching {
        file(context).takeIf { it.exists() }?.readLines().orEmpty().takeLast(limit.coerceIn(1, 500)).mapNotNull { line ->
            runCatching { JSONObject(line) }.getOrNull()
        }.reversed()
    }.getOrDefault(emptyList())
}

object ForgeArtifactStore {
    data class SaveResult(val uri: Uri, val displayName: String, val sizeBytes: Long, val sha256: String)

    fun saveApk(context: Context, displayName: String, bytes: ByteArray): SaveResult =
        save(context, ForgeFolderSlot.APK_ARTIFACT, displayName, "application/vnd.android.package-archive", bytes)

    fun saveArtifactZip(context: Context, displayName: String, bytes: ByteArray): SaveResult =
        save(context, ForgeFolderSlot.APK_ARTIFACT, displayName, "application/zip", bytes)

    fun saveFailureLogs(context: Context, displayName: String, bytes: ByteArray): SaveResult =
        save(context, ForgeFolderSlot.FAILED_BUILD_LOG, displayName, "application/zip", bytes)

    private fun save(context: Context, slot: ForgeFolderSlot, displayName: String, mime: String, bytes: ByteArray): SaveResult {
        val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]+"), "_").ifBlank { "swrlz-output.bin" }
        val contentSha256 = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        val configured = ForgeAutomationPreferences.treeUri(context, slot)
            ?.let { DocumentFile.fromTreeUri(context, it) }
        val root = configured?.takeIf { it.isDirectory && it.canWrite() }
        if (root != null) {
            root.findFile(safeName)?.delete()
            val destination = root.createFile(mime, safeName) ?: error("Unable to create $safeName in ${slot.label} folder.")
            context.contentResolver.openOutputStream(destination.uri, "w")?.use { it.write(bytes) }
                ?: error("Unable to open destination stream for $safeName")
            return SaveResult(destination.uri, safeName, bytes.size.toLong(), contentSha256)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val projectName = ForgeAutomationPreferences.projectDirectoryName(context)
            val relative = when (slot) {
                ForgeFolderSlot.APK_ARTIFACT -> "${Environment.DIRECTORY_DOWNLOADS}/$projectName/apk/"
                ForgeFolderSlot.FAILED_BUILD_LOG -> "${Environment.DIRECTORY_DOWNLOADS}/$projectName/artifact apk logs/"
                else -> "${Environment.DIRECTORY_DOWNLOADS}/$projectName/"
            }
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, relative)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Unable to create Downloads item for $safeName")
            try {
                context.contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes) }
                    ?: error("Unable to write Downloads item for $safeName")
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
                return SaveResult(uri, safeName, bytes.size.toLong(), contentSha256)
            } catch (failure: Throwable) {
                runCatching { context.contentResolver.delete(uri, null, null) }
                throw failure
            }
        }
        error("Select an artifact/log folder in Forge settings on this Android version.")
    }
}

