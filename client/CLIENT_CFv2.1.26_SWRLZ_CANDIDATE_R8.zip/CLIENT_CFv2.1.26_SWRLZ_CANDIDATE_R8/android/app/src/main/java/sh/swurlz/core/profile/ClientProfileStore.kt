package sh.swurlz.core.profile

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import sh.swrlz.profile.BuiltInProfiles
import sh.swrlz.profile.ProfileAssignmentsV1
import sh.swrlz.profile.ProfileDocumentV1
import sh.swrlz.profile.ProfileLifecycle
import sh.swrlz.profile.ProfileOverridesV1
import sh.swrlz.profile.ProfileResolverV1
import sh.swrlz.profile.ProfileScope
import sh.swrlz.profile.ResolvedProfileV1
import sh.swrlz.profile.SwrlzProfileV1
import java.util.UUID

private val Context.swrlzProfileDataStore by preferencesDataStore(name = "swrlz_profile_registry")

object ClientProfileStore {
    private val DOCUMENT = stringPreferencesKey("profile_document_v1")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun documentFlow(context: Context): Flow<ProfileDocumentV1> = context.swrlzProfileDataStore.data.map { prefs ->
        decodeOrDefault(prefs[DOCUMENT])
    }

    suspend fun document(context: Context): ProfileDocumentV1 = documentFlow(context).first()

    suspend fun setDocument(context: Context, document: ProfileDocumentV1) {
        require(ProfileResolverV1.validate(document).isEmpty()) {
            "Invalid profile document: ${ProfileResolverV1.validate(document).joinToString()}"
        }
        context.swrlzProfileDataStore.edit { it[DOCUMENT] = json.encodeToString(document) }
    }

    suspend fun updateAssignments(context: Context, transform: (ProfileAssignmentsV1) -> ProfileAssignmentsV1) {
        val current = document(context)
        setDocument(context, current.copy(assignments = transform(current.assignments)))
    }

    suspend fun createCustomProfile(
        context: Context,
        displayName: String,
        scope: ProfileScope,
        parentId: String,
        customInstruction: String = "",
    ): SwrlzProfileV1 {
        val current = document(context)
        val parent = current.profiles.firstOrNull { it.id == parentId } ?: error("Unknown parent profile $parentId")
        val profile = SwrlzProfileV1(
            id = "custom.${scope.name.lowercase()}.${UUID.randomUUID().toString().replace("-", "").take(12)}",
            displayName = displayName.trim().ifBlank { "Custom ${scope.name.lowercase().replace('_', ' ')}" },
            scope = scope,
            parentId = parentId,
            providerId = if (scope == ProfileScope.PROVIDER) parent.providerId else null,
            overrides = ProfileOverridesV1(customInstruction = customInstruction.trim().takeIf { it.isNotEmpty() }),
            builtIn = false,
            lifecycle = ProfileLifecycle.TEST,
        )
        setDocument(context, current.copy(profiles = current.profiles + profile))
        return profile
    }

    suspend fun duplicateProfile(
        context: Context,
        sourceId: String,
        displayName: String? = null,
        lifecycle: ProfileLifecycle = ProfileLifecycle.TEST,
    ): SwrlzProfileV1 {
        val current = document(context)
        val source = current.profiles.firstOrNull { it.id == sourceId } ?: error("Unknown source profile $sourceId")
        val clone = source.copy(
            id = "custom.${source.scope.name.lowercase()}.${UUID.randomUUID().toString().replace("-", "").take(12)}",
            displayName = displayName?.trim()?.takeIf { it.isNotEmpty() } ?: "${source.displayName} Copy",
            parentId = source.id,
            overrides = ProfileOverridesV1(),
            builtIn = false,
            lifecycle = lifecycle,
            favorite = false,
        )
        setDocument(context, current.copy(profiles = current.profiles + clone))
        return clone
    }

    suspend fun renameCustomProfile(context: Context, id: String, displayName: String) {
        val current = document(context)
        val source = current.profiles.firstOrNull { it.id == id } ?: return
        require(!source.builtIn) { "Built-in profiles cannot be renamed" }
        val nextName = displayName.trim().take(80)
        require(nextName.isNotEmpty()) { "Profile name cannot be empty" }
        setDocument(context, current.copy(profiles = current.profiles.map { if (it.id == id) source.copy(displayName = nextName) else it }))
    }

    suspend fun setProfileLifecycle(context: Context, id: String, lifecycle: ProfileLifecycle) {
        val current = document(context)
        val source = current.profiles.firstOrNull { it.id == id } ?: return
        require(!source.builtIn) { "Built-in profiles are always stable" }
        setDocument(context, current.copy(profiles = current.profiles.map { if (it.id == id) source.copy(lifecycle = lifecycle) else it }))
    }

    suspend fun setFavorite(context: Context, id: String, favorite: Boolean) {
        val current = document(context)
        val source = current.profiles.firstOrNull { it.id == id } ?: return
        setDocument(context, current.copy(profiles = current.profiles.map { if (it.id == id) source.copy(favorite = favorite) else it }))
    }

    suspend fun upsertProfile(context: Context, profile: SwrlzProfileV1) {
        require(!profile.builtIn) { "Built-in profiles cannot be overwritten" }
        val current = document(context)
        val next = current.profiles.filterNot { it.id == profile.id } + profile
        setDocument(context, current.copy(profiles = next))
    }

    suspend fun deleteCustomProfile(context: Context, id: String) {
        val current = document(context)
        val profile = current.profiles.firstOrNull { it.id == id } ?: return
        require(!profile.builtIn) { "Built-in profiles cannot be deleted" }
        val a = current.assignments
        require(id !in listOf(
            a.clientEndpointProfileId, a.serverEndpointProfileId, a.clientToServerProfileId,
            a.serverToClientProfileId, a.serverToServerProfileId, a.openAiProviderProfileId,
            a.geminiProviderProfileId, a.localProviderProfileId, a.sessionProfileId,
        )) { "Profile is assigned and must be unassigned before deletion" }
        setDocument(context, current.copy(profiles = current.profiles.filterNot { it.id == id }))
    }

    fun resolveClientLocal(document: ProfileDocumentV1): ResolvedProfileV1 = ProfileResolverV1.resolve(
        document = document,
        endpointProfileId = document.assignments.clientEndpointProfileId,
    )

    fun resolveClientToServer(document: ProfileDocumentV1, providerId: String? = null): ResolvedProfileV1 = ProfileResolverV1.resolve(
        document = document,
        endpointProfileId = document.assignments.clientEndpointProfileId,
        relationshipProfileId = document.assignments.clientToServerProfileId,
        providerProfileId = providerId?.let { providerProfileId(document, it) },
    )

    fun resolveProvider(document: ProfileDocumentV1, providerId: String): ResolvedProfileV1 = ProfileResolverV1.resolve(
        document = document,
        endpointProfileId = document.assignments.clientEndpointProfileId,
        providerProfileId = providerProfileId(document, providerId),
    )

    private fun providerProfileId(document: ProfileDocumentV1, providerId: String): String? = when (providerId.lowercase()) {
        "openai", "gpt" -> document.assignments.openAiProviderProfileId
        "local", "client_local" -> document.assignments.localProviderProfileId
        else -> null
    }

    private fun decodeOrDefault(raw: String?): ProfileDocumentV1 {
        if (raw.isNullOrBlank()) return ProfileDocumentV1()
        return runCatching { json.decodeFromString<ProfileDocumentV1>(raw) }
            .getOrNull()
            ?.takeIf { ProfileResolverV1.validate(it).isEmpty() }
            ?: ProfileDocumentV1()
    }
}
