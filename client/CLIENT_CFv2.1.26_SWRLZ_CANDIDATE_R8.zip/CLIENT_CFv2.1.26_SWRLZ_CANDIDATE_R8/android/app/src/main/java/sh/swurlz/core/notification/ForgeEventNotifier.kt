package sh.swurlz.core.notification

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import sh.swurlz.core.MainActivity
import sh.swurlz.core.R
import sh.swurlz.core.bubble.ClientBubbleController
import sh.swurlz.core.github.ForgeRuntimeState
import sh.swurlz.core.identity.ThemeIdentityManager

/**
 * User-visible Forge events projected to both Android notifications and the CLIENT bubble.
 * Repository acceptance and artifact-build completion remain separate event classes.
 */
object ForgeEventNotifier {
    private const val CHANNEL_ID = "swrlz_forge_events_v1"
    private const val PREFS = "swrlz_forge_event_history_v1"
    private const val KEY_TITLE = "latest_title"
    private const val KEY_DETAIL = "latest_detail"
    private const val KEY_TONE = "latest_tone"
    private const val KEY_TIME = "latest_time"
    private const val NOTIFICATION_BASE = 4210

    fun uploadSucceeded(
        context: Context,
        commitSha: String,
        uploadedPaths: List<String>,
        transactionId: String,
    ) {
        val detail = buildString {
            append("Commit ")
            append(commitSha.take(12))
            append(" confirmed · ")
            append(uploadedPaths.size)
            append(" file")
            if (uploadedPaths.size != 1) append("s")
            append(" · TX ")
            append(transactionId.take(8))
        }
        publish(
            context = context,
            identity = "upload-success:$transactionId",
            title = "Forge upload succeeded",
            detail = detail,
            tone = ForgeRuntimeState.EventTone.SUCCESS,
            autoExpandBubble = false,
        )
    }

    fun uploadFailed(context: Context, transactionId: String, detail: String) {
        val safe = buildString {
            if (transactionId.isNotBlank()) {
                append("TX ")
                append(transactionId.take(8))
                append(" · ")
            }
            append(detail.take(220))
        }
        publish(
            context = context,
            identity = "upload-failure:$transactionId:${safe.hashCode()}",
            title = "Forge upload failed",
            detail = safe,
            tone = ForgeRuntimeState.EventTone.FAILURE,
            autoExpandBubble = true,
        )
    }

    fun workflowDispatchFailed(
        context: Context,
        transactionId: String,
        commitSha: String,
        detail: String,
    ) {
        publish(
            context = context,
            identity = "dispatch-failure:$transactionId",
            title = "Build dispatch failed",
            detail = "Commit ${commitSha.take(12)} is in the repository · TX ${transactionId.take(8)} · ${detail.take(180)}",
            tone = ForgeRuntimeState.EventTone.FAILURE,
            autoExpandBubble = true,
        )
    }

    fun workflowCompleted(
        context: Context,
        runId: Long,
        workflowName: String,
        conclusion: String?,
        artifactCount: Int,
        commitSha: String,
        transactionId: String,
    ) {
        val success = conclusion.equals("success", ignoreCase = true)
        val title = if (success) "Artifact build succeeded" else "Artifact build failed"
        val detail = if (success) {
            buildString {
                append(workflowName)
                append(" · commit ")
                append(commitSha.take(12))
                if (transactionId.isNotBlank()) {
                    append(" · TX ")
                    append(transactionId.take(8))
                }
                append(" · ")
                append(artifactCount)
                append(" artifact")
                if (artifactCount != 1) append("s")
                if (artifactCount == 0) append(" reported") else append(" ready")
            }
        } else {
            buildString {
                append(workflowName)
                append(" · ")
                append(conclusion ?: "failed")
                append(" · commit ")
                append(commitSha.take(12))
                if (transactionId.isNotBlank()) {
                    append(" · TX ")
                    append(transactionId.take(8))
                }
                append(" · logs available in Forge")
            }
        }
        publish(
            context = context,
            identity = "build:$runId:${conclusion.orEmpty()}",
            title = title,
            detail = detail,
            tone = if (success) ForgeRuntimeState.EventTone.SUCCESS else ForgeRuntimeState.EventTone.FAILURE,
            autoExpandBubble = !success,
        )
    }

    fun latestEvent(context: Context): ForgeRuntimeState.Event? {
        val preferences = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val title = preferences.getString(KEY_TITLE, null) ?: return null
        val detail = preferences.getString(KEY_DETAIL, "").orEmpty()
        val tone = runCatching {
            ForgeRuntimeState.EventTone.valueOf(
                preferences.getString(KEY_TONE, ForgeRuntimeState.EventTone.INFO.name).orEmpty(),
            )
        }.getOrDefault(ForgeRuntimeState.EventTone.INFO)
        return ForgeRuntimeState.Event(
            title = title,
            detail = detail,
            tone = tone,
            timestampMillis = preferences.getLong(KEY_TIME, 0L),
        )
    }

    private fun publish(
        context: Context,
        identity: String,
        title: String,
        detail: String,
        tone: ForgeRuntimeState.EventTone,
        autoExpandBubble: Boolean,
    ) {
        val appContext = context.applicationContext
        val event = ForgeRuntimeState.Event(title, detail, tone)
        ForgeRuntimeState.publishEvent(event)
        appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TITLE, title)
            .putString(KEY_DETAIL, detail)
            .putString(KEY_TONE, tone.name)
            .putLong(KEY_TIME, event.timestampMillis)
            .apply()

        postAndroidNotification(
            context = appContext,
            notificationId = eventNotificationId(identity),
            title = title,
            detail = detail,
            failure = tone == ForgeRuntimeState.EventTone.FAILURE,
        )
        ClientBubbleController.publish(
            context = appContext,
            title = title,
            detail = detail,
            autoExpand = autoExpandBubble,
        )
    }

    private fun postAndroidNotification(
        context: Context,
        notificationId: Int,
        title: String,
        detail: String,
        failure: Boolean,
    ) {
        if (!ClientStatusNotification.canPost(context)) return
        ensureChannel(context)

        val launchIntent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val themeFamily = ThemeIdentityManager.currentThemeFamily(context)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_crystal)
            .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.drawable.swrlz_client_identity))
            .setColor(ThemeIdentityManager.accentColor(themeFamily))
            .setContentTitle(title)
            .setContentText(detail)
            .setStyle(NotificationCompat.BigTextStyle().bigText(detail))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setCategory(if (failure) NotificationCompat.CATEGORY_ERROR else NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .build()

        runCatching { NotificationManagerCompat.from(context).notify(notificationId, notification) }
    }

    private fun eventNotificationId(identity: String): Int =
        NOTIFICATION_BASE + (identity.hashCode() and 0x7fffffff) % 700

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "SWRLZ Forge Events",
                NotificationManager.IMPORTANCE_HIGH,
            ).apply {
                description = "Forge upload and GitHub artifact-build success or failure events."
                lockscreenVisibility = Notification.VISIBILITY_PRIVATE
                setShowBadge(true)
            },
        )
    }
}
