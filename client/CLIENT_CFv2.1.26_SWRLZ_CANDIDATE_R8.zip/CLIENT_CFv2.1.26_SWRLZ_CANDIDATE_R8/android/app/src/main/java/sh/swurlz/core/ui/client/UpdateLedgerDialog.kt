package sh.swurlz.core.ui.client

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import sh.swurlz.core.update.UpdateLedgerCatalog
import sh.swurlz.core.update.UpdateLedgerEntry

@Composable
internal fun UpdateLedgerDialog(
    onDismiss: () -> Unit,
    onAskSwrlz: (String) -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    var selectedLabel by rememberSaveable { mutableStateOf(UpdateLedgerCatalog.latest.label) }
    val selected = remember(selectedLabel) {
        UpdateLedgerCatalog.entries.firstOrNull { it.label == selectedLabel } ?: UpdateLedgerCatalog.latest
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(.96f)
                .fillMaxHeight(.88f),
            shape = RoundedCornerShape(24.dp),
            color = tokens.surfaces.bgPanel.copy(alpha = .98f),
            border = BorderStroke(1.dp, tokens.accents.primary.copy(alpha = .46f)),
        ) {
            Column(Modifier.fillMaxSize().padding(12.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("SWRLZ UPDATE LEDGER", color = tokens.text.primary, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                        Text("Local patch history · evidence-aware", color = tokens.text.muted, fontSize = 10.sp)
                    }
                    IconButton(onClick = onDismiss) {
                        Text("×", color = tokens.text.primary, fontSize = 24.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))

                Row(Modifier.fillMaxSize()) {
                    LazyColumn(
                        modifier = Modifier
                            .width(118.dp)
                            .fillMaxHeight()
                            .border(1.dp, tokens.borders.neutral.copy(alpha = .55f), RoundedCornerShape(14.dp))
                            .padding(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        items(UpdateLedgerCatalog.entries) { entry ->
                            UpdateRailItem(
                                entry = entry,
                                selected = entry.label == selected.label,
                                onClick = { selectedLabel = entry.label },
                            )
                        }
                    }

                    Spacer(Modifier.width(10.dp))

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState()),
                    ) {
                        Text(selected.label, color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(selected.checkpoint, color = tokens.text.muted, fontSize = 10.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(selected.summary, color = tokens.text.primary, fontSize = 12.sp, lineHeight = 17.sp)
                        Spacer(Modifier.height(10.dp))

                        selected.sections.forEach { section ->
                            Text(section.title.uppercase(), color = tokens.accents.secondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(Modifier.height(4.dp))
                            section.bullets.forEach { bullet ->
                                Text("• $bullet", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
                                Spacer(Modifier.height(3.dp))
                            }
                            Spacer(Modifier.height(8.dp))
                        }

                        Box(
                            Modifier
                                .fillMaxWidth()
                                .background(tokens.surfaces.bgElevated.copy(alpha = .72f), RoundedCornerShape(12.dp))
                                .padding(10.dp),
                        ) {
                            Text("EVIDENCE · ${selected.evidence}", color = tokens.text.muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Spacer(Modifier.height(10.dp))

                        Button(
                            onClick = { onAskSwrlz("/updates (ask) ${selected.label} ") },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text("ASK SWRLZ ABOUT THIS UPDATE")
                        }
                        Spacer(Modifier.height(6.dp))
                        OutlinedButton(
                            onClick = { onAskSwrlz("/updates (latest) give me the highlights") },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text("LATEST UPDATE SUMMARY")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UpdateRailItem(
    entry: UpdateLedgerEntry,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .background(if (selected) tokens.accents.primary.copy(alpha = .13f) else tokens.surfaces.bgElevated.copy(alpha = .35f), shape)
            .border(1.dp, if (selected) tokens.accents.primary.copy(alpha = .55f) else tokens.borders.neutral.copy(alpha = .28f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 8.dp),
    ) {
        Text(entry.label, color = if (selected) tokens.accents.primary else tokens.text.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(entry.checkpoint, color = tokens.text.muted, fontSize = 8.sp, maxLines = 2)
    }
}
