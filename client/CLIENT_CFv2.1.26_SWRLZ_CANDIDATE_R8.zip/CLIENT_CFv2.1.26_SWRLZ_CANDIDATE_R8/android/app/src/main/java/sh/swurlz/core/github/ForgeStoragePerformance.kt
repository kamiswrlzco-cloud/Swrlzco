package sh.swurlz.core.github

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext

data class ForgeScanProgress(
    val phase: String,
    val detail: String,
)

/**
 * Public Downloads is the zero-configuration inbox. Android 11+ requires the user to explicitly
 * authorize all-files access before direct scanning; a persisted SAF custom inbox remains optional.
 */
object ForgePublicDownloadsAccess {
    fun hasDirectAccess(context: Context): Boolean = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> Environment.isExternalStorageManager()
        else -> publicDirectory().canRead()
    }

    fun publicDirectory(): File = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

    fun directory(context: Context): DocumentFile? = publicDirectory()
        .takeIf { hasDirectAccess(context) && it.exists() && it.isDirectory && it.canRead() }
        ?.let(DocumentFile::fromFile)

    fun settingsIntent(context: Context): Intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    } else {
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}

/** One scan at a time across automatic and manual callers. */
object ForgeScanCoordinator {
    private val mutex = Mutex()

    suspend fun scan(
        context: Context,
        target: ForgeBuildTarget,
        onProgress: suspend (ForgeScanProgress) -> Unit = {},
    ): ForgeProjectDiscovery {
        mutex.lock()
        return try {
            onProgress(ForgeScanProgress("SCANNING", "Reading the Downloads inbox once…"))
            val result = withContext(Dispatchers.IO) {
                ForgeSourceResolver.discoverDownloads(context.applicationContext, target)
            }
            onProgress(
                ForgeScanProgress(
                    if (result.ready) "READY" else "BLOCKED",
                    result.detail.ifBlank { result.conflicts.joinToString(" ") },
                ),
            )
            result
        } finally {
            mutex.unlock()
        }
    }
}

/**
 * Scan-time SHA cache. The cache is advisory only: ForgeAutomatedBuildRunner performs a full
 * uncached revalidation immediately before upload.
 */
object ForgeDocumentHashCache {
    private data class Key(
        val uri: String,
        val name: String,
        val size: Long,
        val modified: Long,
    )

    private val values = ConcurrentHashMap<Key, String>()

    fun sha256(context: Context, document: DocumentFile, allowCache: Boolean): String {
        val key = Key(document.uri.toString(), document.name.orEmpty(), document.length(), document.lastModified())
        if (allowCache) values[key]?.let { return it }
        val digest = MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(document.uri)?.use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        } ?: error("Unable to read ${document.uri}")
        val result = digest.digest().joinToString("") { "%02x".format(it) }
        if (allowCache) {
            values.keys.filter { it.uri == key.uri && it != key }.forEach(values::remove)
            values[key] = result
        }
        return result
    }

    fun invalidate(document: DocumentFile) {
        val uri = document.uri.toString()
        values.keys.filter { it.uri == uri }.forEach(values::remove)
    }
}
