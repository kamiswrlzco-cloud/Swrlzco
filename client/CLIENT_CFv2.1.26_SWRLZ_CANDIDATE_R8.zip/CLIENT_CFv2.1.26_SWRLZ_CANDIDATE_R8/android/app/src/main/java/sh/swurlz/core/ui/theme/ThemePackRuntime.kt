package sh.swurlz.core.ui.theme

import android.animation.ValueAnimator
import android.content.Context
import android.os.Build
import androidx.annotation.DrawableRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import sh.swrlz.theme.BuiltInThemePacks
import sh.swrlz.theme.SemanticAssetRole
import sh.swrlz.theme.ThemeAssetSpec
import sh.swrlz.theme.ThemePack
import sh.swrlz.theme.ThemeTarget

data class ThemeMotionPolicy(
    val enabled: Boolean,
    val level: String,
    val particleFraction: Float,
    val durationMultiplier: Float,
)

val LocalThemePack = staticCompositionLocalOf { BuiltInThemePacks.glitchDragonGlass }
val LocalThemeMotionPolicy = staticCompositionLocalOf {
    ThemeMotionPolicy(enabled = true, level = "Standard", particleFraction = 1f, durationMultiplier = 1f)
}

fun resolveClientThemePack(selector: String?): ThemePack =
    BuiltInThemePacks.registry.resolve(selector, ThemeTarget.CLIENT)

fun themeColor(value: String, fallback: Color = Color.Magenta): Color {
    val normalized = value.removePrefix("#")
    return runCatching {
        when (normalized.length) {
            6 -> Color((0xFF000000L or normalized.toLong(16)).toInt())
            8 -> Color(normalized.toLong(16).toInt())
            else -> fallback
        }
    }.getOrDefault(fallback)
}

@Composable
fun rememberThemeMotionPolicy(level: String): ThemeMotionPolicy {
    val systemAnimationsEnabled = remember {
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O || ValueAnimator.areAnimatorsEnabled()
    }
    return remember(level, systemAnimationsEnabled) {
        val normalized = level.ifBlank { "Standard" }
        val enabled = systemAnimationsEnabled && normalized != "Off"
        when (normalized) {
            "Low" -> ThemeMotionPolicy(enabled, normalized, .35f, 1.35f)
            "Pulse" -> ThemeMotionPolicy(enabled, normalized, 1f, .82f)
            "Off" -> ThemeMotionPolicy(false, normalized, 0f, 1f)
            else -> ThemeMotionPolicy(enabled, "Standard", .72f, 1f)
        }
    }
}

data class ResolvedThemeAsset(
    val owner: ThemePack,
    val spec: ThemeAssetSpec,
)

object ThemeAssetResolver {
    fun resolve(pack: ThemePack, role: SemanticAssetRole): ResolvedThemeAsset? {
        val registry = BuiltInThemePacks.registry
        val visited = linkedSetOf<String>()
        var current = pack
        while (visited.add(current.id)) {
            current.asset(role)?.let { return ResolvedThemeAsset(current, it) }
            val next = current.fallbacks.asSequence().mapNotNull(registry::find).firstOrNull() ?: break
            current = next
        }
        return null
    }

    @DrawableRes
    fun drawableId(context: Context, pack: ThemePack, role: SemanticAssetRole): Int? {
        val spec = resolve(pack, role)?.spec ?: return null
        val resourceName = spec.path.substringAfterLast('/').substringBeforeLast('.')
        return context.resources.getIdentifier(resourceName, "drawable", context.packageName)
            .takeIf { it != 0 }
    }

    fun kapanionRole(pack: ThemePack): SemanticAssetRole? {
        val identity = pack.kapanionIdentity
        return sequenceOf(
            pack.chromeStyle.kapanionRole,
            identity?.clientRole,
            identity?.sharedRole,
        )
            .filterNotNull()
            .mapNotNull(SemanticAssetRole::fromWireName)
            .firstOrNull { resolve(pack, it) != null }
    }

    fun backgroundRole(pack: ThemePack): SemanticAssetRole? =
        SemanticAssetRole.fromWireName(pack.chromeStyle.backgroundArtRole)
            ?.takeIf { resolve(pack, it) != null }

    fun voiceCoreRole(pack: ThemePack): SemanticAssetRole? =
        SemanticAssetRole.fromWireName(pack.chromeStyle.voiceCoreRole)
            ?.takeIf { resolve(pack, it) != null }
            ?: kapanionRole(pack)
}
