package sh.swurlz.core.bubble

import android.content.Context
import kotlinx.coroutines.runBlocking
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.net.AdminRoutePolicy

enum class BubbleIdentity {
    CLIENT,
    SERVER,
    FUSION,
}

enum class BubbleCapability {
    CLIENT_CHAT,
    CLIENT_STATUS,
    CLIENT_MISSIONS,
    CLIENT_LOGS,
    SERVER_CHAT,
    SERVER_STATUS,
    SERVER_LOGS,
    SERVER_MAINTENANCE,
    FUSED_CHAT,
    FUSED_APPROVALS,
    FUSED_ARTIFACTS,
    FUSED_AUDIT,
    EMERGENCY_STOP,
}

data class BubbleAuthoritySnapshot(
    val verifiedAdmin: Boolean,
    val adminUsername: String,
    val capabilities: Set<BubbleCapability>,
) {
    fun canShow(identity: BubbleIdentity): Boolean = when (identity) {
        BubbleIdentity.CLIENT -> true
        BubbleIdentity.SERVER, BubbleIdentity.FUSION -> verifiedAdmin
    }

    fun allows(capability: BubbleCapability): Boolean = capability in capabilities

    companion object {
        val CLIENT_ONLY = BubbleAuthoritySnapshot(
            verifiedAdmin = false,
            adminUsername = "",
            capabilities = setOf(
                BubbleCapability.CLIENT_CHAT,
                BubbleCapability.CLIENT_STATUS,
                BubbleCapability.CLIENT_MISSIONS,
                BubbleCapability.CLIENT_LOGS,
                BubbleCapability.EMERGENCY_STOP,
            ),
        )
    }
}

/**
 * Resolves bubble visibility from authenticated state. Persisted layout preferences
 * never grant server or fused authority.
 */
object BubbleAuthorityResolver {
    fun resolveBlocking(context: Context): BubbleAuthoritySnapshot = runCatching {
        val session = runBlocking { Prefs.adminSession(context.applicationContext) }
        val verified = AdminRoutePolicy.hasVerifiedSession(
            modeEnabled = session.modeEnabled,
            savedToken = SecretStore.adminSessionToken(context.applicationContext),
            lastVerifiedAt = session.lastVerifiedAt,
        )
        if (!verified) return@runCatching BubbleAuthoritySnapshot.CLIENT_ONLY

        BubbleAuthoritySnapshot(
            verifiedAdmin = true,
            adminUsername = session.username,
            capabilities = BubbleCapability.entries.toSet(),
        )
    }.getOrDefault(BubbleAuthoritySnapshot.CLIENT_ONLY)
}
