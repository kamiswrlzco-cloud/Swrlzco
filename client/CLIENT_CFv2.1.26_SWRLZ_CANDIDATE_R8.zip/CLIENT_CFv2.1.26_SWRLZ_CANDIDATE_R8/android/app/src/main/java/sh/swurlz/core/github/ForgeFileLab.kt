package sh.swurlz.core.github

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.time.Instant
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private const val FILE_LAB_BUFFER = 1024 * 1024
private const val DEFAULT_TEXT_PREVIEW_BYTES = 2 * 1024 * 1024
private const val DEFAULT_CONTENT_SEARCH_BYTES = 64L * 1024L * 1024L

data class ForgeFileInfo(
    val uri: Uri,
    val displayName: String,
    val sizeBytes: Long,
    val mimeType: String?,
    val sha256: String,
    val category: String,
)

data class ForgeArchiveEntryInfo(
    val index: Int,
    val name: String,
    val directory: Boolean,
    val uncompressedSize: Long,
    val compressedSize: Long,
    val crc: Long,
    val method: Int,
    val timeMillis: Long,
    val category: String,
)

data class ForgeArchiveMap(
    val source: ForgeFileInfo,
    val mappedAt: String,
    val entries: List<ForgeArchiveEntryInfo>,
) {
    val fileCount: Int get() = entries.count { !it.directory }
    val directoryCount: Int get() = entries.count { it.directory }
    val knownUncompressedBytes: Long get() = entries.filter { it.uncompressedSize >= 0L }.sumOf { it.uncompressedSize }
}

data class ForgeContentHit(
    val entryName: String,
    val preview: String,
)

data class ForgeTextEditStage(
    val id: String,
    val archiveUri: Uri,
    val archiveName: String,
    val parentSha256: String,
    val entryName: String,
    val stagedFile: File,
    val createdAt: String,
)

data class ForgeFileLabResult(
    val uri: Uri,
    val displayName: String,
    val sizeBytes: Long,
    val sha256: String,
    val lineageManifestUri: Uri? = null,
)

/**
 * INT-FILE-059A deterministic file/archive surface.
 * Reads never mutate source content. All edits are staged in app-private storage and committed to a new output.
 */
object ForgeFileLab {
    fun inspectFile(context: Context, uri: Uri): ForgeFileInfo {
        val metadata = metadata(context, uri)
        return ForgeFileInfo(
            uri = uri,
            displayName = metadata.first,
            sizeBytes = metadata.second,
            mimeType = context.contentResolver.getType(uri),
            sha256 = sha256(context, uri),
            category = categoryFor(metadata.first),
        )
    }

    fun mapZip(context: Context, uri: Uri, maxEntries: Int = 250_000): ForgeArchiveMap {
        val source = inspectFile(context, uri)
        val entries = mutableListOf<ForgeArchiveEntryInfo>()
        context.contentResolver.openInputStream(uri)?.use { raw ->
            ZipInputStream(BufferedInputStream(raw, FILE_LAB_BUFFER)).use { zip ->
                var index = 0
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (index >= maxEntries) error("Archive entry limit $maxEntries exceeded; map aborted fail-closed.")
                    val beforeSize = entry.size
                    val beforeCompressed = entry.compressedSize
                    val beforeCrc = entry.crc
                    zip.closeEntry() // Consume any remaining compressed data without extracting it to storage.
                    entries += ForgeArchiveEntryInfo(
                        index = index,
                        name = entry.name,
                        directory = entry.isDirectory,
                        uncompressedSize = if (entry.size >= 0L) entry.size else beforeSize,
                        compressedSize = if (entry.compressedSize >= 0L) entry.compressedSize else beforeCompressed,
                        crc = if (entry.crc >= 0L) entry.crc else beforeCrc,
                        method = entry.method,
                        timeMillis = entry.time,
                        category = categoryFor(entry.name),
                    )
                    index++
                }
            }
        } ?: error("Unable to open archive for reading.")
        return ForgeArchiveMap(source, Instant.now().toString(), entries)
    }

    fun searchEntries(map: ForgeArchiveMap, query: String): List<ForgeArchiveEntryInfo> {
        val needle = query.trim()
        if (needle.isBlank()) return map.entries
        return map.entries.filter {
            it.name.contains(needle, ignoreCase = true) || it.category.contains(needle, ignoreCase = true)
        }
    }

    fun searchTextContents(
        context: Context,
        archiveUri: Uri,
        query: String,
        maxEntryBytes: Int = DEFAULT_TEXT_PREVIEW_BYTES,
        maxTotalBytes: Long = DEFAULT_CONTENT_SEARCH_BYTES,
        maxHits: Int = 200,
    ): List<ForgeContentHit> {
        val needle = query.trim()
        if (needle.isBlank()) return emptyList()
        val hits = mutableListOf<ForgeContentHit>()
        var consumed = 0L
        context.contentResolver.openInputStream(archiveUri)?.use { raw ->
            ZipInputStream(BufferedInputStream(raw, FILE_LAB_BUFFER)).use { zip ->
                while (hits.size < maxHits) {
                    val entry = zip.nextEntry ?: break
                    if (entry.isDirectory || !isLikelyText(entry.name)) {
                        zip.closeEntry()
                        continue
                    }
                    val cap = maxEntryBytes.coerceAtMost((maxTotalBytes - consumed).coerceAtLeast(0L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
                    if (cap <= 0) break
                    val bytes = readBounded(zip, cap)
                    consumed += bytes.size
                    val text = decodeText(bytes) ?: continue
                    val at = text.indexOf(needle, ignoreCase = true)
                    if (at >= 0) {
                        val start = (at - 90).coerceAtLeast(0)
                        val end = (at + needle.length + 140).coerceAtMost(text.length)
                        hits += ForgeContentHit(entry.name, text.substring(start, end).replace('\n', ' '))
                    }
                    zip.closeEntry()
                    if (consumed >= maxTotalBytes) break
                }
            }
        } ?: error("Unable to open archive for content search.")
        return hits
    }

    fun previewTextEntry(context: Context, archiveUri: Uri, entryName: String, maxBytes: Int = DEFAULT_TEXT_PREVIEW_BYTES): String {
        require(isLikelyText(entryName)) { "Entry is not classified as text: $entryName" }
        context.contentResolver.openInputStream(archiveUri)?.use { raw ->
            ZipInputStream(BufferedInputStream(raw, FILE_LAB_BUFFER)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (!entry.isDirectory && entry.name == entryName) {
                        return decodeText(readBounded(zip, maxBytes)) ?: error("Entry is not valid text preview data.")
                    }
                    zip.closeEntry()
                }
            }
        }
        error("Archive entry not found: $entryName")
    }

    fun previewPlainText(context: Context, uri: Uri, maxBytes: Int = DEFAULT_TEXT_PREVIEW_BYTES): String {
        val name = metadata(context, uri).first
        require(isLikelyText(name)) { "File is not classified as text: $name" }
        val bytes = context.contentResolver.openInputStream(uri)?.use { readBounded(it, maxBytes) }
            ?: error("Unable to read text file.")
        return decodeText(bytes) ?: error("File is not valid text preview data.")
    }

    fun extractSelected(
        context: Context,
        archiveUri: Uri,
        selectedNames: Set<String>,
        outputSlot: ForgeFolderSlot = ForgeFolderSlot.FILELAB_OUTPUT,
    ): List<ForgeFileLabResult> {
        if (selectedNames.isEmpty()) return emptyList()
        val results = mutableListOf<ForgeFileLabResult>()
        context.contentResolver.openInputStream(archiveUri)?.use { raw ->
            ZipInputStream(BufferedInputStream(raw, FILE_LAB_BUFFER)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (!entry.isDirectory && entry.name in selectedNames) {
                        val safeRelative = sanitizeRelativeEntry(entry.name)
                        val destination = createOutputDocument(context, outputSlot, safeRelative, mimeFor(entry.name))
                        val digest = MessageDigest.getInstance("SHA-256")
                        var total = 0L
                        context.contentResolver.openOutputStream(destination.uri, "w")?.use { rawOut ->
                            BufferedOutputStream(rawOut, FILE_LAB_BUFFER).use { out ->
                                val buffer = ByteArray(FILE_LAB_BUFFER)
                                while (true) {
                                    val count = zip.read(buffer)
                                    if (count < 0) break
                                    out.write(buffer, 0, count)
                                    digest.update(buffer, 0, count)
                                    total += count
                                }
                            }
                        } ?: error("Unable to write extracted entry: ${entry.name}")
                        results += ForgeFileLabResult(destination.uri, destination.name.orEmpty(), total, digest.hex())
                    }
                    zip.closeEntry()
                }
            }
        } ?: error("Unable to open archive for selective extraction.")
        return results
    }

    fun stageTextEdit(
        context: Context,
        archiveUri: Uri,
        archiveName: String,
        parentSha256: String,
        entryName: String,
        text: String,
    ): ForgeTextEditStage {
        require(isLikelyText(entryName)) { "Only text-classified archive entries can be staged for text editing." }
        val stageDir = File(context.filesDir, "forge_file_lab/staged_edits").apply { mkdirs() }
        val id = UUID.randomUUID().toString()
        val stagedFile = File(stageDir, "$id.txt")
        stagedFile.writeText(text, Charsets.UTF_8)
        File(stageDir, "$id.json").writeText(
            JSONObject()
                .put("schema", "swrlz-forge-text-edit-stage-v1")
                .put("id", id)
                .put("archiveUri", archiveUri.toString())
                .put("archiveName", archiveName)
                .put("parentSha256", parentSha256)
                .put("entryName", entryName)
                .put("stagedTextFile", stagedFile.absolutePath)
                .put("createdAt", Instant.now().toString())
                .toString(2),
        )
        return ForgeTextEditStage(id, archiveUri, archiveName, parentSha256, entryName, stagedFile, Instant.now().toString())
    }

    fun commitTextRevision(context: Context, stage: ForgeTextEditStage): ForgeFileLabResult {
        require(stage.stagedFile.exists()) { "Staged edit payload is missing." }
        val base = stage.archiveName.removeSuffix(".zip").ifBlank { "archive" }
        val outputName = "${base}.swrlz-revised-${stage.id.take(8)}.zip"
        val destination = createOutputDocument(context, ForgeFolderSlot.FILELAB_OUTPUT, outputName, "application/zip")
        var replaced = false
        context.contentResolver.openInputStream(stage.archiveUri)?.use { rawIn ->
            context.contentResolver.openOutputStream(destination.uri, "w")?.use { rawOut ->
                ZipInputStream(BufferedInputStream(rawIn, FILE_LAB_BUFFER)).use { zipIn ->
                    ZipOutputStream(BufferedOutputStream(rawOut, FILE_LAB_BUFFER)).use { zipOut ->
                        while (true) {
                            val entry = zipIn.nextEntry ?: break
                            val outEntry = ZipEntry(entry.name).apply {
                                if (entry.time >= 0L) time = entry.time
                                comment = entry.comment
                            }
                            zipOut.putNextEntry(outEntry)
                            if (!entry.isDirectory) {
                                if (entry.name == stage.entryName) {
                                    stage.stagedFile.inputStream().use { it.copyTo(zipOut, FILE_LAB_BUFFER) }
                                    replaced = true
                                } else {
                                    zipIn.copyTo(zipOut, FILE_LAB_BUFFER)
                                }
                            }
                            zipOut.closeEntry()
                            zipIn.closeEntry()
                        }
                    }
                }
            } ?: error("Unable to create revised archive output stream.")
        } ?: error("Unable to open original archive.")
        if (!replaced) {
            runCatching { destination.delete() }
            error("Staged entry no longer exists in source archive: ${stage.entryName}")
        }
        val revisedSha = sha256(context, destination.uri)
        val lineage = writeLineageManifest(
            context = context,
            outputName = "$outputName.lineage.json",
            parentName = stage.archiveName,
            parentSha = stage.parentSha256,
            childName = outputName,
            childSha = revisedSha,
            operation = "TEXT_ENTRY_REPLACEMENT",
            detail = JSONObject().put("entryName", stage.entryName).put("stageId", stage.id),
        )
        return ForgeFileLabResult(destination.uri, outputName, destination.length(), revisedSha, lineage.uri)
    }

    fun commitPlainTextRevision(context: Context, sourceUri: Uri, sourceName: String, parentSha256: String, text: String): ForgeFileLabResult {
        val outputName = sourceName.substringBeforeLast('.', sourceName) + ".swrlz-revised." + sourceName.substringAfterLast('.', "txt")
        val destination = createOutputDocument(context, ForgeFolderSlot.FILELAB_OUTPUT, outputName, mimeFor(sourceName))
        context.contentResolver.openOutputStream(destination.uri, "w")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(text) }
            ?: error("Unable to write revised text file.")
        val childSha = sha256(context, destination.uri)
        val lineage = writeLineageManifest(context, "$outputName.lineage.json", sourceName, parentSha256, outputName, childSha, "TEXT_FILE_REVISION", JSONObject())
        return ForgeFileLabResult(destination.uri, outputName, destination.length(), childSha, lineage.uri)
    }

    fun splitBinary(context: Context, sourceUri: Uri, sourceName: String, maxPartBytes: Long = 500L * 1024L * 1024L): ForgeFileLabResult {
        require(maxPartBytes >= 8L * 1024L * 1024L) { "Part size must be at least 8 MiB." }
        val sourceDigest = MessageDigest.getInstance("SHA-256")
        val parts = JSONArray()
        var sourceBytes = 0L
        var partIndex = 0
        var currentDoc: DocumentFile? = null
        var currentOut: BufferedOutputStream? = null
        var currentDigest: MessageDigest? = null
        var currentBytes = 0L

        fun closePart() {
            val doc = currentDoc ?: return
            currentOut?.flush()
            currentOut?.close()
            val digest = currentDigest ?: error("Part digest missing")
            parts.put(JSONObject().put("index", partIndex).put("name", doc.name).put("uri", doc.uri.toString()).put("sizeBytes", currentBytes).put("sha256", digest.hex()))
            currentDoc = null
            currentOut = null
            currentDigest = null
            currentBytes = 0L
        }

        fun openPart() {
            partIndex++
            val name = "${sourceName}.part${partIndex.toString().padStart(3, '0')}"
            val doc = createOutputDocument(context, ForgeFolderSlot.FILELAB_SHARDS, name, "application/octet-stream")
            currentDoc = doc
            currentOut = BufferedOutputStream(context.contentResolver.openOutputStream(doc.uri, "w") ?: error("Unable to write $name"), FILE_LAB_BUFFER)
            currentDigest = MessageDigest.getInstance("SHA-256")
        }

        context.contentResolver.openInputStream(sourceUri)?.use { input ->
            val buffer = ByteArray(FILE_LAB_BUFFER)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                var offset = 0
                while (offset < count) {
                    if (currentOut == null) openPart()
                    val room = (maxPartBytes - currentBytes).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                    val take = minOf(room, count - offset)
                    currentOut!!.write(buffer, offset, take)
                    currentDigest!!.update(buffer, offset, take)
                    sourceDigest.update(buffer, offset, take)
                    currentBytes += take
                    sourceBytes += take
                    offset += take
                    if (currentBytes >= maxPartBytes) closePart()
                }
            }
        } ?: error("Unable to open source for binary split.")
        closePart()
        val sourceSha = sourceDigest.hex()
        val manifestName = "$sourceName.swrlz-split-manifest.json"
        val manifestJson = JSONObject()
            .put("schema", "swrlz-binary-split-v1")
            .put("createdAt", Instant.now().toString())
            .put("sourceName", sourceName)
            .put("sourceSizeBytes", sourceBytes)
            .put("sourceSha256", sourceSha)
            .put("maxPartBytes", maxPartBytes)
            .put("parts", parts)
        val manifest = createOutputDocument(context, ForgeFolderSlot.FILELAB_SHARDS, manifestName, "application/json")
        context.contentResolver.openOutputStream(manifest.uri, "w")?.bufferedWriter()?.use { it.write(manifestJson.toString(2)) }
            ?: error("Unable to write split manifest.")
        return ForgeFileLabResult(manifest.uri, manifestName, manifest.length(), sha256(context, manifest.uri))
    }

    fun recombineBinary(context: Context, manifestUri: Uri): ForgeFileLabResult {
        val manifest = context.contentResolver.openInputStream(manifestUri)?.bufferedReader()?.use { JSONObject(it.readText()) }
            ?: error("Unable to read split manifest.")
        require(manifest.optString("schema") == "swrlz-binary-split-v1") { "Unsupported split manifest schema." }
        val sourceName = manifest.getString("sourceName")
        val expectedSha = manifest.getString("sourceSha256")
        val outputName = sourceName.substringBeforeLast('.', sourceName) + ".recombined." + sourceName.substringAfterLast('.', "bin")
        val output = createOutputDocument(context, ForgeFolderSlot.FILELAB_OUTPUT, outputName, mimeFor(sourceName))
        val digest = MessageDigest.getInstance("SHA-256")
        var total = 0L
        context.contentResolver.openOutputStream(output.uri, "w")?.use { rawOut ->
            BufferedOutputStream(rawOut, FILE_LAB_BUFFER).use { out ->
                val parts = manifest.getJSONArray("parts")
                for (i in 0 until parts.length()) {
                    val item = parts.getJSONObject(i)
                    val name = item.getString("name")
                    val partUri = item.optString("uri").takeIf { it.isNotBlank() }?.let(Uri::parse) ?: error("Split part URI missing: $name")
                    val partDigest = MessageDigest.getInstance("SHA-256")
                    var partBytes = 0L
                    context.contentResolver.openInputStream(partUri)?.use { input ->
                        val buffer = ByteArray(FILE_LAB_BUFFER)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            out.write(buffer, 0, count)
                            digest.update(buffer, 0, count)
                            partDigest.update(buffer, 0, count)
                            total += count
                            partBytes += count
                        }
                    } ?: error("Unable to read split part: $name")
                    require(partBytes == item.getLong("sizeBytes")) { "Split part size mismatch: $name" }
                    require(partDigest.hex() == item.getString("sha256")) { "Split part SHA-256 mismatch: $name" }
                }
            }
        } ?: error("Unable to create recombined output.")
        val actualSha = digest.hex()
        if (actualSha != expectedSha) {
            runCatching { output.delete() }
            error("Recombined SHA-256 mismatch; output removed fail-closed.")
        }
        return ForgeFileLabResult(output.uri, outputName, total, actualSha)
    }

    fun createLogicalShards(
        context: Context,
        archiveUri: Uri,
        map: ForgeArchiveMap,
        targetUncompressedBytes: Long = 500L * 1024L * 1024L,
    ): ForgeFileLabResult {
        require(targetUncompressedBytes >= 8L * 1024L * 1024L) { "Shard target must be at least 8 MiB." }
        val sourceBase = map.source.displayName.removeSuffix(".zip").ifBlank { "archive" }
        val shardRecords = JSONArray()
        val entryRecords = JSONArray()
        var shardIndex = 0
        var shardDoc: DocumentFile? = null
        var shardOut: ZipOutputStream? = null
        var shardApproxBytes = 0L
        var shardEntryCount = 0

        fun closeShard() {
            val doc = shardDoc ?: return
            shardOut?.close()
            shardRecords.put(JSONObject().put("index", shardIndex).put("name", doc.name).put("uri", doc.uri.toString()).put("sizeBytes", doc.length()).put("entryCount", shardEntryCount))
            shardDoc = null
            shardOut = null
            shardApproxBytes = 0L
            shardEntryCount = 0
        }

        fun openShard() {
            shardIndex++
            val name = "${sourceBase}.logical-shard-${shardIndex.toString().padStart(3, '0')}.zip"
            val doc = createOutputDocument(context, ForgeFolderSlot.FILELAB_SHARDS, name, "application/zip")
            shardDoc = doc
            shardOut = ZipOutputStream(BufferedOutputStream(context.contentResolver.openOutputStream(doc.uri, "w") ?: error("Unable to write logical shard $name"), FILE_LAB_BUFFER))
        }

        context.contentResolver.openInputStream(archiveUri)?.use { raw ->
            ZipInputStream(BufferedInputStream(raw, FILE_LAB_BUFFER)).use { zipIn ->
                var entryIndex = 0
                while (true) {
                    val entry = zipIn.nextEntry ?: break
                    val mapped = map.entries.getOrNull(entryIndex)
                    val expected = mapped?.uncompressedSize?.takeIf { it >= 0L } ?: entry.size.takeIf { it >= 0L } ?: 0L
                    if (!entry.isDirectory && shardOut != null && shardEntryCount > 0 && shardApproxBytes + expected > targetUncompressedBytes) closeShard()
                    if (shardOut == null) openShard()
                    val shardName = shardDoc?.name.orEmpty()
                    val outEntry = ZipEntry(entry.name).apply { if (entry.time >= 0L) time = entry.time }
                    shardOut!!.putNextEntry(outEntry)
                    var written = 0L
                    if (!entry.isDirectory) {
                        val buffer = ByteArray(FILE_LAB_BUFFER)
                        while (true) {
                            val count = zipIn.read(buffer)
                            if (count < 0) break
                            shardOut!!.write(buffer, 0, count)
                            written += count
                        }
                    }
                    shardOut!!.closeEntry()
                    shardEntryCount++
                    shardApproxBytes += written
                    entryRecords.put(JSONObject().put("index", entryIndex).put("name", entry.name).put("shard", shardName).put("uncompressedBytes", written).put("crc", mapped?.crc ?: entry.crc))
                    zipIn.closeEntry()
                    entryIndex++
                }
            }
        } ?: error("Unable to open archive for logical sharding.")
        closeShard()
        val manifestName = "${sourceBase}.logical-shards.manifest.json"
        val manifest = JSONObject()
            .put("schema", "swrlz-logical-shards-v1")
            .put("createdAt", Instant.now().toString())
            .put("sourceName", map.source.displayName)
            .put("sourceSha256", map.source.sha256)
            .put("targetUncompressedBytes", targetUncompressedBytes)
            .put("shards", shardRecords)
            .put("entries", entryRecords)
        val doc = createOutputDocument(context, ForgeFolderSlot.FILELAB_SHARDS, manifestName, "application/json")
        context.contentResolver.openOutputStream(doc.uri, "w")?.bufferedWriter()?.use { it.write(manifest.toString(2)) }
            ?: error("Unable to write logical shard manifest.")
        return ForgeFileLabResult(doc.uri, manifestName, doc.length(), sha256(context, doc.uri))
    }

    fun recombineLogicalShards(context: Context, manifestUri: Uri): ForgeFileLabResult {
        val manifest = context.contentResolver.openInputStream(manifestUri)?.bufferedReader()?.use { JSONObject(it.readText()) }
            ?: error("Unable to read logical shard manifest.")
        require(manifest.optString("schema") == "swrlz-logical-shards-v1") { "Unsupported logical shard manifest schema." }
        val sourceName = manifest.getString("sourceName")
        val outputName = sourceName.removeSuffix(".zip") + ".logical-recombined.zip"
        val output = createOutputDocument(context, ForgeFolderSlot.FILELAB_OUTPUT, outputName, "application/zip")
        val seen = mutableSetOf<String>()
        context.contentResolver.openOutputStream(output.uri, "w")?.use { rawOut ->
            ZipOutputStream(BufferedOutputStream(rawOut, FILE_LAB_BUFFER)).use { zipOut ->
                val shards = manifest.getJSONArray("shards")
                for (i in 0 until shards.length()) {
                    val shardRecord = shards.getJSONObject(i)
                    val name = shardRecord.getString("name")
                    val shardUri = shardRecord.optString("uri").takeIf { it.isNotBlank() }?.let(Uri::parse) ?: error("Logical shard URI missing: $name")
                    context.contentResolver.openInputStream(shardUri)?.use { rawIn ->
                        ZipInputStream(BufferedInputStream(rawIn, FILE_LAB_BUFFER)).use { zipIn ->
                            while (true) {
                                val entry = zipIn.nextEntry ?: break
                                require(seen.add(entry.name)) { "Duplicate logical entry while recombining: ${entry.name}" }
                                val outEntry = ZipEntry(entry.name).apply { if (entry.time >= 0L) time = entry.time }
                                zipOut.putNextEntry(outEntry)
                                if (!entry.isDirectory) zipIn.copyTo(zipOut, FILE_LAB_BUFFER)
                                zipOut.closeEntry()
                                zipIn.closeEntry()
                            }
                        }
                    } ?: error("Unable to open logical shard: $name")
                }
            }
        } ?: error("Unable to write logical recombination output.")
        val sha = sha256(context, output.uri)
        val lineage = writeLineageManifest(context, "$outputName.lineage.json", sourceName, manifest.optString("sourceSha256"), outputName, sha, "LOGICAL_SHARD_RECOMBINATION", JSONObject().put("byteIdenticalToParent", false))
        return ForgeFileLabResult(output.uri, outputName, output.length(), sha, lineage.uri)
    }

    fun recombineFromManifest(context: Context, manifestUri: Uri): ForgeFileLabResult {
        val schema = context.contentResolver.openInputStream(manifestUri)?.bufferedReader()?.use { JSONObject(it.readText()).optString("schema") }
            ?: error("Unable to read manifest.")
        return when (schema) {
            "swrlz-binary-split-v1" -> recombineBinary(context, manifestUri)
            "swrlz-logical-shards-v1" -> recombineLogicalShards(context, manifestUri)
            else -> error("Unsupported Forge File Lab manifest schema: $schema")
        }
    }

    fun exportMap(context: Context, map: ForgeArchiveMap): ForgeFileLabResult {
        val json = JSONObject()
            .put("schema", "swrlz-archive-map-v1")
            .put("mappedAt", map.mappedAt)
            .put("source", JSONObject().put("name", map.source.displayName).put("sizeBytes", map.source.sizeBytes).put("sha256", map.source.sha256).put("mimeType", map.source.mimeType).put("category", map.source.category))
            .put("fileCount", map.fileCount)
            .put("directoryCount", map.directoryCount)
            .put("knownUncompressedBytes", map.knownUncompressedBytes)
            .put("entries", JSONArray().apply {
                map.entries.forEach { entry ->
                    put(JSONObject().put("index", entry.index).put("name", entry.name).put("directory", entry.directory).put("uncompressedSize", entry.uncompressedSize).put("compressedSize", entry.compressedSize).put("crc", entry.crc).put("method", entry.method).put("timeMillis", entry.timeMillis).put("category", entry.category))
                }
            })
        val name = map.source.displayName + ".swrlz-map.json"
        val doc = createOutputDocument(context, ForgeFolderSlot.FILELAB_WORKING, name, "application/json")
        context.contentResolver.openOutputStream(doc.uri, "w")?.bufferedWriter()?.use { it.write(json.toString(2)) }
            ?: error("Unable to write archive map.")
        return ForgeFileLabResult(doc.uri, name, doc.length(), sha256(context, doc.uri))
    }

    private fun metadata(context: Context, uri: Uri): Pair<String, Long> {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "file"
        var size = -1L
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        return name to size
    }

    private fun sha256(context: Context, uri: Uri): String {
        val digest = MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(FILE_LAB_BUFFER)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        } ?: error("Unable to hash file.")
        return digest.hex()
    }

    private fun categoryFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "zip", "jar", "apk", "aab", "7z", "rar", "tar", "gz", "tgz" -> "archive"
        "json", "jsonl", "md", "txt", "csv", "xml", "yaml", "yml", "kt", "kts", "java", "py", "js", "ts", "html", "css", "gradle", "properties", "toml" -> "text"
        "png", "jpg", "jpeg", "gif", "webp", "svg" -> "image"
        "mp3", "wav", "ogg", "m4a", "flac" -> "audio"
        "mp4", "mkv", "webm", "mov" -> "video"
        "pdf", "doc", "docx" -> "document"
        "gguf", "bin", "dat" -> "binary"
        else -> "other"
    }

    private fun isLikelyText(name: String): Boolean = categoryFor(name) == "text"

    private fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "json", "jsonl" -> "application/json"
        "zip" -> "application/zip"
        "md", "txt", "kt", "kts", "java", "py", "js", "ts", "css", "csv", "yaml", "yml", "properties", "toml" -> "text/plain"
        "html" -> "text/html"
        "xml" -> "application/xml"
        else -> "application/octet-stream"
    }

    private fun decodeText(bytes: ByteArray): String? {
        if (bytes.any { it == 0.toByte() }) return null
        return runCatching { bytes.toString(Charsets.UTF_8) }.getOrNull()
    }

    private fun readBounded(input: java.io.InputStream, maxBytes: Int): ByteArray {
        val out = ByteArrayOutputStream(minOf(maxBytes, 64 * 1024))
        val buffer = ByteArray(64 * 1024)
        var remaining = maxBytes
        while (remaining > 0) {
            val count = input.read(buffer, 0, minOf(buffer.size, remaining))
            if (count < 0) break
            out.write(buffer, 0, count)
            remaining -= count
        }
        return out.toByteArray()
    }

    private fun sanitizeRelativeEntry(name: String): String {
        val cleaned = name.replace('\\', '/').trimStart('/')
        require(cleaned.isNotBlank() && cleaned.split('/').none { it == ".." }) { "Unsafe archive entry path: $name" }
        return cleaned
    }

    private fun outputRoot(context: Context, slot: ForgeFolderSlot): DocumentFile {
        val configured = ForgeAutomationPreferences.treeUri(context, slot)
        if (configured != null) {
            return DocumentFile.fromTreeUri(context, configured)?.takeIf { it.isDirectory && it.canWrite() }
                ?: error("Configured ${slot.label} folder is unavailable. Re-select it in Forge settings.")
        }
        error("Select ${slot.label} in Forge settings before this operation.")
    }

    private fun createOutputDocument(context: Context, slot: ForgeFolderSlot, relativeName: String, mime: String): DocumentFile {
        val configured = ForgeAutomationPreferences.treeUri(context, slot)
        if (configured != null) {
            val root = DocumentFile.fromTreeUri(context, configured)?.takeIf { it.isDirectory && it.canWrite() }
                ?: error("Configured ${slot.label} folder is unavailable. Re-select it in Forge settings.")
            return createDocumentInRoot(context, root, relativeName, mime)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val base = when (slot) {
                ForgeFolderSlot.FILELAB_WORKING -> "${Environment.DIRECTORY_DOWNLOADS}/swrlz core/file lab/working/"
                ForgeFolderSlot.FILELAB_OUTPUT -> "${Environment.DIRECTORY_DOWNLOADS}/swrlz core/file lab/output/"
                ForgeFolderSlot.FILELAB_SHARDS -> "${Environment.DIRECTORY_DOWNLOADS}/swrlz core/file lab/shards/"
                else -> "${Environment.DIRECTORY_DOWNLOADS}/swrlz core/"
            }
            val safeName = relativeName.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]+"), "_").ifBlank { "swrlz-file" }
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, base)
                put(MediaStore.Downloads.IS_PENDING, 0)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Unable to create Downloads item for $safeName")
            return DocumentFile.fromSingleUri(context, uri) ?: error("Unable to wrap Downloads item.")
        }
        error("Select ${slot.label} in Forge settings on this Android version.")
    }

    private fun createDocumentInRoot(context: Context, root: DocumentFile, relativeName: String, mime: String): DocumentFile {
        val clean = sanitizeRelativeEntry(relativeName)
        val segments = clean.split('/').filter { it.isNotBlank() }
        var directory = root
        for (segment in segments.dropLast(1)) {
            val safe = segment.replace(Regex("[^A-Za-z0-9._ -]+"), "_").ifBlank { "folder" }
            directory = directory.findFile(safe)?.takeIf { it.isDirectory } ?: directory.createDirectory(safe)
                ?: error("Unable to create output directory: $safe")
        }
        val leaf = segments.last().replace(Regex("[^A-Za-z0-9._ -]+"), "_").ifBlank { "file" }
        directory.findFile(leaf)?.delete()
        return directory.createFile(mime, leaf) ?: error("Unable to create output file: $leaf")
    }

    private fun writeLineageManifest(
        context: Context,
        outputName: String,
        parentName: String,
        parentSha: String,
        childName: String,
        childSha: String,
        operation: String,
        detail: JSONObject,
    ): DocumentFile {
        val doc = createOutputDocument(context, ForgeFolderSlot.FILELAB_OUTPUT, outputName, "application/json")
        val json = JSONObject()
            .put("schema", "swrlz-file-lineage-v1")
            .put("createdAt", Instant.now().toString())
            .put("operation", operation)
            .put("parent", JSONObject().put("name", parentName).put("sha256", parentSha))
            .put("child", JSONObject().put("name", childName).put("sha256", childSha))
            .put("detail", detail)
        context.contentResolver.openOutputStream(doc.uri, "w")?.bufferedWriter()?.use { it.write(json.toString(2)) }
            ?: error("Unable to write lineage manifest.")
        return doc
    }

    private fun MessageDigest.hex(): String = digest().joinToString("") { "%02x".format(it) }
}
