package sh.swurlz.core.overlay.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.withContext
import sh.swurlz.core.data.MissionBus
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.UiStyleSettings
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import sh.swurlz.core.ui.theme.ProgressSnapshot
import sh.swurlz.core.ui.theme.SwurlzTheme
import sh.swurlz.core.ui.theme.ThemedProgressBar
import sh.swrlz.theme.ThemeProgressState

@Composable
fun OverlayBubble(
    onDrag: (Float, Float) -> Unit,
    onDragEnd: () -> Unit,
    onPauseToggle: () -> Unit,
    onTakeOver: () -> Unit,
    onStopMission: () -> Unit,
    onApprove: () -> Unit,
    onOpenBubble: () -> Unit,
    onCollapsedChange: (Boolean) -> Unit,
    onClose: () -> Unit,
) {
    val ctx = LocalContext.current
    var collapsed by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    var style by remember { mutableStateOf(UiStyleSettings()) }
    LaunchedEffect(Unit) {
        collapsed = withContext(Dispatchers.IO) { Prefs.overlayCollapsed(ctx) }
        loaded = true
        Prefs.uiStyleFlow(ctx).collectLatest { style = it }
    }
    LaunchedEffect(collapsed, loaded) { if (loaded) onCollapsedChange(collapsed) }
    val ambient by MissionBus.ambient.collectAsState()
    LaunchedEffect(ambient) {
        if (ambient == MissionBus.Ambient.Acting) collapsed = true
    }
    SwurlzTheme(style) {
        if (collapsed) MissionPuck(onDrag,onDragEnd,onOpenBubble){ collapsed=false }
        else MissionHud(onDrag,onDragEnd,{collapsed=true},onPauseToggle,onTakeOver,onStopMission,onApprove,onOpenBubble,onClose)
    }
}

@Composable private fun MissionPuck(onDrag:(Float,Float)->Unit,onDragEnd:()->Unit,onOpenBubble:()->Unit,onExpand:()->Unit){
    val ambient by MissionBus.ambient.collectAsState(); val mission by MissionBus.mission.collectAsState(); val t=LocalSwurlzTokens.current
    Box(Modifier.size(64.dp).clip(CircleShape).background(t.surfaces.bgOverlay).border(2.dp,t.accents.primary,CircleShape)
        .pointerInput(Unit){detectDragGestures(onDragEnd={onDragEnd()}){c,a->c.consume();onDrag(a.x,a.y)}}
        .pointerInput(Unit){detectTapGestures(onTap={onExpand()},onDoubleTap={onOpenBubble()})}, contentAlignment=Alignment.Center){
        Column(horizontalAlignment=Alignment.CenterHorizontally){
            Box(Modifier.size(18.dp).clip(CircleShape).background(ambientColor(ambient,t.accents.primary)))
            Text(if(mission.total>0) "${mission.step}/${mission.total}" else "S", color=t.text.primary,fontSize=9.sp,fontWeight=FontWeight.Bold)
        }
    }
}

@Composable private fun MissionHud(onDrag:(Float,Float)->Unit,onDragEnd:()->Unit,onMinimize:()->Unit,onPauseToggle:()->Unit,onTakeOver:()->Unit,onStopMission:()->Unit,onApprove:()->Unit,onOpenBubble:()->Unit,onClose:()->Unit){
    val ambient by MissionBus.ambient.collectAsState(); val mission by MissionBus.mission.collectAsState(); val timeline by MissionBus.timeline.collectAsState(); val needsApproval by MissionBus.needsApproval.collectAsState(); val paused by MissionBus.pauseRequest.collectAsState(); val err by MissionBus.lastError.collectAsState(); val t=LocalSwurlzTokens.current
    val progress=mission.total.takeIf { it > 0 }?.let {
        (mission.step.toFloat() / it).coerceIn(0f, 1f)
    }
    Column(Modifier.width(340.dp).clip(RoundedCornerShape(24.dp)).background(t.surfaces.bgOverlay).border(2.dp,t.accents.primary,RoundedCornerShape(24.dp)).padding(14.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){
            Box(Modifier.size(28.dp).pointerInput(Unit){detectDragGestures(onDragEnd={onDragEnd()}){c,a->c.consume();onDrag(a.x,a.y)}},contentAlignment=Alignment.Center){Text("⋮⋮",color=t.text.muted,fontSize=16.sp)}
            Spacer(Modifier.width(6.dp)); Box(Modifier.size(12.dp).clip(CircleShape).background(ambientColor(ambient,t.accents.primary)))
            Spacer(Modifier.width(8.dp)); Column(Modifier.weight(1f)){Text("MISSION HUD",color=t.accents.primary,fontWeight=FontWeight.Black,fontSize=12.sp,letterSpacing=1.5.sp);Text(mission.goal.ifBlank{"No active mission"},color=t.text.primary,fontWeight=FontWeight.Bold,fontSize=14.sp,maxLines=1)}
            Mini("—",t.text.secondary,onMinimize); Spacer(Modifier.width(4.dp)); Mini("×",t.status.danger,onClose)
        }
        Spacer(Modifier.height(10.dp)); Text(mission.state.uppercase(),color=ambientColor(ambient,t.accents.primary),fontSize=11.sp,fontWeight=FontWeight.Bold)
        if (mission.goal.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            ThemedProgressBar(
                snapshot = ProgressSnapshot(
                    operationId = mission.missionId ?: "overlay-mission-current",
                    value = progress,
                    state = when {
                        paused -> ThemeProgressState.PAUSED
                        ambient == MissionBus.Ambient.Done -> ThemeProgressState.SUCCESS
                        ambient == MissionBus.Ambient.Error -> ThemeProgressState.FAILED
                        else -> ThemeProgressState.ACTIVE
                    },
                    label = "Mission overlay progress",
                    statusText = if (mission.total > 0) {
                        "STEP ${mission.step.coerceIn(0, mission.total)} OF ${mission.total}"
                    } else {
                        "${mission.state.uppercase()} · EXACT PERCENTAGE UNKNOWN"
                    },
                ),
                showStatusText = true,
            )
        }
        if(mission.rationale.isNotBlank()){Spacer(Modifier.height(8.dp));Text(mission.rationale,color=t.text.secondary,fontSize=11.sp,maxLines=2)}
        err?.let{Spacer(Modifier.height(8.dp));Text(it,color=t.status.danger,fontSize=11.sp,maxLines=2)}
        val recent=timeline.takeLast(3); if(recent.isNotEmpty()){Spacer(Modifier.height(10.dp));LazyColumn(Modifier.heightIn(max=78.dp)){items(recent){e->Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(7.dp).clip(CircleShape).background(phaseColor(e.phase,t.accents.primary)));Spacer(Modifier.width(7.dp));Text(e.label,color=t.text.primary,fontSize=10.sp,maxLines=1)}}}}
        Spacer(Modifier.height(12.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
            HudButton(if(paused)"RESUME" else "PAUSE",t.status.warning,Modifier.weight(1f),onPauseToggle);HudButton("STOP",t.status.danger,Modifier.weight(1f),onStopMission);HudButton("CHAT",t.accents.primary,Modifier.weight(1f),onOpenBubble)
        }
        Spacer(Modifier.height(6.dp)); HudButton("TAKE OVER / OBSERVE ONLY",t.status.danger,Modifier.fillMaxWidth(),onTakeOver)
        if(needsApproval){Spacer(Modifier.height(7.dp));HudButton("APPROVE CURRENT STEP",t.status.success,Modifier.fillMaxWidth(),onApprove)}
    }
}

@Composable private fun Mini(label:String,color:Color,onClick:()->Unit){Box(Modifier.size(26.dp).clip(RoundedCornerShape(8.dp)).border(1.dp,color,RoundedCornerShape(8.dp)).pointerInput(Unit){detectTapGestures{onClick()}},contentAlignment=Alignment.Center){Text(label,color=color,fontWeight=FontWeight.Bold)}}
@Composable private fun HudButton(label:String,color:Color,modifier:Modifier,onClick:()->Unit){OutlinedButton(onClick=onClick,modifier=modifier.height(34.dp),contentPadding=PaddingValues(horizontal=6.dp),colors=ButtonDefaults.outlinedButtonColors(contentColor=color),border=BorderStroke(1.dp,color),shape=RoundedCornerShape(12.dp)){Text(label,fontSize=9.sp,fontWeight=FontWeight.Black,maxLines=1)}}
private fun ambientColor(s:MissionBus.Ambient,a:Color)=when(s){MissionBus.Ambient.Idle->Color.Gray;MissionBus.Ambient.Listening->Color(0xFF4DFFB4);MissionBus.Ambient.Observing->a;MissionBus.Ambient.Planning->Color(0xFFC45DFF);MissionBus.Ambient.Acting->Color(0xFF4ADE80);MissionBus.Ambient.Paused->Color(0xFFEAB308);MissionBus.Ambient.Error->Color(0xFFEF4444);MissionBus.Ambient.Done->Color(0xFF4DFFB4)}
private fun phaseColor(p:String,a:Color)=when(p){"planned"->Color(0xFFC45DFF);"executing"->a;"success"->Color(0xFF4ADE80);"failure"->Color(0xFFEF4444);"rolled_back"->Color(0xFFEAB308);else->Color.Gray}
