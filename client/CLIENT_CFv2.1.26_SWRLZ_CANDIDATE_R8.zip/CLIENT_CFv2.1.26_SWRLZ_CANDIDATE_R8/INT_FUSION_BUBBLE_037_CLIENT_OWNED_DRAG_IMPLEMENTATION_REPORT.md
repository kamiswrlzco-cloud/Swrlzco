# INT-FUSION-BUBBLE-037 — Client-Owned Drag Fusion

## Implemented

- Added `InteractiveBubbleDockService` to the SWRLZ Client.
- The Client owns and renders three custom overlay identities:
  - SWRLZ Client
  - authenticated remote SWURLZER control surface
  - SWURVER fusion surface
- The remote SWURLZER bubble does not require the Server APK to run on the Client device.
- Dragging Client and SWURLZER within the fusion threshold creates the SWURVER bubble.
- Magnetic approach behavior begins before collision.
- User-selectable layout modes:
  - SINGLE
  - DUAL
  - FUSION
  - ALL_THREE
- User can keep the original two bubbles after fusion or replace them with SWURVER.
- Bubble positions, selected layout, persistence preference, and fusion behavior are saved.
- Tapping each identity opens the matching Client-rendered control surface.
- Remote actions remain subject to authenticated protocol permissions and SWURLZER authority.
- Display-over-other-apps is requested only for this custom interactive dock path.

## Architecture

The Client is the sole overlay renderer and coordinate authority. SWURLZER remains the remote authoritative runtime. The purple bubble is a view into authorized remote capabilities, not a local Server process.

## Build identity

- Version code: 66
- Version name: `2.0.37-client-owned-drag-fusion`
