# CLIENT CFv2.1.10 — Progress Layering + Clipping Repair

Canonical checkpoint evidence:

`docs/checkpoints/INT-THEME-036A_CLIENT_PROGRESS_LAYERING_CLIPPING_REPAIR.md`

This CLIENT-only source checkpoint is based on the verified CFv2.1.9 package pair.
It repairs runtime progress composition exposed by real-device visual evidence:
Jester track geometry now follows the transparent frame opening, determinate fill
is revealed at full track geometry instead of compressed, moving highlight/particle
effects are bounded by the active progress window, and the decorative frame remains
above all streaming layers.

No SERVER, protocol, trust, Truth Firewall, identity proof, permission, mission,
Forge authority, local/remote, accessibility-automation, or offline-first behavior
is changed. Build/device re-verification remains separately gated.
