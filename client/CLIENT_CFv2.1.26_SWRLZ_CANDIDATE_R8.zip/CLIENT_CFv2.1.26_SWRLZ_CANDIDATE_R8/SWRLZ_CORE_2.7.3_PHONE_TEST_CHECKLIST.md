# SWRLZ-Core 2.7.3 Phone Test Checklist

## Identity

- [ ] Home/Core shows `0.2.7.3-theme-armor`.
- [ ] Version code is `16`.
- [ ] Patch label shows `2.7.3-THEME-ARMOR`.
- [ ] Source ZIP shows `SWRLZ_CORE_2.7.3_THEME_ARMOR_SOURCE.zip`.

## Style / Appearance

- [ ] Style tab opens without crash.
- [ ] Original Core selects and persists.
- [ ] Glitch Neon selects and persists.
- [ ] Pharaoh Emerald selects and persists.
- [ ] Void Jester selects and persists.
- [ ] Dark variant selects and persists.
- [ ] Sunlight variant selects and persists.
- [ ] Inverse variant selects and persists.
- [ ] Live preview cards update.
- [ ] High Contrast toggle persists.
- [ ] Semantic Borders Only toggle persists.
- [ ] Solid Buttons in Sunlight toggle persists.
- [ ] Glow Strength persists.
- [ ] Text Size persists.
- [ ] Card Density persists.

## App shell

- [ ] Top bar uses selected theme.
- [ ] Active tab is visually obvious.
- [ ] Inactive tabs stay readable.
- [ ] App remains usable outdoors in Sunlight mode.

## Relay regression

- [ ] Core Node URL remains saved.
- [ ] Radar connects to server 0.7.1.
- [ ] Auto Presence / Node Heartbeat still works.
- [ ] Device identity remains stable after relaunch.
- [ ] Rotate ID works.
- [ ] Forget ID regenerates an identity.
- [ ] Group/device check-in still works.
- [ ] Packet send works.
- [ ] Pull queue works.
- [ ] DISPLAY / ACK / COMPLETE still work.
