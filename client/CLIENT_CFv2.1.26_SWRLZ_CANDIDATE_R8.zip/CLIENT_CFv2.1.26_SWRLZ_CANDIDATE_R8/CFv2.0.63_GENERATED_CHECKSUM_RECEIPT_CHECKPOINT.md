# CLIENT CFv2.0.63 Generated Checksum Receipt

- Selecting a source ZIP first attempts exact readable sibling `.sha256` resolution.
- When Android grants only the ZIP URI, Forge computes the ZIP SHA-256 and stages a canonical `<base>.sha256` receipt from app cache.
- No second picker or `LOCATE SHA-256` action is required during the normal path.
- Repository integrity independently recomputes the ZIP digest.
- Manual locate remains only as exceptional recovery if the selected ZIP itself cannot be read.
