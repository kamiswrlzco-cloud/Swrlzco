# CLIENT CFv2.1.26 Candidate R1 — INT-FORGE-054A-R2

- Mirrors the shared Forge build conveyor from SERVER: ASK/CLIENT/SERVER/BOTH/FILES, `BUILD LATEST VERIFIED`, authoritative source-triple resolution, persisted SAF directories, default-on successful-artifact/failure-log downloads, and build ledger provenance.
- Keeps CLIENT Forge usable as the practical updater for repeated SERVER source/build iterations while preserving CLIENT-only legacy Dev Mode, Missions, and client-side capabilities.
- Adds CLIENT-local persistent chat threads with history/new/rename/delete controls and a compact Chat header; SERVER reasoning/evidence remains SERVER-authoritative.
- Adds machine-readable patch/checkpoint lineage and explicit CLIENT/SERVER feature-parity documentation.
- Source-only candidate: no Gradle compile, APK build, GitHub write/workflow, release, deployment, or installation is claimed.

---

# CFv2.1.24 R1 — INT-FORGE-042B

- Forge Transport V2: 4 MiB protected-source chunks, bounded transient per-blob retries, 401 auth/repository reprobe, verified resume, richer diagnostics.
- Repairs missing `@Composable` on `ChatSettingsChoiceGroup` from the CFv2.1.23 R1 build failure.

# CLIENT CFv2.1.23 Candidate R1 — Modular Model Rack + Expression EQ

Brain & AI now includes a paired SERVER model-rack panel. It shows installed GGUFs, identifies the exact optimized SWRLZ Q4, stores separate Speed/Reasoning Depth/Expression EQ profiles for each model hash, toggles prompt/EQ packs and offers profile/model rollback.

Reasoning Depth is labeled honestly: it changes response budget, profile density and validation emphasis; it does not add learned intelligence. The nine EQ sliders shape expression, not truth or authority. SERVER remains authoritative and LAN changes require registered paired control.

The shared source/static/model-identity gates pass `36/36`. Android compilation/APK/device evidence is pending because Gradle 8.7 could not be obtained in this workspace. The GGUF is never bundled in CLIENT.

---

# CLIENT CFv2.1.20 Candidate R1 — Resilient Forge Source Transport

Large protected source ZIPs can now use verified chunk transport instead of one oversized REST Git-blob request. Build eligibility requires the source ZIP only; checksum and manifest companions are optional evidence and remain strict when supplied.

This source candidate does not claim an Android build yet. The official repository router patch is included as a source-only handoff and has not been committed or pushed.

---

# CLIENT CFv2.1.18 — Forge Rescue Profile-Store Compile Repair

Checkpoint: `INT-FIX-039G`

- Repairs the `ClientProfileStore.resolveClientToServer` provider-profile expression that blocked `compileDebugKotlin` in workflow `30302109949`.
- Changes the incorrect function-symbol nullable access `providerProfileId?.let` to the declared `providerId?.let`.
- Audits SERVER CFv2.1.7 profile-store Kotlin; the corresponding SERVER paths are already correct, so SERVER remains unchanged.
- Preserves the CFv2.1.17 default-theme Forge rescue payload and GitHub credential/write-preflight repair.
- Source/static verification only; successful compilation remains pending the next authorized build/workflow.

---

# CLIENT CFv2.1.17 — Forge Rescue / Default-Theme Bootstrap

Checkpoint: `INT-FORGE-039E`

This source-only rescue successor is intentionally transport-light. It preserves the current CLIENT code lineage while exposing only the canonical default `Glitch Dragon Glass` ThemePack at runtime and removing optional ThemePack/ignition payloads from the package so the Forge uploader repair can itself be transported through older CLIENT builds.

## Forge repair

- Preflight now proves authentication, repository read, and `Contents: write` before a large transfer by creating a tiny unreferenced Git blob. The probe does not modify a branch/tree/file.
- A 401 during a later repository operation is no longer automatically interpreted as proof that the credential is revoked. Forge re-probes authentication and preserves the credential when the re-probe succeeds.
- 422 `input was too large` is classified as a transport-size failure, not an authentication failure.
- Sanitized GitHub request ID / accepted-permission evidence is included when supplied by GitHub.

## Temporary bootstrap theme boundary

- Runtime registry selectable set: `Glitch Dragon Glass` only.
- Alternate launcher aliases are removed from the bootstrap Android manifest.
- Optional theme progress, ignition, launcher, Kapanion, and legacy alternate identity artwork is omitted.
- The full declarative ThemePack definitions remain in source lineage for restoration; this bootstrap edition is not a design rollback.
- ThemePack authority/trust/protocol/mission semantics are unchanged.

## Evidence boundary

Source/static/package verification only. No Gradle build, APK, device acceptance, GitHub upload, workflow, commit, push, release, deployment, or installation is claimed.

## CFv2.1.27 · INT-FILE-059A · Forge File Lab / Archive Cartographer
- Mirrors SERVER baseline Forge **FILE LAB** capability in CLIENT.
- Adds deterministic file SHA-256 inspection and ZIP structural mapping without bulk extraction to storage.
- Adds path/type search, bounded text-content search, text preview, and selective entry extraction.
- Adds staged text editing with explicit new-output commit and lineage manifest; originals are unchanged.
- Adds byte-exact ~500 MiB binary split manifests/recombination and logical ~500 MiB ZIP shards.
- Adds configurable File Lab working/output/shard SAF directory lanes with Downloads fallback where Android supports it.
- CLIENT-only Missions and legacy Dev Mode remain preserved; no SERVER-only inference authority is copied into CLIENT.
- Source-only checkpoint; no APK build, install, GitHub write, workflow dispatch, release, or deployment claimed.


## INT-FORGE-064A — CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R2

- Adds automatic protected source + metadata ZIP pairing.
- Adds strict metadata archive and evidence archive validation.
- Adds chunked-git-blobs-v2 and shared workflow resolver/verifier support.
- Preserves complete legacy loose sidecars for the one-time bootstrap.
- Source-only candidate: no Android build, install, promotion, release, or deployment.
- Lineage disclosure: built from the verified CFv2.1.27 descendant implementation base because the byte-exact accepted CFv2.1.26 archive was not available in the active runtime; File Lab surfaces are preserved.


## INT-FIX-064A-CLIENT-R3 — CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R3

- Adds the four missing GitHub Forge imports identified by workflow `30700898714`.
- Preserves the INT-FORGE-064A source/metadata ZIP pairing and evidence-bundle implementation.
- Advances Android identity to versionCode `126` and versionName `2.1.26-forge-metadata-bundle-compile-fix-r3`.
- Source-only repair; no APK build, install, promotion, release, or deployment.
## INT-FORGE-064B-CLIENT-R4 — CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R4

- Adds project-root package discovery and genuine CLIENT/SERVER/BOTH auto-detection.
- Selects the newest valid source package by verified versionCode/revision and rejects equal-rank hash conflicts.
- Supports two-file metadata pairs and three-file legacy triples.
- Stages matching checkpoint evidence and performs scan-stage-upload from one explicit action.
- Reconciles transient GitHub 5xx outcomes and reuses unresolved transaction IDs to prevent duplicate commits.
- Gives authoritative workflow success precedence over stale local failure presentation.
- Advances CLIENT to VC127. Source-only; Android workflow compilation is pending.

