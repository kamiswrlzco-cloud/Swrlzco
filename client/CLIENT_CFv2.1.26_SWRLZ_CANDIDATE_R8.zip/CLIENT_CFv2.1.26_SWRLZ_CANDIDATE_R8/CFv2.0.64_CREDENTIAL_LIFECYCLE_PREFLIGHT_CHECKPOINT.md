# CLIENT CFv2.0.64 — GitHub Credential Lifecycle and Upload Preflight

**Status:** Source/static verified; GitHub APK build and device acceptance pending.

## Problem

Forge could repeatedly receive `401 Bad credentials` during or after a long upload. Reconnecting created a new token and could temporarily restore uploads, but the CLIENT stored only the current access token. It did not preserve GitHub App refresh-token metadata or access-token expiration, and a GitHub-rejected credential could remain eligible for reuse.

Manual token input also accepted pasted `Bearer ` / `token ` prefixes and embedded whitespace literally, which could produce a malformed Authorization value.

## Repair

CLIENT CFv2.0.64:

- normalizes token input before validation, storage, or Authorization-header creation;
- distinguishes fine-grained PAT, classic PAT, OAuth App token, and GitHub App user token by non-secret prefix classification;
- parses device-flow `refresh_token`, `expires_in`, `refresh_token_expires_in`, and `token_type` fields when GitHub supplies them;
- stores access and refresh tokens plus expiration metadata in Android Keystore-backed encrypted preferences;
- includes refresh metadata in the eligible encrypted Android backup/device-transfer envelope;
- refreshes GitHub App user tokens before expiry and when GitHub returns 401, then persists the rotated access and refresh tokens;
- validates the exact immutable credential snapshot against both `/user` and the configured repository branch before streaming any source bytes;
- retries one upload once when a refreshable credential expires during transfer;
- retires an explicitly rejected credential instead of silently reusing it on the next transaction;
- keeps network/transient validation failures non-destructive;
- logs only credential kind and refresh outcome, never token material.

## Preserved work

- CLIENT CFv2.0.63 generated canonical `.sha256` receipt fallback;
- automatic readable sibling receipt lookup;
- repeated same-install uploads and branch confirmation;
- live redacted upload diagnostics;
- upload/build bubble and notification outcomes;
- Dragon Kamileon Theme Armor;
- connector profile continuity and approved disconnect.

## Android identity

```text
versionCode: 91
versionName: 2.0.64-credential-lifecycle-preflight-v1
```

## Acceptance gate

1. Build and install CLIENT CFv2.0.64.
2. Reconnect GitHub once.
3. Confirm upload diagnostics record `AUTH_PREFLIGHT` before `BLOB_UPLOAD`.
4. Confirm an invalid/revoked token fails before source streaming and exposes reconnect controls.
5. Confirm a GitHub App user token refreshes without another device code when refresh metadata is available.
6. Confirm a valid fine-grained PAT persists across restart and theme changes.
7. Confirm generated checksum receipt and repeated-upload behavior remain correct.
