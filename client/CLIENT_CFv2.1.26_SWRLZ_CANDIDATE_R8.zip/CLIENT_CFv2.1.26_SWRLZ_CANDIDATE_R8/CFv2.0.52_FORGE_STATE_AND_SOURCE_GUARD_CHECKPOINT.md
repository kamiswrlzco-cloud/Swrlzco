# CLIENT CFv2.0.52 — Forge State Header and Source ZIP Guard

## Scope

This additive CLIENT patch makes Forge state visible in the global CLIENT header and adds an optional local source-archive content gate before any network upload begins.

## Implemented behavior

### Authoritative Forge header state

When the Forge tab is selected, the top bar now projects the process-local Forge phase instead of the unrelated ambient mission state:

- IDLE
- VALIDATING
- UPLOADING
- BUILDING
- DOWNLOADING
- ARTIFACTS READY
- COMPLETE
- FAILED

The state is color-coded and derived from real upload state, workflow runs, artifact retrieval, and failure outcomes. It does not invent build percentages.

### Source ZIP Content Guard

A persisted `SOURCE ZIP CONTENT GUARD` toggle is enabled by default.

Before checksum validation or any GitHub network upload, Forge performs a bounded streaming inspection of each staged ZIP. The guard:

- rejects empty or unreadable ZIPs;
- blocks archives containing APK or DEX payloads that strongly indicate a built artifact bundle;
- requires recognizable project/source structure such as Gradle files, Android manifests, package metadata, or a credible quantity of code/resource files;
- avoids extraction and scans at most 2,500 file entries;
- provides an explicit bypass for intentionally nonstandard source archives.

Checksum pairing and SHA-256 verification remain mandatory independently of the content guard.

## Authority and safety notes

- Header state is presentation only and grants no authority.
- ZIP inspection is heuristic and local; SHA-256 verification remains the integrity control.
- Workflow progress remains phase-based because GitHub does not expose truthful compile percentages.
