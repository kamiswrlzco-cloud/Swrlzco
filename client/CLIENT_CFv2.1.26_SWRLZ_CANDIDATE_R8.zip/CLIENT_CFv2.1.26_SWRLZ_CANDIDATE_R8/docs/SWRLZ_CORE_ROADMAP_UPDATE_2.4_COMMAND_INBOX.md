# SWRLZ-Core Roadmap Update 2.4 — Command Inbox

## Field-verified foundation

- SWRLZ-Core app can reach Local Node Server over same-device loopback.
- SWRLZ-Core app can reach Local Node Server over phone-to-phone LAN.
- Core Node admin settings, recent events, and session logs are reachable from the app.

## 2.4 target

Create the first server-to-client command loop.

### Implemented

- [x] Responsive status row layout for long Core Node versions.
- [x] Truthful Core Node state machine: configured, checking, reachable, unreachable.
- [x] Strict `/status` validation before success display.
- [x] Clean Core/admin error messages.
- [x] `Cmds` tab.
- [x] Pending command pull.
- [x] Admin safe-test command creation.
- [x] Action Phone acknowledge/reject/complete loop.

### Next

- [ ] Command cards instead of raw JSON.
- [ ] Action proposal preview UI.
- [ ] Safety gate labels per command.
- [ ] Teach-packet return path.
- [ ] Command execution audit trail.

