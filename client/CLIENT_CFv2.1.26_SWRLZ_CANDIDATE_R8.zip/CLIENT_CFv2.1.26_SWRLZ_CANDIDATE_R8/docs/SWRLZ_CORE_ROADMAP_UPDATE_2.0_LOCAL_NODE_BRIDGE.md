# SWRLZ-CORE Roadmap Update — Revision 2.0 Local Node Bridge

**Roadmap revision:** 2.0  
**Android build target:** `0.2.0-local-node-bridge` / code `7`  
**Patch label:** `2.0-LOCAL-NODE-BRIDGE`  
**Source ZIP:** `SWRLZ_CORE_2.0_LOCAL_NODE_BRIDGE_SOURCE.zip`

## Field-verified foundation carried forward

- 0.1.5 Context-Control repaired and phone-tested.
- CTXVIEW self-capture loop discovered, hotfixed, and phone-tested.
- 0.1.6 Identity + Provenance verified on device with visible build identity and `app.buildIdentity` context metadata.
- Project law remains active: **No invisible patches. No mystery APKs. Every build carries its nameplate.**

## New target: 0.2.0 Local Node Bridge Foundation

This revision separates the optional online Mentor from a local Core Node.

- **Mentor backend URL** remains the optional online planning/backend service.
- **Core Node URL** is a local-first SWRLZ node, usually another phone, Termux server, LAN device, or PC.
- The Android app can save a Core Node URL and encrypted pairing token.
- The Android app can test a Core Node with `/status`.
- Failure must remain graceful: local features continue even if the Core Node is missing.

## Implementation items

- [x] `versionCode = 7`
- [x] `versionName = "0.2.0-local-node-bridge"`
- [x] Build identity updated to `2.0-LOCAL-NODE-BRIDGE`.
- [x] Added `CoreNodeConfig` and `CoreNodeStatus` models.
- [x] Added Core Node URL storage in DataStore.
- [x] Added encrypted Core Node pairing token storage.
- [x] Added `CoreNodeApi.status()` client.
- [x] Added `TEST CORE NODE` button in Setup.
- [x] Added Local Core Node bridge status row on Home.
- [x] Added local node `/status` bridge metadata.
- [x] Added prototype `/pair` endpoint.

## Test checklist

1. Install APK and confirm Home shows `v0.2.0-local-node-bridge · code 7`.
2. Confirm Build Identity panel shows `2.0-LOCAL-NODE-BRIDGE`.
3. Open Setup and confirm Local Core Node Bridge section exists.
4. Save blank Core Node URL and confirm it reports Core Node disabled/not configured.
5. Enter fake Core Node URL such as `http://127.0.0.1:8787`, tap TEST CORE NODE, and confirm readable failure.
6. Confirm Mentor backend fields still work separately.
7. Confirm STANDARD context packet still includes `buildIdentity`.
8. Confirm no context viewer self-capture regression.

## Next phase after 0.2.0

- 0.2.1 Pairing + Device Identity
- 0.2.2 Teach Packet Sync
- 0.2.3 Action Proposal Queue
- 0.2.4 Dual-Phone Operator Mode
- 0.3.0 Real Teach Mode Recorder

## Core law

**Core Phone proposes. Action Phone verifies and executes. User approves risky actions. Both log.**
