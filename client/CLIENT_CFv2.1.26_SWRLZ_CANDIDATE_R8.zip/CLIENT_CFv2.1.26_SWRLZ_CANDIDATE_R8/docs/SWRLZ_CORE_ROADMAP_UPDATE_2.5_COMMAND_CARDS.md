# SWRLZ-Core Roadmap Update 2.5 — Command Cards

## Status

Patch 2.5 converts the working command bridge into a usable command-card interface.

## Completed in this patch

- [x] Bumped app identity to `0.2.5-command-cards`, code `11`.
- [x] Added visible patch label `2.5-COMMAND-CARDS`.
- [x] Added command-card parsing for server command JSON.
- [x] Added one-tap ACK / REJECT / COMPLETE controls per command card.
- [x] Auto-filled latest command ID after create, pending pull, or command list.
- [x] Kept manual command ID fallback for diagnostics.
- [x] Tightened Home system status layout for long Core Node version strings.

## Server compatibility

Designed to work with:

- `local-node-server-0.4-command-queue`
- `local-node-server-0.5-command-history`

## Next target: 2.6

Recommended next app update:

- Command polling toggle.
- Command card filters.
- Server command history viewer.
- Cleaner payload/result display.
- Optional action-phone role mode.
