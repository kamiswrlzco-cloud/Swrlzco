# Build Provenance Request

Use this prompt after Codespaces successfully builds an APK or fails with a real Gradle error.

```text
Before doing any more edits, give me a build provenance report.

Please summarize exactly what you did to get the Android build environment working and what happened during the APK build.

Include:

1. Current working directory when the successful/failed build command ran.
2. Exact commands you ran to install Android SDK / command-line tools.
3. Values of:
   - ANDROID_HOME
   - ANDROID_SDK_ROOT
   - PATH entries related to Android
4. Output of:
   - java -version
   - ./android/gradlew --version OR ./gradlew --version from the android folder
   - sdkmanager --list_installed
5. Whether you edited any SWRLZ source files. If yes, list every changed file and why.
6. Exact Gradle command used to build the APK.
7. Whether the build passed or failed.
8. If it passed, list the APK file path, APK filename, APK size, and SHA-256 checksum.
9. If it failed, list:
   - failing Gradle task
   - exact error message
   - file path and line number if shown
   - last 80 lines of the build log
10. Any temporary folders or leftover files created during setup.

Save this report as docs/BUILD_PROVENANCE_REPORT.md.
Do not make new source edits while generating this report.
```
