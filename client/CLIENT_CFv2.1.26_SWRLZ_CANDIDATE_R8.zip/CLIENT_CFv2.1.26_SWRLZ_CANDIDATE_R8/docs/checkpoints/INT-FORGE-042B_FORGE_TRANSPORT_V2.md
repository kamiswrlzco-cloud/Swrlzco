# INT-FORGE-042B — Forge Transport V2

Status: **SOURCE CANDIDATE ONLY**

## Scope

- protected CLIENT/SERVER source ZIP transport uses 4 MiB chunks in AUTO mode;
- each immutable Git blob is retried independently for bounded transient failures;
- HTTP 401 triggers an immediate authenticated branch reprobe before retrying the same blob;
- `Retry-After` and rate-limit signals participate in bounded retry delay;
- persisted completed-chunk blobs are remotely read back and verified by raw size + SHA-256 before reuse;
- SERVER receives CLIENT-equivalent protected-source chunk transport, evidence routing and transport manifests;
- CLIENT `ChatSettingsChoiceGroup` receives the missing `@Composable` annotation proven by workflow 30506148619.

## Preserved boundaries

No Android build, APK generation, GitHub write, workflow dispatch, installation, promotion, release, deployment, training, GGUF/model modification or Swurlzara profile modification is authorized or claimed.

The INT-AI-041F-A Model Rack/module behavior is not changed by this checkpoint.
