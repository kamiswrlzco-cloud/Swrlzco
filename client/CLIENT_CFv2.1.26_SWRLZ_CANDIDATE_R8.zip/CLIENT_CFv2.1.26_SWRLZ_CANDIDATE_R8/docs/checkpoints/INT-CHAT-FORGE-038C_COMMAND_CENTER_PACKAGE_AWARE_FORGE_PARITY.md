# INT-CHAT-FORGE-038C — Command Center + Package-Aware Forge + SERVER Parity

Date: 2026-07-27
Scope: CLIENT + SERVER source only.

## Implemented

- shared byte-identical `command-contract` catalog;
- CLIENT Chat composer drop-up quick actions and searchable/favoritable Command Center;
- SERVER Command Center catalog under Command & AI;
- Forge target selection: CLIENT / SERVER / BOTH / FILES / ask-auto;
- automatic protected ZIP checksum lookup with `.sha256`, `.sha256.txt`, `.sha` normalization;
- automatic protected ZIP manifest lookup;
- strict ZIP/checksum/manifest verification;
- CLIENT+SERVER atomic combo transaction while retaining separate identities and lanes;
- destination preview setting/default;
- SERVER Forge catch-up for generic ZIP repository-root expansion and package automation;
- Documentation Synchronization Policy and full documentation impact inventory.

## Explicitly unchanged

Protocol version/semantics, trust, device proof, Truth Firewall, mission authority, provider secret custody, provider network policy, permissions, ThemePack contract/assets, release/deployment authority.

## Evidence

Source/static verification only. Gradle, tests, APK assembly, workflow execution, device runtime, provider calls, GitHub writes, release, deployment, and installation are not claimed.
