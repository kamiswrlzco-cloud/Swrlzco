# INT-MSG-060A — Android CLIENT protocol-2 messaging

Date: 2026-08-01
Component successor: CLIENT CFv2.1.26 candidate R7 / VC130
Predecessor: CLIENT CFv2.1.26 candidate R6 / VC129 / SHA-256 `09d221ffff66feb56971525d039904a0e7cd135dfc89e65d3a13c5be2e0f3136`
Sibling successor: SERVER CFv2.1.26 candidate R10 / VC93

## Facts

- CLIENT creates and retains an encrypted app-private device proof.
- Registration, heartbeat, and disconnect requests present the proof header.
- Registration advertises protocol-2 messaging capability while remaining subject to SERVER trust policy.
- `ClientNodeMessaging` provides typed source APIs for message send, inbox polling, and correlated reply.
- Send requests carry protocol 2, communication envelope identifiers, idempotency and request headers, bounded payloads, and configurable synchronous wait.
- Inbox polling supports cursor, limit, type filtering, and bounded long polling.
- No message/approval UI was added that could fabricate SERVER state.

## Verification boundary

The CLIENT source participates in the 52/52 source and migration verification suite. Android compilation and device acceptance were not performed.
