# INT-AI-041F-A-R8 — Modular Model Rack + Expression EQ

Status: **SOURCE/STATIC CANDIDATE — REVIEW**

## Immutable lineage

- SERVER parent: `SERVER_CFv2.1.9_SWRLZ_CANDIDATE_R8.zip`
- SERVER parent SHA-256: `7557dfb23a1ee1f71b51f435b335becc9ee60bbac398532bced7a40809b75303`
- CLIENT parent: `CLIENT_CFv2.1.22_SWRLZ_CANDIDATE_R1.zip`
- CLIENT parent SHA-256: `49284e9a57d30a2b37912c32ac9a85fbb333d4a6ed620687c855469363d0ecd5`
- Verified external model: `SWRLZ-LFM-OPT-001A.gguf`
- Model SHA-256: `651cd5c40e4ef24de2ff12c2b53b257d15816ddd4346e2575e6768a6ec1d8590`
- Model size: `229315680` bytes
- SERVER successor: versionCode `67`, versionName `2.1.10-modular-model-rack-expression-eq-candidate-r1`
- CLIENT successor: versionCode `121`, versionName `2.1.23-modular-model-rack-expression-eq-candidate-r1`

The GGUF remains an external user-installed artifact. No model weights are embedded in either source package or APK configuration.

## Delivered vertical slice

| Surface | Delivered behavior |
|---|---|
| Model | SERVER inventories GGUFs and recognizes the optimized SWRLZ base only when both its SHA-256 and byte size match. |
| Speed | Per-model Eco, Balanced, Fast, Quality and Custom profiles coordinate context, output budget, threads and load policy. |
| Reasoning Depth | Quick, Balanced and Deep change response budget/profile density/validation emphasis; they do not retrain the model or claim new learned intelligence. |
| Expression EQ | Nine model-specific 0–100 controls shape warmth, energy, humor, directness, creativity, technical depth, skepticism, verbosity and mythic expression. |
| Modules | Declarative prompt capsules and EQ packs install and activate live. Packs are hash/size checked, compatibility gated and rollback-capable. |
| LoRA | The shared ABI and pack type are declared. Installation may preserve adapter bytes, but activation fails closed until the Android native bridge proves adapter support. |
| Rollback | SERVER retains the preceding per-model profile and preceding selected model for bounded rollback. |
| CLIENT control | A registered action-phone CLIENT can read/update the rack over same-subnet paired LAN using the existing device identity and a dedicated encrypted model-rack credential. |

## Authority boundary

The model rack configures reasoning equipment and expression. It does not grant or weaken:

- Truth Firewall;
- permissions or approvals;
- provenance or node trust;
- mission, tool, file or execution authority;
- Forge authority;
- provider credential authority.

Loopback SERVER diagnostics remain local. LAN writes require a registered, non-archived CLIENT identity, the `action-phone` role, same-subnet authorization and the dedicated pairing token. That token is scoped to model-rack configuration only.

## Model integration

1. Import `SWRLZ-LFM-OPT-001A.gguf` through the existing SERVER Model Vault.
2. SERVER hashes and parses the external file before staging it.
3. Exact SHA + byte-size identity marks it `VERIFIED_SWRLZ_BASE`.
4. Load and inference probes still decide activation and known-good status.
5. The embedded `swrlz.prompt.default_system` value is consumed only for the exact recognized optimized base.
6. Per-model settings are keyed by model SHA-256, so another GGUF receives an isolated profile.

The optimized model exposes `prompt_capsule_v1 + verified_state_v1 + lora_adapter_v1` metadata. This checkpoint makes prompt capsules and expression EQ live, continues deterministic verified-state boundaries, and leaves LoRA activation unavailable.

## Declarative module lifecycle

The Kapanion import discipline is implemented as:

`select .swrlzmod → bounded copy → inspect ZIP → validate manifest → verify payload hashes/sizes → type-check payload → atomic install → explicit activation`

Arbitrary APK, DEX, JAR, native library and script content is rejected. Archive traversal, undeclared payloads, unsupported types, incompatible model hashes, conflicts and invalid ranges fail closed.

Two built-in modules provide an immediately usable vertical slice:

- `Technical Focus` prompt capsule;
- `Warm Companion EQ`.

Two portable example packs are included beneath `docs/contracts/examples/model-rack/` and are packaged separately in the checkpoint handoff.

## Evidence

- `scripts/verify_int_ai_041f_a.py`: `36/36` PASS.
- Shared CLIENT/SERVER contract: byte-identical.
- Optimized model identity: size and SHA-256 verified.
- Source package scan: no `.gguf` or `.safetensors` payload.
- Kotlin grammar differential: parent `213` files / `7` parser limitations; successor `224` files / the same `7` file-pattern limitations. No new parser-failure class was introduced.
- Android compilation did not begin because Gradle `8.9` (SERVER) and `8.7` (CLIENT) were not cached and `services.gradle.org` was unreachable from this workspace.

Tree-sitter is supporting differential syntax evidence, not a Kotlin compiler substitute.

## Excluded and unclaimed

No model training, merging, quantization or weight modification occurred. No LoRA adapter was activated. No debug APK was produced. No device test, APK installation, GitHub write, workflow trigger, commit, push, publication, promotion, release or deployment occurred.

The candidate must remain in REVIEW until both Android projects compile and their paired-device integration path passes with a real external GGUF and pack import.
