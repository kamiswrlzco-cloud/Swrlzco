# INT-UX-025B-REV1 — Runtime Synchronization and Collaboration UX

Component: CLIENT
Baseline: CFv2.0.13
Target: CFv2.0.14

## Objective
Make authoritative changes observable immediately, establish SERVER-owned heartbeat authority with lag tolerance, surface CLIENT group creation/join controls, and add SERVER node-details and Mission Council foundations.

## Implemented
- SERVER is the canonical presence/heartbeat authority.
- Heartbeat cadence: 10 seconds.
- Progressive health: CONNECTED, DELAYED after 2 misses, UNAVAILABLE after 4, DISCONNECTED after 6.
- Administrative disconnect suppresses automatic reconnect until manual operator action.
- CLIENT persists the stable node ID and latest SERVER heartbeat receipt.
- CLIENT exposes visible Create Group and Join With Code controls.
- SERVER node menu opens a details dialog and Mission Council draft surface.
- Group, trust, identity, and Truth Firewall authority remain unchanged.

## Limitations
- Current transport is request/response HTTP. Immediate authoritative state is applied on the next active exchange; a future persistent event channel may reduce latency further.
- Mission Council is a draft/review foundation and does not enable unrestricted autonomous execution.
- APK/Gradle build and runtime verification were not run during source packaging.
