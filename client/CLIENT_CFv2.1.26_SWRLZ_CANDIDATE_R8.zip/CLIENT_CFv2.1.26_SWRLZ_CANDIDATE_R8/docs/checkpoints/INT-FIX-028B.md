# INT-FIX-028B — CLIENT connection truth and operational routing repair

## Evidence
The CLIENT could reach the SERVER discovery endpoint on port 8787 while registration and Groups failed with a connection attempt to port 8080. Source inspection proved that SERVER registration, heartbeat, disconnect, and Groups routes are dispatched by the advertised discovery/operational listener. Port 8080 is a minimal loopback compatibility surface, not the authoritative operational API base.

## Changes
- Operational registration, heartbeat, disconnect, and Groups traffic remains on the advertised endpoint.
- Discovery reachability no longer equals an online CLIENT session.
- A session is online only after registration succeeds.
- Durable enrollment and current-session state are displayed separately.
- Disconnect is local-first: heartbeat stops and the local session becomes disconnected before a best-effort SERVER notification.
- A failed remote disconnect acknowledgment cannot leave the CLIENT displayed as connected.

## Preserved laws
No local membership fabrication, no trust elevation, no identity merge by model/display name, and no deletion of enrollment lineage.
