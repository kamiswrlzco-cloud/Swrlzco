# INT-CMD-039P — Hierarchical Chat Command Palette + Capability Registry

Date: 2026-07-28
Component: CLIENT
Parent: `CLIENT_CFv2.1.20_SWRLZ_CANDIDATE_R1.zip`
Successor: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R1.zip`

## Approved scope

- hierarchical Command → subcommand navigation from Chat;
- basic typed command prompt in the Chat Command Center;
- canonical slash-path resolution and autocomplete suggestions;
- capability registry metadata rather than hardcoded execution behavior;
- Chat-context suggestions;
- local recent commands and pins/favorites;
- visible approval and availability classification;
- integration seam for Forge, missions, files, providers, profiles, connections, Chat, and system commands.

## Implementation

- preserves the existing `command-contract` stable command IDs and capability IDs;
- derives hierarchy from dotted command IDs;
- adds `CommandApproval`, `CommandAvailability`, and `CommandContext` metadata;
- adds canonical prompt, hierarchy traversal, contextual ranking, search, and exact typed resolution helpers;
- converts the Chat quick menu from flat actions to nested category/subcommand browsing;
- upgrades the full Command Center with typed prompt resolution, breadcrumbs, command detail, suggestions, pins, recents, and context recommendations;
- preserves insert-for-review behavior rather than creating a parallel executor;
- registers approved 039M organizer command vocabulary as `PLANNED` only;
- marks commercial provider commands `REQUIRES_CONFIGURATION` / `SENSITIVE` and does not enable them.

## Explicitly unchanged

No change to protocol versions, CLIENT/SERVER trust, identity proof, Truth Firewall, mission authority, Forge transaction authority, provider secret custody, filesystem permissions, local/remote semantics, repository authority, release/deployment authority, or ThemePack behavior.

## Validation state

- command-contract Kotlin compilation: PASS;
- command resolution/hierarchy smoke checks: PASS;
- INT-CMD-039P static regression gate: PASS;
- Android `:app:compileDebugKotlin` attempt: BLOCKED BEFORE COMPILATION because Gradle 8.7 was not cached and `services.gradle.org` was unreachable;
- APK assembly: NOT RUN;
- device validation: NOT RUN;
- GitHub workflow/commit/push/promotion/release/deployment/install: NOT RUN.
