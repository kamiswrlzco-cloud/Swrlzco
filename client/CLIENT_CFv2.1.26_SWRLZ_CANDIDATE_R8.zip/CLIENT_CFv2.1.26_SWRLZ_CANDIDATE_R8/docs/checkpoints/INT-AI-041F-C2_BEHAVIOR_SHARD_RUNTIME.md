# INT-AI-041F-C2 — Behavior Shard V1 CLIENT Contract Integration

CLIENT adopts versioned Model Rack protocol V2 (`/ai/model-rack/v2/...`) with the `BEHAVIOR_SHARD` enum value and `behavior_shard_v1` manifest validation rule so the paired CLIENT can decode, display, activate/deactivate, and preserve generation-checked control of behavior modules exposed by SERVER. SERVER retains a filtered V1 route for older peers.

Behavior import, payload validation, routing, compilation, and prompt assembly remain SERVER-owned. CLIENT receives no new execution authority.

## Provider visibility cleanup
- The legacy direct-device Gemini planner/client/key path is removed from active CLIENT code.
- Public branded remote-provider commands, profile targets, status rows, route selectors, probes, and settings are removed/hidden.
- GPT/OpenAI compatibility remains beneath the public surface for paired/legacy protocol compatibility; CLIENT does not advertise it or auto-select it from ordinary source-analysis wording.
- Legacy provider-contract enum/tag fields are retained only to decode older V1 payloads and explicit legacy text without changing the wire contract.

Mirror Profile v1.0.2, Harmonic Chaos EQ v1.0.0, Truth Firewall, permissions, approvals, trust, provenance, mission/Forge/file/tool authority, execution, model weights, training, local-time injection, output validation, and model verification are unchanged/out of scope.

No Android/Gradle build, APK build, GitHub write, workflow dispatch, promotion, release, deployment, installation, model/weight modification, or training was performed.
