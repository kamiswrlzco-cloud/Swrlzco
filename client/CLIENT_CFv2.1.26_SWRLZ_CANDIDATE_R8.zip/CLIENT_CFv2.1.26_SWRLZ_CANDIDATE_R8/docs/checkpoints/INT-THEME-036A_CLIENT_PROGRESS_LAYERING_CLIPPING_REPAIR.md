# INT-THEME-036A — CLIENT Progress Layering + Clipping Repair

Status: `IMPLEMENTED — SOURCE ONLY; BUILD/DEVICE RE-VERIFICATION PENDING`
Date: 2026-07-27
Target: CLIENT only
Source identity: `CLIENT CFv2.1.10`
Android identity: versionCode `108`, versionName `2.1.10-progress-layering-clipping-repair-v1`

## Authorization

`APPROVE INT-THEME-036A — REPAIR THEMED PROGRESS BAR LAYERING + CLIPPING, SOURCE ONLY`

## Parent lineage

- Parent package: `CLIENT_CFv2.1.9_SWRLZ.zip`
- Parent SHA-256: `87a09a5032751dbf74f5a277a6d9b0e1f9bc48e38e48006c50d0c107cd3d30ac`
- Parent checkpoint: `INT-THEME-035D`
- Parent Android identity: versionCode `107`, versionName `2.1.9-package-pair-repair-v1`
- The supplied parent ZIP and checksum receipt were hash-matched before extraction.
- CFv2.1.9 remains the rollback baseline and its successful CI debug-build evidence is not rewritten.

## Device evidence

The user supplied CFv2.1.9 screenshots from a real Android device showing the
Jester Glitch Dragon progress preview. The bar rendered, but the filled region and
streaming effects did not read as one contained track:

- the active filler began beneath the large left dragon cap rather than at the
  transparent track opening;
- highlight/particle effects were allowed to remain visible beyond the determinate
  progress boundary;
- the desired visual model is energy contained inside the track, under the frame,
  with the fill revealed rather than squeezed.

This is runtime visual evidence. It does not invalidate CFv2.1.9 compilation,
package integrity, protocol, trust, mission, Forge, or unrelated ThemePack behavior.

## Confirmed source causes

1. The Jester frame is `1024 x 126`. Alpha inspection of the center track opening
   places the clear horizontal window at approximately `x=207..898` and the clear
   vertical window at approximately `y=37..94`.
2. The old Jester runtime geometry used fixed dp insets (`28 / 20 / 10`) that were
   too permissive for the large left cap and top/bottom frame artwork at phone widths.
3. Determinate fill used a fractional parent clip correctly, but particle and
   highlight layers remained full-track siblings, allowing active motion to appear
   beyond the progress head.
4. The decorative frame already rendered after the main track block; this ordering is
   preserved and made explicit as an invariant.

## Implementation

### Artwork-calibrated Jester track window

`ThemedProgress.kt` now treats the declared dp values as lower bounds and additionally
enforces normalized Jester frame bounds:

- start inset: at least `20.5%` of component width;
- end inset: at least `12.5%` of component width;
- top inset: at least `30%` of component height;
- bottom inset: at least `25%` of component height.

Other themes retain their existing declarative geometry.

This repair is CLIENT-renderer-local; the shared ThemePack contract is unchanged.

### Active-window compositing

The asset-backed track now renders in this order:

```text
outer clipped component
└─ inner clipped track
   ├─ ambient underlay — full track, low alpha
   └─ active progress window
      ├─ fill texture — full track width, cropped by the active window
      ├─ particles — full track geometry, cropped by the active window
      └─ highlight — animated only inside the active window
└─ decorative frame — above all streaming/fill layers
└─ progress head — clamped to track travel
└─ truth-gated terminal effect
```

Determinate progress reveals `0 .. trackWidth * value`; it does not resize the
texture to the percentage. Unknown progress retains a moving indeterminate segment
without fabricating a percentage.

### Motion/accessibility truth preserved

- paused state still disables decorative motion;
- reduced-motion behavior remains authoritative;
- semantic progress value/state text is unchanged;
- success/failure/cancellation terminal effects remain state-gated.

## Files changed

- `android/app/src/main/java/sh/swurlz/core/ui/theme/ThemedProgress.kt`
- `android/app/build.gradle.kts`
- `README.md`
- `CHANGELOG.md`
- `CFv2.1.10_PROGRESS_LAYERING_CLIPPING_REPAIR_CHECKPOINT.md`
- `docs/checkpoints/INT-THEME-036A_CLIENT_PROGRESS_LAYERING_CLIPPING_REPAIR.md`
- `docs/engineering/ENGINEERING_LOG.md`
- `docs/releases/CLIENT_CFv2.1.10_PROGRESS_LAYERING_CLIPPING_REPAIR.md`
- `docs/evidence/INT-THEME-036A_RUNTIME_DIAGNOSIS.md`

## Preserved boundaries

No SERVER source, ThemePack contract, runtime theme asset, launcher identity,
startup choreography, protocol, connection, trust, Truth Firewall, identity proof,
permission, mission authority, Forge authority, notification authority,
accessibility automation, local/remote distinction, or offline-first behavior was changed.

The separately requested Chat auto-follow change is **not** part of this checkpoint
and remains separately approval-gated.

## Static verification boundary

Required for source-only completion:

- exact parent SHA-256 match;
- bounded changed-file diff;
- no ThemePack contract or runtime asset byte changes;
- Kotlin delimiter/resource-reference sanity;
- Jester normalized track calibration present;
- active particles/highlight nested inside the active clip window;
- frame draw remains after streaming/fill layers;
- archive CRC/path/root safety;
- deterministic source ZIP recreation;
- exact checksum/manifest binding.

Not run or claimed:

- Gradle/Kotlin/Android compilation;
- unit/instrumentation/UI tests;
- APK/AAB assembly or signing;
- GitHub workflow, commit, push, release, or deployment;
- device installation or final visual acceptance.


## Static verification result

Pre-package source verification: `PASS`

- parent ZIP/checksum match: PASS;
- bounded implementation/documentation delta: 5 modified paths + 4 new checkpoint/evidence/release paths;
- shared `android/theme-contract` tree: byte-identical to CFv2.1.9 (7 files);
- 103 `theme_*` runtime resources: byte-identical to CFv2.1.9;
- runtime asset catalog: byte-identical to CFv2.1.9;
- Android and visible source identity: CFv2.1.10 / versionCode 108;
- Jester midline transparent frame window independently measured at approximately `x=208..897`, consistent with the normalized runtime calibration;
- active fill/particles/highlight occur inside one draw-time clip before the decorative frame;
- changed Kotlin delimiter sanity: PASS;
- generated build outputs: none.

Archive/checksum/manifest verification is recorded in the external source handoff after packaging.

## Next gate

Build/device verification may be authorized separately after source package delivery.
