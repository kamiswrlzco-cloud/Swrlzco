# INT-CHAT-037A — CLIENT Chat Control Center + Personality Profile

Status: `IMPLEMENTED — SOURCE ONLY; BUILD/DEVICE VERIFICATION PENDING`
Date: 2026-07-27
Target: CLIENT only
Source identity: `CLIENT CFv2.1.11`
Android identity: versionCode `109`, versionName `2.1.11-chat-control-center-v1`
Parent: `CLIENT CFv2.1.10` / INT-THEME-036A

## Objective

Turn the existing one-toggle `Chat & Commands` Settings room into an operator-facing conversation control center while implementing the previously requested new-response-top follow behavior.

## Confirmed source baseline

CFv2.1.10 already provided:

- persistent Chat auto-follow;
- `↓ LATEST` detachment/resume behavior;
- Settings Control Center domain routing;
- local/remote reasoning separation;
- optional Gemini reasoning provider;
- Truth Firewall and approval boundaries.

## Implementation

### Conversation Flow

- Auto-follow remains separately persisted and can be disabled.
- New `followTarget` preference defaults to `Response top`.
- `Conversation bottom` preserves the legacy behavior.
- Response-top mode reserves trailing scroll extent inside the conversation list, allowing the latest assistant item to align at the viewport top without fabricating messages.
- New assistant content triggers a swift `animateScrollToItem(target, 0)` only while follow is armed.
- Manual upward scrolling detaches follow.
- `↓ LATEST` re-arms and uses the configured follow target.
- Sending a new user message re-arms follow for the next SWRLZ response.
- `autoOpenRuntimeEvents` controls whether ChatRuntimeBus/Forge milestones bring Chat to the foreground.

### Personality & Response

Persisted CLIENT-local profile:

- Base style: Adaptive SWRLZ / Engineer / Companion / Glitch Muse / Direct / Candid
- Detail: Compact / Balanced / Deep
- Warmth: Low / Balanced / High
- Energy: Low / Balanced / High
- Humor: Off / Light / Adaptive / Chaos
- Formatting: Natural / Balanced / Structured
- Emoji: Off / Light / Adaptive

The profile is normalized against allowed values before storage/use. Optional Gemini consultation receives an explicit profile directive. Deterministic runtime truth, safety gates, mission state, Forge state, and protocol semantics are not personality-controlled.

### Privacy & Context

The Chat settings room reiterates the authoritative Truth Firewall and local-first boundaries and links to existing sharing approvals rather than creating a parallel privacy policy.

## Files changed

- `android/app/src/main/java/sh/swurlz/core/model/ChatSettings.kt`
- `android/app/src/main/java/sh/swurlz/core/data/Prefs.kt`
- `android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt`
- `android/app/src/main/java/sh/swurlz/core/MainActivity.kt`
- `android/app/src/test/java/sh/swurlz/core/model/ChatSettingsTest.kt`
- `android/app/build.gradle.kts`
- current README/changelog/checkpoint/release/engineering/source-line documentation

## Documentation impact set

- SETTINGS / UX
- CHAT / RESPONSE BEHAVIOR
- PERSONALITY / REASONING ROUTING
- BUILD IDENTITY / LINEAGE
- CHECKPOINT / RELEASE / HANDOFF

Architecture and protocol contracts are intentionally unchanged.

## Verification

Static checks cover:

- Kotlin delimiter balance for changed source;
- ChatSettings allowed-value normalization and test-source presence;
- DataStore key/read/write symmetry;
- response-top follow target wiring from Prefs → shell → Chat;
- personality wiring from Prefs → Settings UI → optional reasoning prompt;
- no SERVER/protocol source delta;
- ZIP path/CRC/root/checksum/manifest verification at packaging.

Not run or claimed:

- Gradle/Kotlin/Android compilation;
- JUnit/instrumentation/UI tests;
- APK/AAB assembly or signing;
- device keyboard/scroll/animation acceptance;
- TalkBack/font-scale/orientation acceptance;
- GitHub workflow, commit, push, release, deployment, or installation.

## Deferred adjacent work

Not included here:

- theme quick-action icon/drop-up next to the Chat composer;
- automatic Chat Forge ZIP/SHA/manifest companion selection;
- learned terminology / alias confirmation such as `forgaroo → Forge`;
- INT-THEME-036C companion progress HUD + emerald endpoint calibration.
