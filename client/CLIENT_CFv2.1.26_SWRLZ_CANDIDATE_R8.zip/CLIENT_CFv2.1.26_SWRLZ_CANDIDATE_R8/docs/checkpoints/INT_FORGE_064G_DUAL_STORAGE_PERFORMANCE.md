# INT-FORGE-064G-DUAL-STORAGE-PERFORMANCE

## Authorized scope

Synchronized CLIENT and SERVER Forge correction for project-root UI blocking, repeated Downloads traversal, overlapping rescans, and the Android restriction that prevents selecting the public Download root through `ACTION_OPEN_DOCUMENT_TREE`.

## Implemented

- Public Downloads is the default incoming inbox.
- Explicit Android all-files-access settings handoff for Android 11+.
- Optional custom SAF inbox override retained.
- Project-root persistence and layout creation moved to background coroutines.
- Settings surfaces responsive setup status.
- Single-flight scan coordinator shared by automatic, manual, and upload-triggered scans.
- One-pass root and bounded child-folder snapshot reused for CLIENT and SERVER classification.
- Unchanged-document SHA-256 cache keyed by URI, name, size, and last-modified value.
- Full uncached source/evidence revalidation immediately before upload.
- Existing metadata ZIP, loose SHA/manifest, one-level extractor-folder, evidence, and CLIENT/SERVER/BOTH routing behavior preserved.

## Identity

- CLIENT: CFv2.1.26 R6 / VC129
- SERVER: CFv2.1.26 R9 / VC92

## Boundaries

No GitHub write, workflow run, Gradle Android compilation, APK build, install, device acceptance, promotion, release, or deployment was performed.
