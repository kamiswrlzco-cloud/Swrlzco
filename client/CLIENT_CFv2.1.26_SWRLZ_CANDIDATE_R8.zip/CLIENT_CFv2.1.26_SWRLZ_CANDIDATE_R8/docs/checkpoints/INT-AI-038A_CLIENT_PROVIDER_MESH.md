# INT-AI-038A — CLIENT Provider Mesh + Profile Library

Status: `SOURCE IMPLEMENTED — BUILD / LIVE PROVIDER / DEVICE VALIDATION PENDING`
Date: 2026-07-27
Target: CLIENT
Source identity: `CLIENT CFv2.1.13`
Android identity: versionCode `111`, versionName `2.1.13-provider-mesh-v1`
Parent: `CLIENT CFv2.1.12` (`INT-PROFILE-037B`)

## Objective

Make SWRLZ Chat provider-aware while keeping SWRLZ as the assistant identity and SERVER as the credential/execution boundary for OpenAI and Gemini.

## Implemented

- Shared `provider-contract` v1 and provider-tag parser.
- CLIENT provider snapshot runtime using existing authenticated Core Node connection semantics.
- Chat route overrides for GPT/OpenAI, Gemini, Council, Compare, Local Only, and SWRLZ Auto.
- Compact Chat provider status strip with CLIENT SWRLZ, SERVER, GPT, and Gemini state plus provider details/model controls.
- Chat & Commands → AI Providers settings for default route, provider-status visibility, explicit automatic-remote policy, model selection, and probe-all action.
- Canonical latest CLIENT/SERVER source-analysis intent routing to SERVER for checksum/manifest verification and sanitization before provider consultation.
- Profile library lifecycle metadata (`STABLE`, `TEST`, `DRAFT`), favorites, duplication, rename/store primitives, and quick assignment/switching on top of INT-PROFILE-037B inheritance/precedence.
- Existing direct-device Gemini path retained only as an explicit compatibility fallback; no CLIENT OpenAI secret storage was added.

## Preserved boundaries

No change to Truth Firewall semantics, trust authority, permissions, sensitive-action approval, mission authority, Forge authority, ThemePack truth, or offline-first fallback. Remote provider calls are not required for normal deterministic/local Chat paths.

## Remote execution boundary

CLIENT can discover provider state through SERVER. In INT-AI-038A, provider operational routes on SERVER are loopback-only pending verified device-proof integration for remote/LAN provider execution. CLIENT UI must surface unavailability rather than pretending remote providers are reachable.

## Validation boundary

Source-only static verification only. No Gradle/Kotlin compilation, test execution, APK/AAB assembly, real provider credential, provider probe, paid call, device acceptance, workflow, commit, push, release, deployment, or installation is claimed.
