# INT-CHAT-039J — Adaptive Chat Build-Evidence Repair

Status: **REPAIRED CANDIDATE — Android promotion still pending**

Parent candidate: CLIENT CFv2.1.19 / VC117 candidate v1
Candidate v2: `2.1.19-adaptive-chat-workspace-candidate-v2`

## Evidence

Workflow `30306467282` intentionally selected CLIENT only. Source resolution and package verification passed, the Android toolchain was configured, and Gradle reached `:app:compileDebugKotlin`. The compiler stopped at `ClientShellScreen.kt:1034:9` because `ProviderMeshStatusStrip` used experimental Material3 `ModalBottomSheet` without opting that function into `ExperimentalMaterial3Api`.

## Repair

Added `@OptIn(ExperimentalMaterial3Api::class)` to `ProviderMeshStatusStrip`. No broader Material3 behavior or Chat architecture was changed.

## Test-method repair

Added `scripts/verify_compose_experimental_optins.py` to the local precheck suite. The gate self-tests both negative and positive fixtures and scans production Kotlin for known experimental Compose APIs missing function/file opt-in. Candidate v2 passes both the self-test and full source scan.

This gate is deliberately supplementary: only a real Kotlin/Android compile can close the Promotion Gate.
