# INT-PROFILE-037B — CLIENT Distributed Profile Architecture

Status: source implemented; build/device verification pending.
Source: CLIENT CFv2.1.12 / versionCode 110 / `2.1.12-distributed-profile-architecture-v1`.
Parent: CLIENT CFv2.1.11 / INT-CHAT-037A.

## Implemented

- shared pure-Kotlin `profile-contract` module;
- deterministic profile inheritance and precedence;
- CLIENT endpoint, CLIENT→SERVER, provider and session assignment substrate;
- built-in CLIENT Main/Engineer, relationship, GPT, Gemini, and Local profiles;
- CLIENT-local profile registry persistence;
- Chat & Commands → Profiles & Routing Settings room;
- custom profile creation by inheriting from the currently assigned route/provider profile;
- existing Gemini reasoning prompt receives the resolved Gemini provider profile directive in addition to the existing Chat personality directive.

## Preserved

No mission state, approval policy, trust, permission, Forge authority, protocol truth, Truth Firewall behavior, provider credential behavior, network provider call behavior, or SERVER authority is changed by profiles.

## Deferred

Provider credentials/status/model discovery, `@gpt`/`@gemini` routing, Council/Compare execution, source-file dispatch, terminology learning, and provider network brokerage remain for later checkpoints.
