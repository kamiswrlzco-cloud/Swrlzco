# CLIENT CFv2.1.3 — Settings Control Center

- Replaced the flat CLIENT Settings screen with searchable domain submenus.
- Added persistent Chat auto-follow preference and detached-scroll behavior with a `↓ LATEST` resume control.
- Added persistent mission-start approval policy; `Always ask` blocks mission execution behind a dialog before the first Android action.
- Centralized Core/connection, Chat, Missions, Activity/notifications, Forge, Interface/Bubble, Brain/AI, Privacy/Security, and Developer/Diagnostics settings entry points.
- Keeps everyday action tabs focused on actions while configuration moves behind Settings.

Verification claim: source-level implementation until Gradle compilation completes.
