# INT-FIX-026C — Group Routing and Synchronization Truth Repair

## Objective
Repair the runtime group-list routing defect exposed by CFv2.0.16, enrich canonical membership responses, expose roster details, and prevent CLIENT UI from reporting synchronized group state when the group request failed.

## SERVER changes
- Registered `/v1/groups/list` in the authoritative group dispatcher.
- Added node-ID validation for list requests.
- Group-list responses now include role, membership state, leader ID, group status, and active-member count.
- Roster responses now include node label, role, membership state, presence state, and last-seen time.
- Group and membership truth remains SERVER-owned and Room-backed.

## CLIENT changes
- Added roster API support.
- Added truthful synchronization states: synchronizing, synchronized, group-sync error, and offline cache.
- Raw route errors are translated into readable messages.
- Group cards display role, membership state, leader, and member count.
- Open/Members retrieves the authoritative SERVER roster.

## Compatibility
Additive protocol response fields only. Existing request routes and fields are preserved.

## Verification boundary
Targeted static inspection and archive verification only. No Gradle build, APK build, workflow run, runtime test, release, or deployment was performed.
