# INT-FORGE-064D-DUAL-DOWNLOADS-PIPELINE

## Components

- CLIENT CFv2.1.26 R5 / VC128
- SERVER CFv2.1.26 R6 / VC89

## Bounded implementation

This synchronized checkpoint moves automatic Forge source discovery from the Project root to a separately selected public Downloads inbox. It supports metadata ZIP pairs without extraction and exact legacy loose companions, including one bounded extractor-created child directory.

Both Forge interfaces describe the exact source package and intended APK build before upload. The durable build watch preserves that identity through GitHub workflow observation. Successful workflow artifacts are safely unpacked and the actual APK is stored under `Download/<projectName>/apk/`.

Repository CI updates are prepared under `repo-patches/swrlz-core/`: schema-2/metadata-aware resolver and verifier files target the current `scripts/ci` paths, and a bounded APK Router workflow patch adds source/build descriptions to notices, summaries, and artifact provenance.

## Boundaries

No GitHub write, workflow dispatch/run, Gradle build, APK build, installation, device acceptance, promotion, release, or deployment was performed.
