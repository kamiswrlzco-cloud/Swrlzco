# CFv2.1.5 — AAPT2 CI Portability Hotfix

## Trigger

The GitHub Actions build for CLIENT CFv2.1.4 reached Android resource processing and failed because
`android/gradle.properties` forced AAPT2 to `/opt/aapt2-wrap/aapt2`, a path that does not exist on
the hosted Ubuntu runner.

## Change

Removed the `android.aapt2FromMavenOverride` property. The Android Gradle Plugin can now use its
normal AAPT2 resolution/toolchain behavior.

## Preserved

All CFv2.1.4 Forge + Repository Console behavior is retained.

## Verification state

- Archive integrity: verified after packaging.
- Active Gradle property pointing at `/opt/aapt2-wrap/aapt2`: removed.
- GitHub Actions compilation: pending upload/build of CFv2.1.5.
- Device verification: pending successful artifact and on-device smoke test.
