# INT-THEME-035D — CLIENT Package Pair Repair

Status: `IMPLEMENTED — PACKAGE PAIR VERIFICATION PENDING`
Date: 2026-07-26
Target: CLIENT only
Source identity: `CLIENT CFv2.1.9`
Android identity: versionCode `107`, versionName `2.1.9-package-pair-repair-v1`

## Objective

Repair the canonical source ZIP/checksum/manifest contract after both automatic
workflows stopped before compilation on the published CFv2.1.8 manifest.

## Confirmed evidence

- PR #1 merged CFv2.1.8 to `main` at
  `bc80d7a4d28d656f640ac1a511b9ae340e8b45ee`.
- Source Package Integrity run `30222384992` selected the expected CFv2.1.8 ZIP.
- APK Router run `30222384996` passed resolver tests and selected the expected
  CFv2.1.8 ZIP/SHA pair.
- Both runs failed because the manifest used `sourcePackage` and `bytes` rather
  than canonical `zip` and `size_bytes`, and omitted `verified: true`.
- No Kotlin/Android compilation occurred and no APK was produced.

## Implementation

- Preserved CFv2.1.8 as immutable failed lineage.
- Advanced CLIENT identity to CFv2.1.9 / versionCode 107.
- Preserved all CFv2.1.8 application behavior.
- Prepared a canonical manifest containing `zip`, `sha256`, `size_bytes`, and
  `verified: true`, while retaining checkpoint, parent, scope, and verification
  metadata.
- Synchronized source identity, changelog, engineering, release, and checkpoint
  documentation.

## Preserved boundaries

No theme rendering, launcher, startup, progress, Kapanion, SERVER, protocol,
trust, Truth Firewall, identity proof, permission, mission, Forge authority,
local/remote, accessibility-automation, or offline-first behavior changed.

## Verification boundary

Required before promotion:

- exact ZIP/checksum/manifest pairing;
- archive CRC and path safety;
- Android identity and source-root checks;
- source behavior diff limited to package identity and documentation;
- repository verifier pass.

Build, APK, installation, runtime, release, and deployment are not claimed until
direct evidence exists.
