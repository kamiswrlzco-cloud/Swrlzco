# INT-FORGE-064B-CLIENT-R4

Candidate: `CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R4`  
Android identity: `versionCode 127` / `2.1.26-project-root-forge-auto-detect-r4`  
Parent: `CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R3.zip`  
Parent SHA-256: `fd6a65ba7043be4870d222835b9c61b95dbf493b42b03253db813b36ac4cbda8`

## Implemented

- Uses the persisted Project root as the automatic discovery boundary.
- Recursively finds verified CLIENT and SERVER source packages.
- Accepts either source + metadata ZIP or source + loose SHA-256 + manifest.
- Auto-detects CLIENT, SERVER, or BOTH from verified package evidence.
- Selects the highest versionCode and candidate revision; equal-rank conflicting hashes fail closed.
- Optionally stages the matching checkpoint evidence bundle when its delivery manifest names the selected packages.
- Runs scan, selection, staging, and upload from one explicit operator action.
- Reuses unresolved transaction IDs and reconciles transient GitHub 5xx/read-back failures before another commit.
- Adds a RECONCILING runtime state and gives current successful workflow evidence precedence over stale local failure text.

## Preserved boundaries

No SERVER source change, GitHub write, CI bootstrap, workflow run, Gradle/APK build, installation, device acceptance, promotion, release, or deployment was performed by this source-only checkpoint.
