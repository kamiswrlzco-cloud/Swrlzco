# INT-FORGE-039F + INT-FORGE-039N — Chunked Source Transport + ZIP-Only Build Eligibility

Status: **SOURCE CANDIDATE — Android build and repository-CI patch application pending**

Candidate: CLIENT CFv2.1.20 CANDIDATE_R1  
Version code: 118  
Version name: `2.1.20-forge-chunked-transport-optional-evidence-candidate-r1`

## Evidence that triggered the checkpoint

SERVER CFv2.1.8 R3 passed local ZIP/SHA/manifest validation, created the small manifest Git blob, then streamed the ~40 MiB source ZIP to 100% before GitHub returned 401. Immediate credential re-probe remained authenticated. The failure is therefore treated as a large REST Git-blob transport/finalization defect, not proof that the credential is invalid.

## CLIENT transport implementation

Protected CLIENT/SERVER source ZIPs support `AUTO`, `DIRECT`, and `CHUNKED` transport modes.

- `AUTO` is the default and chunks protected source ZIPs above 8 MiB.
- `CHUNKED` forces deterministic 8 MiB chunks.
- `DIRECT` preserves the legacy single Git-blob path and remains subject to GitHub single-blob/request constraints.
- Each chunk receives SHA-256 evidence.
- The complete ZIP receives a whole-file SHA-256.
- A final `<stem>.transport.json` records component, canonical ZIP name, whole size/hash, chunk order/path/size/hash, and optional supplied-evidence locations.
- Successfully created chunk Git blob SHAs are cached per repository/package/chunk so a retry can reuse already-created blobs instead of restarting every completed chunk.

Chunk transport does not merge CLIENT and SERVER authority. `BOTH` still represents two independent source identities.

## Optional sidecar contract

Build eligibility now requires the protected source ZIP only.

- Missing checksum: allowed.
- Missing manifest: allowed.
- Supplied checksum: parsed and verified against the ZIP; disagreement blocks.
- Supplied manifest: canonical ZIP/hash/verified fields are validated; malformed or contradictory evidence blocks.
- Canonical promotion policy may still require stronger evidence than build eligibility.

## Repository CI handoff

`repo-patches/INT-FORGE-039F-039N/` contains an unapplied repository working-tree patch for:

- root APK router path triggers;
- direct-ZIP or chunk-transport source resolution;
- verified runner-temp chunk reassembly;
- optional checksum/manifest verification;
- resolver regression tests.

The patch is not committed or pushed by this source checkpoint.

## Truth boundary

A local Android compile was attempted but stopped before compilation because Gradle 8.7 was not cached and the environment could not resolve `services.gradle.org`. No Android compile success, APK build, device validation, GitHub workflow dispatch, repository commit/push, release, deployment, or SERVER source modification is claimed by this checkpoint.
