# INT-CHAT-039I — Adaptive Chat Workspace Candidate

Status: **SOURCE CANDIDATE — promotion gate not yet complete**

Parent: CLIENT CFv2.1.18 / VC116
Planned successor identity: CLIENT CFv2.1.19 / VC117 / `2.1.19-adaptive-chat-workspace-candidate-v2`

## Runtime evidence entering the checkpoint

The supplied device screenshots show CFv2.1.18 / VC116 running on-device. This proves the parent line advanced beyond the earlier profile-store compile blocker, but it does not validate the new 039I candidate.

## Acceptance requirements

- Conversation owns the flexible viewport.
- The large onboarding hero appears only before a user conversation starts and stays collapsed while the IME is visible.
- Reasoning Mesh is a compact always-available strip and expands on demand into a provider/routing sheet.
- Bottom version/navigation chrome hides while the keyboard is visible in Chat.
- Secondary Forge/companion telemetry collapses after conversation starts and while typing.
- Composer is compact, ThemePack-aware, grows up to a bounded number of lines, and keeps the Kapanion/Command Center entry point.
- Existing response-top follow, manual detach, and LATEST reattachment semantics are preserved.
- No mission, provider, trust, Truth Firewall, approval, permission, Forge authority, or protocol semantics are weakened.

## Implementation

- Added pure `ChatWorkspacePolicy` so IME/conversation state resolves presentation without touching operational authority.
- Added `ChatWorkspacePolicyTest` acceptance vectors.
- `ClientShellScreen` reads IME insets and suppresses CLIENT bottom version/navigation chrome only while Chat is keyboard-active.
- Replaced the permanently expanded Reasoning Mesh card with `ProviderMeshCompactBar` plus an on-demand `ProviderMeshExpandedPanel` bottom sheet.
- Added `ChatCompactComposer` with active ThemePack Kapanion quick-actions entry, one-to-five-line growth (one-to-four with IME), and bounded send affordance.
- Secondary Forge/companion status is retained on the empty-chat surface and removed from the active typing workspace.

## Validation completed locally

- Requirement acceptance scan: PASS after implementation.
- `ChatWorkspacePolicy` compiles with local Kotlin compiler and executable acceptance vectors pass.
- Kotlin parser pass on the changed Compose source reached only expected unresolved Android/Compose symbols because this environment has no Android SDK/Gradle dependency cache; no parser-level syntax diagnostic was observed.
- Full Android Gradle compile/build remains **pending** and is required before this candidate may be promoted as a normal CF successor under the standing SWRLZ Promotion Gate.


## Build evidence feedback — INT-CHAT-039J

GitHub workflow `30306467282` selected only the CLIENT candidate as intended, verified the source package, configured the Android toolchain, and reached `:app:compileDebugKotlin`. Compilation stopped at `ClientShellScreen.kt:1034:9` because the new `ProviderMeshStatusStrip` called experimental Material3 `ModalBottomSheet` without opting that enclosing function into `ExperimentalMaterial3Api`. No later Kotlin error can be inferred from that run because compilation stopped at this blocker.

Candidate v2 adds the narrow `@OptIn(ExperimentalMaterial3Api::class)` annotation to `ProviderMeshStatusStrip`. It also adds `scripts/verify_compose_experimental_optins.py`, a compile-sensitive regression precheck that detects known experimental Compose API calls lacking function/file opt-in. The script self-test and full CLIENT Kotlin-source scan pass. This remains a candidate until a real Android compile/build turns green.
