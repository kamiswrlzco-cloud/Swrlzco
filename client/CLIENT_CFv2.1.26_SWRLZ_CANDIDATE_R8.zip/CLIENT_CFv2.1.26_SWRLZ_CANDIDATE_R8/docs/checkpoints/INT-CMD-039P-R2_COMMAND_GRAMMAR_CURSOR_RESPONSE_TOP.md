# INT-CMD-039P-R2 — Parent/Child Command Grammar + Chat Precision Repairs

Date: 2026-07-28
Component: CLIENT
Parent: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R1.zip`
Successor: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R2.zip`

## Approved scope

- adopt `/parent (child) [instructions]` as the clear visible Chat command grammar;
- make the command list easy to browse by parent → action/subcommand;
- preserve freeform natural instructions after the structured prefix;
- place the Chat input caret at the end of command text inserted from Command Center/quick menu;
- correct response-top following so the newest SWRLZ response lands at the actual top anchor rather than approximately near it.

## Implementation

- command catalog adds structured action metadata plus insertion/display helpers;
- hierarchy now derives action-first menu paths, adding selector depth only where multiple presets share one action;
- `/files` organizer vocabulary is simplified to generic scan/organize/duplicates/undo/keep-organized actions while retaining legacy names as aliases;
- structured prompt parsing resolves `/parent (child) ...` and retains legacy tokenized slash resolution;
- Command Center and quick menu display the new grammar and insert structured command text;
- Chat composer uses `TextFieldValue` with end-selection on external draft insertion;
- response-top layout reserves a full viewport as trailing scroll slack and verifies the animated target at zero offset.

## Truth boundary

039M file actions remain `PLANNED`. This checkpoint does not implement filesystem scanning, moving, directory creation, deletion, background monitoring, or Storage Access Framework execution.

No protocol, SERVER, trust, identity, Truth Firewall, mission authority, Forge authority, provider custody, repository authority, release, deployment, or installation behavior is changed.

## Validation boundary

Source/static checks are required for this R2 package. Android compilation/APK build and device validation remain separate evidence states and are not claimed by this checkpoint.
