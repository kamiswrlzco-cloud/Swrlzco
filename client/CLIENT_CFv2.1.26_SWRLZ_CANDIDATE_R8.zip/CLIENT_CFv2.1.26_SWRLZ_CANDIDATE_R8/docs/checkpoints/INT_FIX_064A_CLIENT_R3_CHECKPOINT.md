# INT-FIX-064A-CLIENT-R3 — GitHub Forge import repair

Component: CLIENT  
Candidate: `CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R3`  
Android identity: versionCode `126`; versionName `2.1.26-forge-metadata-bundle-compile-fix-r3`  
Parent: `CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R2.zip`  
Parent SHA-256: `ac248bbdcc3db2d57f64fc5270864c0b93c72ee10e0c34fbd435afbb76c8ec83`

## Authorized repair

- Add the four missing `sh.swurlz.core.github` imports required by `GitHubForgeScreen.kt`:
  - `ForgeAutomatedBuildRunner`
  - `ForgeAutomationPreferences`
  - `ForgeBuildLedger`
  - `ForgeBuildTarget`
- Preserve the INT-FORGE-064A source/metadata bundle implementation.
- Advance CLIENT identity to R3 / VC126.
- Add focused import regression verification.

## Build evidence that triggered the repair

GitHub workflow `30700898714` reached `:app:compileDebugKotlin` and reported unresolved references for the four symbols above. The source files defining those symbols were present; the screen imports were missing. Remaining compiler messages were downstream type-inference cascades.

## Boundary

Source-only repair. No SERVER change, GitHub write, workflow dispatch, Gradle/APK build, installation, promotion, release, or deployment is claimed.
