# INT-FIX-060C — CLIENT compiler repair

Date: 2026-08-01
Component successor: CLIENT CFv2.1.26 candidate R8 / VC131
Direct parent: CLIENT CFv2.1.26 candidate R7 / VC130 / SHA-256 `ab453b8cc213e65ad10d99e5d9cf3bdb4cc77974b72dfb5f73ca8eaa9a63ac2e`
Sibling successor: SERVER CFv2.1.26 candidate R11 / VC94
Workflow evidence: `30722649056`

## Repair

`ClientNodeProofStore` now uses the alias-based `MasterKeys` API and argument order provided by the project-pinned `androidx.security:security-crypto:1.0.0` dependency. No dependency upgrade or cryptographic downgrade was introduced. Device proof remains encrypted and app-private.

## Preserved behavior

Protocol-2 registration, heartbeat, disconnect, send, inbox, reply, proof binding, idempotency, offline-first behavior, trust boundaries, and Truth Firewall behavior remain unchanged.

## Verification boundary

Focused source verification and package-integrity checks were performed. Android compilation and APK production were not performed under this source-only checkpoint.
