# INT-FIX-027D — Groups route compatibility and user-facing error sanitation

## Evidence

A CLIENT connected to a SERVER returned a structured discovery error for `/v1/groups/list`:

- HTTP error payload used nested `error.code` and `error.message` fields.
- The CLIENT parser only read top-level `code` and `detail` fields.
- As a result, raw JSON was rendered in the Groups workspace and notification surface.

Inspection of the canonical source packages established that CLIENT CFv2.0.18 calls the versioned `/v1/groups/*` contract and SERVER CFv2.0.17 implements those exact routes. The observed `Discovery route not found` response therefore indicates that the installed/running SERVER does not contain the current Groups protocol implementation, rather than a mismatch between the two canonical source packages.

## Repair

- Parse both canonical top-level group errors and nested discovery/compatibility errors.
- Map nested `NOT_FOUND` route failures to a concise compatibility message.
- Preserve the raw payload in `Result.payload` for developer diagnostics.
- Prevent Create Group and Join With Code actions until authoritative group-list synchronization succeeds.
- Preserve SERVER ownership of membership truth; no local fallback or fabricated membership was added.

## Scope

CLIENT source only. SERVER CFv2.0.17 was inspected and required no source change.

## Exclusions

No APK build, installation, runtime execution, GitHub operation, workflow dispatch, release, or deployment.
