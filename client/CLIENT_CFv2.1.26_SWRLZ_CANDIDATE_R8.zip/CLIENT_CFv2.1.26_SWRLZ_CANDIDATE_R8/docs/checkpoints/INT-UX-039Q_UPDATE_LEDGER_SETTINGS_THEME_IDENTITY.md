# INT-UX-039Q — Update Ledger, Settings Navigation/IA, and Theme Identity Roles

Date: 2026-07-28
Component: CLIENT
Parent: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R2.zip`
Successor: `CLIENT_CFv2.1.22_SWRLZ_CANDIDATE_R1.zip`

## Approved scope

- make the header Kapanion open a local interactive Update Ledger;
- provide a left-side version selector and a larger right-side patch-note detail pane;
- let Chat answer evidence-aware questions about patch notes, latest update highlights, and version comparisons;
- expose `/updates (latest)`, `/updates (ask)`, and `/updates (compare)` in the Command Center;
- repair Android Back behavior so CLIENT tabs and nested Settings pages pop one application level before Android owns the true root;
- reorganize Settings so Brain & AI is nested under Chat & Commands and Messages & Bubble is nested under Activity & Notifications;
- add primary/complementary ThemePack role identity so SWRLZ-owned CLIENT/SERVER/Fusion bubble surfaces can be visually distinct without recoloring launcher identity.

## Implementation

### Update Ledger

`UpdateLedgerCatalog` is a bundled, offline catalog of version/checkpoint summaries and sections. `UpdateLedgerDialog` renders a version rail on the left and selected notes on the right. The header Kapanion is the entry control.

The dialog can seed Chat with an update-specific question or a latest-update summary request. Chat recognizes patch-note information requests before ordinary provider/intent routing and answers them locally from the catalog. The catalog preserves evidence wording rather than treating source, build, device, promotion, release, or deployment states as interchangeable.

### Settings and Back

CLIENT root tabs now consume Back only while a non-Core tab is selected, returning to Core before Android owns Back at the true root. Settings child pages consume Back only while a nested page is active.

Settings information architecture now separates:

- `Chat & Commands` → conversation/personality/privacy plus `Brain & AI`;
- `Brain & AI` → local/private-node reasoning overview plus provider/profile routing surfaces;
- `Activity & Notifications` → notification controls plus `Messages & Bubble`;
- `Theme & Interface` → visual presentation and motion settings.

### Theme identity roles

`ThemeIdentityManager` derives role-specific bubble colors from the selected ThemePack palette:

- CLIENT bubble: complementary/secondary palette role;
- SERVER bubble: tertiary role;
- Fusion bubble: secondary/tertiary blend.

The owned bubble bitmap receives a bounded alpha-tint overlay. The launcher resource/alias is not recolored by this operation. Android/SystemUI may add its own app/launcher badge to a system bubble; that badge is outside SWRLZ styling authority and is not represented as independently recolorable.

## Truth boundaries

The CFv2.1.21 rescue lineage still exposes only `Glitch Dragon Glass` in the selectable runtime registry. INT-UX-039Q adds generic role logic but does **not** restore the full ThemePack visual asset/launcher-alias line. Full visual restoration remains a later merge from the preserved full visual lineage.

This checkpoint also does **not** implement INT-CMD-039P-R3. Generic `/parent (child)` execution dispatch and the reported subcommand-insertion repair remain separately scoped work. It does not implement INT-FILE-039M filesystem execution.

No SERVER source, protocol, trust, Truth Firewall, mission authority, Forge authority, provider custody policy, repository authority, release, deployment, or installation behavior is changed.
