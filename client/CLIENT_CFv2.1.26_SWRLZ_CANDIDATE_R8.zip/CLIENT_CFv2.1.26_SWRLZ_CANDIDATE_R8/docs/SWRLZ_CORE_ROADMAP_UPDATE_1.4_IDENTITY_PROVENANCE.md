# SWRLZ-CORE Roadmap Update 1.4 — Identity + Provenance Nameplate

**Roadmap revision:** 1.4  
**Patch label:** 1.4-IDENTITY-PROVENANCE  
**Android version target:** `0.1.6-identity-provenance`  
**Android version code target:** `6`  
**Source ZIP:** `SWRLZ_CORE_1.4_IDENTITY_PROVENANCE_SOURCE.zip`

## Why this update exists

The CTXVIEW hotfix successfully changed runtime behavior, but the installed app still displayed the old `0.1.5-context-control · code 5` identity. That made it harder to prove which APK was installed during phone-side testing.

Revision 1.4 introduces a new project law:

```text
No invisible patches.
No mystery APKs.
Every build carries its nameplate.
```

## Added to the roadmap

### 0.1.6 — Identity + Provenance Nameplate

- `IDENTITY-001` — Android version bump for every patch.
- `IDENTITY-002` — Visible Home-screen build identity panel.
- `IDENTITY-003` — Build identity inside SWRLZ context packets.
- `IDENTITY-004` — Build provenance report includes identity fields.
- `IDENTITY-005` — No invisible patches project law.

## Expected visible app result

Home should show:

```text
v0.1.6-identity-provenance · code 6
▸ BUILD IDENTITY
Patch: 1.4-IDENTITY-PROVENANCE
Roadmap: 1.4
Build line: Build Mesh / CTXVIEW self-capture hotfix + identity provenance
Source: SWRLZ_CORE_1.4_IDENTITY_PROVENANCE_SOURCE.zip
Law: No invisible patches · No mystery APKs
```

## Expected context result

When the app observes itself in STANDARD or DETAILED mode, the `app` object should include:

```json
"buildIdentity": {
  "appVersionName": "0.1.6-identity-provenance",
  "appVersionCode": 6,
  "patchLabel": "1.4-IDENTITY-PROVENANCE",
  "roadmapRevision": "1.4",
  "buildLine": "Build Mesh / CTXVIEW self-capture hotfix + identity provenance",
  "sourceZip": "SWRLZ_CORE_1.4_IDENTITY_PROVENANCE_SOURCE.zip"
}
```

In MINIMAL mode, app version/build identity remains suppressed by privacy reduction.

## Expected provenance result

`APK_DOWNLOAD/BUILD_PROVENANCE_REPORT.md` should include a `SWRLZ Build Identity` section with Android version name/code, patch label, roadmap revision, build line, source ZIP, and patch notes.

## Acceptance tests

- [ ] Build succeeds through `bash scripts/install_android_sdk_and_build.sh`.
- [ ] APK installs over the previous CTXVIEW hotfix without uninstalling, if the signing key matches.
- [ ] Home shows `0.1.6-identity-provenance · code 6`.
- [ ] Home shows `Patch: 1.4-IDENTITY-PROVENANCE`.
- [ ] STANDARD context includes `buildIdentity`.
- [ ] DETAILED context includes `buildIdentity` plus bounds.
- [ ] MINIMAL context suppresses detailed app identity as expected.
- [ ] CTXVIEW self-capture remains fixed.
- [ ] Build provenance report includes identity fields.

## Next major update after this

After this identity layer is verified, the next large feature line should be `0.2.0 Local Node Bridge Foundation`: Core Node URL, pairing token, `/status`, device handshake, logs, teach packets, and dual-phone separation between Core Phone and Action Phone.
