# CLIENT CFv2.1.14 — Command Center + Package-Aware Forge

Source successor for `INT-CHAT-FORGE-038C`. Adds Chat quick-action/Command Center discovery, package target selection, ZIP/checksum/manifest companion handling, combo CLIENT+SERVER staging, and documentation synchronization. Static/source evidence only; build and device acceptance pending.
