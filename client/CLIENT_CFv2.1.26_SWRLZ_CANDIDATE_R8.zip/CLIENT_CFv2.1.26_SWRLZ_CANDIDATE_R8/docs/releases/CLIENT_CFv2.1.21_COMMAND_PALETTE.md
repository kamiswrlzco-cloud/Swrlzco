# CLIENT CFv2.1.21 — Hierarchical Chat Command Palette Candidate R1

Checkpoint: `INT-CMD-039P`

- versionCode: `119`
- versionName: `2.1.21-command-palette-hierarchy-capability-registry-candidate-r1`
- parent: CLIENT CFv2.1.20 R1
- status: SOURCE/STATIC VERIFIED CANDIDATE; Android compile remains evidence-gated

Adds nested command/subcommand browsing, typed canonical command prompt resolution, context-ranked suggestions, local pins/recents, and visible approval/availability metadata while retaining the existing insert-for-review command model.

This candidate does not implement the 039M file organizer itself. Organizer command paths are registered as `PLANNED` so UI discovery is ready without falsely representing runtime availability.
