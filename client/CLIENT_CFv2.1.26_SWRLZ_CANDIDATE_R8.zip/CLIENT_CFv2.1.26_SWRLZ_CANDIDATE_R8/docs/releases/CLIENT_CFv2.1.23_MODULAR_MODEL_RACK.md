# CLIENT CFv2.1.23 — Modular Model Rack + Expression EQ Candidate R1

Checkpoint: `INT-AI-041F-A-R8`

- Advances CLIENT from the immutable CFv2.1.22 R1 source parent to versionCode `121`.
- Adds Brain & AI → Model Rack & Expression EQ.
- Shows SERVER GGUF inventory and exact optimized-base identity.
- Exposes per-model Speed, truthful Reasoning Depth, context/output controls and nine Expression EQ sliders.
- Exposes prompt/EQ module activation state plus profile/model rollback.
- Sends generation-checked requests over the existing Core Node connection with registered device identity, action-phone role and pairing token.
- Keeps SERVER authoritative for validation, persistence, activation and rollback.
- Surfaces immutable Truth Firewall, permission, approval, provenance, trust, mission, Forge and execution boundaries.
- Passes the paired `36/36` source/static/model-identity gates.
- Android compilation did not begin because Gradle 8.7 was not cached and its distribution host was unreachable.

No GGUF bytes, LoRA activation, APK, device result, installation, repository write, workflow, promotion, publication, release or deployment is included or claimed.
