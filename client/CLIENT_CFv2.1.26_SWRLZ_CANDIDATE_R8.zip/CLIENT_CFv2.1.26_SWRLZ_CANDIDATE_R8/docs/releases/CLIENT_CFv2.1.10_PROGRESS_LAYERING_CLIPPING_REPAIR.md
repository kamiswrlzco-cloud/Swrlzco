# CLIENT CFv2.1.10 — Progress Layering + Clipping Repair

Checkpoint: `INT-THEME-036A`

CLIENT CFv2.1.10 is a CLIENT-only presentation repair over verified CFv2.1.9.

It recalibrates the Jester Glitch Dragon track to the actual transparent frame
opening, keeps ambient energy as an underlay, clips particles/highlight to the
active progress window, and reveals the full-width fill texture through that window.
The decorative shell remains above streaming effects.

Android identity: versionCode `108`,
versionName `2.1.10-progress-layering-clipping-repair-v1`.

No ThemePack contract/assets, SERVER, protocol, trust, mission, permission, Forge,
local/remote, or offline-first semantics changed.

Source-only static verification is required before delivery. Compilation, APK/device
acceptance, GitHub publication, release, deployment, and installation are not claimed.
