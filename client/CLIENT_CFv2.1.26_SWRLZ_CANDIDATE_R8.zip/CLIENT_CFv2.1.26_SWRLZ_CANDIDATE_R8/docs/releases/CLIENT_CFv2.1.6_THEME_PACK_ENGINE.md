# CLIENT CFv2.1.6 — ThemePack Engine

CLIENT gains a declarative ThemePack registry shared with SERVER, thirteen independently selectable built-in identities, staged settings previews, Jester Core Ignition, and semantic layered progress across missions, overlays, Forge, workflows, and repository work.

Existing Theme Armor IDs migrate without replacement. Unknown progress remains indeterminate, terminal effects require real terminal state, reduced motion is static, and decorative art cannot own authority.

This is a source-only release candidate. Static integrity checks passed. Android compilation, APK build, device acceptance, and repository publication are pending separate authorization.

