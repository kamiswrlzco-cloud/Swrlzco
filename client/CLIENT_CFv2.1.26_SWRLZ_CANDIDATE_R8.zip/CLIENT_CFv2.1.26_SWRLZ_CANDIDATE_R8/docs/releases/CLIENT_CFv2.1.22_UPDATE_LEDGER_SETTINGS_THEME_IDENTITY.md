# CLIENT CFv2.1.22 — Update Ledger + Settings/Theme Identity Candidate R1

Checkpoint: `INT-UX-039Q`
Parent: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R2.zip`

- versionCode: `120`
- versionName: `2.1.22-update-ledger-settings-theme-identity-candidate-r1`
- header Kapanion opens an interactive local Update Ledger;
- ledger uses selectable version history plus detailed patch-note sections;
- Chat can answer local latest-update, patch-note, and compare questions;
- `/updates (latest|ask|compare)` commands are registered;
- CLIENT tab Back returns to Core before true Android root behavior;
- nested Settings pages pop one level at a time;
- Brain & AI is nested beneath Chat & Commands;
- Messages & Bubble is nested beneath Activity & Notifications;
- SWRLZ-owned CLIENT/SERVER/Fusion bubble identity supports complementary role tinting without recoloring launcher identity.

Truth boundary: Android/SystemUI-added app badges remain system-owned. The rescue selectable ThemePack set remains Glitch Dragon Glass; this candidate does not restore the full historical multi-theme asset line. INT-CMD-039P-R3 and INT-FILE-039M execution are not included.

Source/static candidate only until later Android build/device evidence exists. No promotion, release publication, deployment, or installation is claimed.
