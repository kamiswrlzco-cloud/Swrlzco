# CLIENT CFv2.1.21 — Command Palette Candidate R2

Checkpoint: `INT-CMD-039P-R2`
Parent: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R1.zip`

- versionCode: `119`
- versionName: `2.1.21-command-palette-parent-child-cursor-follow-candidate-r2`
- preferred grammar: `/parent (child) [instructions]`
- command-list hierarchy: parent → action/subcommand → selector only when needed
- composer caret: external command insertion selects `draft.length`
- response-top follow: full trailing viewport + zero-offset anchor verification
- legacy tokenized command syntax remains compatible
- 039M file actions remain PLANNED

Source/static candidate only until later Android build/device evidence exists. No promotion, release publication, deployment, or installation is claimed.
