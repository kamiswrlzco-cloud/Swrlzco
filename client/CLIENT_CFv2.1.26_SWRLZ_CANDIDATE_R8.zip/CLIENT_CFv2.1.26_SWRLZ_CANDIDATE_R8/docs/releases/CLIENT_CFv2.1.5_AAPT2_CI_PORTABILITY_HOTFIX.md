# CLIENT CFv2.1.5 — AAPT2 CI Portability Hotfix

Version code: 103

Version name: `2.1.5-aapt2-ci-portability-hotfix-v1`

This hotfix removes the environment-specific AAPT2 override that prevented CFv2.1.4 from building
on the GitHub Actions runner. No Forge/Repository Console feature is intentionally changed.

Build status remains unverified until CFv2.1.5 completes CI successfully.
