# CLIENT CFv2.1.20 — Forge Chunked Transport + Optional Evidence

Checkpoint: `INT-FORGE-039F + INT-FORGE-039N`

Status: **candidate; build pending**

This candidate hardens CLIENT Forge transport for large protected CLIENT/SERVER source ZIPs. `AUTO` mode chunks sources above 8 MiB, while `DIRECT` and `CHUNKED` remain explicit operator choices. Chunk transport records per-part SHA-256 and a whole-ZIP SHA-256 transport manifest, with retry reuse of already-created Git blobs.

Build eligibility now requires the source ZIP only. SHA-256 and package-manifest sidecars remain optional evidence: missing evidence is allowed, while supplied malformed or contradictory evidence blocks.

The repository APK-router changes required to reconstruct `.transport.json` packages are included as an unapplied source handoff under `repo-patches/INT-FORGE-039F-039N/`.
