# CLIENT CFv2.1.11 — Chat Control Center

CLIENT CFv2.1.11 is a CLIENT-only conversation UX/settings successor over CFv2.1.10.

It expands Settings → Chat & Commands into nested Conversation Flow, Personality & Response, and Privacy & Context controls; changes the default auto-follow target to the top of the newest SWRLZ response; and applies the selected SWRLZ response profile to optional outside reasoning.

Android identity: versionCode `109`, versionName `2.1.11-chat-control-center-v1`.

No SERVER, protocol, trust, Truth Firewall, permission, mission authority, Forge authority, repository authority, or offline-first behavior is changed.

Source-only release note. Compilation, APK, workflow, device acceptance, release signing, distribution, deployment, and installation are not claimed.
