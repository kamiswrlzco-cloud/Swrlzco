# CLIENT CFv2.1.18 — Forge Rescue Profile-Store Compile Repair

Checkpoint: `INT-FIX-039G`

- Repairs the `ClientProfileStore.resolveClientToServer` provider-profile expression that blocked `compileDebugKotlin` in workflow `30302109949`.
- Changes the incorrect function-symbol nullable access `providerProfileId?.let` to the declared `providerId?.let`.
- Audits SERVER CFv2.1.7 profile-store Kotlin; the corresponding SERVER paths are already correct, so SERVER remains unchanged.
- Preserves the CFv2.1.17 default-theme Forge rescue payload and GitHub credential/write-preflight repair.
- Source/static verification only; successful compilation remains pending the next authorized build/workflow.
