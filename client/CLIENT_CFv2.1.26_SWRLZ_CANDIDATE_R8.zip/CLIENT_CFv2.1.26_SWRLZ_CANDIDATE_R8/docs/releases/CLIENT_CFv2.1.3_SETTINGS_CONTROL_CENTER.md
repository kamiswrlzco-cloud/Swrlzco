# CLIENT CFv2.1.3 — Settings Control Center

Version code: 101
Version name: `2.1.3-settings-control-center-v1`

## Implemented
- Searchable Settings root with domain submenus.
- Core & Connection, Chat & Commands, Missions, Activity & Notifications, Forge, Interface & Bubble, Brain & AI, Privacy & Security, Developer & Diagnostics.
- Auto Presence moved out of Style into Core & Connection settings.
- Chat auto-follow is persistent and follows new content only while the operator remains at the bottom; scrolling upward detaches and exposes `↓ LATEST`. Sending a new message resumes following.
- Mission start policy is persistent. `Always ask` now requires a start dialog before the first Android mission action; later action gates remain independent.

## Verification
Source structure and static syntax balance checked. Full Gradle compilation could not run in the packaging environment because the Gradle 8.7 distribution host was unreachable.
