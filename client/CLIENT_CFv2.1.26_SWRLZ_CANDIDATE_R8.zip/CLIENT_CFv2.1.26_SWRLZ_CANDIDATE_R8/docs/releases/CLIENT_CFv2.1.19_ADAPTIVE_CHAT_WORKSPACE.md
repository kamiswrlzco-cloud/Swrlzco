# CLIENT CFv2.1.19 — Adaptive Chat Workspace

Checkpoint: `INT-CHAT-039I`

**Candidate v2 release note. Workflow `30306467282` reached Kotlin compilation and exposed one missing Material3 opt-in; the source repair and regression precheck are included, but promotion still requires a green Android compile/debug build.**

- Makes Chat conversation-first instead of dashboard-first.
- Collapses onboarding after the first user message and while the keyboard is visible.
- Converts Reasoning Mesh to a compact status strip with expandable detailed provider/routing sheet.
- Hides CLIENT bottom version/navigation chrome while typing.
- Introduces a compact ThemePack/Kapanion composer with bounded auto-growth and Command Center quick actions.
- Preserves response-top follow and LATEST reattachment semantics.
- Adds pure layout policy tests and documentation impact evidence.
