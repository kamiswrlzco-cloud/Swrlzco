# CLIENT CFv2.1.15 — Theme Ignition Family Completion

Source successor for `INT-THEME-039A`.

Identity: versionCode `113`, versionName `2.1.15-theme-ignition-family-completion-v1`.

Completes the user-supplied ignition artwork coverage for Dragon Kamileon, Jade, Frost, Crystal Cyber, and Inferno while preserving the existing Jester Glitch Dragon ignition reference and the existing readiness/reduced-motion startup semantics.

Source/static evidence only; compile, APK, workflow, and device startup acceptance remain pending.
