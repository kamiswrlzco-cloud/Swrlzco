# CLIENT CFv2.1.16 — Theme Progress Semantic Anchor Calibration

Checkpoint: `INT-THEME-039C`  
Android identity: versionCode `114`, versionName `2.1.16-theme-progress-semantic-anchor-v1`.

This source-only successor repairs the shared progress renderer used by Forge and other themed progress surfaces. Jester Glitch Dragon's resolved track now ends at the right green emerald landmark at 89.5% of outer frame width. The progress head uses its center as the semantic progress anchor so 100% and intermediate values align with the same boundary used by determinate fill and active clipping.

The renderer is now theme-aware rather than containing inline Jester layout logic. Themes without explicit runtime calibration continue to use their existing ThemeProgressStyle dp insets. ThemePack manifest v1 is unchanged to preserve CLIENT/SERVER shared-contract parity.

Validation in this checkpoint is static/source only. Build, APK, workflow, device runtime acceptance, GitHub promotion, release, deployment, and installation remain unclaimed.
