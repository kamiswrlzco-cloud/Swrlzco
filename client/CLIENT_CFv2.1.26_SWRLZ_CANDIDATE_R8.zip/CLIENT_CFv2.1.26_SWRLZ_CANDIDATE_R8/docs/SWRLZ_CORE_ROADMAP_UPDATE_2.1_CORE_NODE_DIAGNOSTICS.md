# SWRLZ-Core Roadmap Update 2.1 — Core Node Diagnostics

## Patch

`2.1-CORE-NODE-DIAGNOSTICS`

## Android version

```text
versionName = 0.2.1-core-node-diagnostics
versionCode = 8
```

## Why this patch exists

Browser access to the Local Core Node succeeded, but the Android app did not produce server-side request logs and still displayed Core Node unreachable.

Two issues were identified:

1. The Android manifest had cleartext traffic disabled even though the Local Core Node test URL is plain local LAN HTTP.
2. The Setup screen colored `unreachable` as green because `unreachable` contains the substring `reachable`.

## Changes

- Enables local HTTP/LAN Core Node traffic.
- Adds Android network security config.
- Sends Core Node request headers:
  - `X-SWRLZ-Client-Role`
  - `X-SWRLZ-App-Version`
  - `X-SWRLZ-App-Version-Code`
  - `X-SWRLZ-Patch-Label`
  - `X-SWRLZ-Roadmap-Revision`
  - `X-SWRLZ-Device-Node-Id`
- Parses server fields:
  - `node_name`
  - `node_type`
  - `server_version`
  - `paid_ai_required`
- Displays failure/unreachable in red.
- Displays testing/not-configured in yellow.
- Displays reachable in green.

## Field test target

With the 0.2 Connection Observer server running on the second phone:

```text
http://192.168.1.177:8787
```

Expected app result:

```text
Core Node reachable · SWRLZ Local Core Node · local-node-server-0.2-connection-observer
```

Expected Termux server result:

```text
[SWRLZ BRIDGE CHECK-IN]
Result: SUCCESS
Path: /status
Client IP: ...
Device ID: android-...
App Version: 0.2.1-core-node-diagnostics
```
