# Command Center + Package-Aware Forge V1

Checkpoint: `INT-CHAT-FORGE-038C`

## Purpose

SWRLZ exposes one discoverable command vocabulary across CLIENT and SERVER while keeping Chat, menus, missions, Forge, and provider routing on canonical capability paths. Command Center templates are operator-facing intent helpers; they are not a parallel execution engine.

## Command Center

- A byte-identical `command-contract` module defines categories, titles, natural-language insertion templates, aliases, and canonical capability IDs.
- CLIENT Chat exposes a theme-aware drop-up quick menu beside the composer plus a searchable/favoritable Command Center dialog.
- Selecting a command normally inserts editable natural language into Chat before send.
- SERVER exposes the same catalog under Command & AI for discovery/favorites without pretending SERVER has a CLIENT-style Android action surface.
- Capability execution remains governed by trust, approval, mission, Forge, provider, and Truth Firewall rules.

## Forge package unit

A protected source package has one required logical source identity:

```text
<ROLE>_CFvX.Y.Z_SWRLZ.zip
```

Optional evidence may accompany it:

```text
<ROLE>_CFvX.Y.Z_SWRLZ.sha256
<ROLE>_CFvX.Y.Z_SWRLZ.manifest.json
```

Missing optional evidence does not prevent an APK build attempt. Supplied contradictory evidence remains fail-closed.

Checksum transport aliases `.sha256.txt` and `.sha` normalize to canonical `.sha256` repository identity. Download-copy suffixes such as ` (1)` are transport-local and are removed before logical pairing/routing.

## Automatic companion resolution

When a protected CLIENT/SERVER ZIP is selected, Forge attempts to resolve its same-location checksum and manifest companions. Checksum lookup may generate a canonical receipt from the selected ZIP when Android grants the ZIP but withholds the sibling. Manifest content is never invented. A missing manifest remains visibly unavailable but does not block ZIP build eligibility.

Source validation verifies:

1. ZIP readable and source-like when Source ZIP Guard is active;
2. supplied SHA-256 receipt syntax and digest;
3. supplied manifest canonical `zip`, `sha256`, and `verified: true`;
4. supplied manifest/receipt agreement;
5. no orphan supplied evidence;
6. canonical destination lane.

Only item 1 plus a valid source identity is required for build eligibility; items 2–4 become mandatory only when that evidence is supplied or when a stronger promotion policy requires it.

## Package targets

Forge supports `CLIENT`, `SERVER`, `BOTH`, and ordinary `FILES`. `BOTH` stages two independently verified package units in one atomic repository transaction; it does not merge CLIENT/SERVER identities or lineage.

## Routing

- CLIENT package files route to configured CLIENT source directory.
- SERVER package files route to configured SERVER source directory.
- Ordinary files use the generic destination.
- Destination preview is enabled by default.

## SERVER parity

SERVER now receives the package-aware Forge behaviors that legitimately belong to both roles: command catalog, checksum/manifest pairing, package target selection, destination preview, CLIENT+SERVER transaction staging, source routing, and generic repository-bootstrap ZIP expansion. CLIENT-only Android UI execution remains CLIENT-only.

## Authority boundary

This checkpoint does not change protocol semantics, trust, permission, mission authority, provider authority, Forge commit approval semantics, Truth Firewall, offline-first behavior, or local/remote distinctions.


## INT-FORGE-039E truthful credential/write preflight

Forge distinguishes authentication from operation capability. Before large repository transfer, CLIENT validates account authentication and branch readability, then performs a tiny unreferenced Git-blob probe to prove `Contents: write` without changing the branch/tree. A later 401 is re-probed before credential retirement. Oversized REST blob requests are transport failures rather than credential failures. This boundary is required before resumable/chunked transport is introduced.


## INT-FORGE-039F / 039N — resilient source transport

The CLIENT Forge transport now separates logical source identity from GitHub REST request shape.

- `AUTO` is the default and chunks protected source ZIPs above 8 MiB.
- `DIRECT` preserves the prior single-blob behavior.
- `CHUNKED` forces deterministic 8 MiB source parts.
- The final transport manifest contains the canonical ZIP identity, whole SHA-256/size, and ordered per-chunk path/size/SHA-256.
- Git blob SHAs for completed chunks are cached as resume hints scoped to repository + whole package digest + chunk digest.
- A retry may reuse already-created chunk blobs; the final repository tree remains atomic.
- The repository CI handoff reconstructs chunked sources only in runner temporary storage and verifies every chunk plus the complete ZIP before build.

This is transport hardening only. It does not merge CLIENT/SERVER lineage or reduce Truth Firewall, trust, permission, mission, identity, or protocol boundaries.
