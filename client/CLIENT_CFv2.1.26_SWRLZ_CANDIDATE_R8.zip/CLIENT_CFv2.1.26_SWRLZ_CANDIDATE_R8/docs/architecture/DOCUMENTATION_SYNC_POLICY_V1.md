# Documentation Synchronization Policy V1

Effective from `INT-CHAT-FORGE-038C`.

Every bounded SWRLZ checkpoint must perform a Documentation Impact Set before completion. All maintained documentation is assessed; every affected living document is synchronized with the implementation/evidence state. Historical checkpoint, release, CI, and failure records remain immutable except for explicit errata or supersession links.

Evidence classes remain separate: source presence/static verification, compilation, automated tests, CI/workflow, APK/artifact, device/runtime acceptance, repository promotion, release, and deployment. Documentation must not upgrade one class into another.

Repository authority documents are updated only when the corresponding source/evidence is actually promoted to repository authority. Source-only checkpoints instead package their current architecture/contract/checkpoint/release/handoff documentation and a pending repository documentation impact set.
