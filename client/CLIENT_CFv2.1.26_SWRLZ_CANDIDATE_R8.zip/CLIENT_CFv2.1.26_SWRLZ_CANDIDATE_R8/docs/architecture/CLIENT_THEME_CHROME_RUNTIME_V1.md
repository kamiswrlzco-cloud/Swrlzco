# CLIENT Theme Chrome Runtime v1

Checkpoint: `INT-THEME-035C`  
Extends: `ADR-0025 — Declarative ThemePack Engine`

## Boundary

The runtime converts one selected declarative `ThemePack` into CLIENT presentation. It does not own application truth.

```mermaid
flowchart TD
    P["Local CLIENT ThemePack"] --> R["Semantic asset resolver"]
    P --> C["Chrome + motion tokens"]
    R --> U["Backdrop, Kapanion, startup, progress"]
    C --> U
    S["Semantic app state"] --> U
```

`Semantic app state` remains authoritative for mission progress, readiness, permissions, trust, connection, Forge, and terminal outcomes. Theme renderers decide only how those states look.

## Chrome contract

`ThemeChromeStyle` adds:

- `motif`: procedural ornament family;
- `backgroundArtRole`: semantic background identity;
- `kapanionRole`: header/chat/companion identity;
- `voiceCoreRole`: tap-to-speak identity;
- bounded background and ornament alpha;
- bounded edge complexity and ambient tilt.

All fields have safe manifest-v1 defaults, so older declarative packs remain readable. Validation rejects unsupported semantic roles and out-of-range visual values.

## Rendering

`ThemeAppBackdrop` resolves selected background art once through Android resources, animates transform/alpha only, places a dark readability veil above it, and adds a lightweight motif canvas.

`ThemeKapanionAvatar` is reused at multiple sizes while retaining one semantic identity. Decorative instances are excluded from accessibility; the header instance has a concise description.

`ThemeChromePanel` and `ThemeChromeBox` preserve layout semantics and touch behavior while applying pack-defined corner geometry, gradient edges, and low-alpha corner ornaments.

## Progress layout

```mermaid
flowchart TD
    O["Outer clipped component"] --> T["Inset clipped track"]
    T --> F["Fill / ambient / particles / highlight"]
    O --> B["Decorative frame"]
    T --> H["Bounded progress head"]
    O --> X["Truth-gated terminal effect"]
```

Every moving layer resolves through one theme-aware semantic track geometry and therefore shares one start boundary, one end boundary, and one vertical channel. Packs without artwork-specific calibration retain their declared `ThemeProgressStyle` dp insets. A pack with a meaningful visual landmark may use a bounded runtime geometry calibration; for Jester Glitch Dragon, 100% terminates at the center of the right green emerald rather than the decorative tail of the frame. The progress-head semantic anchor (normally its center) follows the exact same truthful boundary used by fill and active masking. An indeterminate segment moves only inside the resolved track. The outer component clips all artwork as a final containment boundary.

The current manifest-v1 schema is unchanged by INT-THEME-039C. Theme-specific normalized geometry is resolved in the CLIENT runtime so the shared CLIENT/SERVER ThemePack contract remains byte-compatible; a future paired contract checkpoint may promote normalized landmark hints into the declarative manifest after cross-theme calibration evidence exists.

## Startup layout

The startup renderer is semantic rather than Jester-specific. Six supplied families now carry the full eight-stage ignition set: Jester Glitch Dragon, Dragon Kamileon, Jade, Frost, Crystal Cyber, and Inferno. Core-state artwork crossfades in narrow windows while shockwave, radial, particle, spark, and residual effects use separate bounded transforms. Themes without supplied startup art continue to use their own Kapanion/emblem with a short reveal. The startup overlay never fabricates readiness or blocks initialization.

## Performance and accessibility

- Existing preprocessed PNG/WebP resources are reused.
- Launcher masters and screen backgrounds remain separate; Glitch Dragon Glass uses a bounded 720×1280 runtime WebP background.
- No per-frame bitmap allocation or regeneration is introduced.
- Motion uses transforms, alpha, clipping, and canvas primitives.
- Android animator state and the CLIENT motion setting remain authoritative.
- Reduced motion removes ongoing drift/pulse and uses static startup presentation.
- Decorative artwork has no semantic status role.
- Status remains readable in text and retains locked semantic colors.

## Extension rule

A future built-in theme adds assets, semantic mappings, chrome tokens, and registration. It does not require CLIENT screen rewrites. A future custom pack remains declarative and must pass the existing archive/manifest validator before activation.


## CFv2.1.17 bootstrap transport edition

CFv2.1.17 is intentionally not a full ThemePack distribution. To break the Forge uploader bootstrap deadlock, the runtime selectable registry is restricted to the canonical default Glitch Dragon Glass ThemePack and optional ThemePack artwork is omitted. Full theme definitions/assets remain authoritative in the parent lineage and are expected to return after the repaired/chunked Forge transport is promotable. This temporary packaging profile does not redefine the ThemePack architecture.


## CFv2.1.18 rescue compile-repair successor

CFv2.1.18 retains the exact default-only ThemePack packaging boundary introduced by CFv2.1.17. INT-FIX-039G changes profile-store compilation and package identity only; it does not restore or redefine optional ThemePack artwork. Full-theme restoration remains a later transport-capable successor task.
