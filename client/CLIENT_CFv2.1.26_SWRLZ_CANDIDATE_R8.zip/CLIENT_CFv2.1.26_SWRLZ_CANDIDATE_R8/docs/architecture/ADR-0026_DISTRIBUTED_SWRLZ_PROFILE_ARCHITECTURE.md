# ADR-0026 — Distributed SWRLZ Profile Architecture

Status: accepted for source implementation under `INT-PROFILE-037B`.

## Decision

SWRLZ keeps one continuous core identity while allowing separately assigned endpoint, relationship, provider, session, and message-level profiles.

```text
SWRLZ core / immutable authority boundaries
        ↓
endpoint profile
        ↓
relationship profile
        ↓
provider profile
        ↓
session profile
        ↓
per-message presentation override
```

CLIENT and SERVER own independent local registries so the CLIENT may use one conversational profile while SERVER uses a different local architect profile. Link-specific profiles support CLIENT→SERVER, SERVER→CLIENT, and SERVER→SERVER behavior without conflating those directions.

## Consequences

- profile inheritance avoids cloning large prompt blobs;
- provider specialists may use independent GPT/Gemini/local profiles;
- SERVER-node coordination can remain compact and schema-first while user-facing CLIENT replies remain conversational;
- profile settings remain inspectable and user-editable;
- future provider orchestration can consume resolved directives without gaining mission/action authority;
- no current protocol version changes are required.
