# ADR-0025 — Declarative ThemePack Engine

Status: Accepted for source checkpoint `INT-THEME-035A`  
Date: 2026-07-26

## Context

CLIENT and SERVER already had Theme Armor palettes, independent local preferences, launcher aliases, bubbles, notifications, and semantic status colors. The supplied visual packs add several complete identity and progress families. INT-THEME-039A extends the startup surface from the original Jester reference ignition to six complete eight-stage ignition families: Jester Glitch Dragon, Dragon Kamileon, Jade, Frost, Crystal Cyber, and Inferno. Treating those images as screen-specific files would duplicate theme logic, weaken accessibility, and couple presentation to mission or protocol state.

## Decision

CLIENT and SERVER use one byte-identical, pure Kotlin `theme-contract` module. A `ThemePack` is declarative data with:

- a stable reverse-domain ID, display name, theme version, manifest version, and target compatibility;
- palette, typography, shapes, dimensions, buttons, progress, startup, motion, particles, launcher, Kapanion, and optional future sound metadata;
- semantic asset mappings such as `progress.fill`, `startup.awakened`, and `kapanion.server`;
- explicit fallback IDs and source-pack provenance.

Screen and runtime code expose semantic state. Theme renderers decide presentation. Theme code does not own connection, trust, identity proof, permissions, mission state, Forge behavior, protocol behavior, or listener exposure.

Legacy theme IDs and aliases remain stable. New themes join the same registry. CLIENT and SERVER persist their selected IDs in separate local stores.

## Runtime behavior

- Jester Glitch Dragon remains the reference eight-layer startup sequence, and the same semantic startup roles are now populated for Dragon Kamileon, Jade, Frost, Crystal Cyber, and Inferno.
- Themes without supplied startup art continue to use a static Kapanion/progress-emblem fade; no missing art is invented.
- The startup overlay runs above a live content tree and waits on a readiness signal without blocking initialization; fast readiness accelerates the sequence to approximately 600 ms, while long readiness transitions to truthful indeterminate progress.
- Known progress uses the reported value. Unknown progress is indeterminate. Terminal effects require a real terminal state.
- Reduced motion honors the user setting and Android animator state, uses one static startup identity, freezes paused progress, and omits decorative particle/highlight decoding.

## Custom themes

Manifest v1 permits only JSON plus PNG/WebP assets. Validation rejects incompatible schema versions, duplicate IDs, unsupported roles or extensions, traversal paths, links, encryption, archive collisions, suspicious compression, excessive counts/sizes/dimensions, and malformed checksums. Pack content receives no application permission and cannot contain executable code.

The schema and validator are implemented in this checkpoint. Import and activation of user archives remain intentionally unavailable until a later checkpoint completes the Android archive reader, transactional install store, and explicit import UI.

## Consequences

- New built-in themes require assets, a manifest/definition, and registry entry, not screen rewrites.
- Startup and progress engines remain reusable across theme families.
- Existing button banners with baked English text or opaque backgrounds are not treated as universal button states.
- Teal Serpent remains visibly marked as partial and uses defined identity fallbacks.
- Build, runtime, frame-time, and device-memory acceptance remain separate evidence gates.

## INT-THEME-035C extension

CLIENT CFv2.1.8 adds defaulted `ThemeChromeStyle` and calibrated progress-track fields to manifest v1. Older manifests remain readable. Full-shell rendering now resolves semantic background, Kapanion, voice-core, motif, panel ornament, and motion roles without moving application state or authority into theme code.

The CLIENT runtime details and containment order are documented in `CLIENT_THEME_CHROME_RUNTIME_V1.md`. SERVER does not consume this CLIENT renderer change and remains unchanged.
