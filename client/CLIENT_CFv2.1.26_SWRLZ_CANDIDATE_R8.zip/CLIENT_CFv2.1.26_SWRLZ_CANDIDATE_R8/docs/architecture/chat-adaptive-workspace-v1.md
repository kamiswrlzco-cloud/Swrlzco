# Adaptive Conversation Workspace v1

Chat is conversation-first. ThemePack presentation remains declarative, while layout state is derived from IME visibility and whether a real user conversation has begun.

## Presentation states

### Empty Chat

Keeps onboarding, compact reasoning status, optional Forge/companion telemetry, and the composer.

### Active Chat

Collapses onboarding and secondary telemetry so the message list owns the remaining viewport. Provider reachability remains available in one compact strip.

### Keyboard / IME active

Hides CLIENT bottom version/navigation chrome, keeps the compact reasoning strip, gives the message list all remaining vertical space, and pins the compact composer above IME insets.

## Reasoning Mesh

The compact strip presents SWRLZ / SERVER / GPT / Gemini health and the active route. Tapping it opens a detailed sheet with models, statuses, routing selection, and `PROBE ALL`.

Provider status is informational. It never grants provider action authority.

## Follow semantics

The existing response-top policy remains authoritative: a new SWRLZ response can be positioned at the top of the message viewport with trailing reserve beneath it, manual upward scrolling detaches follow, `LATEST` re-arms it, and sending a message re-arms the next response.

## Authority boundary

`ChatWorkspacePolicy` is presentation-only. It does not modify missions, approvals, permissions, provider authorization, Truth Firewall, device proof, protocol messages, Forge transaction authority, or local/remote routing truth.
