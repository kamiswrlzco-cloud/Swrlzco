# ADR-0021: Floating Dragon Conversation Bubbles

## Status
Accepted for phased delivery.

## Decision
SWRLZ Client and Server publish Android conversation notifications with `MessagingStyle`, `BubbleMetadata`, long-lived dynamic shortcuts, and dedicated resizeable bubble activities.

The client bubble provides compact mission context, message composition, and pause/resume. The server bubble provides runtime context, compact administrative messaging, and a safe jump into the full server app.

## Platform boundary
Android System UI controls whether a conversation appears as a bubble. The user may disable bubbles globally, by app, or by conversation. Chat bubbles do not use `SYSTEM_ALERT_WINDOW`.

## Delivery phase
This release establishes the native bubble shell and local UI state. Durable client/server message transport, unread synchronization, delivery receipts, authenticated command dispatch, and history persistence remain in the next chat protocol phase.

## Security
Irreversible and high-risk actions are excluded from the bubble. Those actions continue to require the trusted full-app surface and existing approval gates.

## Migration
No database migration is required. Conversation notification channels and dynamic shortcuts are created lazily. Existing notification permission remains authoritative.
