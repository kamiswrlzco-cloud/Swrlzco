# ADR-0020: Preflight bulk acknowledgement and themed status notifications

## Status
Accepted

## Context
The client first-mission sovereignty screen requires five explicit acknowledgements. Users requested an **Accept All** control on that screen, not on the Android permission centre. Users also requested an opt-out notification-shade status surface for both client and server, enabled by default and visually aligned with the selected Glitch Dragon theme.

## Decision
1. The client preflight screen retains every individual acknowledgement and adds **Accept All**, which checks all five statements. Final continuation remains a separate deliberate action.
2. The client Android permission centre is restored to its prior two-permission workflow. Accessibility and overlay access still require Android system confirmation.
3. Client and server expose a **Notification widget** setting backed by DataStore and defaulted to `true`.
4. Client status notifications show local mission state, server reachability evidence, and the selected theme family/variant.
5. Server foreground notifications show runtime/listener health and selected theme metadata.
6. Disabling the server's enhanced widget only suppresses expanded details. Android still requires a foreground-service notification while the server service runs.

## Security and privacy
Notifications intentionally avoid secrets, tokens, node proofs, raw UI trees, mission payload details beyond a short user-authored goal, and private server addresses. Notification content remains visible according to the user's Android lock-screen notification policy.

## Android constraints
Android 13+ requires `POST_NOTIFICATIONS` for normal notification-shade visibility. A foreground service must still provide a notification even when the enhanced server widget is disabled. Custom notification presentation is ultimately constrained by System UI; the app can match wording and theme identity but cannot fully reproduce an in-app Compose surface.

## Migration
The new preference keys default to enabled when absent, so no schema migration or destructive reset is required. Existing users receive the status notification after granting notification permission.

## Testing
- Verify Accept All checks all five preflight statements and does not bypass Continue.
- Verify the permission centre no longer contains Accept All.
- Toggle each notification widget off/on and confirm cancellation or reduced server detail.
- Change theme family/variant and confirm notification text updates.
- Exercise client mission and server runtime transitions.
- Verify no sensitive credentials appear in notification extras or rendered text.
