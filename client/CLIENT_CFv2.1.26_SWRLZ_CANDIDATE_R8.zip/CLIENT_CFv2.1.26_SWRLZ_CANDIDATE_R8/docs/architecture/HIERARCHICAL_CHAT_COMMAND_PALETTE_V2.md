# Hierarchical Chat Command Palette v2

Checkpoint: `INT-CMD-039P-R2`
Status: **CLIENT CANDIDATE IMPLEMENTATION**

## Preferred grammar

The operator-facing Chat grammar is:

```text
/parent (child) [instructions]
```

The structured prefix selects a capability family and subcommand. Everything after the closing parenthesis remains ordinary instruction text. Examples:

```text
/files (scan) check Downloads for SWRLZ artifacts
/files (organize) organize Downloads, ask before creating directories
/mission (pause) after the current safe step
/forge (latest) CLIENT source
```

The command prefix is a discovery/intent-entry contract. It is not an execution grant.

## Menu behavior

The Command Center presents:

1. parent categories such as Files, Forge, Missions, Connections, Chat, and System;
2. action/subcommand choices such as `(scan)`, `(organize)`, `(latest)`, `(pause)`;
3. a selector tier only when multiple registered presets share the same parent/action, for example Forge `(latest)` → CLIENT / SERVER / combo;
4. clear syntax text beside selectable leaf commands.

This keeps command discovery aligned with the visible grammar instead of exposing raw dotted capability IDs as the user-facing hierarchy.

## Resolver compatibility

Stable command/capability IDs remain canonical internal identities. The resolver accepts the preferred parenthesized grammar and keeps legacy tokenized slash paths, IDs, titles, aliases, templates, and ordinary search terms as compatibility inputs.

Where one parent/action maps to several presets, freeform instructions rank the matching preset. Example: `/forge (latest) CLIENT source` resolves to the CLIENT latest-source preset.

## Composer insertion contract

Selecting a command inserts the structured prefix, plus a deliberate preset instruction when the selected leaf represents a specific preset. The Chat composer owns a `TextFieldValue` and explicitly sets selection to the end of externally inserted text. Normal user editing preserves the live selection rather than forcing the caret to the end on every keystroke.

## Response-top follow contract

`FOLLOW_RESPONSE_TOP` is an exact semantic anchor. The message list reserves a full viewport of trailing scroll space so even a short final SWRLZ response can reach the top of the conversation viewport. After animated scrolling, the list reasserts the target at zero offset if layout rounding/settling left it elsewhere.

Manual upward scrolling still detaches auto-follow. `↓ LATEST` and sending a new message still re-arm the configured follow behavior.

## 039M boundary

The palette exposes generic planned file actions:

```text
/files (scan) [instructions]
/files (organize) [instructions]
/files (duplicates) [instructions]
/files (undo) [instructions]
/files (keep-organized) [instructions]
```

They remain `PLANNED` until INT-FILE-039M provides the Local Artifact Resolver, scoped storage execution, approvals, verified moves, journal/undo, and Keep Organized runtime.

## Authority boundary

No command selection bypasses user approval, Truth Firewall, trust/identity, mission authority, Forge transaction authority, provider enablement, filesystem permission, local/remote distinctions, or protocol-version discipline.
