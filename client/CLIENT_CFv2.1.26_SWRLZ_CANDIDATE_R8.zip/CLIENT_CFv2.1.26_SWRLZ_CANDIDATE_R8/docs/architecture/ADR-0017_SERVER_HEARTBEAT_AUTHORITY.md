# ADR-0017 — SERVER Heartbeat Authority

Status: Accepted

## Decision
The SERVER owns canonical presence state and heartbeat thresholds. CLIENT nodes acknowledge SERVER-issued heartbeat leases and may report local degradation, but they do not independently promote themselves to authoritative online state.

## Rationale
A single authority prevents split-brain presence while still tolerating mobile latency, temporary packet loss, background throttling, and network handoff.

## State progression
CONNECTED → DELAYED → UNAVAILABLE → DISCONNECTED. One missed exchange never causes an immediate disconnect. Explicit administrative disconnects bypass the grace window and suppress automatic reconnect.

## Consequences
- SERVER dashboards remain canonical.
- CLIENT UI can truthfully show local uncertainty.
- Registration, trust, lineage, and group membership survive transient loss.
- Persistent event transport may be added later without changing authority.
