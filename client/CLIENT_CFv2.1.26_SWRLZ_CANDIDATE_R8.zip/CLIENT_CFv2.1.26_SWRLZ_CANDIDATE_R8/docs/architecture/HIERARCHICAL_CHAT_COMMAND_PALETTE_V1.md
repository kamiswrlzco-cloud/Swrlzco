# Hierarchical Chat Command Palette v1

Checkpoint: `INT-CMD-039P`
Status: **CLIENT CANDIDATE IMPLEMENTATION**

## Purpose

SWRLZ Chat exposes one command surface that supports three equivalent discovery paths:

1. category → subcommand navigation;
2. typed canonical command syntax such as `/forge client latest`;
3. natural-language templates inserted into Chat for review.

The palette is a discovery and intent-entry layer. It is not a second execution engine and does not grant authority merely because a command is selected.

## Hierarchy

The existing stable command ID is the hierarchy source. A dotted ID maps to a nested path:

```text
forge.client.latest
→ /forge client latest
→ Forge / Client / Latest
```

The UI derives child branches from the catalog rather than hardcoding one menu tree. New registered capabilities can therefore appear in the palette without rewriting Chat navigation.

## Prompt resolution

The command prompt accepts canonical slash syntax, stable command IDs, titles, templates, aliases, capability IDs, and ordinary search words. Resolution produces:

- an exact command when one stable identity matches;
- ranked suggestions otherwise;
- a raw-text insertion option when the operator intentionally wants ordinary Chat wording.

No prompt text is executed directly by the resolver.

## Context, pins, and recents

Commands declare relevant contexts such as Chat, Forge, Files, Missions, Connections, Providers, Profiles, and System. The palette may rank context-relevant capabilities higher without hiding the full catalog.

Pinned and recent command IDs are stored locally in CLIENT preferences. They are convenience metadata only and do not alter capability authority.

## Approval and availability metadata

Every command exposes an operator-facing approval class:

- `READ_ONLY`
- `REVIEW`
- `CONFIRM`
- `SENSITIVE`

and an availability class:

- `AVAILABLE`
- `REQUIRES_CONFIGURATION`
- `PLANNED`

The palette displays these states before insertion. `PLANNED` entries are discoverable but cannot be inserted as if the backing runtime already exists.

Commercial-provider commands are marked `REQUIRES_CONFIGURATION` / `SENSITIVE`, consistent with the approved local/private-node-first provider direction. The command catalog does not enable a provider.

## 039M integration seam

The palette reserves hierarchical command identities for the approved Local Artifact Resolver / organizer roadmap, including:

```text
/files scan downloads
/files organize downloads
/files organize selected
/files duplicates review
/files undo last
/files keep organized
```

They remain `PLANNED` until INT-FILE-039M implementation provides the backing capabilities.

## Authority boundary

Command selection or prompt resolution does not bypass:

- user approvals;
- Truth Firewall;
- trust and identity;
- mission authority;
- Forge transaction authority;
- provider enablement;
- filesystem permission;
- local/remote distinctions;
- protocol-version discipline.
