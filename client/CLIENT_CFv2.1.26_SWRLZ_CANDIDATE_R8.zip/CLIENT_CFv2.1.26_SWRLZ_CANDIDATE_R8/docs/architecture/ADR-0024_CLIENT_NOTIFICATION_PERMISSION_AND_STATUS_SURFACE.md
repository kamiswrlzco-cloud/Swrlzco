# ADR-0024 — Client Notification Permission and Status Surface

## Status

Accepted

## Context

The Client already generated a persistent status notification, but Android 13+ requires runtime authorization before the notification can be displayed. Declaring the permission in the manifest is insufficient.

## Decision

Request notification authorization with the Android Activity Result API and expose a first-class permission-state card in the existing Permission Centre. The status surface remains driven by existing mission, server-truth, preference, and theme flows.

## Consequences

- Fresh installs receive the system notification prompt.
- Returning users can recover disabled notification access from the Permission Centre.
- Android may still suppress the surface when the user disables the app or channel.
- No custom background polling or hidden permission workaround is introduced.
