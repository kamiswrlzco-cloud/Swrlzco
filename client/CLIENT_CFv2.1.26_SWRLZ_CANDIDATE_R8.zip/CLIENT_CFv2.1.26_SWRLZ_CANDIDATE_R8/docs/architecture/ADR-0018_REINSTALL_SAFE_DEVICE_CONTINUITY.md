# ADR-0018: Reinstall-Safe Logical Device Continuity

**Status:** Accepted  
**Date:** 2026-07-23  
**Applies to:** CLIENT CFv2.0.23 and SERVER CFv2.0.20

## Context

Android removes application-private data and Android Keystore entries on uninstall. A random
installation identifier therefore cannot represent a durable logical device. The existing CLIENT
already derived a SHA-256 binding from the package name, app-scoped `ANDROID_ID`, and the
`swrlz-device-binding-v1` namespace. The SERVER already stored that binding, but registration was
not fully transactional and protocol v1 transmitted raw `ANDROID_ID`.

## Decision

1. Keep the existing v1 binding derivation material to preserve compatibility with enrolled devices.
2. Rename its protocol meaning to `deviceRecoveryId`; only the SHA-256 digest is transmitted.
3. Generate a fresh `installationId` for each install.
4. Let the SERVER retain the existing canonical `nodeId` when the recovery digest matches.
5. Store every observed installation ID in `installationLineage`.
6. Perform lookup, canonical selection, upsert, and duplicate archival in one Room transaction.
7. A matching digest restores logical registration, but a new installation without proof is set to
   `UNTRUSTED` with `proofState=REAPPROVAL_REQUIRED`.
8. Protocol v2 is preferred; protocol v1 remains accepted for migration compatibility.

## Security Properties

The recovery digest is a correlation signal, not an authentication secret. It must not silently restore
privileged trust after uninstall. Mission/group authority remains behind the Trust Firewall. Raw
`ANDROID_ID` is not sent by protocol v2.

## Known Boundaries

Continuity can fail after a factory reset, signing-certificate change, Android user/profile change, or
application ID change. Stable release signing is therefore an operational requirement.

## Migration

No Room schema change is required. Existing `deviceBindingFingerprint` values remain valid.
Protocol v1 clients continue to register. Protocol v2 clients send both the new key and the legacy
digest key during the compatibility window.
