# SWRLZ Model Rack and Module Pack Contract v1

## Purpose

Contract v1 makes the LLM replaceable equipment beneath SWRLZ and makes response modifiers portable without turning packs into executable plugins. The shared Kotlin contract must remain byte-identical between CLIENT and SERVER.

## Model identity

`SWRLZ-LFM-OPT-001A.gguf` is recognized only by this pair:

- SHA-256: `651cd5c40e4ef24de2ff12c2b53b257d15816ddd4346e2575e6768a6ec1d8590`
- size: `229315680` bytes

A matching filename or metadata label is insufficient. All GGUFs still pass Model Vault parsing, load and inference checks.

## Per-model profile

Profiles are persisted by normalized model SHA-256 with an increasing generation number.

| Field | Runtime meaning |
|---|---|
| `speed` | Coordinates context, output budget, threads and loading policy. |
| `reasoningDepth` | Adjusts budget/density/validation emphasis; never claims retraining. |
| `contextTokens` | `0` means AUTO; otherwise bounded to `1024..32768`. |
| `maxOutputTokens` | Bounded to `32..2048`. |
| `temperature`, `topP`, `topK` | Sampling controls within contract ranges. |
| `expressionEq` | Nine presentation/response-shaping controls, each `0..100`. |
| `activeModuleIds` | At most 16 normalized, distinct module IDs. |

Every profile write supplies `expectedGeneration`. Stale writes return a conflict instead of silently overwriting a newer CLIENT or SERVER change.

## `.swrlzmod` container

A module pack is a ZIP-compatible file with:

- root `manifest.json`;
- one or more hash-declared payloads;
- optional `LICENSE.txt` and `NOTICE.txt`.

Limits:

- archive: at most 600 MiB;
- combined declared/uncompressed entries: at most 600 MiB;
- entries: `2..32`;
- manifest: at most 128 KiB;
- payload declarations: `1..16`;
- prompt suffix: at most 6000 characters and `32..900` declared tokens.

Absolute paths, backslashes, blank segments, `.`/`..`, duplicate entries, undeclared payloads and duplicate/missing declared payloads are rejected. APK, DEX, JAR/AAR, WebAssembly, class, native-library, executable, source-code and script extensions are rejected.

## Manifest

Required semantic fields:

```json
{
  "schemaVersion": 1,
  "id": "vendor.family.module-id",
  "displayName": "Readable name",
  "version": "1.0.0",
  "type": "PROMPT_CAPSULE",
  "compatibleBaseSha256": ["64 lowercase hexadecimal characters"],
  "requiredRuntimeContract": "prompt_capsule_v1",
  "payloads": [
    {
      "path": "prompt.json",
      "sha256": "64 lowercase hexadecimal characters",
      "sizeBytes": 123,
      "mediaType": "application/vnd.swrlz.prompt+json"
    }
  ],
  "conflicts": [],
  "licenseId": "LicenseRef-User-Provided"
}
```

An empty `compatibleBaseSha256` list means any installed base is eligible. A non-empty list requires an exact selected-model hash match.

Module IDs use lowercase letters/digits plus `.`, `_` or `-`. Versions use a bounded alphanumeric token plus `.`, `_`, `+` or `-`; path separators are invalid.

## Live payloads

### Prompt capsule

```json
{
  "schemaVersion": 1,
  "systemSuffix": "Bounded response-shaping instructions.",
  "maxTokens": 220
}
```

Prompt text is appended after the base system directive and verified Swurlzara profile. It cannot replace deterministic truth, memory, approval or execution gates.

### Expression EQ

```json
{
  "warmth": 55,
  "energy": 50,
  "humor": 35,
  "directness": 65,
  "creativity": 45,
  "technicalDepth": 60,
  "skepticism": 65,
  "verbosity": 45,
  "mythicExpression": 30
}
```

EQ is model-specific presentation/sampling state. It does not rewrite learned weights or authority.

## Reserved payloads

`LORA_ADAPTER` uses `requiredRuntimeContract = "lora_adapter_v1"` and must include a `.gguf` or `.safetensors` payload. Contract/install recognition exists, but activation returns `LORA_NATIVE_BRIDGE_UNAVAILABLE` in this checkpoint.

`KNOWLEDGE_PACK` and `TOOL_PACK` are ABI reservations only and are not installable or activatable in v1.

## Installation and activation

1. Copy the selected document to a bounded partial file.
2. Inspect ZIP entry count, names, sizes and extensions.
3. Parse and validate `manifest.json`.
4. Require that all non-auxiliary entries are declared.
5. Verify every declared payload byte size and SHA-256.
6. Parse and range-check the type-specific payload.
7. Atomically rename staging into the module vault.
8. Persist the registry.
9. Require explicit activation under the selected model profile.

Conflicts and incompatible bases fail before profile mutation. The previous profile remains available for rollback.

`LOCAL_HASH_VERIFIED` means the user-selected archive is internally self-consistent with its own manifest. It does not prove publisher identity or confer execution trust. Only code-shipped built-ins are labeled `BUILTIN`.

## CLIENT ↔ SERVER protocol

Base path: `/ai/model-rack`

| Method | Route | Purpose |
|---|---|---|
| `GET` | `/status` | Inventory, active per-model profile, modules, rollback state and immutable safeguards. |
| `POST` | `/profile` | Generation-checked profile/EQ update. |
| `POST` | `/model/activate` | Verified load/test activation. |
| `POST` | `/module/activate` | Generation-checked module toggle. |
| `POST` | `/rollback` | Profile or model rollback. |

Loopback is local-only. LAN requests require the registered device node ID, `action-phone` role, same-subnet proof and the dedicated model-rack pairing token. Responses are `no-store`.

## Immutable safeguards

The protocol snapshot always names these non-slider controls:

`truth_firewall`, `permissions`, `approvals`, `provenance`, `node_trust`, `mission_authority`, `forge_authority`, `execution`.

Example pack sources live at `docs/contracts/examples/model-rack/`.
