# SWRLZ Forge Storage Performance Contract V1

## Scope

This contract applies equally to CLIENT and SERVER Forge storage behavior.

## Incoming package inbox

- Public Android `Download` is the default incoming package inbox.
- On Android 11+, direct public-Downloads scanning is enabled only after the user explicitly grants the application-specific all-files access capability in Android Settings.
- Forge never grants that capability silently.
- A persisted Storage Access Framework folder remains available as an optional custom inbox override.
- The custom override takes precedence over public Downloads when configured.

## Project root

- Selecting or changing the project root must return control to Compose immediately.
- Persisted-URI work, directory creation, folder verification, and project-layout resolution execute on `Dispatchers.IO`.
- The UI exposes setup progress instead of presenting a black or frozen screen.

## Package scanning

- Automatic and manual scans share one single-flight coordinator.
- A scan lists the Downloads root once and snapshots one bounded child-directory level once.
- CLIENT and SERVER classification reuse that snapshot.
- Scan-time SHA-256 values may be cached only when URI, display name, size, and last-modified identity are unchanged.
- Immediately before GitHub upload, every selected source is rehashed and revalidated without the cache.
- A source mutation or evidence mismatch blocks upload.

## Responsiveness and trust

- Document-provider queries, ZIP evidence inspection, and source hashing do not execute on the UI thread.
- Duplicate rescan requests may wait behind the active scan but may not start concurrent storage-provider traversals.
- Progress states distinguish setup, scanning, ready, and blocked conditions.
- Existing metadata-bundle and complete legacy-sidecar compatibility remains intact.
