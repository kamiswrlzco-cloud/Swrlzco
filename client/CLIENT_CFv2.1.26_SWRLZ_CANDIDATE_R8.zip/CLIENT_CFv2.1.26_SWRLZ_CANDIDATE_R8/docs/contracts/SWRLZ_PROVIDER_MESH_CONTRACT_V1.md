# SWRLZ Provider Mesh Contract v1

Checkpoint: `INT-AI-038A`
Contract version: `1`
Status: `SOURCE IMPLEMENTED — BUILD / LIVE PROVIDER / DEVICE VALIDATION PENDING`

## Purpose

The provider mesh lets SWRLZ consult remote or local reasoning specialists without transferring conversation identity, trust authority, mission authority, or action authority to a provider. SWRLZ remains the user-facing assistant and the Truth Firewall remains authoritative.

## Provider identities

Canonical provider IDs:

- `local_client`
- `local_server`
- `openai`
- `gemini`

Canonical strategies:

- `SWRLZ_AUTO`
- `LOCAL_ONLY`
- `OPENAI`
- `GEMINI`
- `COUNCIL`
- `COMPARE`

Per-message tags are presentation shortcuts only. `@gpt`, `@openai`, and `@chatgpt` map to OpenAI; `@gemini` maps to Gemini; `@both` and `@council` map to Council; `@compare` maps to Compare; `@local` prohibits remote providers for that message.

## Credential custody

Remote provider credentials are SERVER-owned secrets. The shared provider contract, CLIENT status snapshots, logs, profile assignments, dispatch receipts, and model selectors never contain secret bytes.

Credential UI follows one-way custody:

1. user enters a credential into SERVER;
2. SERVER stores it through Android Keystore-backed encrypted storage;
3. the text field is cleared;
4. a bounded status/model probe may be requested;
5. later UI displays only configured state, health, timestamps, and model information;
6. the credential can be replaced or removed, but not revealed.

The existing CLIENT Gemini credential path remains compatibility-only. No CLIENT OpenAI secret store is introduced by this contract.

## Health semantics

Provider health is explicit and non-boolean:

- `UNCONFIGURED`
- `STORED`
- `PROBING`
- `READY`
- `DEGRADED`
- `AUTH_FAILED`
- `OFFLINE`
- `ERROR`

A green/ready presentation must be backed by current runtime state; status text accompanies visual orbs so color is never the sole semantic signal.

## Model routing

SERVER owns discovered model catalogs and selected model IDs. CLIENT can request a model selection through the provider protocol but cannot supply or retrieve provider credentials.

`SWRLZ_AUTO` is local-first. Automatic remote escalation is disabled by default. Remote strategies require either an explicit per-request allowance or an enabled SERVER policy.

## Council and Compare

`COMPARE` requests independent provider contributions and presents them without fabricating agreement.

`COUNCIL` begins with parallel independent contributions. When enabled, at most one bounded cross-review round may occur. SWRLZ synthesis remains the final user-facing stage. Unlimited provider-to-provider recursion is not part of v1.

## Profile integration

Profiles from `SWRLZ_PROFILE_CONTRACT_V1` remain declarative behavior directives. Provider profiles can tune advisory reasoning style, while endpoint and relationship profiles tune SWRLZ presentation/routing. Profiles cannot override trust, Truth Firewall, permission, approval, protocol, mission, or Forge authority.

Saved profiles support `STABLE`, `TEST`, and `DRAFT` lifecycle labels plus favorites and duplication, so experimental personas can coexist with stable defaults without replacing them.

## Operational routes

SERVER exposes v1 provider operations through the existing node-host listener:

- `GET /providers/status`
- `POST /providers/probe`
- `POST /providers/model`
- `POST /providers/reason`
- `POST /providers/source/analyze`

These operational provider routes are loopback-only in this checkpoint. A LAN/remote request is rejected until verified device-proof authorization is integrated for provider execution. This prevents a provider credential from becoming a new unauthenticated remote authority surface.

## Canonical source analysis dispatch

`/providers/source/analyze` resolves the latest canonical CLIENT or SERVER source from configured Forge repository authority on SERVER, then:

1. resolves the source ZIP and companion checksum;
2. verifies SHA-256 and optional manifest identity;
3. rejects unsafe ZIP paths;
4. extracts only bounded text/source entries;
5. excludes build output, VCS internals, keystores, credential files, and known secret-bearing paths;
6. redacts token/key/password-like values;
7. caps individual and total text volume;
8. generates a dispatch receipt/provenance summary;
9. sends only the sanitized analysis context to the selected provider strategy.

Raw provider secrets are not added to the dispatch receipt. Raw source ZIP transport to a provider is not required by v1.

## Truth and cost boundary

Provider output is advisory evidence. It cannot directly execute missions, approve sensitive actions, alter trust, or mutate protocol truth. Remote/paid provider use remains intentional and policy-gated. A provider failure degrades reasoning availability; it does not redefine SWRLZ core readiness.

## Validation boundary

Source-only static verification may establish contract equality, package integrity, safe route guards, secret-field absence, and bounded changed scope. It does not establish successful provider authentication, current provider-model availability, billing behavior, network reachability, Android compilation, or device acceptance.
