# SWRLZ Command Center and Forge Package Contract V1

## Command definition

Every discoverable command has a stable ID, category, title, natural-language template, optional aliases, and optional canonical capability ID. UI surfaces may search, favorite, insert, or copy command templates. A command template never grants authority by itself.

## Protected package roles

Recognized protected source roles are `CLIENT_` and `SERVER_`. A protected source unit has one canonical ZIP identity. Checksum and manifest companions are optional evidence bound to that ZIP when supplied.

### Checksum aliases

Accepted transport names:

- `.sha256`
- `.sha256.txt`
- `.sha`

All normalize to `.sha256` for logical matching and repository routing. Multiple physical aliases that disagree must not be treated as one verified package.

### Manifest

The canonical manifest companion is `<stem>.manifest.json`. When supplied, it must name the canonical ZIP, contain a 64-character SHA-256 matching the ZIP (and receipt when a receipt is supplied), and declare `verified: true`. Forge may discover a manifest but must not synthesize one from incomplete metadata. A missing manifest does not block build eligibility.

## BOTH transaction

`BOTH` means one repository transaction containing one CLIENT source unit and one SERVER source unit. Each role retains independent source identity, optional evidence, destination lane, version, and lineage.

## Defaults

Auto-route protected source packages: ON.
Auto-resolve checksum: ON.
Auto-resolve manifest: ON.
Source ZIP guard: ON.
CLIENT+SERVER one transaction: ON.
Destination preview: ON.

## Failure rule

Checksum mismatch, manifest mismatch, or role-target mismatch blocks commit. Missing checksum/manifest companions do not block source-ZIP build eligibility. Forge must distinguish `BUILDABLE` from stronger evidence states and must never ignore contradictory supplied evidence.


## INT-FORGE-039F / 039N transport extension

Protected source transport modes are `AUTO`, `DIRECT`, and `CHUNKED`.

- `AUTO` chunks protected ZIPs above the 8 MiB transport threshold.
- `DIRECT` uses the legacy single Git blob.
- `CHUNKED` forces deterministic 8 MiB chunks.
- Chunk transport records ordered chunk path/size/SHA-256 plus whole ZIP size/SHA-256 in `<stem>.transport.json`.
- The runner must verify every chunk and the complete reconstructed ZIP before existing source/build validation.
- Completed chunk blob identities may be reused on a retry; source integrity is still re-established from SHA-256 evidence before build.

Build eligibility and promotion evidence are separate states. ZIP-only input may be built, while repository promotion policy may require additional provenance.
