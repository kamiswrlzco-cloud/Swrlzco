# SWRLZ Source + Metadata Bundle Contract V1

Checkpoint: `INT-FORGE-064A`
Status: source-candidate contract

## Canonical delivery shapes

Single component update:

```text
<COMPONENT>_<IDENTITY>.zip
<COMPONENT>_<IDENTITY>_METADATA.zip
INT_<CHECKPOINT>_EVIDENCE.zip
```

Dual CLIENT/SERVER update:

```text
CLIENT_<IDENTITY>.zip
CLIENT_<IDENTITY>_METADATA.zip
SERVER_<IDENTITY>.zip
SERVER_<IDENTITY>_METADATA.zip
INT_<CHECKPOINT>_EVIDENCE.zip
```

## Metadata ZIP

The metadata ZIP name is derived from the source ZIP stem and contains exactly two root entries:

```text
<SOURCE_STEM>.sha256
<SOURCE_STEM>.manifest.json
```

No nested paths, duplicate or case-colliding names, traversal, unrelated payloads, or oversized entries are accepted. The source ZIP, checksum target, manifest source filename, computed SHA-256, declared SHA-256, source size, component, versionCode, and candidate revision must agree before the pair is build eligible.

## Evidence ZIP

The evidence ZIP remains one archive. It contains checkpoint evidence, the delivery manifest, repository documentation, and the exact CI resolver/verifier update files. Repository expansion is fail-closed and restricted to:

- root documentation files explicitly allowed by Forge;
- `docs/`, `reports/`, `swrlz-core/docs/`, and `swrlz-core/reports/`;
- the four exact `swrlz-core/tools/ci/` resolver/verifier paths declared by this checkpoint.

Every expanded file is declared in `delivery/INT_FORGE_064A_DELIVERY.manifest.json` with an archive path, repository destination, SHA-256, and size.

## Git transport

Large source archives use `chunked-git-blobs-v2`. The transport manifest binds the reconstructed source SHA-256 and size to the metadata bundle name, repository path, metadata-bundle SHA-256, checksum entry, and manifest entry. Direct source ZIPs use the same metadata-pair verification without chunk reconstruction.

## Bootstrap compatibility

Complete legacy loose `.sha256` + `.manifest.json` sidecars remain accepted temporarily. Missing or partial legacy evidence is not build eligible. A source must use either the metadata ZIP or the complete legacy pair; mixing both for one source is rejected.

The first installation of this capability may require one legacy upload/build cycle because the previously installed Forge and repository resolver do not yet understand metadata ZIPs. After the updated Forge and shared CI files are present, later uploads use the canonical source + metadata + evidence package shape.

## Authority and safety

- Filenames are routing hints, not integrity authority.
- The computed source SHA-256 is authoritative and must match both metadata entries.
- Metadata ZIPs and evidence ZIPs are not treated as Android source ZIPs.
- Evidence expansion cannot write arbitrary repository paths.
- No package is promoted, released, deployed, or installed by this contract.
