# SWRLZ Protocol & Data Contracts v1.0 — Integrated Foundation

Canonical transport remains `CLIENT → SWURLZER → CLIENT`. This checkpoint implements matching, source-local v1 communication-envelope and deterministic conversation-routing foundations without exposing a state-changing LAN endpoint.

## Communication envelope
Stable identifiers: `messageId`, `correlationId`, `conversationId`, optional `missionId`, and immutable `eventId`. Source identifies device, component, and interface mode. Destination identifies component, optional device, and optional provider. Request type and route are explicit. Lifecycle timestamps, status, bounded error category, latency, retry metadata, and payload summary are modeled. Secrets, API keys, proof material, and raw payloads are prohibited from general summaries.

## Conversation and mission separation
Ordinary chat is never a mission by default. A conversation may be promoted only through an explicit approval request. Mission identity and lifecycle remain independent.

## Runtime events and projections
One authoritative event representation may be projected differently into User Mode and Dev Mode. Dev Mode is supplemental and cannot become a second runtime authority.

## User/Developer boundary
User Mode must expose all permissions and controls required for normal operation. Dev Mode may expose diagnostics, fixtures, compatibility testing, and experimental controls, but normal chat, mission confirmation, permissions, trust actions, and recovery cannot require entering Dev Mode.

## Non-goals for INT-CONV-012A
No live endpoint, Room migration, persistent communication log, provider adapter, protocol-version migration, APK build, deployment, or silent chat-to-mission conversion.
