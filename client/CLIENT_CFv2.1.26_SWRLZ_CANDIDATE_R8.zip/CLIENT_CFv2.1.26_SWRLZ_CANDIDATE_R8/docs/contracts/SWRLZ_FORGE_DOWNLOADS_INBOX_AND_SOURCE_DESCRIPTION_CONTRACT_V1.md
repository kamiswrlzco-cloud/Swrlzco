# SWRLZ Forge Downloads Inbox and Source Description Contract V1

## Purpose

Separate the incoming source-package inbox from the project output root and preserve exact source identity from Android Forge selection through GitHub Actions build provenance.

## Directory authority

- **Downloads inbox:** user-selected public `Download/` tree used only to discover incoming CLIENT/SERVER source packages.
- **Project root:** user-selected output root. Its folder name is the project name; fallback is `swrlz core`.
- **APK output:** `Download/<projectName>/apk/` unless an explicit APK folder override is configured.
- **Failure logs:** `Download/<projectName>/artifact apk logs/` unless overridden.

## Accepted source package forms

Preferred:

```text
<Component>_<identity>.zip
<Component>_<identity>_METADATA.zip
```

The metadata ZIP must contain exactly the matching `.sha256` and `.manifest.json` at archive root.

Legacy bootstrap:

```text
<Component>_<identity>.zip
<Component>_<identity>.sha256
<Component>_<identity>.manifest.json
```

Legacy loose companions may be siblings in Downloads or share one bounded extractor-created child directory. Exact source stem, manifest component, filename, size, SHA-256, versionCode, and revision must agree. Ambiguity fails closed.

## Automatic routing

- verified CLIENT only → CLIENT
- verified SERVER only → SERVER
- verified CLIENT and SERVER → BOTH
- incomplete, conflicting, or mismatched evidence → block and describe

## Operator description

Before mutation, Forge must show for every selected source:

- component and APK build target;
- exact source filename;
- version, candidate revision, and versionCode;
- metadata mode and companion filename(s);
- SHA-256 and source size;
- repository destination lane;
- matching evidence bundle when present.

The same identity is stored in the upload log, build ledger, durable build watch, success/failure status, and workflow provenance.

## GitHub workflow description

The source resolver emits `source_description`, `build_description`, `evidence_description`, and `metadata_mode`. The APK Router workflow publishes these as a GitHub notice, job summary, `SOURCE_RESOLUTION.json`, and `SOURCE_BUILD_DESCRIPTION.txt` in the artifact.

## Artifact completion

A successful workflow artifact ZIP is temporary transport. Forge safely inspects it, rejects unsafe paths, duplicates, oversized APK entries, and ambiguous APK sets, extracts the actual APK, verifies its SHA-256, and saves the APK under the project APK lane. Installation remains explicit.

## Compatibility

The repository resolver retains:

1. direct source + metadata ZIP;
2. chunked-git-blobs-v2 + metadata ZIP;
3. direct source + loose legacy checksum/manifest;
4. chunked-git-blobs-v1 + loose legacy checksum/manifest.

Unsupported historical candidates must not override a valid current-push verified source.
