# SWRLZ Command Palette + Capability Registry Contract v1

Checkpoint: `INT-CMD-039P`

## Stable identity

`SwrlzCommandV1.id` remains the stable discoverable command identity. Dotted segments define the navigable hierarchy and canonical prompt:

```text
<id> forge.client.latest
<path> /forge client latest
```

Capability IDs remain the execution-authority reference. A command ID, alias, template, pin, recent entry, or UI branch does not itself authorize execution.

## Required metadata

A discoverable command carries:

- stable command ID;
- title;
- category;
- editable natural-language template;
- optional aliases;
- optional canonical capability ID;
- insertion safety flag;
- approval classification;
- availability classification;
- context tags;
- optional search keywords.

## Resolver contract

The resolver may match:

- slash path;
- dotted command ID;
- title;
- template;
- alias;
- capability ID;
- keyword overlap.

An exact match returns one stable command identity. Non-exact input returns ranked suggestions. The resolver performs no side effect.

## Hierarchy contract

Hierarchy is derived from dotted IDs. UI callers may request:

- root segment for a category;
- commands under a prefix;
- child segments under a prefix;
- exact leaf at a full path.

This keeps menu structure data-driven.

## Approval classes

`READ_ONLY`: expected to inspect/show state only.

`REVIEW`: command should be reviewed in context before the backing capability runs.

`CONFIRM`: backing capability is expected to cross a meaningful state-change boundary and must retain its own confirmation/approval semantics.

`SENSITIVE`: provider, credential, sharing, or similarly sensitive capability; command discovery never enables it.

## Availability classes

`AVAILABLE`: backing capability is represented as currently available in this CLIENT lineage.

`REQUIRES_CONFIGURATION`: capability exists only when its separate configuration/enablement requirements are satisfied.

`PLANNED`: vocabulary is reserved for an approved future capability but must not be represented as implemented runtime behavior.
