# SWRLZ Behavior Shard Authoring Contract V1

Checkpoint: `INT-AI-041F-C1`  
Status: **frozen authoring contract; runtime implementation intentionally absent**

## Purpose

Behavior Shard V1 defines immutable, declarative teaching packs for a constrained local LLM. A shard teaches **how to respond** within a behavioral territory; it does not own live facts, identity authority, approvals, permissions, execution, trust, or Truth Firewall semantics.

The four authoring bands are:

1. `DO` — preferred behavior / attractor.
2. `FEASIBLY OK` — acceptable variation.
3. `FEASIBLY NOT OK` — recognizable drift that should be steered away from.
4. `DON'T` — clear failure pattern.

These labels are **authoring metadata only**. A future compiler must remove or rewrite them before inference. Examples are demonstrations, not facts, lore, memories, state, or canned replies.

## Package layout

Each `.swrlzmod` is a ZIP with:

```text
manifest.json
behavior.json
LICENSE.txt
NOTICE.txt
```

`manifest.json` reuses the generic Model Rack manifest shape with the forward module type `BEHAVIOR_SHARD` and runtime contract `behavior_shard_v1`.

`behavior.json` must validate against `SWRLZ_BEHAVIOR_SHARD_V1.schema.json`.

## Current-runtime compatibility

SERVER CFv2.1.11 does **not** implement `BEHAVIOR_SHARD`. Its current `ModelModuleTypeV1` recognizes prompt, EQ, LoRA, knowledge, and tool pack types only, and the module vault activates only prompt/EQ modules. Therefore these C1 packs are **authoring artifacts for the next runtime checkpoint and are not installable/activatable under SERVER CFv2.1.11**.

C1 intentionally does not modify SERVER or CLIENT source.

## Shared grounding foundation

All shards reference:

```text
swrlz.foundation.behavior-grounding@1.0.0
```

The reference is package/compiler metadata. A future compiler resolves it and injects the compact foundation text exactly once. The model-facing prompt must not see reference IDs or duplicated grounding paragraphs.

## Separation of concerns

```text
Permanent identity / authority     higher-order, not behavior-shard owned
Trusted runtime facts              current data with provenance/freshness
Behavior shard                     response-pattern teaching
Composition                        layout/rhythm/hierarchy
Style / EQ                         expression only
```

Behavior cannot override identity, trusted facts, grounding, Truth Firewall, approvals, permissions, trust, provenance, or execution gates.

## Conflict resolution metadata

Priority classes in this contract are:

```text
TASK_BEHAVIOR
COMPOSITION
STYLE
```

They live beneath higher-order authority/identity/fact/grounding layers. Peer resolution is deterministic:

```text
narrower scope
→ explicit declared precedence
→ stable module ID
```

Activation recency is not a default tie-breaker.

## Runtime-fact rule

Behavior shards never carry live values such as local time, current model state, connection state, update state, or Forge status. They may teach how to use those facts when a trusted runtime block supplies them.

## Mistake vs malfunction identity

Allowed accountability:

```text
I was wrong about that.
I misread the question.
My previous answer mixed those roles.
```

Disallowed identity absorption:

```text
I am broken.
I am malfunctioning.
I am an error.
```

When a technical fault exists, attribute it to the actual subsystem, operation, request, data source, module, model, transport, or prior statement.

## Base-model lineage

Initial C1 packs are pinned to:

```text
SWRLZ-LFM-OPT-001A
SHA-256: 651cd5c40e4ef24de2ff12c2b53b257d15816ddd4346e2575e6768a6ec1d8590
```

## Frozen C1 shards

- Self-State & Meaningful Changes
- Context & Pragmatics
- Grounded Lore
- Response Composition
- Expressive Signaling

Mirror Profile v1.0.2 and Harmonic Chaos EQ v1.0.0 remain unchanged baselines.
