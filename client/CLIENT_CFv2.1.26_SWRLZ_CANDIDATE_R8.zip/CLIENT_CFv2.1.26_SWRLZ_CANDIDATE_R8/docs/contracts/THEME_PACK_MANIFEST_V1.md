# ThemePack Manifest v1

Checkpoint: `INT-THEME-035A`  
Engine major: `1`

## Package form

```text
theme/
  manifest.json
  images/
  buttons/
  progress/
  startup/
  kapanion/
  backgrounds/
  overlays/
```

Only `manifest.json`, PNG, and lossless/lossy WebP are supported by manifest v1. A package is presentation data, not an executable plugin.

## Required identity

- `manifestVersion`: must equal `1`.
- `id`: stable, unique reverse-domain identifier.
- `displayName`
- `themeVersion`: semantic `major`, `minor`, `patch`.
- `compatibility`: minimum engine, maximum engine major, and CLIENT/SERVER targets.

## Presentation sections

- `palette`
- `typography`
- `shapes`
- `dimensions`
- `buttonStyle`
- `progressStyle`
- optional `startupSequence`
- `motionProfile`
- `particleStyle`
- optional launcher and Kapanion identities
- optional future `soundProfile` metadata, ignored with a warning in v1
- semantic `assets` map
- ordered `fallbacks`
- source `provenance`

Semantic roles are defined by `SemanticAssetRole.kt`. Filenames are implementation details and never appear in screen logic.

## Validation limits

Default limits are:

- archive compressed size: 64 MiB;
- total unpacked size: 160 MiB;
- individual file size: 16 MiB;
- entries: 512;
- image edge: 4096 px;
- image pixels: 16 million;
- compression ratio: 120:1.

Validation rejects absolute paths, `..`, empty path segments, backslashes, drive/URI prefixes, case-folding collisions, links, encrypted entries, unsupported file extensions, invalid dimensions, malformed hashes, duplicate IDs, unsupported targets, fallback self-cycles, and incompatible engine versions.

The importer must extract into a private staging directory, validate before activation, and transactionally select only a complete valid pack. Failure retains the known-good active pack.

## Activation status

The schema, registry, validator, fallback semantics, and built-in theme definitions are implemented. External archive import/activation is reserved and is not exposed as a working control in this source checkpoint.

