# SWRLZ Distributed Profile Contract v1

Checkpoint: `INT-PROFILE-037B`

## Purpose

Profiles provide declarative, reusable guidance for how SWRLZ presents information and emphasizes reasoning across different endpoints, relationships, providers, sessions, and per-message overrides.

Profiles are **not authority objects**. They cannot change protocol truth, identity/trust state, permissions, approval policy, mission authority, Forge authority, Truth Firewall behavior, or local/remote distinctions.

## Precedence

The deterministic precedence order is:

1. foundation;
2. endpoint;
3. relationship;
4. provider;
5. session;
6. per-message override.

Later layers refine presentation/reasoning fields only. Safety and authority remain outside this stack.

## Scopes

- `FOUNDATION`
- `CLIENT_ENDPOINT`
- `SERVER_ENDPOINT`
- `CLIENT_TO_SERVER`
- `SERVER_TO_CLIENT`
- `SERVER_TO_SERVER`
- `PROVIDER`
- `SESSION`

## Built-in profiles

- SWRLZ Base
- CLIENT Main
- CLIENT Engineer
- SERVER Architect
- CLIENT → SERVER Deep Reason
- SERVER → CLIENT Conversational
- SERVER → SERVER Node Coordination
- GPT Engineer
- Gemini Explorer
- Local Grounded

Built-ins are immutable presets. Custom profiles use stable generated IDs, inherit from an existing profile, and store only declarative profile guidance.

## Persistence

CLIENT and SERVER persist separate `ProfileDocumentV1` registries locally. Their assignments therefore may intentionally differ. A later provider/router checkpoint may transport resolved profile references across authenticated links; this checkpoint does not add a wire-protocol field or remote synchronization.

## Provider boundary

Provider profiles describe reasoning emphasis only. They do not configure credentials, probe a provider, select a live API model, or authorize paid/remote usage.
