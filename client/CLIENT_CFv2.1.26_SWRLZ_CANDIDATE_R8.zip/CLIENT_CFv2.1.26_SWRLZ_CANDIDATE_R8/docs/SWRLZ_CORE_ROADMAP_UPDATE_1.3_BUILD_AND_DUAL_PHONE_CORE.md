# SWRLZ-CORE Roadmap Update 1.3 — Build Provenance + Dual-Phone Core Node

**Roadmap revision target:** 1.3  
**Patch label:** Pzhp-BUILD-MESH  
**Purpose:** Add the mobile-friendly build automation path and the future two-phone Core Server / Action Phone architecture.

---

## Header update

Replace the current roadmap header fields with:

```md
**Roadmap revision:** 1.3 — Pzhp-LDS + Build Provenance + Dual-Phone Core integrated  
**Source patch:** 0.1.5 Context and Control Foundation + Pzhp-LDS Build Ready  
**Current verified APK baseline:** 0.1.4 Offline-First
**Current build target:** 0.1.5 / Pzhp-LDS Build Ready
```

---

## Add after `0.1.6 — Pzhp-LDS Local Core, Patch Manifests, and Learning Delta Sync`

# 0.1.6a — Build Provenance and Phone-First Cloud Build

- [ ] **BUILD-001 — One-command Android build bootstrap.** ⏳ **Planned.** Add a script that installs or verifies Android command-line tools, sets `ANDROID_HOME`/`ANDROID_SDK_ROOT`, accepts licenses, installs Android platform 34/build-tools, then calls the APK bundle build script.

- [ ] **BUILD-002 — Environment detection and self-healing build path.** ⏳ **Planned.** Detect whether the Codespace is in the repo root or a temp folder, return to the project root automatically, and fail with readable guidance instead of leaving the user stuck in `/tmp`.

- [ ] **BUILD-003 — Successful build provenance report.** ⏳ **Planned.** After a successful APK build, generate a report containing exact commands used, Android SDK path, installed SDK packages, Java/Gradle versions, APK path, APK size, SHA-256, source commit SHA, and whether any files were modified.

- [ ] **BUILD-004 — Failed build diagnostic report.** ⏳ **Planned.** If the build fails, capture the failing Gradle task, exact error, source file/line if present, last 80 lines of the build log, and whether the failure happened before Gradle, during dependency resolution, during Kotlin compile, or during packaging.

- [ ] **BUILD-005 — APK download bundle standard.** ⏳ **Planned.** Standardize `APK_DOWNLOAD/` to always include the APK, APK SHA-256, build log, build provenance report, source commit file, and one ZIP bundle ready for phone download.

- [ ] **BUILD-006 — GitHub Actions fallback APK builder.** ⏳ **Planned.** Keep a manual workflow that can build the APK in GitHub Actions and upload the APK artifact if browser Codespaces becomes too laggy or the mobile workflow hits limits.

- [ ] **BUILD-007 — Codespaces AI no-random-edit rule.** ⏳ **Planned.** Document that the Codespaces AI may install/configure build tools and run scripts, but must not rewrite SWRLZ source unless Gradle reports a real source compile error and the exact error is captured first.

- [ ] **BUILD-008 — Mobile-only maintainer workflow.** ⏳ **Planned.** Preserve the phone-first workflow: upload/pull source, run one build command, download APK bundle, install/test on Android, then report results back into the roadmap.

---

## Add after `0.2.1 — Cross-Device Mesh`

# 0.2.1a — Dual-Phone Core Node Bridge

- [ ] **PHONECORE-001 — Core Phone / Action Phone architecture.** ⏳ **Planned.** Define one Android phone as the Core Server / Brain Node and another as the Action Phone / Hands Node so reasoning, memory, logs, skills, and patch sync can run separately from the phone executing accessibility actions.

- [ ] **PHONECORE-002 — Core Node URL separate from Mentor URL.** ⏳ **Planned.** Add a dedicated Core Node endpoint setting so the Android app can connect to a local Moto 5G core server without confusing it with an online paid Mentor backend.

- [ ] **PHONECORE-003 — Same-network local connection mode.** ⏳ **Planned.** Support Action Phone connection to Core Phone over shared Wi-Fi/hotspot using local IP and port, with offline operation when internet is unavailable.

- [ ] **PHONECORE-004 — Pairing token and node identity.** ⏳ **Planned.** Pair phones with a private shared token and stable device-node IDs before allowing command, teaching, sync, or planning traffic.

- [ ] **PHONECORE-005 — `/status` health check from Action Phone to Core Phone.** ⏳ **Planned.** Show Core Phone online/offline state, core version, available routes, storage health, and last sync time inside the Android app.

- [ ] **PHONECORE-006 — Action Phone proposes/executed separation.** ⏳ **Planned.** Preserve the safety law: Core Phone can propose plans, but Action Phone verifies context, checks permissions, requests confirmation for risky actions, executes locally, and logs the result.

- [ ] **PHONECORE-007 — Teach packets from Action Phone to Core Phone.** ⏳ **Planned.** Send user corrections and demonstrated skills from the Action Phone into the Core Phone learning-delta inbox.

- [ ] **PHONECORE-008 — Core Phone local skill and memory store.** ⏳ **Planned.** Store Skill Capsules, action logs, local deltas, version history, patch manifests, and merge reports on the Core Phone so the main phone can stay lighter.

- [ ] **PHONECORE-009 — Optional Tailscale/VPN remote bridge.** ⏳ **Planned.** Later support a private VPN mode so paired nodes can reconnect across different networks without exposing unsafe public ports.

- [ ] **PHONECORE-010 — Core Node dashboard.** ⏳ **Planned.** Provide a local dashboard for status, logs, skills, sync queue, paired devices, emergency stop, and update history.

- [ ] **PHONECORE-011 — Termux prototype path.** ⏳ **Planned.** Prototype the Core Phone server in Termux/Python first, then decide whether to port to a native Android foreground service after the flow proves stable.

- [ ] **PHONECORE-012 — No-paid-runtime dependency law.** ⏳ **Planned.** The Core Phone must remain useful for storage, skills, logs, local rules, patch sync, and command routing even without OpenAI/API credits.

---

## Add to Immediate Test Target

After the current 0.1.5 phone test paragraph, add:

```md
# Immediate Build Target — Build Provenance

After the next successful Codespaces build, capture and archive the successful build provenance report: exact SDK install/setup commands, `ANDROID_HOME`, `ANDROID_SDK_ROOT`, Android packages installed, Java/Gradle versions, APK path, APK size, SHA-256, source commit SHA, and whether any source files were edited. Use this to create `scripts/install_android_sdk_and_build.sh` so future Android builds become one-command from a fresh Codespace.

# Immediate Architecture Target — Dual-Phone Core

Document the planned Moto 5G Core Phone setup as a local-first Brain Node and keep the main phone as the Action Node. Do not wire direct high-risk remote action execution yet. First target `/status`, pairing token, local IP connection, `/teach`, `/logs`, and read-only dashboard checks.
```

---

## Recommended commit message

```text
Update roadmap for build provenance and dual-phone core node
```

---

## Notes

This roadmap update does not mark any new item complete. It adds new planned milestones so the project can track:
- the clean phone-first Codespaces build flow,
- the successful-build report needed to stabilize the repo script,
- the future Moto 5G Core Server / Action Phone split,
- and the safety law that the Core proposes while the Action Phone verifies and executes.
