# INT-THEME-039A Source Handoff — CLIENT Ignition Family Completion

Date: 2026-07-27

Parent source: `CLIENT_CFv2.1.14_SWRLZ.zip`  
Parent SHA-256: `2ab12d7646bd4a733fa6986375c31715f106a3d181b315b79271d215ba946f7e`

User-supplied ignition pack: `SWRLZ_Core_Ignition_Resource_Pack_Jester_to_Kamileon.zip`  
Resource pack SHA-256: `fc5e41188e429cf5b088f8da47ead713ba0e39849b75e79e6f5011e532d58c3c`

## Result

The CLIENT source successor advances to CFv2.1.15 / versionCode 113 / `2.1.15-theme-ignition-family-completion-v1`.

Jester Glitch Dragon remains the existing reference ignition. Dragon Kamileon, Jade, Frost, Crystal Cyber, and Inferno now each use the same complete eight-role semantic startup compositor.

The new runtime derivatives are lossless WebP assets produced through the existing ThemePack alpha-crop and bounded-fit policy.

## Unchanged boundaries

No SERVER runtime change, protocol change, trust/Truth Firewall change, mission/Forge authority change, provider/profile/command contract change, GitHub write, build, workflow, APK, release, deployment, or installation is included.

The final package hash is intentionally carried by the external SHA-256 sidecar and manifest rather than embedded into the archive that it hashes.
