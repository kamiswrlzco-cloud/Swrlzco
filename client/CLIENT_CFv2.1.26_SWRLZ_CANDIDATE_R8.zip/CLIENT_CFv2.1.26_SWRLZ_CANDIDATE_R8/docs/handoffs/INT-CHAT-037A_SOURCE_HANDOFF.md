# INT-CHAT-037A — Source Handoff

Date: 2026-07-27
Status: source implementation complete; build/device evidence pending
Target: CLIENT CFv2.1.11

## Outcome

The existing `Chat & Commands` Settings domain is now a nested Chat Control Center with persistent Conversation Flow, Personality & Response, and Privacy & Context controls. Response-top follow is the new default while the old conversation-bottom behavior remains selectable.

The SWRLZ personality profile is CLIENT-local and only guides conversational model output. It does not own mission state, approval policy, Forge state, protocol truth, trust, permission, or Truth Firewall behavior.

## Deferred

- companion progress HUD / emerald endpoint calibration (`INT-THEME-036C`);
- theme quick-action composer drop-up;
- Chat Forge automatic ZIP/SHA/manifest sibling resolution;
- learned terminology/alias confirmation such as `forgaroo → Forge`.

## Verification boundary

Source-only static verification. No Gradle build, APK, device installation, GitHub workflow, commit, push, release, or deployment is claimed.
