# INT-FIX-039G Source Handoff

Parent CLIENT: CFv2.1.17 / VC115 / `2.1.17-forge-rescue-default-theme-v1`.
Successor CLIENT: CFv2.1.18 / VC116 / `2.1.18-forge-rescue-profile-store-compile-repair-v1`.
SERVER audited: CFv2.1.7, unchanged.

## Confirmed failure

Workflow `30302109949` reached `compileDebugKotlin` and rejected `ClientProfileStore.kt:142:29` because `providerProfileId?.let` referenced the helper function rather than the nullable `providerId` argument.

## Repair

`providerProfileId = providerId?.let { providerProfileId(document, it) }`

The SERVER analogue was already correct and no SERVER successor was manufactured.

## Preservation

The small default-theme rescue packaging and INT-FORGE-039E GitHub write-preflight/credential diagnostics are preserved. No protocol, trust, Truth Firewall, permission/mission authority, shared profile/provider/command contract, or offline-first behavior change is introduced.

## Evidence boundary

Source/static/package verification only. No build, APK, device test, GitHub write, workflow dispatch, commit/push, release, deployment, or installation was performed.
