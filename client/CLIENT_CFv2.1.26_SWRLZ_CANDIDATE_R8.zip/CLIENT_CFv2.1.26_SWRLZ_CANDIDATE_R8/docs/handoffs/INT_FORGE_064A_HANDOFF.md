# INT-FORGE-064A Handoff — CLIENT

Candidate: `CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R2`  
versionCode: `125`  
versionName: `2.1.26-forge-metadata-bundle-candidate-r2`

## Next external action

Use the legacy bootstrap path once to upload/build/install this Forge generation. After the shared `swrlz-core/tools/ci` files included in the combined evidence transaction are present, future updates use source ZIP + metadata ZIP + combined evidence ZIP without loose sidecars.

## Not completed here

No GitHub commit, workflow run, Android build, APK installation, promotion, release, or deployment.

## CLIENT lineage disclosure

The accepted lineage anchor remains `CLIENT_CFv2.1.26_SWRLZ_CANDIDATE_R1.zip` with SHA-256 `7b0202c01ea2ffbf7c7a3cb50f1e635c1eb6658299abb63de78b2b78502589eb` and VC124. That byte-exact archive was not available in the active runtime. Implementation therefore used the verified CFv2.1.27 R1 descendant source as the working base and preserved its File Lab surfaces while rebasing the delivery identity to the approved CFv2.1.26 R2 / VC125 target. This is a functional descendant rebase and is not represented as a byte-exact direct-parent reconstruction.
