# INT-UX-039Q — Source Handoff

Artifact: `CLIENT_CFv2.1.22_SWRLZ_CANDIDATE_R1.zip`
Parent: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R2.zip`
Parent SHA-256: `c4eb68554bc3c5bf95a0599c42da782ad3b948331cab3b08229eb73c3a9b089b`
Version code: `120`
Version name: `2.1.22-update-ledger-settings-theme-identity-candidate-r1`

## Continuation state

INT-UX-039Q adds the local interactive Update Ledger, patch-note Q&A/latest/compare support, hierarchical CLIENT/Settings Back behavior, reorganized Settings IA, and complementary role identities for SWRLZ-owned bubble surfaces.

The current rescue runtime still exposes Glitch Dragon Glass as the selectable ThemePack. Role logic is generic, but full visual/launcher asset restoration is deferred to a later merge from the preserved full visual lineage.

Android/SystemUI may add its own launcher/app badge to system bubbles. INT-UX-039Q styles the SWRLZ-owned collapsed bubble/shortcut bitmap; it does not claim independent SystemUI badge recoloring.

INT-CMD-039P-R3 and INT-FILE-039M execution remain separate pending checkpoints. Android build/device evidence must be tied to the exact packaged R1 SHA before promotion can be considered.
