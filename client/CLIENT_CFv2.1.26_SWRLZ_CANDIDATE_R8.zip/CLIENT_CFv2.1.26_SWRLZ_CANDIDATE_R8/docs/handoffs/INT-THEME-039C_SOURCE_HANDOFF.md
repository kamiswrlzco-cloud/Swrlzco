# INT-THEME-039C Source Handoff

Prepared: 2026-07-27

## Successor

CLIENT CFv2.1.16 / VC114 / `2.1.16-theme-progress-semantic-anchor-v1`.

## Defect repaired

A 100% Jester Forge progress bar stopped before the right green emerald. The older installed VC108 screenshot is retained as runtime defect evidence; current CFv2.1.15 inspection confirmed the geometry flaw still existed.

## Implementation

`ThemedProgressBar` now resolves one semantic progress geometry per ThemePack. Jester's start/end/vertical landmarks are calibrated to its ornate frame, with 100% at the 89.5% outer-width green emerald center. The progress-head center follows the same boundary used by fill/masking. Other packs preserve declared dp geometry until separately calibrated.

## Boundary

No shared ThemePack schema change and no SERVER change. No build/APK/workflow/GitHub/release/deploy/install action performed.
