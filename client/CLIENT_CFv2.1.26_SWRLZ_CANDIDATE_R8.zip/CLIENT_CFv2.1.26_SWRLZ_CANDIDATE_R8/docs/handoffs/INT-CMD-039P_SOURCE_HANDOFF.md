# INT-CMD-039P — Source Handoff

Artifact: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R1.zip`
Candidate revision: R1
Version code: 119
Version name: `2.1.21-command-palette-hierarchy-capability-registry-candidate-r1`
Parent: `CLIENT_CFv2.1.20_SWRLZ_CANDIDATE_R1.zip`

Primary changes:

1. hierarchical Chat Command quick menu generated from the command registry;
2. category/subcommand/leaf traversal from dotted stable command IDs;
3. typed command prompt with canonical slash syntax and ranked suggestions;
4. command detail with capability ID, approval class, and availability state;
5. local pinned/favorite and recent command surfaces;
6. Chat-context recommendations;
7. 039M organizer vocabulary reserved as `PLANNED`;
8. GPT/Gemini command entries marked configuration-required/sensitive rather than default-ready.

Validation boundary:

- pure command-contract Kotlin compile passes;
- hierarchy/resolver smoke checks pass;
- static regression checks pass;
- Android compile attempt is blocked before compilation by unavailable Gradle 8.7 / unreachable `services.gradle.org`;
- no APK build, device test, workflow, GitHub write, promotion, release, deployment, or install is claimed.
