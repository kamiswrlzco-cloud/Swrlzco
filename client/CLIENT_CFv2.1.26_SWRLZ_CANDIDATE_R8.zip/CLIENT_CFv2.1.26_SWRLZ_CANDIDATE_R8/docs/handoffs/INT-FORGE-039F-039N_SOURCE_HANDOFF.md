# INT-FORGE-039F + 039N — Source Handoff

Artifact: `CLIENT_CFv2.1.20_SWRLZ_CANDIDATE_R1.zip`  
Candidate revision: R1  
Version code: 118  
Version name: `2.1.20-forge-chunked-transport-optional-evidence-candidate-r1`

Primary changes:

1. protected source ZIP chunk transport (`AUTO` / `DIRECT` / `CHUNKED`);
2. 8 MiB deterministic chunking in AUTO/CHUNKED mode;
3. per-chunk and whole-ZIP SHA-256 transport manifest;
4. Git-blob resume hints for completed chunks across retry attempts;
5. ZIP-only build eligibility with optional strict sidecar evidence;
6. repository CI patch bundle for verified runner-temp reconstruction.

SERVER CFv2.1.8 R3 remains the current SERVER candidate and is not modified by this CLIENT transport checkpoint.


Validation boundary:

- source/static/regression gates pass;
- local Android compile attempt was blocked before compilation because Gradle 8.7 was unavailable locally and the environment could not resolve `services.gradle.org`;
- repository CI patch is intentionally bundled but unapplied;
- canonical promotion remains pending matching Android build evidence.
