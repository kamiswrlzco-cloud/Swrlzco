# INT-CHAT-FORGE-038C Source Handoff

Date: 2026-07-27

Paired source successors:

- CLIENT `CFv2.1.14` / versionCode `112` / `2.1.14-command-center-package-forge-v1`
- SERVER `CFv2.1.7` / versionCode `57` / `2.1.7-command-center-forge-parity-v1`

## Scope delivered

- shared Command Center catalog and canonical capability templates;
- CLIENT theme-aware Chat quick menu + searchable/favoritable Command Center;
- SERVER Command Center catalog under Command & AI;
- CLIENT / SERVER / BOTH / FILES / ASK package targets;
- automatic canonical checksum and manifest companion resolution;
- protected source ZIP + checksum + manifest verification;
- canonical CLIENT/SERVER destination routing;
- configurable CLIENT+SERVER single-transaction staging, enabled by default;
- SERVER Forge parity for role-appropriate generic ZIP expansion and package settings;
- complete source-package documentation inventory/impact classification and standing Documentation Gate.

## Evidence boundary

`docs/evidence/INT-CHAT-FORGE-038C_STATIC_VERIFICATION.md` records static checks. Compilation, APKs, device acceptance, GitHub writes/workflows, provider calls, release, deployment, and installation are not claimed.

## Repository documentation

Repository authority remains whatever `main` currently evidences. The exact living-document impact set is recorded in `docs/checkpoints/INT-CHAT-FORGE-038C_DOCUMENTATION_IMPACT_SET.md`; those repository documents must be synchronized only during a separately authorized promotion.

## Continue from here

The next bounded evidence checkpoint should compile both Android projects and validate package staging vectors: `.sha256`, `.sha256.txt`, `.sha`, missing manifest, manifest mismatch, CLIENT-only, SERVER-only, BOTH transaction, combo-disabled behavior, destination routing, and generic ZIP expansion on both apps.
