# INT-CMD-039P-R2 — Source Handoff

Artifact: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R2.zip`
Parent: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R1.zip`
Version code: `119`
Version name: `2.1.21-command-palette-parent-child-cursor-follow-candidate-r2`

## Continuation state

R2 refines the already-implemented hierarchical Chat Command Center. Preferred syntax is `/parent (child) [instructions]`. The menu is action-first, old tokenized forms remain compatible, command insertion is end-caret stable, and response-top follow is an exact zero-offset target when layout permits.

039M runtime actions remain planned. Do not infer filesystem execution capability from their presence in the command catalog.

Android build/device verification remains pending and must be tied to the exact packaged R2 SHA before promotion can be considered.
