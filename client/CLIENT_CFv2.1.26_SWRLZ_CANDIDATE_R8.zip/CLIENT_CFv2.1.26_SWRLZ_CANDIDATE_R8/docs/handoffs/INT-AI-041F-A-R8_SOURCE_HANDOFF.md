# INT-AI-041F-A-R8 Source Handoff

Deliver together:

- `SERVER_CFv2.1.10_SWRLZ_CANDIDATE_R1.zip` plus checksum and verification manifest;
- `CLIENT_CFv2.1.23_SWRLZ_CANDIDATE_R1.zip` plus checksum and verification manifest;
- `SWRLZ_TECHNICAL_FOCUS_EXAMPLE_v1.0.0.swrlzmod`;
- `SWRLZ_WARM_COMPANION_EQ_EXAMPLE_v1.0.0.swrlzmod`;
- the separately preserved `SWRLZ-LFM-OPT-001A.gguf`.

The GGUF is deliberately not inside either source ZIP.

## Build handoff

Use the exact source ZIP bytes. Re-run `scripts/verify_int_ai_041f_a.py` against both unpacked roots and the GGUF before compiling. Use the pinned wrappers: Gradle 8.9 for SERVER and 8.7 for CLIENT.

Build/test acceptance remains separate because this workspace could not fetch the wrappers. Do not promote solely from the 36/36 static result.

## Pairing handoff

SERVER generates a dedicated encrypted model-rack credential. The user may reveal/rotate it in SERVER settings and place it in the existing CLIENT Core Node pairing-token field. LAN control additionally requires the CLIENT’s registered device-node identity, `action-phone` role and same-subnet authorization.

This credential does not authorize missions, files, tools, providers, Forge or general administration.

## Runtime handoff

1. Install paired debug candidates after successful builds.
2. Import the external optimized GGUF through SERVER Model Vault.
3. Verify the exact-SHA badge in SERVER and CLIENT.
4. Save a per-model profile, switch Speed/Depth/EQ, activate each prompt/EQ pack, then test profile rollback.
5. Activate a second compatible GGUF and test model rollback.
6. Rotate the pairing token and prove the old token fails.
7. Attempt LoRA activation and prove it returns the native-bridge blocker.

Keep status REVIEW until all steps are recorded against the exact package pair.
