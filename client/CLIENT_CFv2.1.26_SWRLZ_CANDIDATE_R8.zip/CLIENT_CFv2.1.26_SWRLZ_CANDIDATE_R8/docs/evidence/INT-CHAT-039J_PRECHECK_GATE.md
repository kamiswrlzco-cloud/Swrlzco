# INT-CHAT-039J — Compile-Sensitive Precheck Evidence

- Workflow evidence: `30306467282` reached `:app:compileDebugKotlin` and stopped on the unannotated `ModalBottomSheet` in `ProviderMeshStatusStrip`.
- Source repair: narrow `ExperimentalMaterial3Api` opt-in applied to the owning function.
- Regression guard: `scripts/verify_compose_experimental_optins.py`.
- Guard self-test: PASS.
- Production Kotlin scan: PASS.
- Full Android recompile after repair: PENDING external Android-capable build evidence.

Evidence class: source-level tested + compile-failure-derived regression tested. Not build-tested.
