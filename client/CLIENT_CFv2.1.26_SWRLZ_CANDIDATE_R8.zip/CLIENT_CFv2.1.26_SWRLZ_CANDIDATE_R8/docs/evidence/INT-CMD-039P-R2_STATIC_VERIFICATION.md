# INT-CMD-039P-R2 — Static Verification

Date: 2026-07-28
Candidate: `CLIENT_CFv2.1.21_SWRLZ_CANDIDATE_R2`
Parent SHA-256: `c1d3d029b55fdd095067f54e78466856b638ef281daa28ae4171bc446fd32528`

## Passed evidence

- parent source ZIP identity re-read before modification: **PASS**;
- command-contract direct Kotlin compilation with local `kotlinc`: **PASS**;
- structured `/parent (child) [instructions]` resolver smoke: **PASS**;
- legacy tokenized slash compatibility smoke: **PASS**;
- action-first hierarchy smoke, including Forge selector tier: **PASS**;
- INT-CMD-039P-R2 static regression gate: **28 / 28 PASS**;
- existing Forge 039F/039N source regression precheck: **PASS**;
- Compose experimental API opt-in gate: **PASS**;
- JSON parse: **17 files PASS**;
- XML parse: **17 files PASS**.

## Android compile boundary

A compile-only attempt invoked `bash gradlew --offline :app:compileDebugKotlin --no-daemon`. The Gradle wrapper attempted to obtain Gradle 8.7 and failed at `services.gradle.org` because the environment has no network access and the distribution is not cached.

The failure occurred before Android/Kotlin project compilation. It is **not compiler evidence against the R2 source**.

## Not claimed

- Android project compile verification;
- APK assembly/build;
- device/runtime validation;
- GitHub workflow/commit/push;
- source promotion;
- release/deployment/installation.
