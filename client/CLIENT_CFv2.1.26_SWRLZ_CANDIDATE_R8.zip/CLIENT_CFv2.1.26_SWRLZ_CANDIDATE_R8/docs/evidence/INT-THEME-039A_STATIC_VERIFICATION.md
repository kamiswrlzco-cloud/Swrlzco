# INT-THEME-039A Static Verification

Date: 2026-07-27

## Inputs

- Parent CLIENT: `CLIENT_CFv2.1.14_SWRLZ.zip`
- Parent SHA-256: `2ab12d7646bd4a733fa6986375c31715f106a3d181b315b79271d215ba946f7e`
- Ignition resource pack: `SWRLZ_Core_Ignition_Resource_Pack_Jester_to_Kamileon.zip`
- Resource pack SHA-256: `fc5e41188e429cf5b088f8da47ead713ba0e39849b75e79e6f5011e532d58c3c`

## Static checks

| Check | Result | Evidence |
|---|---|---|
| Parent source hash | PASS | exact SHA-256 above |
| Resource pack hash | PASS | exact SHA-256 above |
| Resource root manifest | PASS | all 54 listed entries matched declared bytes and SHA-256 |
| New runtime ignition derivatives | PASS | 40 lossless WebP resources derived through alpha-crop + bounded-fit policy |
| Runtime asset catalog | PASS | each new runtime file hash/size matches its catalog entry |
| Startup role completeness | PASS | Kamileon, Jade, Frost, Crystal Cyber, Inferno each declare all eight semantic startup roles; Jester remains complete |
| Startup compositor | PASS | theme-generic compositor uses the existing readiness-truthful timeline |
| Reduced motion | PRESERVED | existing static startup branch unchanged |
| Theme contract test source | PASS | source asserts six supplied families declare all eight startup roles |
| Android source identity | PASS | versionCode 113 / `2.1.15-theme-ignition-family-completion-v1` |
| Changed JSON parse | PASS | runtime asset catalog parsed successfully |
| Changed Kotlin delimiter scan | PASS | `BuiltInThemePacks.kt`, `ThemeStartupHost.kt`, and `ThemeContractTest.kt` balanced under comment/string-aware static scan |

## Evidence boundary

This report is source/static evidence. Gradle compilation, JUnit execution, APK assembly, workflow execution, device launch behavior, performance, release signing, installation, and deployment are not claimed.
