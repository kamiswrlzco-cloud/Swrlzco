# INT-CHAT-039I — CLIENT Static Verification

Status: **PASS for source/static gates; first Android compile exposed one Material3 opt-in blocker; candidate v2 repair prepared**

## Passed

- Parent package hash verified before extraction: `2de60c5267e9ff9765cdb21af4f0fbe424972521050d4c460f9aac8b76dea7c4`.
- Test-first acceptance scan failed on the unmodified candidate for IME-aware layout / compact mesh / compact composer, then passed after implementation.
- Pure `ChatWorkspacePolicy.kt` compiled with local `kotlinc` and executable acceptance vectors passed.
- Changed Kotlin lexical delimiter/string/comment balance: pass.
- Full JSON parse across candidate tree: pass.
- Full XML parse across candidate tree: pass.
- Shared provider/profile/command contract files remain byte-identical to synchronized SERVER candidate.
- No protocol, mission, permission, trust, Truth Firewall, provider contract, profile contract, or command contract source was modified by CLIENT 039I.

## Full compile attempt

`./gradlew :app:compileDebugKotlin` could not start dependency resolution because this execution environment has no cached Gradle 8.7 distribution and DNS/network access to `services.gradle.org` is unavailable (`UnknownHostException`). This is an environment/toolchain block, not evidence of candidate compile success or failure.

Under the standing SWRLZ Promotion Gate, this candidate must not be described as compile/build verified until an Android-capable build environment runs the gate successfully.


## External Android compile evidence

Workflow `30306467282` progressed through source resolution/verification and Android toolchain setup, then failed at `:app:compileDebugKotlin` on `ClientShellScreen.kt:1034:9`: experimental Material3 API use without local opt-in. Candidate v2 applies the required function-level opt-in.

## Test-method hardening

Added `scripts/verify_compose_experimental_optins.py`. It:

- contains a self-test proving an unannotated `ModalBottomSheet` fixture fails and an annotated fixture passes;
- scans Kotlin production sources before packaging;
- reports file, line, owning function, and required annotation for known compile-sensitive Compose APIs;
- is explicitly a regression/precheck layer, not a substitute for `compileDebugKotlin`.

Results for candidate v2: self-test PASS; full production-source scan PASS.
