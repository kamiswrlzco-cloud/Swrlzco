# INT-AI-041F-A-R8 Static Verification

Evidence class: **SOURCE/STATIC + SUPPLIED-MODEL IDENTITY**

## Gate results

`scripts/verify_int_ai_041f_a.py` passed `36/36` checks against the paired SERVER and CLIENT candidates plus the external optimized GGUF.

Covered invariants:

- byte-identical shared contract;
- exact model SHA-256 and byte-size constants;
- candidate version identities;
- bounded control authority and immutable safeguard list;
- SWRLZ GGUF metadata extraction;
- exact optimized-base recognition;
- per-model profile isolation, generations and rollback;
- 32768-token runtime ceiling;
- pack archive/entry/manifest bounds;
- payload size and SHA-256 verification;
- archive traversal and executable-content rejection;
- live prompt/EQ composition;
- LoRA activation fail-closed;
- exact-model-only embedded prompt consumption;
- verified model activation and rollback;
- encrypted dedicated pairing credential;
- registered action-phone and same-subnet LAN authorization;
- bounded protocol routes;
- complete CLIENT endpoint use;
- CLIENT identity, role and pairing headers;
- CLIENT generation-checked writes;
- Model/Speed/Depth/EQ/Module controls;
- truthful non-intelligence Depth label;
- source exclusion of `.gguf` and `.safetensors`;
- external model file size and SHA-256.

## Differential Kotlin grammar scan

The same `web-tree-sitter` Kotlin grammar scanned both complete source pairs:

| Pair | Kotlin/KTS files | Files reported by grammar |
|---|---:|---:|
| Parent SERVER R8 + CLIENT 2.1.22 R1 | 213 | 7 |
| Successor SERVER 2.1.10 R1 + CLIENT 2.1.23 R1 | 224 | 7 |

The reported files and grammar limitation patterns are the same categories in parent and successor:

- CLIENT `GeminiClient.kt`;
- CLIENT `Api.kt`;
- CLIENT `ClientShellScreen.kt`;
- SERVER `SwrlieModelVault.kt`;
- SERVER `PairedLanAuthorizer.kt`;
- SERVER `NodeCompatibilityProtocol.kt`;
- SERVER `NonMutatingDeviceResolution.kt`.

Line shifts reflect added imports/declarations. No new file-pattern failure was introduced. This is differential parser evidence only; the third-party grammar does not replace the Kotlin compiler.

## Build attempt

- SERVER Gradle wrapper requires Gradle `8.9`.
- CLIENT Gradle wrapper requires Gradle `8.7`.
- Neither distribution was cached in the available isolated Gradle home.
- `services.gradle.org` was unreachable from this workspace.
- Therefore project configuration and Kotlin compilation did not begin.

No compilation, APK or device success is claimed.

## Parent evidence

The supplied SERVER R8 provenance records successful `:app:assembleDebug` for the immutable R8 parent. That evidence does not transfer to this successor’s changed source.

## Required next evidence

1. Compile shared contract tests and both Android applications with their pinned Gradle versions.
2. Build debug APKs from the exact packaged source bytes.
3. Install on paired test devices.
4. Import the external optimized GGUF on SERVER.
5. Verify status, per-model save, model activation, prompt/EQ activation, conflict rejection, profile/model rollback and token rotation over paired LAN.
6. Confirm LoRA activation remains blocked.
7. Record APK/source checksums and device evidence before promotion.
