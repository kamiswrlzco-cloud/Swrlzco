# INT-FORGE-042B Static Verification

- Source/static checkpoint only.
- 4 MiB protected-source chunk planner present.
- bounded per-blob retry present for 401/408/425/429/5xx transient classes.
- 401 credential/repository reprobe present before same-chunk retry.
- remote size + SHA-256 verification required before cached chunk reuse.
- transport diagnostics include attempt/status/request-id/reprobe/wait fields.
- SERVER protected-source transport parity present.
- Android compilation and APK generation were not run in this workspace.
