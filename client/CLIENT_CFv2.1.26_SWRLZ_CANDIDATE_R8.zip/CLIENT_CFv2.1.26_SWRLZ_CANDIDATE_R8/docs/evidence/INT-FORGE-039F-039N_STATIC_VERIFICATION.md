# INT-FORGE-039F + 039N — Static Verification

Status: **PASS for bounded source/static tests; Android build pending**

Verified during candidate preparation:

- pure-JVM `ForgeChunkTransport` split/reconstruct test: 20 MiB+123 bytes -> 3 deterministic chunks -> byte-identical reconstruction;
- repository resolver tests: 8/8 passed, including ZIP-only eligibility, supplied checksum mismatch rejection, supplied manifest mismatch rejection, exact chunk reconstruction, corrupted chunk rejection, and current-push transport-manifest selection;
- repository patch applier Python syntax check passed;
- patch-applier fixture verified expected workflow changes;
- chunk transport manifest contains per-chunk SHA-256 plus whole ZIP SHA-256;
- source-side validation retains fail-closed behavior for supplied contradictory evidence.

Additional validation completed before packaging:

- Compose experimental opt-in gate self-test: PASS;
- full CLIENT Compose opt-in scan: PASS;
- `INT-FORGE-039F+039N` source/regression precheck: PASS;
- CI resolver regression suite: 8/8 PASS;
- actual SERVER CFv2.1.8 R3 source (40,290,065 bytes) simulated as 5 × 8 MiB-or-smaller chunks and reconstructed byte-identically to SHA-256 `506d83b058bf8127092a8d08c20c61f763bbb97e4847d8f6ce4d3f5c0df7c451`;
- reconstructed SERVER R3 ZIP passed the new ZIP-only build-eligibility verifier with no supplied checksum or manifest.

A local `:app:compileDebugKotlin` attempt was made. The Gradle wrapper could not start because Gradle 8.7 is not cached in this environment and `services.gradle.org` is unreachable (`UnknownHostException`). The failure occurred before Android/Kotlin compilation, so compile/build success is **not** claimed.
