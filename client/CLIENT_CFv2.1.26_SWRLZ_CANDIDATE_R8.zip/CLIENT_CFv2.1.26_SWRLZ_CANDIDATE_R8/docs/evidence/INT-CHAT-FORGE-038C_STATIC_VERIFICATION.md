# INT-CHAT-FORGE-038C Static Verification

Date: 2026-07-27

## Parent evidence

- CLIENT parent: `CLIENT_CFv2.1.13_SWRLZ.zip` — SHA-256 `2414eb90bf66ed48eed21090a7b832361ef3fa76b6d4586910ad5b8df2f0ccb1`
- SERVER parent: `SERVER_CFv2.1.6_SWRLZ.zip` — SHA-256 `2b7d23ed5053f421aab0569f5a559e8530d89db516ec7a56a3ebc411190d4099`

Both parent hashes were recalculated from the supplied package bytes before successor packaging.

## Static checks passed

- shared `command-contract` source is byte-identical between CLIENT and SERVER;
- changed-source scope contains no protocol, security, mission, ThemePack contract, provider-contract, or profile-contract modification;
- changed Kotlin `.kt` files pass delimiter/string/comment lexical balance;
- CLIENT Android metadata is `versionCode 112` / `2.1.14-command-center-package-forge-v1`;
- SERVER Android metadata is `versionCode 57` / `2.1.7-command-center-forge-parity-v1`;
- both Gradle settings include `:command-contract`, and both app modules depend on it;
- both Forge settings surfaces default automatic checksum matching, manifest matching, combo transactions, canonical routing, and destination preview to enabled;
- both Forge action surfaces honor CLIENT / SERVER / BOTH / FILES / ASK target selection;
- disabling combo transactions prevents `BOTH` from being selected as a valid package target;
- protected source package validation requires canonical ZIP/checksum/manifest agreement under default settings;
- `.sha256`, `.sha256.txt`, and `.sha` names normalize to the canonical `.sha256` logical companion;
- canonical CLIENT and SERVER package files route to their configured source lanes;
- SERVER now carries the generic-ZIP repository-root expansion behavior/settings already present on CLIENT where that behavior is role-appropriate;
- changed text files contain no detected OpenAI, Gemini, or GitHub token-shaped secret literal.

## Evidence boundary

This is source/static verification only. Gradle compilation, unit/instrumented tests, APK assembly, Android runtime acceptance, GitHub upload/commit/push, workflow execution, provider calls, release, deployment, and installation were not run or claimed.
