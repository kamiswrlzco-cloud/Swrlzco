# INT-THEME-039C Static Verification

Evidence class: **source/static**  
Prepared: 2026-07-27

## Parent and lineage

- Parent `CLIENT_CFv2.1.15_SWRLZ.zip` SHA-256 recalculated as `627e28d90862039f4e52510481f33211ed13c3bfa6611bc93934c2a672c904bb`: **PASS**.
- Android successor identity is versionCode `114`, versionName `2.1.16-theme-progress-semantic-anchor-v1`: **PASS**.

## Geometry repair

- Inline `jesterFrame` layout branch removed from `ThemedProgressBar`: **PASS**.
- Theme-aware `themeProgressGeometry(themePack)` resolver present: **PASS**.
- Jester end landmark is `0.895` outer-width fraction, corresponding to the green emerald core center in the 1024 px frame asset: **PASS**.
- Head semantic anchor is `0.5`, so its center follows the same progress boundary used by fill/masking: **PASS**.
- Uncalibrated themes retain declared `ThemeProgressStyle` dp geometry: **PASS**.

## Contract and source boundaries

- Parent `android/theme-contract` tree hash: `6a229c6c742baaecd6b1f348619d690fbdd203be2899358d9185cbc76559a8ba`.
- Successor `android/theme-contract` tree hash: `6a229c6c742baaecd6b1f348619d690fbdd203be2899358d9185cbc76559a8ba`.
- Shared ThemePack contract byte equality: **PASS**.
- SERVER source modified: **NO**.

## Static syntax/data checks

- Changed Kotlin source lexical delimiter check: **PASS**.
- JSON parse across source tree: **PASS**.
- Android resource XML parse: **PASS**.
- Changed-path inspection limited implementation changes to `ThemedProgress.kt`, Android identity, and documentation: **PASS**.

## Evidence boundary

No Gradle compilation, unit/instrumented test, APK assembly, workflow execution, device acceptance, GitHub write, release, deployment, or installation is claimed by this checkpoint. Archive CRC, archive-to-source equality, deterministic repack, and external sidecar/manifest binding are performed after final source packaging and recorded in the external handoff.
