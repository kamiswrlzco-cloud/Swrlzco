# INT-THEME-036A — Runtime Progress Layering / Clipping Diagnosis

Date: 2026-07-27
Target: CLIENT
Canonical runtime evidence: CLIENT CFv2.1.9 / versionCode 107
State: diagnosis complete; exact CFv2.1.9 source received and repair implemented in CFv2.1.10

## User-reported device evidence

On-device CFv2.1.9 theme preview shows the Jester progress family rendering, but:

- the determinate filler does not read as a clean reveal of the full track texture;
- animated energy/streaming effects visually compete with the decorative bar instead of reading as contained energy behind it;
- the desired composition is energy inside the track, behind the fill/frame, with no effect escaping the bar UI.

This device evidence supersedes the earlier static-only geometry confidence for the affected visual behavior. It does not invalidate CI compilation evidence or unrelated ThemePack behavior.

## Confirmed lineage facts

- INT-THEME-035C documented a shared inset track, moving-layer clipping, and frame-after-track rendering.
- INT-THEME-035D preserved the CFv2.1.8 theme behavior while repairing package/application identity and the canonical manifest contract.
- CFv2.1.9 compiled successfully in CI; the reported defect is runtime visual acceptance evidence, not a compiler failure.

## Root-cause class

The remaining issue is in render composition rather than source routing, asset integrity, protocol, trust, missions, Forge, or build identity.

Two behaviors must be corrected together:

1. **Reveal geometry**
   A determinate progress amount must crop/reveal a full-size track texture. It must not measure the fill image inside a fractional-width parent that can constrain/squash the entire texture into the completed fraction.

2. **Layer ownership**
   Ambient/highlight/particle motion belongs to the clipped active track underlay. The decorative frame owns the outer silhouette and must render after track effects. Effects must not render as full-component overlays.

## Required rendering stack

```text
Outer component — final clip boundary
├─ inactive/dark track substrate
├─ inner track — start/end/vertical insets
│  ├─ animated ambient stream UNDERLAY
│  ├─ active-window clip
│  │  ├─ fill texture at FULL track geometry (cropped, never squeezed)
│  │  ├─ bounded particles
│  │  └─ bounded highlight
│  └─ indeterminate window when progress is unknown
├─ decorative frame — over track/effects
├─ progress head — clamped to track travel
└─ truth-gated terminal effect
```

### Determinate

The active clip window is `0 .. trackWidth * value`. The fill image remains laid out at full track width and is revealed through a draw clip/mask.

### Indeterminate

The active clip window moves inside the track. No percentage is fabricated. The texture is not compressed into the segment width.

### Paused / reduced motion

Existing truth/motion rules remain authoritative: paused motion freezes; reduced-motion presentation omits continuous movement.

## Boundaries

No SERVER, protocol, trust, Truth Firewall, identity proof, permission, mission authority, Forge authority, listener/discovery authority, local/remote distinction, or offline-first behavior is in scope.

No GitHub write, workflow dispatch, build, release, deployment, or installation is authorized by INT-THEME-036A.

## Canonical-source resolution

The exact `CLIENT_CFv2.1.9_SWRLZ.zip` was subsequently supplied and independently
matched to SHA-256
`87a09a5032751dbf74f5a277a6d9b0e1f9bc48e38e48006c50d0c107cd3d30ac`.
INT-THEME-036A was therefore implemented on the correct CFv2.1.9 lineage rather
than the older CFv2.1.7 rollback tree.
