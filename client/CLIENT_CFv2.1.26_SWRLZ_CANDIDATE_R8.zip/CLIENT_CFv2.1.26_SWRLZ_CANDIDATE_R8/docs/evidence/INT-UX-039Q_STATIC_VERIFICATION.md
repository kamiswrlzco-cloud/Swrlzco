# INT-UX-039Q — Static Verification

Date: 2026-07-28
Candidate: `CLIENT_CFv2.1.22_SWRLZ_CANDIDATE_R1`
Parent source ZIP SHA-256: `c4eb68554bc3c5bf95a0599c42da782ad3b948331cab3b08229eb73c3a9b089b`

## Passed evidence before final packaging

- exact parent R2 source identity verified before modification: **PASS**;
- command-contract direct Kotlin compilation with local `kotlinc`: **PASS**;
- Update Ledger catalog direct Kotlin compilation with local `kotlinc`: **PASS**;
- update query smoke for latest/ask/compare and non-hijack behavior: **PASS**;
- INT-UX-039Q dedicated source/static regression gate: **29 / 29 PASS**;
- existing INT-CMD-039P-R2 regression gate before candidate identity advance: **28 / 28 PASS**;
- existing Forge 039F/039N source regression gate: **PASS**;
- Compose experimental API opt-in gate: **PASS**.

Final package-level JSON/XML parse counts, ZIP CRC, deterministic-repack equality, archive/source equality, byte size, and SHA-256 are recorded in the external candidate manifest generated after packaging.

## Android compile boundary

A compile-only attempt invoked the Gradle wrapper for `:app:compileDebugKotlin`. Gradle 8.7 was not cached, and the wrapper could not resolve `services.gradle.org` in this environment. The attempt stopped before Android/Kotlin project compilation.

This is recorded as `blocked_before_compilation`; it is **not compiler evidence against INT-UX-039Q source**.

## Not claimed

- Android project compile verification;
- APK assembly/build;
- device/runtime validation of Update Ledger, navigation, or bubble appearance;
- independent styling control over Android/SystemUI-added app badges;
- full ThemePack visual restoration;
- INT-CMD-039P-R3 execution bridge;
- filesystem organizer execution;
- GitHub workflow/commit/push;
- source promotion, release, deployment, or installation.
