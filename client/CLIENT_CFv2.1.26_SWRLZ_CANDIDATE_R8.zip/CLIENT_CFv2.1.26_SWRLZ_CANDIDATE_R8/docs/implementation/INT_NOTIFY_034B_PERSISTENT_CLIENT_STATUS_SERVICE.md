# INT-NOTIFY-034B — Persistent Client Status Service

## Status

Implemented in CLIENT CFv2.0.31.

## Problem

The Client status notification was published only from `MainActivity`. On devices where the
activity was recreated, dismissed, or the notification pipeline was initialized before Android
13 notification permission was granted, the Client could have no durable notification-shade
surface even though the Server notification remained visible.

## Decision

The Client now owns a dedicated foreground `ClientStatusService` started only from a visible
Client activity and only when:

1. the Notification widget preference is enabled; and
2. Android notification permission is available.

The service observes mission state, ambient state, server truth, notification preference, and
theme settings. It republishes one ongoing status notification whenever any source changes.

## User-visible status

The expanded notification displays:

- Client ambient/runtime state;
- `Server: CONNECTED` or `Server: OFFLINE`;
- configured/discovered server endpoint;
- active mission or ready state;
- current session evidence;
- selected theme family and display mode.

## Android behavior

The status notification uses a new channel ID so devices that retained an older channel
configuration receive the corrected channel definition. The notification is silent, ongoing,
private on the lock screen, and categorized as a service status surface.

The Floating Dragon conversation notification remains separate. Disabling the Client
Notification widget stops the status service and removes both Client status surfaces.

## Security

No credentials, registration tokens, message bodies, or raw device identifiers are placed in
the notification. Lock-screen visibility is private.

## Performance

The service uses one supervised coroutine and a five-source `Flow.combine`. Updates are
`setOnlyAlertOnce` and silent, avoiding repeated sound/vibration. No polling loop was added.

## Verification

Static verification covered:

- manifest service declaration;
- foreground-service permission and special-use subtype;
- Android 13 notification permission guard;
- service start/stop binding to the existing preference;
- live server, mission, and theme flow collection;
- stable notification ID and separate conversation notification ID.

A GitHub Actions or local Gradle build remains the authoritative compile and packaging check.
