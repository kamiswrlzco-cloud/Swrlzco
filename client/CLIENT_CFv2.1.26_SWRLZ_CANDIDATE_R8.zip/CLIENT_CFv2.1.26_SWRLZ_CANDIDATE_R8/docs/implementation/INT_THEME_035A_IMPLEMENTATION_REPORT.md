# INT-THEME-035A CLIENT Implementation Report

## Outcome

CLIENT now resolves presentation through a versioned declarative ThemePack registry while retaining existing Theme Armor behavior and authority boundaries. The implementation is additive to CFv2.1.5.

## Main source changes

- `android/theme-contract/`: semantic roles, registry, built-ins, manifest model, validator, and tests.
- `android/app/.../ui/theme/`: ThemePack resolver, dynamic palette/typography/shapes, startup host, and layered progress renderer.
- `android/app/.../ui/screens/StyleScreen.kt`: active/preview distinction, built-in catalog, Kapanion/progress preview, explicit apply/reset, custom-theme reservation.
- `android/app/.../MainActivity.kt`: selected-theme startup host around concurrently loading navigation.
- mission, overlay, Forge, workflow, and repository surfaces: semantic progress snapshots.
- `Prefs.kt`, `UiStyleSettings`, and `ThemeIdentityManager`: stable-ID migration and independent CLIENT persistence.
- manifest/mipmap resources: six new deferred launcher aliases.
- `tools/theme_assets/`: deterministic master-to-runtime WebP pipeline.

## Renderer contract

Application state supplies `value: Float?` and `ThemeProgressState`. A null value is indeterminate. Paused state freezes visual energy. Completion art is rendered only for `SUCCESS`; failure/interruption art is rendered only for `FAILED`, `INTERRUPTED`, or `CANCELLED`.

The startup host receives only a readiness Boolean. It does not perform initialization. Jester uses the full sequence; all other themes use the registered identity fallback. Fast readiness accelerates cleanly to approximately 600 ms; long readiness uses indeterminate progress.

## Accessibility and performance

- Progress exposes exact range information or TalkBack indeterminate state plus textual status.
- Decorative art has no content description.
- System animator disable and the local animation setting produce a static startup and omit moving particles/highlights.
- PNG masters are bounded, alpha-trimmed lossless WebP at preprocessing time.
- Compose animates alpha, transform, clipping, and masks rather than allocating bitmaps per frame.
- Startup layers enter composition only in their active timeline window.

## Deferred

- Importing/activating custom archives.
- Full preprocessing of text-baked/opaque button banners into language-neutral state layers.
- Dedicated startup packs for non-Jester families.
- Teal launcher/Kapanion identity.
- Build and device evidence.
