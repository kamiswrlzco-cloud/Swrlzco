# INT-THEME-035A Runtime Asset Provenance

The runtime pipeline consumed only inspected visual masters from:

| Source pack | SHA-256 | Runtime use |
|---|---|---|
| `SWRLZ_ASSETS_01_Launchers_Kapanions.zip` | `adfffaa46a72f241f0dfe036278b0b1e9264db3e489041d93c1a61876f8c06e3` | launcher and Kapanion identities |
| `SWRLZ_ASSETS_05_Progress_Inferno_Ice_Jade.zip` | `a2581366f10e324277e6f79c5680d81bb4df51824ffe43e1546ade0e7277d01b` | Inferno, Frost, Jade progress |
| `SWRLZ_ASSETS_06_Progress_Digital_Crystal_Teal_Kamileon.zip` | `6e98f0f65124d89d31afe0c556ee693f0816af40cbece4ac03faaf897f45ae96` | Digital Glitch, Crystal Cyber, Teal Serpent, Kamileon progress |
| `Jester_Glitch_Dragon_Progress_Assets.zip` | `b8a8b57be01ca95327a9604616dd26836719eb822b14b0e2782809d8381fe9ef` | Jester progress |
| `SWRLZ_Jester_Glitch_Dragon_Core_Ignition_Assets.zip` | `8499f5aaab30540076a4c99bfc967bc8d18fd65bedbd22d0701ede06a0a6ecef` | Jester startup |

Button packs 02–04 were inspected but not transformed into generic button states because many files contain baked English action text, opaque rectangles, mixed theme identity, or no true normal/pressed/disabled relationship. Existing code-rendered controls remain in use until a later asset-normalization checkpoint can preserve localization, touch targets, and accessibility.

The split-pack source manifests were not reused because each refers to files outside its own archive. Runtime mappings and hashes are regenerated from verified pack contents.

The 101 emitted WebP files and their exact source path, role, dimensions, size, and SHA-256 are recorded in `android/app/src/main/assets/themes/runtime_asset_catalog.json`.

## INT-THEME-039A ignition resource completion

The user-supplied `SWRLZ_Core_Ignition_Resource_Pack_Jester_to_Kamileon.zip` was verified before integration at SHA-256:

`fc5e41188e429cf5b088f8da47ead713ba0e39849b75e79e6f5011e532d58c3c`

The pack root manifest contains 54 entries and every listed byte count and SHA-256 was revalidated before any runtime asset was copied.

Runtime mapping:

| Supplied ignition family | CLIENT ThemePack | Runtime slug | Action |
|---|---|---|---|
| Jester Glitch Dragon | `sh.swrlz.theme.jester_glitch_dragon` | `jester` | Existing reference ignition preserved |
| Kamileon Glitch | `sh.swrlz.theme.dragon_kamileon` | `kamileon` | Added eight PNG startup roles |
| Jade Emerald Gold | `sh.swrlz.theme.jade` | `jade` | Added eight PNG startup roles |
| Ice Frost Crystal | `sh.swrlz.theme.frost` | `frost` | Added eight PNG startup roles |
| Neon Cyber Glitch | `sh.swrlz.theme.crystal_cyber` | `crystal_cyber` | Added eight PNG startup roles |
| Inferno Volcanic | `sh.swrlz.theme.inferno` | `inferno` | Added eight PNG startup roles |

`Neon Cyber Glitch` is mapped to the existing Crystal Cyber family because the supplied blue/purple/magenta cyber artwork matches that canonical ThemePack family. No new theme ID was invented.

The five newly populated families use the same semantic roles as Jester:
`startup.dormant`, `startup.spark`, `startup.partial`, `startup.awakened`,
`startup.shockwave`, `startup.particles`, `startup.radial`, and `startup.residual`.

The supplied transparent PNGs are normalized with the existing ThemePack preprocessing policy (alpha crop, bounded fit, lossless WebP) before placement in `drawable-nodpi`; no lossy recompression or AI replacement art was introduced.

