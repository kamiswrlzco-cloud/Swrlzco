# INT-FORGE-054A-R2 Checkpoint

Status: **SOURCE CANDIDATE PACKAGED**

This checkpoint introduces a shared CLIENT/SERVER Forge build conveyor and lineage foundation without changing the authority split: SERVER owns SERVER inference/runtime truth; CLIENT mirrors shared Forge and Chat interaction controls while retaining CLIENT-only legacy Dev Mode, Missions, and client-side capabilities.

Core invariant: `latest` means **latest verified candidate**, not newest filename or filesystem timestamp.

Automatic behavior is bounded to an explicit user build action plus post-build artifact/log retrieval controlled by default-ON settings. Merely placing a file into a watched directory does not trigger a build, and downloaded artifacts are never auto-installed.

See:
- `INT_FORGE_054A_R2_IMPLEMENTATION_REPORT.md`
- `SWRLZ_CLIENT_SERVER_FEATURE_PARITY_V1.md`
- `SWRLZ_PATCH_LINEAGE_INDEX_V1.json`
