# SWURVER Fusion Bubble Foundation

Implemented:
- Persistent radial bubble menu in Client and Server.
- Last-opened bubble page restoration.
- Restore-after-relaunch toggle.
- Bubble layout modes: SINGLE, DUAL, FUSION, ALL_THREE.
- SWURLZER-owned third SWURVER fusion bubble notification.
- Dedicated named crystal-dragon assets for Client, Server, and Fusion bubbles.
- Separate Client and Server bubbles remain available in ALL_THREE mode.

Architecture note:
Android does not permit one notification bubble to be jointly owned by two packages. SWURLZER is therefore the authoritative owner of the fusion notification, while SWRLZ remains the cockpit/client. Cross-package connection-aware auto-fusion still requires an authenticated IPC/status signal and is intentionally not fabricated in this source patch.
