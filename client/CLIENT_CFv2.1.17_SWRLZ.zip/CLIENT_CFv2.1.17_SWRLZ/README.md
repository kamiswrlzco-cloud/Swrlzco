# CLIENT CFv2.1.15 — Theme Ignition Family Completion

Current source package: **CLIENT CFv2.1.15**.

**Android identity:** versionCode `113`; versionName `2.1.15-theme-ignition-family-completion-v1`.

INT-THEME-039A integrates the supplied SWRLZ Core Ignition Resource Pack into the existing declarative startup engine. The Jester reference ignition is preserved, while Dragon Kamileon, Jade, Frost, Crystal Cyber, and Inferno now each declare the complete semantic eight-stage startup sequence. Startup remains presentation-only and readiness-truthful; reduced motion and fallback behavior remain intact.

No SERVER runtime, protocol, trust, Truth Firewall, permission, mission authority, Forge authority, provider/profile contract, GitHub write, workflow, build, APK, release, deployment, or installation is changed or claimed by this source-only checkpoint.

See `docs/checkpoints/INT-THEME-039A_CLIENT_IGNITION_FAMILY_COMPLETION.md`.

---

# CLIENT CFv2.1.14 — Command Center + Package-Aware Forge

Current source package: **CLIENT CFv2.1.14**.

**Android identity:** versionCode `112`; versionName `2.1.14-command-center-package-forge-v1`.

INT-CHAT-FORGE-038C adds the theme-aware Chat Command Center, categorized searchable/favoritable command templates, package-target selection for CLIENT/SERVER/BOTH/files, automatic checksum + manifest companion resolution, canonical source-lane routing, combo transaction policy, package destination previews, and the standing Documentation Gate. The provider mesh/profile architecture from CFv2.1.13 remains intact.

No GitHub upload, commit, push, workflow, build, APK, release, deployment, provider call, or secret use is claimed by this source-only checkpoint.

See `docs/checkpoints/INT-CHAT-FORGE-038C_COMMAND_CENTER_PACKAGE_AWARE_FORGE_PARITY.md` and `docs/contracts/SWRLZ_COMMAND_CENTER_AND_FORGE_PACKAGE_CONTRACT_V1.md`.

---

# CLIENT CFv2.1.13 — SWRLZ Provider Mesh + Profile Library

Predecessor source package: **CLIENT CFv2.1.13**.

**Android identity:** versionCode `111`; versionName `2.1.13-provider-mesh-v1`.

INT-AI-038A makes SWRLZ Chat provider-aware through SERVER-custodied OpenAI/Gemini routing, status/model controls, Council/Compare, canonical source-analysis dispatch, and saved STABLE/TEST/DRAFT profile switching. SWRLZ remains the identity and authority owner; remote provider use is explicit/local-first and no CLIENT OpenAI secret store is introduced.

See `docs/checkpoints/INT-AI-038A_CLIENT_PROVIDER_MESH.md` and `docs/contracts/SWRLZ_PROVIDER_MESH_CONTRACT_V1.md`.

---

# CLIENT CFv2.1.12 — Distributed SWRLZ Profile Architecture

Predecessor source package: **CLIENT CFv2.1.12**.

**Android identity:** versionCode `110`; versionName `2.1.12-distributed-profile-architecture-v1`.

INT-PROFILE-037B adds declarative endpoint, relationship, provider, session, inheritance, and custom profile infrastructure. The prior CFv2.1.11 Chat Control Center remains intact beneath this successor. Profiles cannot weaken trust, approval, permission, mission/Forge authority, Truth Firewall, or protocol semantics.

---

# CLIENT CFv2.1.11 — Chat Control Center + Response-Top Follow

Predecessor source package: **CLIENT CFv2.1.11**.

This CLIENT-only source successor preserves CFv2.1.10 ThemePack/progress behavior while expanding Settings → Chat & Commands into a nested conversation control center. It adds response-top auto-follow, live-event focus control, and a persistent SWRLZ personality/response profile that guides optional reasoning providers without changing canonical runtime truth.

No SERVER, protocol, trust, Truth Firewall, permission, mission authority, Forge authority, repository authority, local/remote distinction, or offline-first behavior changed.

**Android identity:** versionCode `109`; versionName `2.1.11-chat-control-center-v1`.

See `docs/checkpoints/INT-CHAT-037A_CLIENT_CHAT_CONTROL_CENTER.md`.

---

# CLIENT CFv2.1.10 — Progress Layering + Clipping Repair

Predecessor source package: **CLIENT CFv2.1.10**.

This CLIENT-only source successor preserves the verified CFv2.1.9 ThemePack
implementation while repairing device-observed progress composition. Jester track
geometry follows the transparent frame opening, fill/particles/highlight are bounded
by the active progress window, and the decorative shell owns the outer chrome above
all streaming energy.

No SERVER, ThemePack contract/runtime asset, protocol, trust, Truth Firewall,
permission, mission, Forge, local/remote, accessibility-automation, or offline-first
behavior changed.

**Android identity:** versionCode `108`; versionName `2.1.10-progress-layering-clipping-repair-v1`.

See `docs/checkpoints/INT-THEME-036A_CLIENT_PROGRESS_LAYERING_CLIPPING_REPAIR.md`.

---

# CLIENT CFv2.1.9 — Package Pair Repair

Predecessor source package: **CLIENT CFv2.1.9**.

This packaging/identity successor preserves the CFv2.1.8 ThemePack implementation and
repairs the canonical repository manifest contract that stopped both automatic workflows
before Kotlin/Android compilation. It adds the verifier-required `zip`, `size_bytes`, and
`verified` evidence fields while retaining the richer checkpoint metadata.

No theme, launcher, startup, progress, protocol, trust, Truth Firewall, permission, mission,
Forge, identity-proof, local/remote, accessibility-automation, or offline-first behavior changed.

**Android identity:** versionCode `107`; versionName `2.1.9-package-pair-repair-v1`.

See `docs/checkpoints/INT-THEME-035D_CLIENT_PACKAGE_PAIR_REPAIR.md`.

---

# CLIENT CFv2.1.8 — Theme Chrome + Runtime Visual Repair

Predecessor source package: **CLIENT CFv2.1.8**.

This CLIENT-only source checkpoint replaces the default legacy launcher identity, contains all animated progress layers inside calibrated theme tracks, stages Jester Core Ignition, and carries each selected ThemePack’s distinct background, Kapanion, motif, border, shape, and motion identity through the full User interface.

Existing protocol, trust, Truth Firewall, permissions, missions, Forge, identity proof, local/remote distinctions, notifications, bubbles, accessibility automation, and offline-first behavior are preserved.

**Android identity:** versionCode `106`; versionName `2.1.8-theme-chrome-runtime-repair-v1`.

See `docs/checkpoints/INT-THEME-035C_CLIENT_THEME_CHROME_RUNTIME_REPAIR.md`. Source-only verification is recorded there. Gradle/APK/device verification remains separately gated and is not claimed.

---

# CLIENT CFv2.1.7 — Theme Progress Compose Scope Repair

Historical source package: **CLIENT CFv2.1.7**.

This bounded source-only repair preserves INT-THEME-035A and fixes the log-confirmed Kotlin compile defect in `ThemedProgress.kt` by capturing the enclosing `BoxWithConstraints.maxWidth` before entering nested `Box` scopes. No theme contract, assets, protocol, trust, permission, mission, Forge, identity-proof, local/remote, or offline-first behavior was changed.

**Android identity:** versionCode `105`; versionName `2.1.7-theme-progress-compose-scope-repair-v1`.

See `CFv2.1.7_THEME_PROGRESS_COMPOSE_SCOPE_REPAIR_CHECKPOINT.md`. Static repair verification passed. A new Gradle/APK/device verification run remains separately gated and is not claimed.

---

# CLIENT CFv2.1.6 — Declarative ThemePack Engine

Historical source package: **CLIENT CFv2.1.6**.

This source-only checkpoint adds the shared ThemePack contract, thirteen built-in identities, independent CLIENT theme persistence, staged settings previews, Jester Core Ignition, and truthful layered progress while preserving existing protocol, trust, permission, mission, Forge, identity-proof, local/remote, and offline-first behavior.

**Android identity:** versionCode `104`; versionName `2.1.6-theme-pack-engine-v1`.

See `CFv2.1.6_THEME_PACK_ENGINE_CHECKPOINT.md`. Static source integrity passed. Compilation, APK, device acceptance, GitHub publication, commit, push, release, and deployment remain pending separate authorization.

---

# CLIENT CFv2.0.65 — Finish-Line Cohesion

Historical source package: **CLIENT CFv2.0.65**.

This patch connects the full CLIENT and CLIENT bubble Forge surfaces through one credential authority, adds a direct bubble Forge destination, and treats Android download-copy counters such as ` (1)` as transport-local filenames rather than source validity failures. Canonical repository paths and checksum names remain clean.

**Android identity:** versionCode `92`; versionName `2.0.65-finish-line-cohesion-v1`.

See `CFv2.0.65_FINISH_LINE_COHESION_CHECKPOINT.md`. GitHub compilation and device acceptance remain pending.

---


# SWRLZ-Core Android Client

Predecessor source package: **CLIENT CFv2.1.11 — Chat Control Center + Response-Top Follow**.

## Current app identity

- Version: `2.1.11-chat-control-center-v1`
- Code: `109`
- Patch: `CFv2.1.11-CHAT-CONTROL-CENTER-V1`
- Source: `CLIENT_CFv2.1.11_SWRLZ.zip`

## Current stabilization scope

- Extends existing Theme Armor through a shared declarative ThemePack contract without replacing application architecture.
- Preserves Forge transaction verification, connector continuity, identity/trust boundaries, local/remote distinctions, missions, permissions, notifications, bubbles, and offline-first behavior.
- Adds thirteen stable built-in identities with CLIENT-local selection and staged preview/apply behavior.
- Adds bounded deterministic runtime assets, staged Jester Core Ignition, reduced motion, and clipped truthful semantic progress.
- Carries each selected pack’s distinct background, Kapanion, motif, border ornament, shape, and motion identity through the CLIENT shell.
- Replaces the default legacy Android launcher resource with the Glitch Dragon Glass identity.
- Reserves custom-theme import architecture without presenting an unsupported working importer.
- Preserves the CFv2.1.9 ThemePack implementation and repairs runtime progress layering/clipping in `CLIENT · CFv2.1.10` / versionCode `108`.
- Expands Chat settings and adds response-top following plus a persistent SWRLZ response profile in `CLIENT · CFv2.1.11` / versionCode `109`.

## Interface modes

- **User Mode** is the fresh-install default: Core, Chat, Missions, Nodes, and Settings on the animated translucent Glitch Dragon Glass shell.
- **SWRLZ Dev Mode** retains the complete engineering surface: Home, Radar, Network, Cockpit, Setup, Style, Permissions, Core Admin, Skills, Allowlist, How To, Info, and More.
- The selected interface persists locally and can be switched in either direction without deleting configuration, identity, mission, trust, or style state.

## Current server pair

- Local Node Server: `0.7.1 Presence Index`

## Project law

- Integrate, do not overwrite.
- No invisible patches.
- No mystery APKs.
- Preserve local data and taught skills.
- Keep Mentor backend and Local Core Node separate.
- Status colors remain semantic; themes may not lie about operational state.
- User Mode never hides Pause, Take Over, approval state, local-versus-remote identity, or Truth Firewall status.


## 2.7.6-CODEFIX3-DISCOVERY-SCAN-TRIM

- Source: `SRC_2.7.6_CF3_SCAN_TRIM.zip`
- Objective: trim discovery scan overhead by skipping `127.0.0.x` range sweeps by default, while keeping a saved debug toggle for unusual loopback testing.
- Output naming convention: `SRC_` for source, `SHA_` for hashes, `REPORT_` for patch notes, `APK_` for APKs, and `BUNDLE_` for APK download bundles.


## 2.7.6 CF4 - Signing + Reconnect

Adds Connection Memory / Last-Good Node Auto-Reconnect and stable dev signing readiness. Source: `SRC_2.7.6_CF4_SIGN_RECONNECT.zip`.


## INT-CONV-012A communication foundation
See `docs/contracts/SWRLZ_PROTOCOL_AND_DATA_CONTRACTS_V1_INTEGRATED.md` and `reports/INT-CONV-012A_IMPLEMENTATION_REPORT.md` (CLIENT) or `INT-CONV-012A_IMPLEMENTATION_REPORT.md` (SERVER). This is source-only foundation work; no live endpoint is exposed.

## Current Forge transaction behavior

CLIENT CFv2.0.62 preserves a fresh transaction ID for every Forge upload, tags the commit with `SWRLZ-Forge-Actor: CLIENT`, rebases on the latest branch head after blob transfer, retries branch races, verifies uploaded repository paths, and reports upload/build results through both Android notifications and the CLIENT conversation bubble. ZIP checksum matching derives the exact `.sha256` name, probes the selected document directory automatically, and exposes a manual fallback only when Android blocks sibling access. See `CFv2.0.61_AUTOMATIC_SIBLING_CHECKSUM_CHECKPOINT.md`.


## CFv2.0.62 manual token validation

Manual token text remains an unverified candidate until `VALIDATE TOKEN` succeeds. Partial input cannot replace the active runtime token or trigger saved-session auto-validation. See `CFv2.0.62_MANUAL_TOKEN_VALIDATION_STATE_CHECKPOINT.md`.
