# CLIENT CFv2.1.17 — Forge Rescue / Default-Theme Bootstrap

Checkpoint: `INT-FORGE-039E`

This source-only rescue successor is intentionally transport-light. It preserves the current CLIENT code lineage while exposing only the canonical default `Glitch Dragon Glass` ThemePack at runtime and removing optional ThemePack/ignition payloads from the package so the Forge uploader repair can itself be transported through older CLIENT builds.

## Forge repair

- Preflight now proves authentication, repository read, and `Contents: write` before a large transfer by creating a tiny unreferenced Git blob. The probe does not modify a branch/tree/file.
- A 401 during a later repository operation is no longer automatically interpreted as proof that the credential is revoked. Forge re-probes authentication and preserves the credential when the re-probe succeeds.
- 422 `input was too large` is classified as a transport-size failure, not an authentication failure.
- Sanitized GitHub request ID / accepted-permission evidence is included when supplied by GitHub.

## Temporary bootstrap theme boundary

- Runtime registry selectable set: `Glitch Dragon Glass` only.
- Alternate launcher aliases are removed from the bootstrap Android manifest.
- Optional theme progress, ignition, launcher, Kapanion, and legacy alternate identity artwork is omitted.
- The full declarative ThemePack definitions remain in source lineage for restoration; this bootstrap edition is not a design rollback.
- ThemePack authority/trust/protocol/mission semantics are unchanged.

## Evidence boundary

Source/static/package verification only. No Gradle build, APK, device acceptance, GitHub upload, workflow, commit, push, release, deployment, or installation is claimed.

---

# CLIENT CFv2.1.16 — Theme Progress Semantic Anchor Calibration

- Generalizes progress-track calibration through one ThemePack-aware runtime geometry resolver instead of a Jester-specific layout branch.
- Calibrates Jester Glitch Dragon's truthful 100% endpoint to the center of the right green emerald landmark (`89.5%` of outer frame width).
- Aligns the progress-head semantic center to the same determinate/indeterminate boundary used by fill and active clipping.
- Preserves existing ThemePack manifest v1 and CLIENT/SERVER shared-contract bytes; uncalibrated themes retain their declared dp geometry.
- Applies the Documentation Gate and records the older VC108 screenshot as valid defect evidence while repairing the current CFv2.1.15 lineage.
- Source-only; build/APK/workflow/device/repository publication/release/deployment/install success is not claimed.

---

# CLIENT CFv2.1.15 — Theme Ignition Family Completion

- Verifies the supplied ignition resource pack at SHA-256 `fc5e41188e429cf5b088f8da47ead713ba0e39849b75e79e6f5011e532d58c3c` and revalidates every entry in its root manifest.
- Preserves the existing Jester Glitch Dragon reference ignition.
- Adds complete eight-stage ignition assets to Dragon Kamileon, Jade, Frost, Crystal Cyber, and Inferno.
- Generalizes the runtime ignition renderer name from Jester-specific to theme-generic without changing readiness or timeline semantics.
- Extends ThemePack tests so all six supplied ignition families must declare all eight semantic startup roles.
- Updates runtime asset catalog, architecture docs, asset provenance, release notes, engineering log, source package note, and documentation impact set.
- Source-only; build/APK/workflow/device/repository publication/release/deployment/install success is not claimed.

---

# CLIENT CFv2.1.14 — Command Center + Package-Aware Forge

- Adds a theme-aware Chat Command Center with categorized search, favorites, and quick natural-language insertion.
- Adds CLIENT / SERVER / BOTH / FILES Forge targeting.
- Auto-resolves canonical SHA-256 and manifest companions for protected source ZIPs, with mismatch/blocking verification.
- Routes CLIENT and SERVER package units to their canonical source lanes and supports one transactional combo staging job when enabled.
- Adds package automation settings and destination previews; defaults preserve safe automatic pairing/routing.
- Establishes the standing Documentation Gate and records the full documentation impact set.
- Source-only; no build/APK/workflow/GitHub write/release/deployment/provider-call result is claimed.

---

# CLIENT CFv2.1.13 — Provider Mesh + Profile Library

- Adds shared provider-contract v1 and per-message `@gpt`, `@gemini`, `@both`/Council, Compare, and Local routing.
- Adds provider status/model controls to Chat and Chat Settings while preserving SWRLZ identity.
- Adds canonical latest CLIENT/SERVER source-analysis dispatch through SERVER sanitization.
- Adds STABLE/TEST/DRAFT profile lifecycle, favorites, duplication, and quick assignment/switching.
- Keeps automatic remote provider use off by default and does not add CLIENT OpenAI secret storage.
- Source-only; provider calls/build/APK/device/workflow/release are not claimed.

---

# CLIENT CFv2.1.12 — Distributed Profile Architecture

- Adds byte-aligned CLIENT/SERVER `profile-contract` v1.
- Adds CLIENT-local profile registry and assignments.
- Adds Chat & Commands → Profiles & Routing.
- Adds custom inherited endpoint/link/provider profiles.
- Applies the resolved Gemini provider profile to the existing private reasoning path.
- Preserves CFv2.1.11 chat flow/personality and all authority boundaries.

---

# CLIENT CFv2.1.11 — Chat Control Center + Response-Top Follow

- Expands Settings → Chat & Commands into Conversation Flow, Personality & Response, and Privacy & Context submenus.
- Adds persisted response-top vs legacy conversation-bottom follow targeting; response-top is the new default.
- Reserves trailing list extent so a new SWRLZ response can animate to the top of the viewport and grow downward.
- Manual upward scrolling detaches follow; ↓ LATEST and sending a new message re-arm it.
- Adds a persisted choice for whether runtime/Forge commentary automatically brings Chat forward.
- Adds SWRLZ-native base style, detail, warmth, energy, humor, formatting, and emoji preferences.
- Applies the profile to optional reasoning-provider prompts while preserving deterministic status/safety semantics.
- Adds normalization unit-test source for ChatSettings.
- Advances Android identity to versionCode `109` / versionName `2.1.11-chat-control-center-v1`.
- No SERVER, protocol, trust, Truth Firewall, permission, mission authority, Forge authority, repository authority, or offline-first change.
- Source-only checkpoint; build/APK/workflow/device/release/deployment/install success is not claimed.

---

# CLIENT CFv2.1.10 — Progress Layering + Clipping Repair

- Uses real-device CFv2.1.9 evidence to correct Jester progress containment.
- Enforces an artwork-calibrated Jester inner track so fill no longer begins beneath the large dragon cap or extends into the frame borders.
- Keeps ambient energy as a low-alpha full-track underlay.
- Reveals the full-width fill texture through the determinate/indeterminate active window instead of compressing texture geometry.
- Clips particles and highlight to the active progress window so motion does not stream past the progress head.
- Keeps the decorative frame above all streaming/fill layers and preserves truthful determinate, indeterminate, paused, reduced-motion, and terminal semantics.
- Advances Android identity to versionCode `108` / versionName `2.1.10-progress-layering-clipping-repair-v1`.
- Does not modify SERVER, ThemePack contract/assets, protocol, trust, permissions, missions, Forge authority, local/remote distinctions, or offline-first behavior.
- Source-only checkpoint; build, APK, workflow, repository publication, release, deployment, installation, and final device acceptance are not claimed.

---

# CLIENT CFv2.1.9 — Package Pair Repair

- Records failed Source Package Integrity run `30222384992` and APK Router run `30222384996`.
- Both workflows selected the correct CFv2.1.8 ZIP and checksum, then stopped before compilation because the sidecar manifest omitted the canonical `zip`, `size_bytes`, and `verified` fields.
- Preserves CFv2.1.8 theme, launcher, startup, progress, Kapanion, accessibility, protocol, trust, mission, Forge, and offline-first behavior.
- Advances Android identity to versionCode `107` / versionName `2.1.9-package-pair-repair-v1`.
- Reissues the immutable source package under `INT-THEME-035D` with a verifier-compatible manifest and preserved failed-lineage evidence.

---

# CLIENT CFv2.1.8 — Theme Chrome + Runtime Visual Repair

- Replaced the base Glitch Dragon launcher’s legacy foreground across application, adaptive, round, and density resources.
- Added declarative theme chrome motifs, semantic background/Kapanion/voice-core roles, bounded alpha/edge settings, and progress track geometry.
- Completed distinct identity mappings for all selectable CLIENT themes; Teal Serpent remains explicitly partial and uses its own emblem.
- Replaced the hard-coded Glitch Dragon shell art with selected ThemePack backgrounds, Kapanions, motif fields, border ornaments, shapes, and motion.
- Added selected Kapanions to the header, tap-to-speak core, companion rail, assistant chat bubbles, and live preview.
- Clipped progress fill/head/ambient/particles/highlight to one calibrated track and retained truthful determinate, indeterminate, paused, and terminal semantics.
- Staged Jester Core Ignition core states and bounded its spark/radial/particle/shockwave/residual effects.
- Advanced Android identity to versionCode `106` / versionName `2.1.8-theme-chrome-runtime-repair-v1`.
- No SERVER, protocol, trust, mission, permission, Forge authority, build, APK, workflow, release, or deployment change is claimed.

---

# CLIENT CFv2.1.7 — Theme Progress Compose Scope Repair

- Records GitHub Actions run `30216145763`: resolver tests passed 6/6, CLIENT source/checksum verification passed, then Kotlin compilation failed at `ThemedProgress.kt:175` and `:190` because nested `Box` scopes could not implicitly resolve `BoxWithConstraints.maxWidth`.
- Captures the outer width as `availableWidth` and uses it for both nested fill images.
- Preserves ThemePack contracts/assets, truthful semantic progress, reduced motion, protocol, trust, missions, permissions, Forge, and offline-first behavior.
- Advances Android identity to versionCode `105` / versionName `2.1.7-theme-progress-compose-scope-repair-v1`.
- Static verification passed; new Gradle/APK/device verification remains pending separate authorization.

---

# CLIENT CFv2.1.6 — ThemePack Engine

- Added one byte-identical declarative ThemePack contract shared with SERVER.
- Preserved six legacy Theme Armor identities and added seven asset-derived built-ins.
- Added independent stable-ID persistence, staged settings preview, launcher/Kapanion identity, Jester Core Ignition, and semantic layered progress.
- Added reduced-motion, TalkBack, truthful indeterminate/terminal state, and bounded WebP asset handling.
- Added manifest v1 validation and reserved custom-theme UI without exposing an unsupported importer.
- Advanced Android identity to versionCode 104 / versionName `2.1.6-theme-pack-engine-v1`.
- Static source integrity passed; Gradle/APK/device/GitHub verification remains pending.

---

# CFv2.1.4 — Forge + Repository Console

- Split Forge into FORGE and REPOSITORY action modes.
- Added live GitHub Actions discovery, dispatch input forms, manual run, cancel, and re-run.
- Added branch-aware repository browser with create/edit/upload/download and atomic move/rename/delete.
- Moved persistent Forge preferences to Settings → Forge.
- Changed identical repository uploads from failure to verified successful no-op.

# CFv2.1.3 — Settings Control Center

- Searchable domain-based Settings hub.
- Mission-start approval policy with Always ask dialog enforcement.
- Chat auto-follow preference with scroll-detach and ↓ LATEST recovery.
- Settings entry points for Core/connection, Chat, Missions, Activity, Forge, Interface/Bubble, Brain/AI, Privacy/Security, and Developer/Diagnostics.

# CFv2.1.2 — Repository Bootstrap Forge

- Default Forge routing moved to `kamiswrlzco-cloud/Swrlzco` + `swrlz-core/...` lanes.
- Added repository-root ZIP expansion with optional outer-ZIP removal.
- Added chat bootstrap intent and chat expansion/removal toggles.
- Added Forge repository tools: browse, read/write text, delete file with confirmation, and create branch.
- Added archive path/size safety gates before repository expansion.

# CLIENT CFv2.0.69 — Chat + Mission Runtime Cohesion

- Grounded Gemini/GitHub/accessibility status queries in authoritative runtime state.
- Added contextual mission handoff for follow-up requests such as “do that as a mission.”
- Added Gemini-backed structured mission planning when Online Mentor is absent.
- Mission completion can return to CLIENT and publish gathered results into Chat.
- Added Forge chat milestone narration and first-class cancellation state/control.
- Added animated complementary-color dragon companion/status rail foundation.

## 2.0.66
- Snapshot-bound accessibility targets with fail-closed live-node validation.

# CLIENT CFv2.0.64 — Credential Lifecycle and Upload Preflight

- Added token normalization and exact credential preflight before source streaming.
- Added GitHub App access/refresh token lifecycle persistence and refresh.
- Added one refresh-and-retry path for a 401 during transfer.
- Retires explicitly rejected credentials instead of reusing them.
- Preserves CFv2.0.63 generated checksum receipts, launcher/theme identity, and Forge reliability.

---

## CFv2.0.63 — Generated checksum receipt

- Generates and stages an exact `<base>.sha256` receipt when Android withholds sibling URI access.
- Eliminates the normal-path `LOCATE SHA-256` requirement.
- Retains independent repository-side digest verification.
- Advances Android identity to versionCode 90 / versionName `2.0.63-generated-checksum-receipt-v1`.

## CFv2.0.62 — Manual token validation state repair

- Separates unverified fine-grained token text from the active validated runtime token.
- Prevents the token-entry form from disappearing after the first typed character.
- Stops automatic validation from running against partial manual input.
- Saves and publishes a token only after GitHub `/user` validation succeeds.
- Keeps invalid input editable without replacing the active session.
- Advances Android identity to versionCode 89 / versionName `2.0.62-manual-token-validation-state-v1`.

## CFv2.0.61 — Automatic same-directory checksum resolution

- Preserves the device-verified repeated-upload and upload-success notification behavior.
- Derives the exact `<base>.sha256` name from a selected `<base>.zip`.
- Adds provider-safe lookup through direct document IDs, parent child enumeration, and Android 10+ MediaStore relative directories.
- Stops opening a second file browser automatically when a provider denies sibling access.
- Adds an explicit `LOCATE SHA-256` fallback beside unmatched staged ZIPs.
- Advances Android identity to versionCode 88 / versionName `2.0.61-automatic-sibling-checksum-v1`.

## CFv2.0.60 — Theme connector continuity and collapsible Forge panels

- Records successful GitHub compilation of CLIENT CFv2.0.58.
- Prevents a launcher/theme task refresh from presenting a false disconnected GitHub account while the saved Keystore token is validating.
- Hides redundant OAuth/device-code controls whenever a saved token exists.
- Keeps temporary verification failure non-destructive.
- Makes Repository Target and Source Package Matching collapsible and persists their state.
- Advances Android identity to versionCode 87 / versionName `2.0.60-theme-connector-collapse-v1`.

## CFv2.0.59 — Build preflight alignment

- Aligned `org.jetbrains.kotlin.android`, `org.jetbrains.kotlin.plugin.serialization`, and `org.jetbrains.kotlin.plugin.compose` at version `2.0.0`.
- Preserved the CFv2.0.58 Forge log repair, CLIENT actor evidence, Dragon Kamileon Theme Armor, connector continuity, and bubble/main version surfaces.
- Advanced Android identity to versionCode 86 / versionName `2.0.59-build-preflight-alignment-v1`.
- Package/static verification complete; GitHub compilation and device acceptance remain pending.

## CFv2.0.58 — Dragon Kamileon and Forge log build repair

- Fixed the CFv2.0.57 `ForgeUploadLogStore` unresolved SharedPreferences receiver.
- Added `SWRLZ-Forge-Actor: CLIENT` to atomic Forge commits and `forge_actor` to diagnostics.
- Added selectable Dragon Kamileon Theme Armor with iridescent interface tokens.
- Added dedicated Kamileon launcher, adaptive, CLIENT, SERVER-context, and fusion bubble assets.
- Advanced Android identity to versionCode 85 / versionName `2.0.58-kamileon-theme-forge-log-buildfix-v1`.

## CFv2.0.57 — Forge live logs and durable GitHub connection

- Added a redacted append-only Forge upload log from source selection through terminal outcome.
- Added live/latest upload-log export during staging, active transfer, retry, failure, and success.
- Logged SHA matching, ZIP/pair validation, transfer checkpoints, blobs, trees, commits, branch confirmation, uploaded-path verification, workflow discovery, and exceptions.
- Persisted OAuth client ID, repository target, connected login, and auto-connect intent outside the Keystore secret file.
- Added secure-transport-gated Android backup/device-transfer restoration that re-imports the GitHub token into the fresh install's Keystore and validates it before reconnecting.
- Added an approval dialog before disconnecting and clearing connector identity/restore state.
- Advanced Android identity to versionCode 84 / versionName `2.0.57-forge-live-logs-connector-restore-v1`.

## CLIENT CFv2.0.56 — Forge observer, themed identity, version footer, and build repair

- Fixed `ForgeBuildWatchStore` compilation by applying `takeLast` to a list rather than a Set.
- Added immediate post-upload workflow discovery and 2-second active polling.
- Added active-first workflow display with configurable completed history and duplicate-card collapse.
- Added CLIENT CF/versionCode footers to main User and Developer interfaces.
- Rebuilt theme launcher assets from the current crystal-dragon art and synchronized all bubble roles with Theme Armor.
- Advanced Android identity to versionCode 83 / versionName `2.0.56-forge-observer-identity-footer-buildfix-v1`.

# Changelog

## CLIENT CFv2.0.55 — Forge repeat-upload truth, event notifications, and same-location SHA matching

- Added a fresh UUID correlation identity to every upload attempt, including validation failures.
- Snapshot staged files at commit press so later UI selection changes cannot mutate an active transaction.
- Upload blobs first, resolve the latest branch head afterward, and retry non-fast-forward branch races up to three times.
- Reject no-op trees explicitly instead of replaying a false success animation.
- Confirm the target branch points to the new commit and verify every uploaded repository path resolves to the expected blob SHA before clearing staging.
- Separate repository-upload success from workflow-dispatch failure; a dispatch error can no longer erase a verified commit result.
- Added Android and CLIENT-bubble events for upload success/failure, workflow-dispatch failure, and artifact-build success/failure.
- Persist up to twelve pending commit watches so later CLIENT/SERVER uploads do not replace earlier build notifications.
- Added background build-result polling to the existing CLIENT status service while notification status is enabled.
- Added a compact latest Forge-event banner inside the CLIENT bubble interface.
- Removed the separate source-folder tree grant from checksum matching.
- Added best-effort exact sibling lookup from the selected ZIP URI with a same-location document-picker fallback when Android blocks direct sibling access.
- Advanced Android identity to versionCode 82 / versionName `2.0.55-forge-repeat-notifications-sibling-v1`.

# CLIENT CFv2.0.53

- Added the first separate SWRLZ CLIENT bubble interface overhaul.
- Replaced the default light Material panel with the saved SWRLZ theme and a compact crystal cockpit.
- Added full navigation labels, icons, responsive crystal tiles, truthful CLIENT/SERVER-link status, and an Open Full Client action.
- Kept CLIENT identity independent instead of visually morphing into SWURVER when a SERVER session exists.
- Added an always-visible `CLIENT · CFv2.0.53` footer derived from `BuildConfig.VERSION_NAME`.
- Corrected stale Android/source identity fields inherited by the CFv2.0.52 archive.
- Reserved the fusion interface for a later pass after CLIENT and SERVER surfaces are accepted.
- Advanced Android identity to versionCode 80 / versionName `2.0.53-client-bubble-interface-v1`.

# CLIENT CFv2.0.52

- Added authoritative Forge phase projection in the CLIENT top bar.
- Added persisted Source ZIP Content Guard with pre-network APK/artifact rejection and source-structure heuristics.
- Preserved exact ZIP/SHA-256 validation and truthful phase-based workflow reporting.

# CLIENT CFv2.0.41 — Native Bubble Admin Morph

## CFv2.0.52
- Removed six unused CLIENT launcher/fusion resource artifacts.
- Preserved all launcher identity resources still referenced by aliases and ThemeIdentityManager.
- Added a conservative resource audit utility and checkpoint documentation.
- Advanced CLIENT build identity to versionCode 79.


- Replaced the experimental three-overlay dock with one Android-managed conversation bubble.
- Corrected identity mapping: SWRLZ Client = cyan/blue; SWURLZER Server = purple; authenticated fusion = SWURVER.
- Added verified-admin-driven bubble identity morphing.
- Prevented bubble taps from spawning separate CLIENT/SERVER/FUSION activity windows.
- Removed excess light padding from bubble avatar resources.

# CLIENT CFv2.0.40

- Added GitHub Forge mass routing for CLIENT and SERVER source packages.
- Added workflow-run observation and Actions artifact download/save support.
- Preserved encrypted GitHub authentication and atomic multi-file commits.

# Changelog

## CFv2.0.32 — Bubble build correction
- Corrected `LocusId` to use the public `android.content.LocusId` API.
- Removed the incompatible explicit Compose `weight` import from the Client bubble activity.
- Advanced Android `versionCode` to 61.
- Added `docs/implementation/INT_CHAT_032D_BUBBLE_BUILD_CORRECTION.md`.

## CFv2.0.31 — Persistent Client notification surface

- Added `ClientStatusService` so Client status remains available outside `MainActivity`.
- Added live notification updates for server connection, endpoint, mission, session evidence, and theme.
- Added a notification-permission guard before foreground startup.
- Introduced a fresh status channel ID to recover from retained legacy channel configuration.
- Kept the Client status notification separate from the Floating Dragon conversation bubble.
- Added `docs/implementation/INT_NOTIFY_034B_PERSISTENT_CLIENT_STATUS_SERVICE.md`.

## CFv2.0.30 — Client status notification recovery

- Requests Android 13+ notification permission on first launch when missing.
- Adds notification permission state and recovery controls to the Permission Centre.
- Republishes the persistent Client status notification after permission approval.
- Keeps server connection, endpoint, mission, and theme details in the expanded notification.
- Documents notification-channel and user-controlled permission limitations.

## CLIENT CFv2.0.30 — Client notification status recovery

- Restored the persistent Client status notification using a fresh Android notification channel.
- Raised the status channel from low to default importance while retaining update-only alert behavior.
- Added an Android 13+ notification permission guard.
- Decoupled the Client status widget from the Floating Dragon bubble lifecycle.
- Added `INT_NOTIFY_034A_CLIENT_STATUS_NOTIFICATION_RECOVERY.md`.

## Unreleased

- Added themed Floating Dragon bubble UI and hardened Android conversation registration.
- Bubble settings now register the conversation before opening system settings.

## Permission priority, live node status, and explicit bubble controls

- Moved the sideloaded-app restricted-settings guide to the top of the Client Permission Centre.
- Added authoritative online/offline/registered node totals to the Server notification.
- Added explicit Client server-connection evidence to its notification.
- Added manual Floating Dragon launch and Android bubble-settings controls.
- Connected the Client telemetry side puck and strip to Floating Dragon.
- Corrected the Server bubble namespace and connected it to live runtime/node state.
- Documented the release in ADR-0022 and INT-UX-033A.

## Floating Dragon bubble release

## Floating Dragon build correction

- Corrected AndroidX conversation Person and IconCompat usage.
- Corrected client permission-route compilation.
- Removed fragile server generated-class dependencies from the bubble feature.


- Added Android-native conversation bubbles for compact SWRLZ chat and mission/server status.
- Added dedicated resizeable bubble activities and long-lived conversation shortcuts.
- Preserved full-app authority for sensitive actions.
- Documented phased chat transport boundaries in ADR-0021.

# Changelog

## INT-UX-031A

- Moved Accept All to the client first-mission acknowledgement screen.
- Restored the Android permission centre workflow.
- Added default-on, theme-aware client/server notification status widgets.
- Preserved Android's mandatory server foreground-service notification.

# CLIENT CFv2.0.23 (2026-07-23)

- Protocol v2 device continuity registration.
- Raw ANDROID_ID removed from registration payload.
- Canonical SERVER node ID retained for subsequent presence calls.

# CLIENT CFv2.0.22 — INT-UI-028D

- Added a SERVER-authoritative group overview to the Core session card.
- Shows group role plus online-versus-active device counts.
- Supports zero, one, and multiple group memberships with truthful unavailable states.
- Added tap-through navigation to the dedicated Groups workspace.
- Advanced Android identity to versionCode 51 and versionName `0.2.7.26-cfv2.0.22-int-ui-028d`.
- Source-only package; no build or runtime verification performed.

# CLIENT CFv2.0.18 — INT-FIX-026E

- Replaced the invalid `tokens.status.error` reference with canonical `tokens.status.danger`.
- Advanced Android identity to `versionCode` 47 and `versionName` `0.2.7.22-cfv2.0.18-int-fix-026e`.
- Recorded the CLIENT CFv2.0.17 GitHub compilation failure and the user-reported SERVER CFv2.0.17 build success.
- Preserved all group, heartbeat, trust, identity, offline-first, lineage, and Truth Firewall behavior.
- Source-only package; compilation and runtime verification were not run.

# CLIENT CFv2.0.17 — INT-FIX-026C

- Repaired SERVER group-list dispatch.
- Added canonical role, membership-state, leader, and member-count data.
- Added live roster retrieval and readable CLIENT synchronization errors.
- Prevented failed group requests from being labeled synchronized.

# INT-UX-026A — Navigation and Groups Workspace

- Added horizontally swipeable bottom navigation.
- Added a dedicated Groups destination.
- Added richer group creation, join, inspection, synchronization, and assignment UI while preserving SERVER authority.
- Advanced package identity to CFv2.0.16.
- No APK build or runtime verification was performed.

# CLIENT CFv2.0.15

- Completed visible group-management dialogs, lists, assignment controls, and immediate post-mutation refresh.
- Corrected prior foundation-only UI claims.

# Changelog

## CLIENT CFv2.0.14
### Added
- SERVER-authoritative heartbeat lease metadata and tolerant liveness states.
- Repository checkpoint, ADR, and protocol-history documentation.
- Visible group controls on CLIENT / node detail and Mission Council foundations on SERVER as applicable.

### Changed
- Administrative disconnect now prevents silent immediate reconnection.
- Connection status progresses through delayed and unavailable states before inferred disconnection.

### Preserved
- Offline-first behavior, Truth Firewall, identity lineage, trust gates, SERVER canonical group ownership, and protocol v1 compatibility.

## CLIENT CFv2.0.19 — INT-FIX-027D

- Sanitized nested SERVER discovery errors in the Groups workspace.
- Preserved raw response payloads for developer diagnostics while removing raw JSON from user-facing status text.
- Classified unsupported Groups routes as a CLIENT/SERVER compatibility condition.
- Disabled group creation and join submission until authoritative group synchronization succeeds.
- Confirmed SERVER CFv2.0.17 already exposes the canonical `/v1/groups/*` route set; no SERVER source change was required.
## CFv2.0.24
- Installable-update version bump, permission onboarding, and guided Accept All flow.
## CLIENT CFv2.0.38 — GitHub Forge
- Added More → GitHub Forge for multi-file Android document selection.
- Added atomic Git Data API commits that bypass the 25 MiB website uploader.
- Added encrypted fine-grained GitHub token storage.
- Added optional workflow_dispatch after a successful commit.


## CLIENT CFv2.0.39 — GitHub Device Authorization

- Added GitHub browser sign-in through the OAuth Device Authorization Flow.
- Added encrypted OAuth Client ID and access-token persistence.
- Added connected-account verification through `GET /user`.
- Added disconnect and manual fine-grained-token fallback controls.
- GitHub Forge upload controls remain locked until authentication succeeds.
- Multi-file atomic commit and optional workflow dispatch remain preserved.

## CLIENT CFv2.0.65 — Finish-Line Cohesion
- Added canonical handling for Android download-copy suffixes such as ` (1)`.
- Added Forge directly to the CLIENT bubble.
- Synchronized GitHub credential state between full CLIENT and bubble surfaces.
- Preserved content-based source validation and canonical ZIP/SHA repository pairing.

## CLIENT CFv2.0.70 — Forge Chat Diagnostics
- Added `Upload from Forge officially Swurlzed!` after confirmed repository upload.
- Added workflow-start and workflow-success chat announcements scoped to the upload commit SHA.
- Added redaction-safe upload-log analysis on Forge failures.
- Added workflow job/step + GitHub log archive analysis on workflow failures.
- Added evidence / likely-cause / recommended-next-step separation to failure feedback.
- Routed Forge milestone narration through the shared ChatRuntimeBus while retaining high-frequency progress inside the live Forge card.
- Advanced Android identity to `versionCode` 96 and `versionName` `2.0.70-forge-chat-diagnostics-v1`.
- GitHub Android compilation and device acceptance remain authoritative release gates.

## CLIENT CFv2.0.71 — Forge STOP Build Fix
- Repaired the CFv2.0.70 Kotlin compilation failure in `ClientShellScreen.kt` by using the canonical `tokens.status.danger` field for the STOP FORGE control.
- Preserved CFv2.0.70 Forge chat diagnostics, upload/workflow narration, cancellation semantics, failure analysis, Gemini/provider routing, mission/chat bridge, and companion work unchanged.
- Advanced Android identity to `versionCode` 97 and `versionName` `2.0.71-forge-stop-buildfix-v1`.
- GitHub Android compilation and device acceptance remain authoritative release gates.


## CLIENT CFv2.0.72 — 2026-07-25
- Mission stop/pause/resume intents are handled locally before Gemini.
- Added Volume Up + Volume Down hold-to-pause safety chord.
- Added Mission HUD STOP control and automatic execution-time collapse.
- Bubble-launched missions collapse the expanded bubble before device execution.
- Fixed chat dragon companion rendering and retained complementary theme treatment.
- Added context-aware Gemini connection offer and secure key entry dialog.
