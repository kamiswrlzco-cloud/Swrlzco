package sh.swurlz.core.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.Instant
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.github.GitHubForgeClient
import sh.swurlz.core.github.ForgeBuildMonitor
import sh.swurlz.core.github.ForgeBuildWatch
import sh.swurlz.core.github.ForgeBuildWatchStore
import sh.swurlz.core.github.ForgeRuntimeState
import sh.swurlz.core.github.ForgeUploadLogStore
import sh.swurlz.core.github.GitHubConnectionStore
import sh.swurlz.core.github.GitHubCredentialLifecycle
import sh.swurlz.core.github.OpenSiblingDocumentContract
import sh.swurlz.core.github.SiblingDocumentRequest
import sh.swurlz.core.notification.ForgeEventNotifier
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import sh.swurlz.core.ui.theme.ProgressSnapshot
import sh.swurlz.core.ui.theme.ThemedProgressBar
import sh.swrlz.theme.ThemeProgressState

@Composable
fun GitHubForgeScreen() {
    var mode by rememberSaveable { mutableStateOf("FORGE") }
    Column(Modifier.fillMaxSize()) {
        ForgeModeSelector(mode) { mode = it }
        Box(Modifier.fillMaxWidth().weight(1f)) {
            if (mode == "REPOSITORY") ForgeRepositoryBrowserScreen() else ForgeOperationsScreen()
        }
    }
}

@Composable
private fun ForgeOperationsScreen() {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    val forgePreferences = remember {
        context.getSharedPreferences("swrlz_forge_preferences", Context.MODE_PRIVATE)
    }
    val restoredConnectionProfile = remember { GitHubConnectionStore.profile(context) }
    val credentialRevision by GitHubConnectionStore.revision.collectAsState()
    val restoredRuntimeToken = remember {
        if (GitHubConnectionStore.shouldAutoConnect(context)) SecretStore.githubToken(context) else ""
    }

    var owner by remember { mutableStateOf(restoredConnectionProfile.owner) }
    var repository by remember { mutableStateOf(restoredConnectionProfile.repository) }
    var branch by remember { mutableStateOf(restoredConnectionProfile.branch) }
    var fineGrainedTokenName by remember { mutableStateOf(restoredConnectionProfile.fineGrainedTokenName) }
    var clientSourceDirectory by remember { mutableStateOf(restoredConnectionProfile.clientSourceDirectory) }
    var serverSourceDirectory by remember { mutableStateOf(restoredConnectionProfile.serverSourceDirectory) }
    var destination by remember { mutableStateOf(restoredConnectionProfile.genericUploadDirectory) }
    var message by remember { mutableStateOf("Upload files through SWRLZ Forge") }
    var token by remember { mutableStateOf(restoredRuntimeToken) }
    var manualTokenInput by rememberSaveable { mutableStateOf("") }
    var oauthClientId by remember { mutableStateOf(restoredConnectionProfile.oauthClientId) }
    var connectedLogin by rememberSaveable {
        mutableStateOf(if (restoredRuntimeToken.isNotBlank()) restoredConnectionProfile.connectedLogin else "")
    }
    var validatingSavedConnection by rememberSaveable { mutableStateOf(restoredRuntimeToken.isNotBlank()) }
    var deviceAuth by remember { mutableStateOf<GitHubForgeClient.DeviceAuthorization?>(null) }
    var workflowId by remember { mutableStateOf("") }
    var dispatch by remember { mutableStateOf(false) }
    var autoRefresh by remember { mutableStateOf(forgePreferences.getBoolean("workflow_auto_refresh", true)) }
    var autoRoute by remember { mutableStateOf(forgePreferences.getBoolean("auto_route_source_packages", true)) }
    var packageTarget by remember { mutableStateOf(forgePreferences.getString("default_package_target", "ASK").orEmpty().ifBlank { "ASK" }) }
    var comboSourceOneTransaction by remember {
        mutableStateOf(forgePreferences.getBoolean("combo_source_one_transaction", true))
    }
    var autoMatchChecksum by remember {
        mutableStateOf(forgePreferences.getBoolean("auto_match_source_checksum", true))
    }
    var autoMatchManifest by remember {
        mutableStateOf(forgePreferences.getBoolean("auto_match_source_manifest", true))
    }
    var sourceZipGuard by remember {
        mutableStateOf(forgePreferences.getBoolean("source_zip_content_guard", true))
    }
    var expandGenericZipToRoot by remember {
        mutableStateOf(forgePreferences.getBoolean("expand_generic_zip_to_repo_root", false))
    }
    var removeExpandedZip by remember {
        mutableStateOf(forgePreferences.getBoolean("remove_expanded_zip_after_unpack", false))
    }
    var showPackagePreview by remember {
        mutableStateOf(forgePreferences.getBoolean("show_package_destination_preview", true))
    }
    var archiveExpansionExpanded by rememberSaveable {
        mutableStateOf(forgePreferences.getBoolean("archive_expansion_expanded", true))
    }
    var workflowHistoryDepth by remember {
        mutableIntStateOf(forgePreferences.getInt("workflow_history_depth", 4).coerceIn(2, 20))
    }
    var files by remember { mutableStateOf(emptyList<GitHubForgeClient.LocalFile>()) }
    var pendingChecksumZip by remember { mutableStateOf<GitHubForgeClient.LocalFile?>(null) }
    var runs by remember { mutableStateOf(emptyList<GitHubForgeClient.WorkflowRun>()) }
    var artifacts by remember { mutableStateOf(emptyList<GitHubForgeClient.Artifact>()) }
    var jobsByRun by remember { mutableStateOf<Map<Long, List<GitHubForgeClient.WorkflowJob>>>(emptyMap()) }
    var selectedRunId by remember { mutableStateOf<Long?>(null) }
    var pendingArtifactBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pendingArtifactName by remember { mutableStateOf("artifact.zip") }
    var pendingWorkflowLogBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pendingWorkflowLogName by remember { mutableStateOf("workflow-logs.zip") }
    var pendingUploadLogBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pendingUploadLogName by remember { mutableStateOf("swrlz-forge-upload.log.txt") }
    var busy by remember { mutableStateOf(false) }
    var forgeProgress by remember { mutableIntStateOf(0) }
    var signingIn by remember { mutableStateOf(false) }
    var showManualToken by remember { mutableStateOf(false) }
    var showDisconnectApproval by remember { mutableStateOf(false) }
    var uploadLogSessionId by remember { mutableStateOf(ForgeUploadLogStore.currentSessionId(context)) }
    var status by remember { mutableStateOf("Connect GitHub, stage CLIENT and SERVER packages, then forge one atomic commit.") }

    LaunchedEffect(credentialRevision) {
        val profile = GitHubConnectionStore.profile(context)
        val sharedToken = if (GitHubConnectionStore.shouldAutoConnect(context)) SecretStore.githubToken(context) else ""
        if (sharedToken != token || profile.connectedLogin != connectedLogin) {
            token = sharedToken
            connectedLogin = if (sharedToken.isNotBlank()) profile.connectedLogin else ""
            validatingSavedConnection = sharedToken.isNotBlank()
            owner = profile.owner
            repository = profile.repository
            branch = profile.branch
            fineGrainedTokenName = profile.fineGrainedTokenName
            clientSourceDirectory = profile.clientSourceDirectory
            serverSourceDirectory = profile.serverSourceDirectory
            destination = profile.genericUploadDirectory
            oauthClientId = profile.oauthClientId
            status = if (sharedToken.isNotBlank()) {
                "Shared GitHub authorization detected. Validating the app-level credential…"
            } else if (profile.connectedLogin.isNotBlank()) {
                "GitHub profile exists without an active token. Reconnect once."
            } else {
                "Connect GitHub, stage CLIENT and SERVER packages, then forge one atomic commit."
            }
        }
    }

    fun ensureUploadLog(reason: String): String {
        val id = ForgeUploadLogStore.ensureSession(context, reason)
        uploadLogSessionId = id
        return id
    }
    val visibleRuns by remember(runs, workflowHistoryDepth) {
        derivedStateOf {
            val deduplicated = runs.distinctBy { "${it.name}|${it.headSha}|${it.event}" }
            deduplicated.filter { it.status != "completed" } +
                deduplicated.filter { it.status == "completed" }.take(workflowHistoryDepth)
        }
    }

    fun refreshRuns() {
        if (token.isBlank()) return
        busy = true
        status = "Refreshing workflow runs…"
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.listWorkflowRuns(owner, repository, branch, token) } }
                .onSuccess { refreshed ->
                    runs = refreshed
                    status = "Loaded ${refreshed.size} recent workflow run(s)."
                    withContext(Dispatchers.IO) { ForgeBuildMonitor.pollOnce(context) }
                }
                .onFailure { status = "Workflow refresh failed: ${it.message}" }
            busy = false
        }
    }

    LaunchedEffect(autoRefresh, token, owner, repository, branch) {
        while (autoRefresh && token.isNotBlank()) {
            delay(if (runs.any { it.status != "completed" }) 2_000 else 5_000)
            runCatching {
                withContext(Dispatchers.IO) {
                    GitHubForgeClient.listWorkflowRuns(owner, repository, branch, token)
                }
            }.onSuccess { refreshed ->
                runs = refreshed
                val active = refreshed.filter { it.status != "completed" }.take(3)
                active.forEach { run ->
                    runCatching {
                        withContext(Dispatchers.IO) {
                            GitHubForgeClient.listWorkflowJobs(owner, repository, run.id, token)
                        }
                    }.onSuccess { jobs ->
                        jobsByRun = jobsByRun + (run.id to jobs)
                    }
                }
                withContext(Dispatchers.IO) { ForgeBuildMonitor.pollOnce(context) }
            }
        }
    }

    LaunchedEffect(token) {
        if (
            token.isNotBlank() &&
            GitHubConnectionStore.shouldAutoConnect(context) &&
            (validatingSavedConnection || connectedLogin.isBlank())
        ) {
            validatingSavedConnection = true
            val activeTokenSnapshot = token
            runCatching {
                withContext(Dispatchers.IO) {
                    GitHubCredentialLifecycle.ensureValid(
                        context = context,
                        oauthClientId = oauthClientId,
                        owner = owner,
                        repository = repository,
                        branch = branch,
                        currentToken = activeTokenSnapshot,
                    )
                }
            }
                .onSuccess { credential ->
                    token = credential.token
                    connectedLogin = credential.login
                    status = if (credential.refreshed) {
                        "GitHub authorization refreshed and validated as ${credential.login}."
                    } else {
                        "Connected to GitHub as ${credential.login}. Saved authorization survived the interface/theme refresh."
                    }
                }
                .onFailure { failure ->
                    if (
                        GitHubForgeClient.isBadCredentials(failure) ||
                        failure.message.orEmpty().contains("bad_refresh_token", ignoreCase = true) ||
                        failure.message.orEmpty().contains("refresh authorization expired", ignoreCase = true)
                    ) {
                        token = ""
                        connectedLogin = ""
                        status = "GitHub rejected the saved credential. Reconnect once; Forge will no longer reuse it."
                    } else {
                        status = "Saved GitHub credential could not be verified right now: ${failure.message}. It was retained because GitHub did not explicitly reject it."
                    }
                }
            validatingSavedConnection = false
        } else if (token.isBlank() && restoredConnectionProfile.connectedLogin.isNotBlank() && restoredConnectionProfile.autoConnect) {
            validatingSavedConnection = false
            status = "GitHub connection identity was restored for ${restoredConnectionProfile.connectedLogin}, but Android did not restore an authorization token. Reconnect once to re-arm automatic sign-in."
        } else {
            validatingSavedConnection = false
        }
    }

    LaunchedEffect(busy, forgeProgress, runs, artifacts, status) {
        val latest = runs.firstOrNull()
        val next = when {
            status.contains("failed", ignoreCase = true) || latest?.conclusion in setOf("failure", "cancelled", "timed_out", "action_required") -> ForgeRuntimeState.Phase.FAILED
            busy && status.contains("Validat", ignoreCase = true) -> ForgeRuntimeState.Phase.VALIDATING
            busy && status.contains("Downloading", ignoreCase = true) -> ForgeRuntimeState.Phase.DOWNLOADING
            busy && forgeProgress in 1..99 -> ForgeRuntimeState.Phase.UPLOADING
            runs.any { it.status != "completed" } -> ForgeRuntimeState.Phase.BUILDING
            status.startsWith("Artifact received") || artifacts.any { !it.expired } -> ForgeRuntimeState.Phase.ARTIFACTS_READY
            latest?.status == "completed" && latest.conclusion == "success" -> ForgeRuntimeState.Phase.COMPLETE
            else -> ForgeRuntimeState.Phase.IDLE
        }
        ForgeRuntimeState.publish(next)
    }

    LaunchedEffect(Unit) {
        // Retire the old directory-grant model. Companion lookup now starts from the
        // selected ZIP and falls back to a picker opened at that document location.
        forgePreferences.edit().remove("source_package_tree_uri").apply()
    }

    val checksumPicker = rememberLauncherForActivityResult(OpenSiblingDocumentContract()) { uri ->
        val zip = pendingChecksumZip
        pendingChecksumZip = null
        if (zip == null) return@rememberLauncherForActivityResult
        val logId = ensureUploadLog("checksum companion selection")

        if (uri == null) {
            ForgeUploadLogStore.append(context, logId, "CHECKSUM_PICKER", "Checksum selection cancelled", mapOf("zip" to zip.displayName))
            status = "Checksum selection cancelled. ${zip.displayName} remains staged, but commit is blocked until its exact SHA-256 sibling is added."
            return@rememberLauncherForActivityResult
        }

        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val checksum = GitHubForgeClient.describe(context, uri)
        val expectedName = GitHubForgeClient.checksumNameForZip(zip.displayName)
        if (GitHubForgeClient.logicalSourceKey(checksum.displayName) != expectedName.lowercase()) {
            ForgeUploadLogStore.append(
                context,
                logId,
                "CHECKSUM_PICKER",
                "Wrong checksum companion selected",
                mapOf("zip" to zip.displayName, "expected" to expectedName, "selected" to checksum.displayName),
            )
            status = "Expected $expectedName beside ${zip.displayName}, but selected ${checksum.displayName}. The ZIP remains staged."
            return@rememberLauncherForActivityResult
        }
        val additions = listOf(zip, checksum)
        val additionsByName = additions.associateBy { GitHubForgeClient.logicalSourceKey(it.displayName) }
        files = (files.filterNot { additionsByName.containsKey(GitHubForgeClient.logicalSourceKey(it.displayName)) } + additions)
            .distinctBy { GitHubForgeClient.logicalSourceKey(it.displayName) }
        status = "Same-folder pair staged: ${zip.displayName} + ${checksum.displayName}."
        ForgeUploadLogStore.append(
            context,
            logId,
            "CHECKSUM_MATCH",
            "Exact same-location checksum companion staged",
            mapOf("zip" to zip.displayName, "checksum" to checksum.displayName, "checksum_size_bytes" to checksum.sizeBytes),
        )
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val logId = ensureUploadLog("source document selection")
        val selected = uris.distinct().map { uri ->
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            GitHubForgeClient.describe(context, uri)
        }
        scope.launch {
            if (selected.isEmpty()) {
                ForgeUploadLogStore.append(context, logId, "SOURCE_PICKER", "No source documents selected")
                status = "No new files selected."
                return@launch
            }

            val bootstrapDetected = selected.any { file ->
                file.displayName.endsWith(".zip", ignoreCase = true) &&
                    file.displayName.contains("bootstrap", ignoreCase = true) &&
                    !GitHubForgeClient.isProtectedSourceZip(file.displayName)
            }
            if (bootstrapDetected) {
                expandGenericZipToRoot = true
                forgePreferences.edit().putBoolean("expand_generic_zip_to_repo_root", true).apply()
                status = "Bootstrap ZIP detected. Repository-root expansion is armed; choose whether to retain the outer ZIP."
            }

            selected.forEach { file ->
                ForgeUploadLogStore.append(
                    context,
                    logId,
                    "SOURCE_SELECTED",
                    "Source document selected",
                    mapOf("name" to file.displayName, "size_bytes" to file.sizeBytes, "provider" to file.uri.authority.orEmpty()),
                )
            }
            val explicitNames = selected.map { GitHubForgeClient.logicalSourceKey(it.displayName) }.toSet()
            val additions = withContext(Dispatchers.IO) {
                selected.flatMap { file ->
                    if (!GitHubForgeClient.isProtectedSourceZip(file.displayName)) {
                        listOf(file)
                    } else {
                        buildList {
                            add(file)
                            val checksumKey = GitHubForgeClient.checksumNameForZip(file.displayName).lowercase()
                            if (autoMatchChecksum && checksumKey !in explicitNames) {
                                runCatching {
                                    GitHubForgeClient.findMatchingChecksumBesideDocument(context, file)
                                        ?: GitHubForgeClient.generateChecksumReceipt(context, file)
                                }.getOrNull()?.let(::add)
                            }
                            val manifestKey = GitHubForgeClient.manifestNameForZip(file.displayName).lowercase()
                            if (autoMatchManifest && manifestKey !in explicitNames) {
                                runCatching { GitHubForgeClient.findMatchingManifestBesideDocument(context, file) }
                                    .getOrNull()?.let(::add)
                            }
                        }
                    }
                }
            }

            val additionsByName = additions.associateBy { GitHubForgeClient.logicalSourceKey(it.displayName) }
            files = (files.filterNot { additionsByName.containsKey(GitHubForgeClient.logicalSourceKey(it.displayName)) } + additions)
                .distinctBy { GitHubForgeClient.logicalSourceKey(it.displayName) }

            val unmatchedChecksums = selected.filter { zip ->
                GitHubForgeClient.isProtectedSourceZip(zip.displayName) &&
                    additions.none { GitHubForgeClient.logicalSourceKey(it.displayName) == GitHubForgeClient.checksumNameForZip(zip.displayName).lowercase() } &&
                    selected.none { GitHubForgeClient.logicalSourceKey(it.displayName) == GitHubForgeClient.checksumNameForZip(zip.displayName).lowercase() }
            }
            val unmatchedManifests = selected.filter { zip ->
                GitHubForgeClient.isProtectedSourceZip(zip.displayName) &&
                    additions.none { GitHubForgeClient.logicalSourceKey(it.displayName) == GitHubForgeClient.manifestNameForZip(zip.displayName).lowercase() } &&
                    selected.none { GitHubForgeClient.logicalSourceKey(it.displayName) == GitHubForgeClient.manifestNameForZip(zip.displayName).lowercase() }
            }
            val autoMatchedChecksumCount = additions.count { GitHubForgeClient.isProtectedSourceChecksum(it.displayName) } -
                selected.count { GitHubForgeClient.isProtectedSourceChecksum(it.displayName) }
            val autoMatchedManifestCount = additions.count { GitHubForgeClient.isProtectedSourceManifest(it.displayName) } -
                selected.count { GitHubForgeClient.isProtectedSourceManifest(it.displayName) }

            ForgeUploadLogStore.append(
                context,
                logId,
                "STAGING_UPDATE",
                "Source staging updated",
                mapOf(
                    "selected_count" to selected.size,
                    "staged_count" to files.size,
                    "auto_matched_checksum_count" to autoMatchedChecksumCount,
                    "auto_matched_manifest_count" to autoMatchedManifestCount,
                    "unmatched_checksum_count" to unmatchedChecksums.size,
                    "unmatched_manifest_count" to unmatchedManifests.size,
                ),
            )
            when {
                autoMatchChecksum && unmatchedChecksums.isNotEmpty() -> {
                    val names = unmatchedChecksums.joinToString { GitHubForgeClient.checksumNameForZip(it.displayName) }
                    status = "Automatic checksum resolution failed for $names. The ZIP remains staged; add the checksum manually before commit."
                    ForgeUploadLogStore.append(context, logId, "CHECKSUM_MATCH", "Automatic checksum sibling lookup/generation failed", mapOf("expected_checksums" to names))
                }
                autoMatchManifest && unmatchedManifests.isNotEmpty() -> {
                    val names = unmatchedManifests.joinToString { GitHubForgeClient.manifestNameForZip(it.displayName) }
                    status = "Automatic manifest resolution failed for $names. The ZIP remains staged; select the manifest companion before commit."
                    ForgeUploadLogStore.append(context, logId, "MANIFEST_MATCH", "Automatic manifest sibling lookup failed", mapOf("expected_manifests" to names))
                }
                autoMatchedChecksumCount > 0 || autoMatchedManifestCount > 0 -> {
                    status = "${selected.size} selection(s) added with $autoMatchedChecksumCount checksum + $autoMatchedManifestCount manifest companion(s); ${files.size} physical files staged."
                }
                else -> status = "${selected.size} file(s) added; ${files.size} total staged."
            }
        }
    }

    val artifactSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val bytes = pendingArtifactBytes
        if (uri != null && bytes != null) {
            runCatching { GitHubForgeClient.writeArtifact(context, uri, bytes) }
                .onSuccess { status = "Saved $pendingArtifactName successfully." }
                .onFailure { status = "Artifact save failed: ${it.message}" }
        }
        pendingArtifactBytes = null
    }

    val workflowLogSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val bytes = pendingWorkflowLogBytes
        if (uri != null && bytes != null) {
            runCatching { GitHubForgeClient.writeArtifact(context, uri, bytes) }
                .onSuccess { status = "Saved $pendingWorkflowLogName successfully." }
                .onFailure { status = "Workflow log save failed: ${it.message}" }
        }
        pendingWorkflowLogBytes = null
    }

    val uploadLogSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val bytes = pendingUploadLogBytes
        if (uri != null && bytes != null) {
            runCatching { GitHubForgeClient.writeArtifact(context, uri, bytes) }
                .onSuccess { status = "Saved $pendingUploadLogName successfully." }
                .onFailure { status = "Forge upload log save failed: ${it.message}" }
        }
        pendingUploadLogBytes = null
    }

    if (showDisconnectApproval) {
        AlertDialog(
            onDismissRequest = { showDisconnectApproval = false },
            title = { Text("Disconnect GitHub?") },
            text = {
                Text(
                    "This removes the active token, saved OAuth client ID, restored account identity, and automatic reconnect backup. Repository files and existing GitHub workflow history are not changed.",
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        GitHubConnectionStore.disconnect(context)
                        token = ""
                        manualTokenInput = ""
                        validatingSavedConnection = false
                        oauthClientId = ""
                        connectedLogin = ""
                        deviceAuth = null
                        signingIn = false
                        showDisconnectApproval = false
                        status = "GitHub disconnected after approval. Automatic reconnect and restore were disabled."
                    },
                ) { Text("DISCONNECT") }
            },
            dismissButton = {
                TextButton(onClick = { showDisconnectApproval = false }) { Text("KEEP CONNECTED") }
            },
        )
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("▸ GITHUB FORGE", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Text("Upload ordinary files or documentation archives directly, auto-route protected CLIENT/SERVER source packages, dispatch builds, observe workflow state, and download resulting artifacts.", color = tokens.text.secondary, fontSize = 13.sp, lineHeight = 19.sp)

        ForgeWorkflowLauncher(
            owner = owner,
            repository = repository,
            branch = branch,
            token = token,
            connected = connectedLogin.isNotBlank(),
            onStatus = { status = it },
            onDispatched = { refreshRuns() },
        )

        ForgePanel("CURRENT TARGET") {
            Text("$owner/$repository · $branch", color = tokens.text.primary, fontWeight = FontWeight.Bold)
            Text("CLIENT → $clientSourceDirectory", color = tokens.text.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("SERVER → $serverSourceDirectory", color = tokens.text.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("Generic → $destination", color = tokens.text.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("Persistent target/routing/guard/ZIP settings are edited under Settings → Forge.", color = tokens.text.secondary, fontSize = 10.sp)
        }

        ForgePanel("UPLOAD ACTION") {
            ForgeField("COMMIT MESSAGE", message, { message = it }, singleLine = false)
        }

        ForgePanel("GITHUB ACCOUNT") {
            if (token.isNotBlank()) {
                Text(
                    if (connectedLogin.isNotBlank()) "Connected as $connectedLogin" else "Saved GitHub authorization found",
                    color = tokens.text.primary,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    if (validatingSavedConnection)
                        "Validating the saved Android Keystore token… Theme Armor and launcher identity changes do not require another device code."
                    else
                        "Runtime token secured by Android Keystore. Connection identity is backup-aware; automatic restore requires Android encrypted backup or device transfer.",
                    color = tokens.text.secondary,
                    fontSize = 11.sp,
                )
                if (validatingSavedConnection) {
                    ThemedProgressBar(
                        snapshot = ProgressSnapshot(
                            operationId = "github-credential-validation",
                            value = null,
                            state = ThemeProgressState.ACTIVE,
                            label = "GitHub credential validation",
                            statusText = "VALIDATING SAVED CONNECTION",
                        ),
                    )
                }
                TextButton(onClick = { showDisconnectApproval = true }) { Text("DISCONNECT GITHUB") }
            } else {
                ForgeField("GITHUB OAUTH APP CLIENT ID", oauthClientId, {
                    oauthClientId = it
                    GitHubConnectionStore.setOAuthClientId(context, it)
                })
                Button(
                    enabled = !signingIn && oauthClientId.isNotBlank(),
                    onClick = {
                        signingIn = true
                        GitHubConnectionStore.setOAuthClientId(context, oauthClientId)
                        status = "Requesting a GitHub device authorization code…"
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.beginDeviceAuthorization(oauthClientId) } }
                                .onSuccess { auth ->
                                    deviceAuth = auth
                                    status = "Enter ${auth.userCode} on GitHub and approve SWRLZ."
                                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(auth.verificationUri))) }
                                    val deadline = System.currentTimeMillis() + auth.expiresInSeconds * 1000L
                                    var interval = auth.pollingIntervalSeconds
                                    while (signingIn && System.currentTimeMillis() < deadline) {
                                        delay(interval * 1000L)
                                        when (val result = withContext(Dispatchers.IO) { GitHubForgeClient.pollDeviceAuthorization(oauthClientId, auth.deviceCode, interval) }) {
                                            is GitHubForgeClient.DeviceTokenPoll.Authorized -> {
                                                val authorizedToken = result.token.trim()
                                                val authorizedLogin = withContext(Dispatchers.IO) {
                                                    GitHubForgeClient.connectedAccount(authorizedToken).login
                                                }
                                                GitHubConnectionStore.saveAuthorizedConnection(
                                                    context = context,
                                                    token = authorizedToken,
                                                    connectedLogin = authorizedLogin,
                                                    oauthClientId = oauthClientId,
                                                    owner = owner,
                                                    repository = repository,
                                                    branch = branch,
                                                    refreshToken = result.refreshToken,
                                                    expiresInSeconds = result.expiresInSeconds,
                                                    refreshTokenExpiresInSeconds = result.refreshTokenExpiresInSeconds,
                                                )
                                                connectedLogin = authorizedLogin
                                                token = authorizedToken
                                                manualTokenInput = ""
                                                validatingSavedConnection = false
                                                status = "Connected to GitHub as $authorizedLogin. Automatic reconnect backup is armed."; signingIn = false
                                            }
                                            is GitHubForgeClient.DeviceTokenPoll.Pending -> interval = result.retryAfterSeconds
                                            is GitHubForgeClient.DeviceTokenPoll.Failed -> { status = "GitHub sign-in failed: ${result.message}"; signingIn = false }
                                        }
                                    }
                                    if (signingIn) { status = "GitHub sign-in code expired."; signingIn = false }
                                }
                                .onFailure { status = "Unable to start sign-in: ${it.message}"; signingIn = false }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(0),
                ) { Text(if (signingIn) "WAITING FOR GITHUB…" else "CONNECT GITHUB") }
                deviceAuth?.let { auth ->
                    Text("Device code: ${auth.userCode}", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = { showManualToken = !showManualToken }) { Text(if (showManualToken) "HIDE TOKEN FALLBACK" else "USE FINE-GRAINED TOKEN") }
                if (showManualToken) {
                    ForgeField("FINE-GRAINED TOKEN", manualTokenInput, { manualTokenInput = it }, secret = true)
                    Text(
                        "The token remains unverified input until VALIDATE TOKEN succeeds. Typing cannot replace the active GitHub session.",
                        color = tokens.text.secondary,
                        fontSize = 10.sp,
                    )
                    OutlinedButton(enabled = manualTokenInput.trim().isNotBlank() && !busy, onClick = {
                        val candidateToken = GitHubForgeClient.normalizeToken(manualTokenInput)
                        busy = true
                        status = "Validating the complete fine-grained token with GitHub…"
                        scope.launch {
                            runCatching {
                                withContext(Dispatchers.IO) {
                                    GitHubForgeClient.validateForgeCredential(owner, repository, branch, candidateToken)
                                }
                            }
                                .onSuccess {
                                    GitHubConnectionStore.saveAuthorizedConnection(
                                        context = context,
                                        token = candidateToken,
                                        connectedLogin = it.login,
                                        oauthClientId = oauthClientId,
                                        owner = owner,
                                        repository = repository,
                                        branch = branch,
                                    )
                                    connectedLogin = it.login
                                    token = candidateToken
                                    manualTokenInput = ""
                                    validatingSavedConnection = false
                                    status = "Connected as ${it.login}. Automatic reconnect backup is armed."
                                }
                                .onFailure {
                                    status = "Token validation failed: ${it.message}. The token was not saved; correct it and retry."
                                }
                            busy = false
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "VALIDATING…" else "VALIDATE TOKEN") }
                }
            }
        }


        ForgePanel("PACKAGE TARGET") {
            Text("Select the package role before choosing files. Companion checksum + manifest lookup stays automatic by default.", color = tokens.text.secondary, fontSize = 10.sp, lineHeight = 14.sp)
            if (!comboSourceOneTransaction) {
                Text("CLIENT + SERVER combo transaction is disabled in Forge settings.", color = tokens.status.warning, fontSize = 9.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("CLIENT", "SERVER").forEach { option ->
                    OutlinedButton(onClick = { packageTarget = option; forgePreferences.edit().putString("default_package_target", option).apply() }, modifier = Modifier.weight(1f)) {
                        Text(if (packageTarget == option) "✓ $option" else option)
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("BOTH", "FILES").forEach { option ->
                    OutlinedButton(
                        onClick = { packageTarget = option; forgePreferences.edit().putString("default_package_target", option).apply() },
                        enabled = option != "BOTH" || comboSourceOneTransaction,
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(if (packageTarget == option) "✓ $option" else option)
                    }
                }
            }
            TextButton(onClick = { packageTarget = "ASK"; forgePreferences.edit().putString("default_package_target", "ASK").apply() }) { Text(if (packageTarget == "ASK") "✓ ASK / AUTO-DETECT" else "ASK / AUTO-DETECT") }
        }

        OutlinedButton(
            enabled = connectedLogin.isNotBlank(),
            onClick = {
                val logId = ensureUploadLog(if (files.isEmpty()) "source picker opened" else "additional source picker opened")
                ForgeUploadLogStore.append(context, logId, "SOURCE_PICKER", "Opening Android source document picker", mapOf("existing_staged_count" to files.size))
                picker.launch(arrayOf("*/*"))
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(0),
            border = BorderStroke(1.dp, tokens.accents.primary),
        ) {
            Text(if (files.isEmpty()) "SELECT SOURCE ZIP OR FILES" else "ADD MORE FILES TO STAGING")
        }

        if (files.isNotEmpty()) ForgePanel("STAGED MASS UPLOAD") {
            files.forEach { file ->
                val expandsAtRoot = expandGenericZipToRoot && file.displayName.endsWith(".zip", true) && !GitHubForgeClient.isProtectedSourceZip(file.displayName)
                val path = if (expandsAtRoot) {
                    if (removeExpandedZip) "[expand → repository root · outer ZIP removed]" else "${file.displayName} + [expand → repository root]"
                } else {
                    GitHubForgeClient.destinationPath(file.displayName, destination, autoRoute, clientSourceDirectory, serverSourceDirectory)
                }
                Text("• ${file.displayName}${formatSize(file.sizeBytes)}", color = tokens.text.primary, fontSize = 12.sp)
                if (showPackagePreview) Text("  ↳ $path", color = tokens.text.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                if (GitHubForgeClient.isProtectedSourceZip(file.displayName)) {
                    val expectedChecksum = GitHubForgeClient.checksumNameForZip(file.displayName)
                    val checksumPresent = files.any {
                        GitHubForgeClient.logicalSourceKey(it.displayName) == expectedChecksum.lowercase()
                    }
                    if (!checksumPresent) {
                        Text(
                            "  ↳ Waiting for $expectedChecksum",
                            color = tokens.status.warning,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                        )
                        TextButton(
                            onClick = {
                                val logId = ensureUploadLog("manual checksum fallback")
                                pendingChecksumZip = file
                                status = "Opening Android's file picker for $expectedChecksum because automatic sibling access was unavailable."
                                ForgeUploadLogStore.append(
                                    context,
                                    logId,
                                    "CHECKSUM_PICKER",
                                    "User requested manual checksum fallback after automatic sibling lookup failed",
                                    mapOf("zip" to file.displayName, "expected" to expectedChecksum),
                                )
                                checksumPicker.launch(SiblingDocumentRequest(file.uri, expectedChecksum))
                            },
                        ) {
                            Text("LOCATE SHA-256")
                        }
                    }
                    val expectedManifest = GitHubForgeClient.manifestNameForZip(file.displayName)
                    val manifestPresent = files.any { GitHubForgeClient.logicalSourceKey(it.displayName) == expectedManifest.lowercase() }
                    if (!manifestPresent) {
                        Text("  ↳ Waiting for $expectedManifest", color = tokens.status.warning, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                        Text("Use ADD MORE FILES if Android withheld same-folder manifest access.", color = tokens.text.secondary, fontSize = 9.sp)
                    }
                }
            }
            TextButton(onClick = {
                val logId = ensureUploadLog("staging cleared")
                ForgeUploadLogStore.append(context, logId, "STAGING_CLEAR", "User cleared staged source files", mapOf("cleared_file_count" to files.size))
                files = emptyList()
                status = "Staging cleared."
            }) { Text("CLEAR STAGING") }
        }


        val hasClientPackage = files.any { GitHubForgeClient.isProtectedSourceZip(it.displayName) && GitHubForgeClient.canonicalSourceFileName(it.displayName).startsWith("CLIENT_", true) }
        val hasServerPackage = files.any { GitHubForgeClient.isProtectedSourceZip(it.displayName) && GitHubForgeClient.canonicalSourceFileName(it.displayName).startsWith("SERVER_", true) }
        val packageTargetSatisfied = when (packageTarget) {
            "CLIENT" -> hasClientPackage
            "SERVER" -> hasServerPackage
            "BOTH" -> comboSourceOneTransaction && hasClientPackage && hasServerPackage
            "FILES" -> files.isNotEmpty()
            else -> files.isNotEmpty()
        }
        if (files.isNotEmpty() && !packageTargetSatisfied) {
            Text("Package target $packageTarget is incomplete. Add the required source ZIP before Forge can commit.", color = tokens.status.warning, fontSize = 10.sp)
        }

        Button(
            enabled = !busy && files.isNotEmpty() && packageTargetSatisfied && token.isNotBlank() && connectedLogin.isNotBlank(),
            onClick = {
                val stagedFiles = files.toList()
                val logId = if (uploadLogSessionId.isBlank()) {
                    ForgeUploadLogStore.startSession(context, "upload submitted from existing staging")
                } else {
                    uploadLogSessionId
                }
                uploadLogSessionId = logId
                val uploadRequest = GitHubForgeClient.UploadRequest(
                    owner = owner,
                    repository = repository,
                    branch = branch,
                    destinationDirectory = destination,
                    commitMessage = message,
                    token = token,
                    files = stagedFiles,
                    workflowId = workflowId,
                    dispatchWorkflow = dispatch,
                    autoRouteSourcePackages = autoRoute,
                    clientSourceDirectory = clientSourceDirectory,
                    serverSourceDirectory = serverSourceDirectory,
                    expandGenericZipToRepositoryRoot = expandGenericZipToRoot,
                    removeExpandedZipAfterUnpack = removeExpandedZip,
                    archiveExpansionRoot = "",
                    forgeActor = "CLIENT",
                    logSessionId = logId,
                    onProgress = { percent, detail ->
                        forgeProgress = percent
                        status = detail
                    },
                )
                val transactionId = uploadRequest.transactionId
                busy = true
                forgeProgress = 1
                status = "Starting Forge transaction ${transactionId.take(8)} for ${stagedFiles.size} staged files…"
                ForgeRuntimeState.beginTransaction(transactionId)
                ForgeUploadLogStore.append(
                    context,
                    logId,
                    "TRANSACTION_START",
                    "Forge upload transaction submitted",
                    mapOf(
                        "transaction_id" to transactionId,
                        "owner" to owner.trim(),
                        "repository" to repository.trim(),
                        "branch" to branch.trim(),
                        "staged_file_count" to stagedFiles.size,
                        "source_zip_guard" to sourceZipGuard,
                        "auto_route" to autoRoute,
                        "expand_generic_zip_to_root" to expandGenericZipToRoot,
                        "remove_expanded_zip" to removeExpandedZip,
                        "dispatch_requested" to dispatch,
                    ),
                )
                scope.launch {
                    var authenticatedUploadRequest = uploadRequest
                    try {
                        status = "Validating the exact GitHub credential snapshot before transfer · TX ${transactionId.take(8)}…"
                        val activeCredential = withContext(Dispatchers.IO) {
                            GitHubCredentialLifecycle.ensureValid(
                                context = context,
                                oauthClientId = oauthClientId,
                                owner = owner,
                                repository = repository,
                                branch = branch,
                                currentToken = token,
                            )
                        }
                        token = activeCredential.token
                        connectedLogin = activeCredential.login
                        authenticatedUploadRequest = uploadRequest.copy(token = activeCredential.token)
                        ForgeUploadLogStore.append(
                            context,
                            logId,
                            "AUTH_PREFLIGHT",
                            if (activeCredential.refreshed) "GitHub credential refreshed and validated before transfer" else "GitHub credential validated before transfer",
                            mapOf(
                                "credential_kind" to activeCredential.kind,
                                "refreshed" to activeCredential.refreshed,
                                "connected_login" to activeCredential.login,
                            ),
                        )

                        status = "Probing GitHub repository write capability before transfer · TX ${transactionId.take(8)}…"
                        val capabilityProbe = withContext(Dispatchers.IO) {
                            GitHubForgeClient.probeForgeCapabilities(
                                owner = owner,
                                repository = repository,
                                branch = branch,
                                token = activeCredential.token,
                            )
                        }
                        ForgeUploadLogStore.append(
                            context,
                            logId,
                            "CAPABILITY_PREFLIGHT",
                            "GitHub authentication, repository read, and Contents write probes passed before transfer",
                            mapOf(
                                "authenticated" to capabilityProbe.authenticated,
                                "repository_read" to capabilityProbe.repositoryReadable,
                                "contents_write" to capabilityProbe.contentsWritable,
                                "actions_read" to capabilityProbe.actionsReadable,
                                "write_probe_sha" to capabilityProbe.writeProbeSha,
                            ),
                        )
                        status = "GitHub ready: authentication, repository read, and Contents write confirmed · TX ${transactionId.take(8)}…"

                        if (sourceZipGuard) {
                            status = "Validating staged ZIP content · TX ${transactionId.take(8)}…"
                            ForgeRuntimeState.publish(ForgeRuntimeState.Phase.VALIDATING)
                            val zipInspection = withContext(Dispatchers.IO) {
                                stagedFiles.filter { GitHubForgeClient.isProtectedSourceZip(it.displayName) }
                                    .map { GitHubForgeClient.inspectSourceZip(context, it) }
                                    .firstOrNull { !it.valid }
                                    ?: GitHubForgeClient.StageValidation(true, "Source ZIP Guard accepted protected source archives; generic files bypass source-structure inspection.")
                            }
                            ForgeUploadLogStore.append(context, logId, "ZIP_GUARD", zipInspection.message, mapOf("valid" to zipInspection.valid))
                            if (!zipInspection.valid) {
                                status = zipInspection.message
                                forgeProgress = 0
                                ForgeRuntimeState.publish(ForgeRuntimeState.Phase.FAILED)
                                ForgeEventNotifier.uploadFailed(context, transactionId, status)
                                ForgeUploadLogStore.finish(context, logId, "FAILED · source ZIP content guard")
                                uploadLogSessionId = ""
                                return@launch
                            }
                            status = zipInspection.message
                        }

                        val validation = withContext(Dispatchers.IO) {
                            GitHubForgeClient.validateSourcePairs(context, stagedFiles)
                        }
                        ForgeUploadLogStore.append(context, logId, "PAIR_VALIDATION", validation.message, mapOf("valid" to validation.valid))
                        if (!validation.valid) {
                            status = validation.message
                            forgeProgress = 0
                            ForgeRuntimeState.publish(ForgeRuntimeState.Phase.FAILED)
                            ForgeEventNotifier.uploadFailed(context, transactionId, status)
                            ForgeUploadLogStore.finish(context, logId, "FAILED · ZIP/SHA pair validation")
                            uploadLogSessionId = ""
                            return@launch
                        }
                        status = validation.message

                        val result = runCatching {
                            withContext(Dispatchers.IO) {
                                GitHubForgeClient.upload(context, authenticatedUploadRequest)
                            }
                        }.recoverCatching { firstFailure ->
                            if (!GitHubForgeClient.isBadCredentials(firstFailure)) throw firstFailure
                            val refreshedCredential = withContext(Dispatchers.IO) {
                                GitHubCredentialLifecycle.forceRefreshIfAvailable(
                                    context = context,
                                    oauthClientId = oauthClientId,
                                    owner = owner,
                                    repository = repository,
                                    branch = branch,
                                )
                            } ?: throw firstFailure
                            token = refreshedCredential.token
                            connectedLogin = refreshedCredential.login
                            authenticatedUploadRequest = authenticatedUploadRequest.copy(token = refreshedCredential.token)
                            status = "GitHub credential expired during transfer; refreshed authorization and retrying once · TX ${transactionId.take(8)}…"
                            ForgeUploadLogStore.append(
                                context,
                                logId,
                                "AUTH_REFRESH_RETRY",
                                "GitHub returned 401 during transfer; refreshed credential and restarted the upload once",
                                mapOf("credential_kind" to refreshedCredential.kind),
                            )
                            withContext(Dispatchers.IO) {
                                GitHubForgeClient.upload(context, authenticatedUploadRequest)
                            }
                        }.getOrElse { failure ->
                            ForgeUploadLogStore.appendFailure(context, logId, "UPLOAD_FAILURE", failure)
                            if (GitHubForgeClient.isBadCredentials(failure)) {
                                val stillAuthenticated = runCatching {
                                    withContext(Dispatchers.IO) {
                                        GitHubForgeClient.validateForgeCredential(owner, repository, branch, authenticatedUploadRequest.token)
                                    }
                                }.isSuccess
                                if (stillAuthenticated) {
                                    token = authenticatedUploadRequest.token
                                    status = "GitHub authentication is still valid. A later repository operation returned 401, so Forge preserved the credential; inspect capability/transport diagnostics instead of reconnecting blindly."
                                    ForgeUploadLogStore.append(
                                        context, logId, "AUTH_REPROBE",
                                        "Credential remained authenticated after the failed repository operation; token preserved",
                                        mapOf("credential_preserved" to true),
                                    )
                                } else {
                                    GitHubConnectionStore.invalidateRejectedCredential(context)
                                    token = ""
                                    connectedLogin = ""
                                    status = "GitHub authentication failed again during re-probe. Forge retired the rejected credential; reconnect once before retrying."
                                }
                            } else if (failure.message.orEmpty().contains("bad_refresh_token", ignoreCase = true)) {
                                GitHubConnectionStore.invalidateRejectedCredential(context)
                                token = ""
                                connectedLogin = ""
                                status = "GitHub refresh authorization was rejected and has been retired; reconnect once before retrying."
                            } else {
                                status = "Upload failed before repository verification: ${failure.message ?: failure::class.simpleName}"
                            }
                            forgeProgress = 0
                            ForgeRuntimeState.publish(ForgeRuntimeState.Phase.FAILED)
                            ForgeEventNotifier.uploadFailed(context, transactionId, status)
                            ForgeUploadLogStore.finish(context, logId, "FAILED · repository upload or confirmation")
                            uploadLogSessionId = ""
                            return@launch
                        }

                        files = emptyList()
                        forgeProgress = 100
                        val dispatchSummary = when {
                            result.dispatchWarning != null -> " Repository verified; workflow dispatch failed."
                            result.workflowDispatched -> " Build dispatched."
                            !result.repositoryChanged -> " Repository already current; no commit required."
                            else -> " Build watch armed."
                        }
                        status = "Upload verified on ${branch.trim()} at ${result.commitSha.take(12)} · TX ${result.transactionId.take(8)}; staging cleared.$dispatchSummary"
                        if (result.repositoryChanged || result.workflowDispatched) {
                            ForgeBuildWatchStore.add(
                                context,
                                ForgeBuildWatch(
                                    owner = owner.trim(),
                                    repository = repository.trim(),
                                    branch = branch.trim(),
                                    commitSha = result.commitSha,
                                    transactionId = result.transactionId,
                                    createdAtMillis = System.currentTimeMillis(),
                                ),
                            )
                        }
                        ForgeEventNotifier.uploadSucceeded(
                            context = context,
                            commitSha = result.commitSha,
                            uploadedPaths = result.uploadedPaths,
                            transactionId = result.transactionId,
                        )
                        result.dispatchWarning?.let { warning ->
                            ForgeEventNotifier.workflowDispatchFailed(
                                context = context,
                                transactionId = result.transactionId,
                                commitSha = result.commitSha,
                                detail = warning,
                            )
                        }
                        if (result.repositoryChanged || result.workflowDispatched) {
                            var observedCommitRun = false
                            ForgeUploadLogStore.append(context, logId, "WORKFLOW_DISCOVERY", "Polling for workflow run associated with transaction commit", mapOf("commit_sha" to result.commitSha))
                            for (attempt in 0 until 8) {
                                if (attempt > 0) delay(1_000)
                                val refreshed = withContext(Dispatchers.IO) {
                                    GitHubForgeClient.listWorkflowRuns(owner, repository, branch, token)
                                }
                                runs = refreshed
                                observedCommitRun = refreshed.any { it.headSha.equals(result.commitSha, ignoreCase = true) }
                                ForgeUploadLogStore.append(
                                    context,
                                    logId,
                                    "WORKFLOW_DISCOVERY",
                                    if (observedCommitRun) "Matching workflow run detected" else "Matching workflow run not visible yet",
                                    mapOf("attempt" to attempt + 1, "returned_run_count" to refreshed.size, "commit_sha" to result.commitSha),
                                )
                                if (observedCommitRun) break
                            }
                            status = if (observedCommitRun) {
                                "$status Workflow run detected for ${result.commitSha.take(12)}."
                            } else {
                                "$status GitHub has not exposed the run yet; observer remains armed."
                            }
                            withContext(Dispatchers.IO) { ForgeBuildMonitor.pollOnce(context) }
                        } else {
                            ForgeUploadLogStore.append(context, logId, "WORKFLOW_DISCOVERY", "Skipped workflow polling because repository content was unchanged and no explicit dispatch occurred")
                        }
                        ForgeUploadLogStore.finish(context, logId, "SUCCESS · commit ${result.commitSha}")
                        uploadLogSessionId = ""
                    } catch (failure: Throwable) {
                        ForgeUploadLogStore.appendFailure(context, logId, "UNHANDLED_UPLOAD_FAILURE", failure)
                        ForgeUploadLogStore.finish(context, logId, "FAILED · unhandled upload exception")
                        uploadLogSessionId = ""
                        forgeProgress = 0
                        ForgeRuntimeState.publish(ForgeRuntimeState.Phase.FAILED)
                        if (GitHubForgeClient.isBadCredentials(failure)) {
                            val stillAuthenticated = runCatching {
                                withContext(Dispatchers.IO) {
                                    GitHubForgeClient.validateForgeCredential(owner, repository, branch, token)
                                }
                            }.isSuccess
                            if (stillAuthenticated) {
                                status = "GitHub authentication re-probe passed after the failure. Forge preserved the credential; download the upload log to inspect the failed capability or transport operation."
                            } else {
                                GitHubConnectionStore.invalidateRejectedCredential(context)
                                token = ""
                                connectedLogin = ""
                                status = "GitHub authentication re-probe failed. Forge retired the rejected credential; reconnect once before retrying."
                            }
                        } else {
                            status = "Forge transaction failed unexpectedly: ${failure.message ?: failure::class.simpleName}. Download the upload log for diagnostics."
                        }
                        ForgeEventNotifier.uploadFailed(context, transactionId, status)
                    } finally {
                        busy = false
                        ForgeRuntimeState.endTransaction(transactionId)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(0),
            colors = ButtonDefaults.buttonColors(containerColor = tokens.accents.primary, contentColor = tokens.surfaces.bgApp),
        ) { Text(if (busy) "FORGING… $forgeProgress%" else "COMMIT MASS UPLOAD", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) }

        if (busy || forgeProgress > 0) {
            ThemedProgressBar(
                snapshot = ProgressSnapshot(
                    operationId = uploadLogSessionId.ifBlank { "forge-upload-current" },
                    value = forgeProgress.coerceIn(0, 100) / 100f,
                    state = when {
                        busy -> ThemeProgressState.ACTIVE
                        forgeProgress == 100 -> ThemeProgressState.SUCCESS
                        else -> ThemeProgressState.INTERRUPTED
                    },
                    label = "Forge upload",
                    statusText = "$forgeProgress% · $status",
                ),
            )
        }


        ForgePanel("UPLOAD DIAGNOSTICS") {
            Text(
                "The latest redacted Forge session log is exportable during staging, transfer, failure, retry, or completion. GitHub tokens, authorization headers, OAuth device codes, and token-like values are removed.",
                color = tokens.text.secondary,
                fontSize = 11.sp,
                lineHeight = 16.sp,
            )
            OutlinedButton(
                enabled = uploadLogSessionId.isNotBlank() || ForgeUploadLogStore.hasLog(context),
                onClick = {
                    val bytes = ForgeUploadLogStore.latestBytes(context)
                    if (bytes == null) {
                        status = "No Forge upload diagnostic log exists yet. Select source files to start one."
                    } else {
                        pendingUploadLogBytes = bytes
                        pendingUploadLogName = ForgeUploadLogStore.latestSuggestedName(context)
                        status = "Forge upload log snapshot ready. Choose where to save it."
                        uploadLogSaver.launch(pendingUploadLogName)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (busy) "DOWNLOAD LIVE UPLOAD LOG" else "DOWNLOAD LATEST UPLOAD LOG") }
        }

        ForgePanel("WORKFLOW OBSERVER") {
            Text(
                "Observer: ${if (autoRefresh) "AUTO · 2s active / 5s idle" else "MANUAL"} · history $workflowHistoryDepth",
                color = tokens.text.primary,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
            )
            Text("Observer preferences are managed under Settings → Forge.", color = tokens.text.secondary, fontSize = 10.sp)
            OutlinedButton(enabled = connectedLogin.isNotBlank() && !busy, onClick = { refreshRuns() }, modifier = Modifier.fillMaxWidth()) { Text("REFRESH NOW") }
            Text("All active runs stay visible. Completed history is limited by the configured history depth.", color = tokens.text.secondary, fontSize = 10.sp)
            visibleRuns.forEach { run ->
                val stateTone = when {
                    run.status != "completed" -> tokens.status.warning
                    run.conclusion == "success" -> tokens.status.success
                    run.conclusion in setOf("failure", "cancelled", "timed_out", "action_required") -> tokens.status.danger
                    else -> tokens.status.info
                }
                Column(
                    Modifier.fillMaxWidth().border(1.dp, stateTone).background(stateTone.copy(alpha = 0.08f)).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                Text(run.name, color = stateTone, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                val runAge = relativeTime(run.runStartedAt ?: run.createdAt)
                val runDuration = elapsedBetween(run.runStartedAt ?: run.createdAt, if (run.status == "completed") run.updatedAt else null)
                Text("${run.status}${run.conclusion?.let { " / $it" } ?: ""} · ${run.branch} · ${run.event}", color = tokens.text.secondary, fontSize = 11.sp)
                Text("Started $runAge · $runDuration", color = tokens.text.secondary, fontSize = 11.sp)
                if (run.status == "completed") {
                    val runState = when (run.conclusion) {
                        "success" -> ThemeProgressState.SUCCESS
                        "cancelled" -> ThemeProgressState.CANCELLED
                        "failure", "timed_out", "action_required" -> ThemeProgressState.FAILED
                        else -> ThemeProgressState.INTERRUPTED
                    }
                    ThemedProgressBar(
                        snapshot = ProgressSnapshot(
                            operationId = "workflow-${run.id}",
                            value = if (runState == ThemeProgressState.SUCCESS) 1f else null,
                            state = runState,
                            label = "Workflow ${run.name}",
                            statusText = "${run.status} · ${run.conclusion ?: "unknown conclusion"}",
                        ),
                    )
                } else {
                    ThemedProgressBar(
                        snapshot = ProgressSnapshot(
                            operationId = "workflow-${run.id}",
                            value = null,
                            state = ThemeProgressState.ACTIVE,
                            label = "Workflow ${run.name}",
                            statusText = "BUILD ACTIVE · EXACT PERCENTAGE UNKNOWN",
                        ),
                    )
                    Text("Build is cooking — GitHub reports phases, not an exact compile percentage.", color = tokens.text.secondary, fontSize = 10.sp)
                }
                Text(run.displayTitle, color = tokens.text.secondary, fontSize = 11.sp)
                val jobs = jobsByRun[run.id].orEmpty()
                jobs.forEach { job ->
                    Text("${job.name}: ${job.status}${job.conclusion?.let { " / $it" } ?: ""}", color = tokens.text.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    job.steps.forEach { step ->
                        val marker = when {
                            step.status == "in_progress" -> "▶"
                            step.conclusion == "success" -> "✓"
                            step.conclusion != null -> "✕"
                            else -> "○"
                        }
                        Text("$marker ${step.name}", color = tokens.text.secondary, fontSize = 10.sp)
                    }
                }
                if (run.status != "completed" && jobs.isEmpty()) {
                    Text("Waiting for GitHub job and step details…", color = tokens.text.secondary, fontSize = 10.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        selectedRunId = run.id; busy = true; status = "Loading artifacts for ${run.name}…"
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.listArtifacts(owner, repository, run.id, token) } }
                                .onSuccess { found ->
                                    artifacts = found
                                    status = "Loaded ${found.size} artifact(s) for run ${run.id}."
                                    val single = found.singleOrNull { !it.expired }
                                    if (single != null) {
                                        status = "Downloading ${single.name} from GitHub Actions…"
                                        runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.downloadArtifact(owner, repository, single.id, token) } }
                                            .onSuccess { bytes ->
                                                pendingArtifactBytes = bytes
                                                pendingArtifactName = if (single.name.endsWith(".zip", true)) single.name else "${single.name}.zip"
                                                status = "Artifact received. Choose where to save it."
                                                artifactSaver.launch(pendingArtifactName)
                                            }
                                            .onFailure { status = "Artifact download failed: ${it.message}" }
                                    }
                                }
                                .onFailure { status = "Artifact lookup failed: ${it.message}" }
                            busy = false
                        }
                    }) { Text("ARTIFACTS") }
                    TextButton(
                        enabled = !busy,
                        onClick = {
                            busy = true
                            status = "Downloading logs for ${run.name}…"
                            scope.launch {
                                runCatching {
                                    withContext(Dispatchers.IO) {
                                        GitHubForgeClient.downloadWorkflowLogs(owner, repository, run.id, token)
                                    }
                                }.onSuccess { bytes ->
                                    pendingWorkflowLogBytes = bytes
                                    pendingWorkflowLogName = "workflow_${run.id}_${run.name.replace(Regex("[^A-Za-z0-9._-]+"), "_")}_logs.zip"
                                    status = "Workflow logs received. Choose where to save them."
                                    workflowLogSaver.launch(pendingWorkflowLogName)
                                }.onFailure {
                                    status = "Workflow log download failed: ${it.message}"
                                }
                                busy = false
                            }
                        },
                    ) { Text("LOGS") }
                    TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(run.htmlUrl))) }) { Text("OPEN") }
                    if (run.status != "completed") {
                        TextButton(enabled = !busy, onClick = {
                            busy = true
                            status = "Canceling ${run.name}…"
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.cancelWorkflowRun(owner, repository, run.id, token) } }
                                    .onSuccess { status = "Cancel request accepted for ${run.name}."; refreshRuns() }
                                    .onFailure { status = "Cancel failed: ${it.message}" }
                                busy = false
                            }
                        }) { Text("CANCEL") }
                    } else {
                        TextButton(enabled = !busy, onClick = {
                            busy = true
                            status = "Re-running ${run.name}…"
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.rerunWorkflowRun(owner, repository, run.id, token) } }
                                    .onSuccess { status = "Re-run request accepted for ${run.name}."; refreshRuns() }
                                    .onFailure { status = "Re-run failed: ${it.message}" }
                                busy = false
                            }
                        }) { Text("RE-RUN") }
                    }
                }
                }
            }
        }

        if (selectedRunId != null) ForgePanel("RUN ARTIFACTS") {
            if (artifacts.isEmpty()) Text("No downloadable artifacts found for the selected run.", color = tokens.text.secondary, fontSize = 11.sp)
            artifacts.forEach { artifact ->
                Text("${artifact.name}${formatSize(artifact.sizeBytes)} · ${relativeTime(artifact.createdAt)}${if (artifact.expired) " · EXPIRED" else ""}", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                OutlinedButton(enabled = !artifact.expired && !busy, onClick = {
                    busy = true; status = "Downloading ${artifact.name} from GitHub Actions…"
                    scope.launch {
                        runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.downloadArtifact(owner, repository, artifact.id, token) } }
                            .onSuccess { bytes ->
                                pendingArtifactBytes = bytes
                                pendingArtifactName = if (artifact.name.endsWith(".zip", true)) artifact.name else "${artifact.name}.zip"
                                status = "Artifact received. Choose where to save it."
                                artifactSaver.launch(pendingArtifactName)
                            }
                            .onFailure { status = "Artifact download failed: ${it.message}" }
                        busy = false
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("DOWNLOAD ${artifact.name.uppercase()}") }
            }
        }

        ForgePanel("FORGE STATUS") { Text(status, color = tokens.text.secondary, fontSize = 12.sp, lineHeight = 17.sp) }
        Text("Fine-grained token setup for this personal build: select only the intended repository; grant Contents read/write and Actions read/write. Pull requests read/write is optional for a later PR-first mode.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun ForgePanel(title: String, content: @Composable ColumnScope.() -> Unit) {
    val tokens = LocalSwurlzTokens.current
    Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bg).padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.6.sp)
        content()
    }
}

@Composable
private fun CollapsibleForgePanel(
    title: String,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    Column(
        Modifier
            .fillMaxWidth()
            .border(1.dp, tokens.borders.neutral)
            .background(tokens.cards.bg),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { onExpandedChange(!expanded) }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(title, color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.6.sp)
            Text(if (expanded) "COLLAPSE ▲" else "EXPAND ▼", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
        }
        if (expanded) {
            Column(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp),
                content = content,
            )
        }
    }
}

@Composable
private fun ForgeField(label: String, value: String, onValueChange: (String) -> Unit, singleLine: Boolean = true, secret: Boolean = false) {
    OutlinedTextField(value = value, onValueChange = onValueChange, label = { Text(label, fontSize = 10.sp, fontFamily = FontFamily.Monospace) }, modifier = Modifier.fillMaxWidth(), singleLine = singleLine, visualTransformation = if (secret) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None)
}

private fun formatSize(bytes: Long): String = when {
    bytes < 0 -> ""
    bytes < 1024 -> " · $bytes B"
    bytes < 1024 * 1024 -> " · ${bytes / 1024} KiB"
    else -> " · ${"%.1f".format(bytes / 1024.0 / 1024.0)} MiB"
}


private fun relativeTime(iso: String): String = runCatching {
    val seconds = Duration.between(Instant.parse(iso), Instant.now()).seconds.coerceAtLeast(0)
    when {
        seconds < 60 -> "${seconds}s ago"
        seconds < 3600 -> "${seconds / 60}m ago"
        seconds < 86400 -> "${seconds / 3600}h ago"
        else -> "${seconds / 86400}d ago"
    }
}.getOrDefault("time unavailable")

private fun elapsedBetween(startIso: String, endIso: String?): String = runCatching {
    val start = Instant.parse(startIso)
    val end = endIso?.takeIf { it.isNotBlank() }?.let(Instant::parse) ?: Instant.now()
    val seconds = Duration.between(start, end).seconds.coerceAtLeast(0)
    when {
        seconds < 60 -> "${seconds}s elapsed"
        seconds < 3600 -> "${seconds / 60}m ${seconds % 60}s elapsed"
        else -> "${seconds / 3600}h ${(seconds % 3600) / 60}m elapsed"
    }
}.getOrDefault("duration unavailable")
