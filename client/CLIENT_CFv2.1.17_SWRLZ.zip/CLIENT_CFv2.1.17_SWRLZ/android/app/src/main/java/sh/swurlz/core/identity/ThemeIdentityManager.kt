package sh.swurlz.core.identity

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import sh.swrlz.theme.BuiltInThemePacks
import sh.swrlz.theme.DEFAULT_THEME_ID
import sh.swrlz.theme.ThemeTarget
import sh.swurlz.core.R

/**
 * Keeps launcher, bubble, shortcut, and notification identity synchronized
 * with the active local CLIENT ThemePack.
 *
 * Theme selection changes presentation identity only. It does not grant
 * registration, trust, connection, authorization, or mission capability.
 */
object ThemeIdentityManager {
    private enum class Alias(
        val componentClass: String,
        val iconRes: Int,
        val themeId: String,
    ) {
        GlitchDragon(
            "sh.swurlz.core.launcher.GlitchDragon",
            R.mipmap.ic_launcher_glitch_dragon,
            DEFAULT_THEME_ID,
        ),
    }

    private val registry get() = BuiltInThemePacks.registry

    fun requestApply(context: Context, selector: String) {
        val pack = registry.resolve(selector, ThemeTarget.CLIENT)
        context.getSharedPreferences("theme_identity", Context.MODE_PRIVATE)
            .edit()
            .putString("current_theme_id", pack.id)
            .putString("current_theme", pack.displayName)
            .putString("pending_theme_id", pack.id)
            .apply()
    }

    fun currentThemeId(context: Context): String {
        val prefs = context.getSharedPreferences("theme_identity", Context.MODE_PRIVATE)
        return registry.resolve(
            prefs.getString("current_theme_id", null)
                ?: prefs.getString("current_theme", null)
                ?: activeAlias(context).themeId,
            ThemeTarget.CLIENT,
        ).id
    }

    fun currentThemeFamily(context: Context): String =
        registry.resolve(currentThemeId(context), ThemeTarget.CLIENT).displayName

    /** Reasserts the selected launcher alias after an APK update. */
    fun reconcileLauncherIdentity(context: Context) {
        applyNow(context, currentThemeId(context))
    }

    fun applyPending(context: Context) {
        val prefs = context.getSharedPreferences("theme_identity", Context.MODE_PRIVATE)
        val selector = prefs.getString("pending_theme_id", null)
            ?: prefs.getString("pending_theme", null)
            ?: return
        applyNow(context, selector)
        prefs.edit().remove("pending_theme_id").remove("pending_theme").apply()
    }

    private fun applyNow(context: Context, selector: String) {
        val themeId = registry.resolve(selector, ThemeTarget.CLIENT).id
        val selected = Alias.entries.firstOrNull { it.themeId == themeId } ?: Alias.GlitchDragon
        context.packageManager.setComponentEnabledSetting(
            ComponentName(context.packageName, selected.componentClass),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP,
        )
        Alias.entries.filter { it != selected }.forEach { alias ->
            context.packageManager.setComponentEnabledSetting(
                ComponentName(context.packageName, alias.componentClass),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP,
            )
        }
    }

    private fun activeAlias(context: Context): Alias =
        Alias.entries.firstOrNull { alias ->
            context.packageManager.getComponentEnabledSetting(
                ComponentName(context.packageName, alias.componentClass),
            ) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
        } ?: Alias.GlitchDragon

    fun activeIconResource(context: Context): Int = activeAlias(context).iconRes

    /** Bubble/shortcut identity follows the selected theme before launcher cache refresh. */
    fun currentThemeIconResource(context: Context): Int = iconResource(currentThemeId(context))

    fun iconResource(selector: String): Int {
        val id = registry.resolve(selector, ThemeTarget.CLIENT).id
        return Alias.entries.firstOrNull { it.themeId == id }?.iconRes ?: Alias.GlitchDragon.iconRes
    }

    fun clientBubbleIconResource(context: Context): Int =
        roleBubbleIconResource("client", currentThemeId(context))

    fun serverBubbleIconResource(context: Context): Int =
        roleBubbleIconResource("server", currentThemeId(context))

    fun fusionBubbleIconResource(context: Context): Int =
        roleBubbleIconResource("fusion", currentThemeId(context))

    private fun roleBubbleIconResource(role: String, selector: String): Int {
        // Bootstrap transport edition exposes only the canonical default ThemePack.
        registry.resolve(selector, ThemeTarget.CLIENT)
        return when (role) {
            "server" -> R.drawable.swrlz_server_bubble_glitch_dragon
            "fusion" -> R.drawable.swrlz_fusion_bubble_glitch_dragon
            else -> R.drawable.swrlz_client_bubble_glitch_dragon
        }
    }

    fun accentColor(selector: String): Int {
        val hex = registry.resolve(selector, ThemeTarget.CLIENT).palette.primary.removePrefix("#")
        return (0xFF000000L or hex.toLong(16)).toInt()
    }
}
