package sh.swurlz.core.ai

object SwrlzIntentRouter {
    enum class Kind { CHAT, QUESTION, SYSTEM_STATE, PROVIDER_SOURCE_ANALYSIS, QUICK_ACTION_SETTINGS, UPDATE, FORGE, FORGE_BOOTSTRAP, FORGE_STOP, MISSION, MISSION_PAUSE, MISSION_RESUME, MISSION_STOP }
    data class Result(val kind: Kind, val reason: String)

    fun classify(text: String): Result {
        val t = text.trim().lowercase()
        if (t.isBlank()) return Result(Kind.CHAT, "empty")
        if (Regex("^(hi|hey|hello|yo|sup|thanks|thank you|ok|okay|lol|lmao)[!.? ]*$", RegexOption.IGNORE_CASE).matches(text.trim())) {
            return Result(Kind.CHAT, "social conversation")
        }
        if (listOf("stop forge", "cancel forge", "abort forge", "stop the forge", "cancel the forge", "never mind forge").any { it in t }) return Result(Kind.FORGE_STOP, "active Forge cancellation requested")
        if ("bootstrap" in t && listOf("upload", "unzip", "expand", "extract", "forge", "repo", "repository").any { it in t }) {
            return Result(Kind.FORGE_BOOTSTRAP, "repository bootstrap expansion requested")
        }
        if (listOf("stop mission", "cancel mission", "abort mission", "end mission", "stop the mission", "cancel the mission").any { it in t }) return Result(Kind.MISSION_STOP, "active mission cancellation requested")
        if (listOf("pause mission", "pause the mission", "hold mission", "hold the mission").any { it in t }) return Result(Kind.MISSION_PAUSE, "active mission pause requested")
        if (listOf("resume mission", "resume the mission", "continue mission", "continue the mission").any { it in t }) return Result(Kind.MISSION_RESUME, "active mission resume requested")
        if (ProviderSourceIntentParser.parse(text) != null) return Result(Kind.PROVIDER_SOURCE_ANALYSIS, "canonical SWRLZ source analysis requested")
        if (("gemini" in t || "gpt" in t || "openai" in t || "provider" in t || "github" in t || "accessibility" in t || "swurver" in t) && listOf("configured", "connected", "enabled", "ready", "status", "reachable").any { it in t }) return Result(Kind.SYSTEM_STATE, "runtime state query")
        if (("update client" in t || "update server" in t || "update swrlz" in t || "update swurlzer" in t) && (".zip" in t || "using" in t || "version" in t)) return Result(Kind.UPDATE, "autonomous source update requested")
        if ("mission" in t && t.length > 15) return Result(Kind.MISSION, "user explicitly requested mission execution")
        if (("open" in t || "launch" in t || "go to" in t) && "settings" in t) return Result(Kind.QUICK_ACTION_SETTINGS, "deterministic Android action")
        if (listOf("forge", "github build", "build the client", "build client", "build the server", "build server", "upload client", "upload server", "source zip").any { it in t }) {
            return Result(Kind.FORGE, "Forge capability requested")
        }
        val missionSignals = listOf("mission", "go through", "learn my phone", "for each", "then", "after that", "keep checking", "monitor", "organize all", "build and download")
        if (missionSignals.any { it in t } && t.length > 35) return Result(Kind.MISSION, "multi-step/stateful request")
        if (text.trim().endsWith("?") || listOf("what ", "why ", "how ", "who ", "when ", "where ", "can you explain").any { t.startsWith(it) }) return Result(Kind.QUESTION, "knowledge request")
        return Result(Kind.CHAT, "conversation by default")
    }
}
