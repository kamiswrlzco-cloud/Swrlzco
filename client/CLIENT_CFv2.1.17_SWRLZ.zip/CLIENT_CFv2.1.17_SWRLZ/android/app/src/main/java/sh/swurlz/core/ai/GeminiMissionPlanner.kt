package sh.swurlz.core.ai

import org.json.JSONArray
import org.json.JSONObject
import sh.swurlz.core.model.Action
import sh.swurlz.core.model.PlanRequest
import sh.swurlz.core.model.PlanResponse

/** Converts Gemini's private reasoning into the same structured action contract used by SWRLZ missions. */
object GeminiMissionPlanner {
    fun plan(apiKey: String, request: PlanRequest): PlanResponse {
        val nodeText = request.nodes.take(80).joinToString("\n") { n ->
            "id=${n.id} class=${n.cls.orEmpty()} text=${n.text.orEmpty()} desc=${n.desc.orEmpty()} clickable=${n.clickable} editable=${n.editable} scrollable=${n.scrollable} bounds=${n.bounds}"
        }
        val prompt = """
You are a private mission-planning consultant inside SWRLZ. Return JSON only.
SWRLZ, not you, executes actions through Android accessibility.
Goal: ${request.goal}
Current package: ${request.`package`.orEmpty()}
Screen summary: ${request.screen_summary.orEmpty()}
Visible nodes:
$nodeText

Return exactly this shape:
{"rationale":"brief operational reason or gathered answer","needs_approval":false,"actions":[...]}
Allowed action types: tap,type_text,scroll,back,home,wait,open_app,ask_user,done.
For tap/type_text use node_id from the visible nodes. For scroll use direction up/down. For open_app use package.
When the goal has been achieved, return a done action and put the useful gathered result in rationale.
Never invent a node id. Prefer observation and deterministic navigation. If information cannot be verified, ask_user instead of guessing.
""".trimIndent()
        val result = GeminiClient.generate(apiKey, prompt)
        require(result.ok) { result.error ?: "Gemini mission planning failed." }
        val raw = result.text.orEmpty().trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val root = JSONObject(raw)
        val actionsJson = root.optJSONArray("actions") ?: JSONArray()
        val actions = buildList {
            for (i in 0 until actionsJson.length()) {
                val a = actionsJson.optJSONObject(i) ?: continue
                add(Action(
                    type = a.optString("type"),
                    node_id = a.optString("node_id").takeIf { it.isNotBlank() },
                    text = a.optString("text").takeIf { it.isNotBlank() },
                    direction = a.optString("direction").takeIf { it.isNotBlank() },
                    ms = a.optInt("ms", 0).takeIf { it > 0 },
                    `package` = a.optString("package").takeIf { it.isNotBlank() },
                    reason = a.optString("reason"),
                    risk = a.optString("risk", "green"),
                    confidence = a.optDouble("confidence", 0.8),
                    expected = a.optString("expected").takeIf { it.isNotBlank() },
                ))
            }
        }
        return PlanResponse(
            mission_id = request.mission_id,
            actions = actions.ifEmpty { listOf(Action(type = "ask_user", text = "I need more on-screen context before I can continue safely.")) },
            rationale = root.optString("rationale", "Planning the next verified step."),
            needs_approval = root.optBoolean("needs_approval", false),
        )
    }
}
