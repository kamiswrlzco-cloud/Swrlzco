package sh.swurlz.core.ui.client

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sh.swrlz.command.CommandCategory
import sh.swrlz.command.SwrlzCommandCatalog
import sh.swurlz.core.ui.theme.LocalSwurlzTokens

@Composable
internal fun ChatCommandQuickMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    onInsert: (String) -> Unit,
    onOpenCommandCenter: () -> Unit,
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(text = { Text("🔥 Forge") }, onClick = { onInsert("start Forge"); onDismiss() })
        DropdownMenuItem(text = { Text("⚡ GPT + Gemini Council") }, onClick = { onInsert("@both "); onDismiss() })
        DropdownMenuItem(text = { Text("📦 Latest CLIENT + SERVER") }, onClick = { onInsert("forge latest SWRLZ CLIENT and SERVER sources"); onDismiss() })
        DropdownMenuItem(text = { Text("🎭 Switch profile") }, onClick = { onInsert("switch CLIENT SWRLZ profile to "); onDismiss() })
        DropdownMenuItem(text = { Text("🧭 Command Center") }, onClick = { onDismiss(); onOpenCommandCenter() })
    }
}

@Composable
internal fun ChatCommandCenterDialog(
    onDismiss: () -> Unit,
    onInsert: (String) -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val prefs = remember { context.getSharedPreferences("swrlz_command_center", Context.MODE_PRIVATE) }
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf<CommandCategory?>(null) }
    var favoriteRevision by remember { mutableIntStateOf(0) }
    val favorites = remember(favoriteRevision) { prefs.getStringSet("favorites", emptySet()).orEmpty().toSet() }
    val commands = remember(search, category, favoriteRevision) {
        SwrlzCommandCatalog.search(search, category).sortedWith(
            compareByDescending<sh.swrlz.command.SwrlzCommandV1> { it.id in favorites }.thenBy { it.title }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("SWRLZ Command Center", color = tokens.text.primary, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("Discover canonical capabilities, favorite useful commands, and insert natural-language templates into Chat for review before sending.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
                OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Search commands") }, singleLine = true)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = category == null, onClick = { category = null }, label = { Text("ALL") })
                    FilterChip(selected = category == CommandCategory.FORGE, onClick = { category = CommandCategory.FORGE }, label = { Text("FORGE") })
                    FilterChip(selected = category == CommandCategory.AI, onClick = { category = CommandCategory.AI }, label = { Text("AI") })
                    FilterChip(selected = category == CommandCategory.FILES, onClick = { category = CommandCategory.FILES }, label = { Text("FILES") })
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = category == CommandCategory.PROFILES, onClick = { category = CommandCategory.PROFILES }, label = { Text("PROFILES") })
                    FilterChip(selected = category == CommandCategory.MISSIONS, onClick = { category = CommandCategory.MISSIONS }, label = { Text("MISSIONS") })
                    FilterChip(selected = category == CommandCategory.CONNECTIONS, onClick = { category = CommandCategory.CONNECTIONS }, label = { Text("LINKS") })
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = category == CommandCategory.CHAT, onClick = { category = CommandCategory.CHAT }, label = { Text("CHAT") })
                    FilterChip(selected = category == CommandCategory.SYSTEM, onClick = { category = CommandCategory.SYSTEM }, label = { Text("SYSTEM") })
                }
                HorizontalDivider()
                commands.forEach { command ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(command.title, fontWeight = FontWeight.SemiBold, color = tokens.text.primary, modifier = Modifier.weight(1f))
                                TextButton(onClick = {
                                    val next = favorites.toMutableSet()
                                    if (!next.add(command.id)) next.remove(command.id)
                                    prefs.edit().putStringSet("favorites", next).apply()
                                    favoriteRevision++
                                }) { Text(if (command.id in favorites) "★" else "☆") }
                            }
                            Text(command.description, color = tokens.text.secondary, fontSize = 10.sp, lineHeight = 14.sp)
                            Text(command.template, color = tokens.accents.primary, fontSize = 10.sp)
                            if (command.aliases.isNotEmpty()) Text("Aliases · ${command.aliases.joinToString()}", color = tokens.text.muted, fontSize = 9.sp)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                Button(onClick = { onInsert(command.template); onDismiss() }) { Text("INSERT") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("CLOSE") } },
    )
}
