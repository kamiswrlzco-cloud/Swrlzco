package sh.swurlz.core.github

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.BaseColumns
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.*
import io.ktor.client.request.forms.FormDataContent
import io.ktor.client.statement.HttpResponse
import io.ktor.http.*
import io.ktor.http.content.OutgoingContent
import io.ktor.utils.io.ByteWriteChannel
import io.ktor.utils.io.writeFully
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.delay
import kotlinx.serialization.SerialName
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream
import java.util.zip.ZipFile

/** GitHub repository forge: atomic mass upload, workflow observation, and artifact download. */
object GitHubForgeClient {
    private const val GITHUB_BLOB_LIMIT_BYTES = 100L * 1024L * 1024L
    private const val ARCHIVE_EXPANSION_LIMIT_BYTES = 512L * 1024L * 1024L
    private const val ARCHIVE_EXPANSION_ENTRY_LIMIT = 2500
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val client = HttpClient(OkHttp) {
        engine {
            config {
                connectTimeout(30, TimeUnit.SECONDS)
                readTimeout(5, TimeUnit.MINUTES)
                writeTimeout(5, TimeUnit.MINUTES)
                callTimeout(10, TimeUnit.MINUTES)
            }
        }
        install(ContentNegotiation) { json(json) }
        followRedirects = true
    }

    data class LocalFile(val uri: Uri, val displayName: String, val sizeBytes: Long)
    private data class FileTarget(val file: LocalFile, val path: String)

    data class UploadRequest(
        val owner: String,
        val repository: String,
        val branch: String,
        val destinationDirectory: String,
        val commitMessage: String,
        val token: String,
        val files: List<LocalFile>,
        val workflowId: String = "",
        val dispatchWorkflow: Boolean = false,
        val autoRouteSourcePackages: Boolean = true,
        val clientSourceDirectory: String = GitHubConnectionStore.DEFAULT_CLIENT_SOURCE_DIRECTORY,
        val serverSourceDirectory: String = GitHubConnectionStore.DEFAULT_SERVER_SOURCE_DIRECTORY,
        val expandGenericZipToRepositoryRoot: Boolean = false,
        val removeExpandedZipAfterUnpack: Boolean = false,
        val archiveExpansionRoot: String = "",
        val transactionId: String = UUID.randomUUID().toString(),
        val forgeActor: String = "CLIENT",
        val logSessionId: String = "",
        val onProgress: suspend (Int, String) -> Unit = { _, _ -> },
    )

    data class UploadResult(
        val commitSha: String,
        val uploadedPaths: List<String>,
        val transactionId: String,
        val workflowDispatched: Boolean,
        val dispatchWarning: String? = null,
        val repositoryChanged: Boolean = true,
    )
    data class DeviceAuthorization(val deviceCode: String, val userCode: String, val verificationUri: String, val expiresInSeconds: Int, val pollingIntervalSeconds: Int)
    data class ConnectedAccount(val login: String, val avatarUrl: String = "")
    data class ForgeCapabilityProbe(
        val authenticated: Boolean,
        val repositoryReadable: Boolean,
        val contentsWritable: Boolean,
        val actionsReadable: Boolean,
        val writeProbeSha: String = "",
    )
    data class WorkflowRun(
        val id: Long,
        val name: String,
        val displayTitle: String,
        val status: String,
        val conclusion: String?,
        val branch: String,
        val headSha: String,
        val event: String,
        val createdAt: String,
        val updatedAt: String,
        val runStartedAt: String?,
        val htmlUrl: String,
    )
    data class WorkflowStep(val name: String, val status: String, val conclusion: String?, val number: Int)
    data class WorkflowJob(val id: Long, val name: String, val status: String, val conclusion: String?, val startedAt: String?, val completedAt: String?, val steps: List<WorkflowStep>)
    data class StageValidation(val valid: Boolean, val message: String)
    data class Artifact(val id: Long, val name: String, val sizeBytes: Long, val expired: Boolean, val createdAt: String)
    data class RepositoryItem(val name: String, val path: String, val type: String, val sizeBytes: Long, val sha: String)
    data class RepositoryWriteResult(val path: String, val commitSha: String, val contentSha: String)
    data class RepositoryMove(val sourcePath: String, val destinationPath: String, val sha: String = "")
    data class RepositoryMutationResult(val commitSha: String, val changedPaths: List<String>)
    data class RepositoryBranch(val name: String)
    data class WorkflowDescriptor(val id: Long, val name: String, val path: String, val state: String, val htmlUrl: String)
    data class WorkflowInput(
        val name: String,
        val description: String = "",
        val required: Boolean = false,
        val type: String = "string",
        val defaultValue: String = "",
        val options: List<String> = emptyList(),
    )
    data class WorkflowDispatchResult(val runId: Long? = null, val htmlUrl: String? = null)

    sealed interface DeviceTokenPoll {
        data class Authorized(
            val token: String,
            val refreshToken: String = "",
            val expiresInSeconds: Int? = null,
            val refreshTokenExpiresInSeconds: Int? = null,
            val tokenType: String = "bearer",
        ) : DeviceTokenPoll
        data class Pending(val retryAfterSeconds: Int) : DeviceTokenPoll
        data class Failed(val message: String) : DeviceTokenPoll
    }

    suspend fun beginDeviceAuthorization(clientId: String): DeviceAuthorization {
        require(clientId.isNotBlank()) { "GitHub OAuth Client ID is required." }
        val response = client.post("https://github.com/login/device/code") {
            header(HttpHeaders.Accept, "application/json")
            setBody(FormDataContent(Parameters.build {
                append("client_id", clientId.trim())
                append("scope", "repo workflow read:user")
            }))
        }
        ensureSuccess(response)
        val body = response.body<DeviceCodeResponse>()
        return DeviceAuthorization(body.deviceCode, body.userCode, body.verificationUri, body.expiresIn, body.interval.coerceAtLeast(5))
    }

    suspend fun pollDeviceAuthorization(clientId: String, deviceCode: String, intervalSeconds: Int): DeviceTokenPoll {
        val response = client.post("https://github.com/login/oauth/access_token") {
            header(HttpHeaders.Accept, "application/json")
            setBody(FormDataContent(Parameters.build {
                append("client_id", clientId.trim())
                append("device_code", deviceCode)
                append("grant_type", "urn:ietf:params:oauth:grant-type:device_code")
            }))
        }
        ensureSuccess(response)
        val body = response.body<DeviceTokenResponse>()
        return when {
            !body.accessToken.isNullOrBlank() -> DeviceTokenPoll.Authorized(
                token = normalizeToken(body.accessToken.orEmpty()),
                refreshToken = normalizeToken(body.refreshToken.orEmpty()),
                expiresInSeconds = body.expiresIn,
                refreshTokenExpiresInSeconds = body.refreshTokenExpiresIn,
                tokenType = body.tokenType.orEmpty().ifBlank { "bearer" },
            )
            body.error == "authorization_pending" -> DeviceTokenPoll.Pending(intervalSeconds)
            body.error == "slow_down" -> DeviceTokenPoll.Pending(intervalSeconds + 5)
            else -> DeviceTokenPoll.Failed(body.errorDescription ?: body.error ?: "GitHub authorization failed.")
        }
    }

    suspend fun refreshDeviceAuthorization(clientId: String, refreshToken: String): DeviceTokenPoll.Authorized {
        require(clientId.isNotBlank()) { "GitHub OAuth/GitHub App Client ID is required to refresh authorization." }
        require(refreshToken.isNotBlank()) { "GitHub refresh token is required." }
        val response = client.post("https://github.com/login/oauth/access_token") {
            header(HttpHeaders.Accept, "application/json")
            setBody(FormDataContent(Parameters.build {
                append("client_id", clientId.trim())
                append("grant_type", "refresh_token")
                append("refresh_token", normalizeToken(refreshToken))
            }))
        }
        ensureSuccess(response)
        val body = response.body<DeviceTokenResponse>()
        require(!body.accessToken.isNullOrBlank()) {
            body.errorDescription ?: body.error ?: "GitHub did not return a refreshed access token."
        }
        return DeviceTokenPoll.Authorized(
            token = normalizeToken(body.accessToken.orEmpty()),
            refreshToken = normalizeToken(body.refreshToken.orEmpty()),
            expiresInSeconds = body.expiresIn,
            refreshTokenExpiresInSeconds = body.refreshTokenExpiresIn,
            tokenType = body.tokenType.orEmpty().ifBlank { "bearer" },
        )
    }

    fun normalizeToken(raw: String): String {
        var value = raw.trim()
        if (value.startsWith("Bearer ", ignoreCase = true)) value = value.substring(7).trim()
        if (value.startsWith("token ", ignoreCase = true)) value = value.substring(6).trim()
        return value.filterNot { it.isWhitespace() }
    }

    fun credentialKind(raw: String): String = when {
        normalizeToken(raw).startsWith("github_pat_") -> "fine-grained PAT"
        normalizeToken(raw).startsWith("ghp_") -> "classic PAT"
        normalizeToken(raw).startsWith("gho_") -> "OAuth App token"
        normalizeToken(raw).startsWith("ghu_") -> "GitHub App user token"
        normalizeToken(raw).startsWith("ghr_") -> "GitHub App refresh token"
        else -> "unknown token type"
    }

    fun isBadCredentials(error: Throwable): Boolean =
        generateSequence(error as Throwable?) { it.cause }
            .filterIsInstance<GitHubRequestException>()
            .any { it.statusCode == 401 }

    suspend fun validateForgeCredential(
        owner: String,
        repository: String,
        branch: String,
        token: String,
    ): ConnectedAccount {
        val normalized = normalizeToken(token)
        val account = connectedAccount(normalized)
        getJson<RefResponse>(
            "${repoBase(owner, repository)}/git/ref/heads/${branch.trim()}",
            auth(normalized),
        )
        return account
    }

    /**
     * Truthful Forge preflight. The tiny Git blob is intentionally unreferenced: it proves
     * Contents:write without mutating a branch, tree, or working file. GitHub may garbage-collect
     * the orphan object later. Provider/workflow capability is observed separately.
     */
    suspend fun probeForgeCapabilities(
        owner: String,
        repository: String,
        branch: String,
        token: String,
    ): ForgeCapabilityProbe {
        val normalized = normalizeToken(token)
        connectedAccount(normalized)
        getJson<RefResponse>(
            "${repoBase(owner, repository)}/git/ref/heads/${branch.trim()}",
            auth(normalized),
        )
        val probe = postJson<BlobRequest, BlobResponse>(
            "${repoBase(owner, repository)}/git/blobs",
            auth(normalized),
            BlobRequest(
                content = "SWRLZ Forge capability probe v1",
                encoding = "utf-8",
            ),
        )
        val actionsReadable = runCatching {
            listRepositoryWorkflows(owner, repository, normalized)
            true
        }.getOrDefault(false)
        return ForgeCapabilityProbe(
            authenticated = true,
            repositoryReadable = true,
            contentsWritable = true,
            actionsReadable = actionsReadable,
            writeProbeSha = probe.sha,
        )
    }

    suspend fun connectedAccount(token: String): ConnectedAccount {
        val normalized = normalizeToken(token)
        require(normalized.isNotBlank()) { "GitHub token is required." }
        val profile = getJson<UserProfileResponse>("https://api.github.com/user", auth(normalized))
        return ConnectedAccount(profile.login, profile.avatarUrl.orEmpty())
    }

    suspend fun upload(context: Context, request: UploadRequest): UploadResult {
        require(request.files.isNotEmpty()) { "Select at least one file." }
        require(request.owner.isNotBlank() && request.repository.isNotBlank()) { "Repository owner and name are required." }
        require(request.branch.isNotBlank()) { "Branch is required." }
        require(request.token.isNotBlank()) { "GitHub token is required." }

        val oversizedFile = request.files.firstOrNull { it.sizeBytes > GITHUB_BLOB_LIMIT_BYTES }
        require(oversizedFile == null) {
            "${oversizedFile?.displayName} exceeds GitHub's 100 MiB regular Git object limit. Route that file through Git LFS or a GitHub Release instead."
        }

        val transactionId = request.transactionId.ifBlank { UUID.randomUUID().toString() }
        val logSessionId = request.logSessionId
        fun log(phase: String, message: String, fields: Map<String, Any?> = emptyMap()) {
            ForgeUploadLogStore.append(context, logSessionId, phase, message, fields)
        }

        val expandableArchives = if (request.expandGenericZipToRepositoryRoot) {
            request.files.filter { file ->
                file.displayName.endsWith(".zip", ignoreCase = true) && !isProtectedSourceZip(file.displayName)
            }
        } else {
            emptyList()
        }
        val expandableKeys = expandableArchives.map { logicalSourceKey(it.displayName) }.toSet()
        val archivePlans = expandableArchives.map { archive ->
            prepareArchiveExpansion(context, archive, request.archiveExpansionRoot)
        }
        fun cleanupArchiveCaches() {
            archivePlans.forEach { runCatching { it.cacheFile.delete() } }
        }

        val regularTargets = request.files.mapNotNull { file ->
            val archiveExpansion = logicalSourceKey(file.displayName) in expandableKeys
            when {
                archiveExpansion && request.removeExpandedZipAfterUnpack -> null
                archiveExpansion -> FileTarget(file, sanitizeFileName(canonicalSourceFileName(file.displayName)))
                else -> FileTarget(
                    file,
                    destinationPath(
                        file.displayName,
                        request.destinationDirectory,
                        request.autoRouteSourcePackages,
                        request.clientSourceDirectory,
                        request.serverSourceDirectory,
                    ),
                )
            }
        }

        val destinationOwners = linkedMapOf<String, String>()
        fun reserveDestination(path: String, source: String) {
            val key = path.lowercase()
            val previous = destinationOwners.putIfAbsent(key, source)
            require(previous == null) {
                "Repository path collision at $path between $previous and $source. Rename one staged source or change the destination before retrying."
            }
        }
        try {
            regularTargets.forEach { reserveDestination(it.path, it.file.displayName) }
            archivePlans.forEach { plan ->
                plan.entries.forEach { entry -> reserveDestination(entry.path, "${plan.archive.displayName}:${entry.sourceName}") }
            }
            require(destinationOwners.isNotEmpty()) { "No repository files remain after applying the archive-expansion policy." }
        } catch (failure: Throwable) {
            cleanupArchiveCaches()
            throw failure
        }

        log(
            "UPLOAD_REQUEST",
            "Prepared repository transaction",
            mapOf(
                "transaction_id" to transactionId,
                "owner" to request.owner.trim(),
                "repository" to request.repository.trim(),
                "branch" to request.branch.trim(),
                "staged_file_count" to request.files.size,
                "direct_blob_count" to regularTargets.size,
                "expanded_archive_count" to archivePlans.size,
                "expanded_entry_count" to archivePlans.sumOf { it.entries.size },
                "remove_expanded_zip" to request.removeExpandedZipAfterUnpack,
                "dispatch_requested" to request.dispatchWorkflow,
                "workflow_id" to request.workflowId.trim(),
                "forge_actor" to request.forgeActor.trim().ifBlank { "CLIENT" },
            ),
        )
        regularTargets.forEach { target ->
            log(
                "STAGED_FILE",
                "Direct upload snapshot",
                mapOf(
                    "name" to target.file.displayName,
                    "size_bytes" to target.file.sizeBytes,
                    "destination" to target.path,
                    "provider" to target.file.uri.authority.orEmpty(),
                ),
            )
        }
        archivePlans.forEach { plan ->
            log(
                "ARCHIVE_PLAN",
                "ZIP expansion preflight accepted",
                mapOf(
                    "archive" to plan.archive.displayName,
                    "entry_count" to plan.entries.size,
                    "expanded_bytes" to plan.totalBytes,
                    "root" to request.archiveExpansionRoot.trim().trim('/'),
                    "retain_zip" to !request.removeExpandedZipAfterUnpack,
                ),
            )
        }

        request.onProgress(2, "Checking repository and token access · TX ${transactionId.take(8)}…")
        log("ACCESS_CHECK", "Checking repository branch and credential access")
        val repoBase = repoBase(request.owner, request.repository)
        val authorization = auth(request.token)
        try {
            getJson<RefResponse>("$repoBase/git/ref/heads/${request.branch.trim()}", authorization)
        } catch (failure: Throwable) {
            cleanupArchiveCaches()
            throw failure
        }
        log("ACCESS_CHECK", "Repository access confirmed")
        request.onProgress(5, "Repository access confirmed. Preparing transaction ${transactionId.take(8)}…")

        val entries = mutableListOf<TreeEntry>()
        val expectedBlobByPath = linkedMapOf<String, String>()
        val uploadedPaths = mutableListOf<String>()
        val totalBlobUnits = (regularTargets.size + archivePlans.sumOf { it.entries.size }).coerceAtLeast(1)
        var blobUnitIndex = 0

        suspend fun uploadBlob(
            displayName: String,
            sizeBytes: Long,
            destination: String,
            openInput: () -> InputStream,
        ) {
            val unitStart = 8 + (blobUnitIndex * 62 / totalBlobUnits)
            val uploadSpan = (62 / totalBlobUnits).coerceAtLeast(2)
            blobUnitIndex += 1
            require(sizeBytes <= GITHUB_BLOB_LIMIT_BYTES || sizeBytes < 0L) {
                "$displayName exceeds GitHub's 100 MiB single-blob limit."
            }
            request.onProgress(unitStart.coerceAtMost(75), "Streaming $displayName to GitHub · TX ${transactionId.take(8)}…")
            log(
                "BLOB_UPLOAD",
                "Starting streamed blob upload",
                mapOf("name" to displayName, "size_bytes" to sizeBytes, "destination" to destination, "index" to blobUnitIndex, "total" to totalBlobUnits),
            )
            var lastLoggedTransferPercent = -10
            val blob = postBlobInputStream(
                url = "$repoBase/git/blobs",
                authorization = authorization,
                displayName = displayName,
                sizeBytes = sizeBytes,
                openInput = openInput,
            ) { sent, total ->
                val ratio = if (total > 0L) sent.toDouble() / total.toDouble() else 0.0
                val local = (ratio * (uploadSpan - 1).coerceAtLeast(1)).toInt()
                val percent = (unitStart + local).coerceAtMost(76)
                val sentMiB = sent / 1024.0 / 1024.0
                val totalMiB = if (total > 0L) total / 1024.0 / 1024.0 else 0.0
                val detail = if (total > 0L) {
                    "Streaming $displayName: %.1f / %.1f MiB · TX %s".format(sentMiB, totalMiB, transactionId.take(8))
                } else {
                    "Streaming $displayName: %.1f MiB · TX %s".format(sentMiB, transactionId.take(8))
                }
                request.onProgress(percent, detail)
                val transferPercent = if (total > 0L) ((sent * 100L) / total).toInt().coerceIn(0, 100) else -1
                if (transferPercent == 100 || transferPercent >= lastLoggedTransferPercent + 10) {
                    lastLoggedTransferPercent = transferPercent
                    log(
                        "TRANSFER_PROGRESS",
                        "Streamed repository bytes",
                        mapOf("name" to displayName, "destination" to destination, "bytes_sent" to sent, "total_bytes" to total, "percent" to transferPercent),
                    )
                }
            }
            entries += TreeEntry(destination, "100644", "blob", blob.sha)
            expectedBlobByPath[destination] = blob.sha
            uploadedPaths += destination
            log("BLOB_UPLOAD", "GitHub blob created", mapOf("name" to displayName, "destination" to destination, "blob_sha" to blob.sha))
        }

        try {
            regularTargets.forEach { target ->
                uploadBlob(target.file.displayName, target.file.sizeBytes, target.path) {
                    openLocalInputStream(context, target.file)
                }
            }

            archivePlans.forEach { plan ->
                ZipFile(plan.cacheFile).use { zip ->
                    plan.entries.forEach { planned ->
                        val zipEntry = zip.getEntry(planned.sourceName)
                            ?: error("Archive changed during Forge expansion: ${planned.sourceName} is missing from ${plan.archive.displayName}.")
                        uploadBlob(
                            displayName = "${plan.archive.displayName} → ${planned.path}",
                            sizeBytes = planned.sizeBytes,
                            destination = planned.path,
                        ) {
                            zip.getInputStream(zipEntry)
                        }
                    }
                }
            }
        } finally {
            cleanupArchiveCaches()
        }

        var committedSha: String? = null
        var repositoryChanged = true
        var lastFailure: Throwable? = null
        for (attempt in 1..3) {
            request.onProgress(78, "Resolving latest branch head · attempt $attempt/3…")
            log("BRANCH_HEAD", "Resolving latest branch head", mapOf("attempt" to attempt))
            val latestRef = getJson<RefResponse>("$repoBase/git/ref/heads/${request.branch.trim()}", authorization)
            val parentSha = latestRef.`object`.sha
            val parentCommit = getJson<CommitResponse>("$repoBase/git/commits/$parentSha", authorization)
            log("BRANCH_HEAD", "Latest branch head resolved", mapOf("parent_commit" to parentSha, "base_tree" to parentCommit.tree.sha))

            request.onProgress(82, "Creating repository tree from latest head…")
            val tree = postJson<TreeRequest, TreeResponse>(
                "$repoBase/git/trees",
                authorization,
                TreeRequest(parentCommit.tree.sha, entries),
            )
            if (tree.sha == parentCommit.tree.sha) {
                repositoryChanged = false
                request.onProgress(94, "Repository already current. Verifying staged paths…")
                log("TRANSACTION_NOOP", "Repository already contains every staged blob; no commit required", mapOf("parent_commit" to parentSha, "path_count" to expectedBlobByPath.size))
                verifyUploadedPaths(
                    repoBase = repoBase,
                    authorization = authorization,
                    branch = request.branch.trim(),
                    expectedBlobByPath = expectedBlobByPath,
                )
                log("PATH_VERIFY", "Every staged path already resolved to its expected blob SHA")
                committedSha = parentSha
                break
            }
            log("TREE_CREATE", "Candidate repository tree created", mapOf("tree_sha" to tree.sha, "entry_count" to entries.size))

            request.onProgress(87, "Creating atomic commit · TX ${transactionId.take(8)}…")
            val baseMessage = request.commitMessage.ifBlank {
                if (archivePlans.isNotEmpty()) "Expand repository bootstrap through SWRLZ Forge" else "Upload files through SWRLZ Forge"
            }.trim()
            val commit = postJson<NewCommitRequest, NewCommitResponse>(
                "$repoBase/git/commits",
                authorization,
                NewCommitRequest(
                    "$baseMessage\n\nSWRLZ-Forge-Transaction: $transactionId\nSWRLZ-Forge-Actor: ${request.forgeActor.trim().ifBlank { "CLIENT" }}",
                    tree.sha,
                    listOf(parentSha),
                ),
            )
            log("COMMIT_CREATE", "Atomic commit object created", mapOf("commit_sha" to commit.sha, "parent_commit" to parentSha))

            try {
                request.onProgress(92, "Updating ${request.branch.trim()} · attempt $attempt/3…")
                log("BRANCH_UPDATE", "Updating target branch reference", mapOf("commit_sha" to commit.sha, "attempt" to attempt))
                patchJson(
                    "$repoBase/git/refs/heads/${request.branch.trim()}",
                    authorization,
                    UpdateRefRequest(commit.sha, false),
                )
            } catch (failure: GitHubRequestException) {
                lastFailure = failure
                if (failure.statusCode in setOf(409, 422) && attempt < 3) {
                    log("BRANCH_RACE", "Branch moved; retrying from a fresh head", mapOf("status" to failure.statusCode, "attempt" to attempt))
                    request.onProgress(92, "Branch moved during upload; rebasing transaction on the newest head…")
                    delay(850L * attempt)
                    continue
                }
                throw failure
            }

            request.onProgress(95, "Confirming branch and uploaded paths…")
            var confirmed = false
            for (confirmationAttempt in 0 until 6) {
                val updatedRef = getJson<RefResponse>("$repoBase/git/ref/heads/${request.branch.trim()}", authorization)
                if (updatedRef.`object`.sha == commit.sha) {
                    confirmed = true
                    break
                }
                if (confirmationAttempt < 5) delay(750L)
            }
            check(confirmed) {
                "GitHub accepted the upload request, but ${request.branch.trim()} did not resolve to commit ${commit.sha.take(12)}. Forge will not report completion."
            }
            log("BRANCH_CONFIRM", "Target branch resolves to new commit", mapOf("commit_sha" to commit.sha))

            log("PATH_VERIFY", "Reading uploaded paths back from GitHub", mapOf("path_count" to expectedBlobByPath.size))
            verifyUploadedPaths(
                repoBase = repoBase,
                authorization = authorization,
                branch = request.branch.trim(),
                expectedBlobByPath = expectedBlobByPath,
            )
            log("PATH_VERIFY", "Every uploaded path resolved to its expected blob SHA")
            committedSha = commit.sha
            break
        }

        val finalCommitSha = committedSha ?: throw (
            lastFailure ?: IllegalStateException("Forge could not commit transaction ${transactionId.take(8)}.")
        )

        var workflowDispatched = false
        var dispatchWarning: String? = null
        if (request.dispatchWorkflow && request.workflowId.isNotBlank()) {
            request.onProgress(98, "Dispatching GitHub Actions workflow…")
            log("WORKFLOW_DISPATCH", "Requesting workflow_dispatch", mapOf("workflow_id" to request.workflowId.trim()))
            runCatching {
                val response = client.post("$repoBase/actions/workflows/${request.workflowId.trim()}/dispatches") {
                    githubHeaders(authorization)
                    setBody(WorkflowDispatchRequest(request.branch.trim()))
                }
                ensureSuccess(response)
            }.onSuccess {
                workflowDispatched = true
                log("WORKFLOW_DISPATCH", "GitHub accepted workflow dispatch")
            }.onFailure { failure ->
                dispatchWarning = failure.message ?: "GitHub workflow dispatch failed."
                ForgeUploadLogStore.appendFailure(context, logSessionId, "WORKFLOW_DISPATCH", failure)
            }
        }
        val completion = if (dispatchWarning == null) {
            when {
                !repositoryChanged -> "Repository already current; staged paths verified with no commit required · TX ${transactionId.take(8)}."
                archivePlans.isNotEmpty() -> "Forge ZIP expansion and repository verification complete · TX ${transactionId.take(8)}."
                else -> "Forge upload and repository verification complete · TX ${transactionId.take(8)}."
            }
        } else {
            "Repository update verified · workflow dispatch failed · TX ${transactionId.take(8)}."
        }
        request.onProgress(100, completion)
        log(
            "UPLOAD_COMPLETE",
            completion,
            mapOf(
                "commit_sha" to finalCommitSha,
                "uploaded_path_count" to uploadedPaths.size,
                "expanded_archive_count" to archivePlans.size,
                "expanded_entry_count" to archivePlans.sumOf { it.entries.size },
                "workflow_dispatched" to workflowDispatched,
                "dispatch_warning" to dispatchWarning.orEmpty(),
            ),
        )
        return UploadResult(
            commitSha = finalCommitSha,
            uploadedPaths = uploadedPaths,
            transactionId = transactionId,
            workflowDispatched = workflowDispatched,
            dispatchWarning = dispatchWarning,
            repositoryChanged = repositoryChanged,
        )
    }



    private val downloadedCopySuffix = Regex("\\s*\\(\\d+\\)$")

    /**
     * Android download managers append copy counters such as ` (1)` before the extension.
     * Forge treats those as transport-local names and restores the canonical package basename
     * for routing, checksum pairing, and repository destinations. Source validity still comes
     * from ZIP contents, never from the filename.
     */
    fun canonicalSourceFileName(fileName: String): String {
        val normalized = fileName.trim()
        val (rawSuffix, canonicalSuffix) = when {
            normalized.endsWith(".manifest.json", ignoreCase = true) -> ".manifest.json" to ".manifest.json"
            normalized.endsWith(".sha256.txt", ignoreCase = true) -> ".sha256.txt" to ".sha256"
            normalized.endsWith(".sha256", ignoreCase = true) -> ".sha256" to ".sha256"
            normalized.endsWith(".sha", ignoreCase = true) -> ".sha" to ".sha256"
            normalized.endsWith(".zip", ignoreCase = true) -> ".zip" to ".zip"
            else -> return normalized
        }
        val stem = normalized.dropLast(rawSuffix.length).replace(downloadedCopySuffix, "").trimEnd()
        return stem + canonicalSuffix
    }

    fun checksumNameForZip(fileName: String): String {
        val canonicalZip = canonicalSourceFileName(fileName)
        require(canonicalZip.endsWith(".zip", ignoreCase = true)) { "A source ZIP is required." }
        return canonicalZip.dropLast(4) + ".sha256"
    }

    fun manifestNameForZip(fileName: String): String {
        val canonicalZip = canonicalSourceFileName(fileName)
        require(canonicalZip.endsWith(".zip", ignoreCase = true)) { "A source ZIP is required." }
        return canonicalZip.dropLast(4) + ".manifest.json"
    }

    fun logicalSourceKey(fileName: String): String = canonicalSourceFileName(fileName).lowercase()

    private fun checksumCandidateNames(fileName: String): List<String> {
        val canonicalZip = canonicalSourceFileName(fileName)
        val canonicalStem = canonicalZip.dropLast(4)
        val localStem = fileName.dropLast(4)
        return listOf(
            "$localStem.sha256", "$localStem.sha256.txt", "$localStem.sha",
            "$canonicalStem.sha256", "$canonicalStem.sha256.txt", "$canonicalStem.sha",
        ).distinctBy { it.lowercase() }
    }

    private fun manifestCandidateNames(fileName: String): List<String> {
        val local = fileName.dropLast(4) + ".manifest.json"
        return listOf(local, manifestNameForZip(fileName)).distinctBy { it.lowercase() }
    }

    /**
     * Best-effort automatic lookup of the exact checksum sibling beside the selected ZIP.
     *
     * A single ACTION_OPEN_DOCUMENT grant does not universally include sibling access, so this
     * resolver uses several provider-safe strategies before the UI offers a manual fallback:
     *
     * 1. ordinary file URI parent lookup;
     * 2. direct document-ID substitution for path-based providers;
     * 3. parent-directory child enumeration when the provider exposes a usable parent ID;
     * 4. MediaStore Files lookup by source name, size, and relative directory on Android 10+.
     */
    fun findMatchingChecksumBesideDocument(context: Context, zip: LocalFile): LocalFile? =
        findMatchingSiblingBesideDocument(context, zip, checksumCandidateNames(zip.displayName))

    fun findMatchingManifestBesideDocument(context: Context, zip: LocalFile): LocalFile? =
        findMatchingSiblingBesideDocument(context, zip, manifestCandidateNames(zip.displayName))

    private fun findMatchingSiblingBesideDocument(context: Context, zip: LocalFile, candidateNames: List<String>): LocalFile? {
        if (!zip.displayName.endsWith(".zip", ignoreCase = true)) return null

        candidateNames.forEach { expectedName ->
            if (zip.uri.scheme == "file") {
                val source = zip.uri.path?.let(::File)
                val sibling = source?.parentFile?.let { File(it, expectedName) }
                if (sibling?.isFile == true) {
                    return LocalFile(Uri.fromFile(sibling), expectedName, sibling.length())
                }
            }

            if (DocumentsContract.isDocumentUri(context, zip.uri)) {
                val authority = zip.uri.authority
                val documentId = runCatching { DocumentsContract.getDocumentId(zip.uri) }.getOrNull()
                if (!authority.isNullOrBlank() && !documentId.isNullOrBlank()) {
                    if (documentId.endsWith(zip.displayName, ignoreCase = true)) {
                        val siblingId = documentId.dropLast(zip.displayName.length) + expectedName
                        val siblingUri = runCatching {
                            if (DocumentsContract.isTreeUri(zip.uri)) {
                                DocumentsContract.buildDocumentUriUsingTree(zip.uri, siblingId)
                            } else {
                                DocumentsContract.buildDocumentUri(authority, siblingId)
                            }
                        }.getOrNull()
                        siblingUri?.let { readableLocalFile(context, it, expectedName) }?.let { return it }
                    }

                    val parentIds = linkedSetOf<String>()
                    val slash = documentId.lastIndexOf('/')
                    if (slash > 0) parentIds += documentId.substring(0, slash)
                    if (documentId.endsWith(zip.displayName, ignoreCase = true)) {
                        documentId.dropLast(zip.displayName.length)
                            .trimEnd('/')
                            .takeIf { it.isNotBlank() }
                            ?.let(parentIds::add)
                    }
                    parentIds.forEach { parentId ->
                        findDocumentChildByName(context, zip.uri, authority, parentId, expectedName)?.let { return it }
                    }
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                findMediaStoreSibling(context, zip, expectedName)?.let { return it }
            }
        }
        return null
    }

    /**
     * Generates the canonical checksum receipt when Android grants the ZIP document but withholds
     * permission to its sibling. The repository workflow independently recomputes the digest, so
     * this removes a storage-provider UX dead end without weakening package integrity.
     */
    fun generateChecksumReceipt(context: Context, zip: LocalFile): LocalFile? {
        if (!zip.displayName.endsWith(".zip", ignoreCase = true)) return null
        val expectedName = checksumNameForZip(zip.displayName)
        val canonicalZipName = canonicalSourceFileName(zip.displayName)
        return runCatching {
            val digest = MessageDigest.getInstance("SHA-256")
            context.contentResolver.openInputStream(zip.uri)?.use { input ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    if (count > 0) digest.update(buffer, 0, count)
                }
            } ?: return@runCatching null
            val hash = digest.digest().joinToString("") { "%02x".format(it) }
            val directory = File(context.cacheDir, "forge-generated-checksums").apply { mkdirs() }
            val receipt = File(directory, expectedName)
            receipt.writeText("$hash  $canonicalZipName\n", Charsets.UTF_8)
            LocalFile(Uri.fromFile(receipt), expectedName, receipt.length())
        }.getOrNull()
    }

    private fun readableLocalFile(context: Context, uri: Uri, expectedName: String): LocalFile? =
        runCatching {
            val described = describe(context, uri)
            if (!described.displayName.equals(expectedName, ignoreCase = true)) {
                return@runCatching null
            }
            context.contentResolver.openInputStream(uri)?.use { input ->
                if (input.read() < 0 && described.sizeBytes > 0L) return@runCatching null
            } ?: return@runCatching null
            described
        }.getOrNull()

    private fun findDocumentChildByName(
        context: Context,
        sourceUri: Uri,
        authority: String,
        parentDocumentId: String,
        expectedName: String,
    ): LocalFile? = runCatching {
        val resolver = context.contentResolver
        val tree = DocumentsContract.isTreeUri(sourceUri)
        val childrenUri = if (tree) {
            DocumentsContract.buildChildDocumentsUriUsingTree(sourceUri, parentDocumentId)
        } else {
            DocumentsContract.buildChildDocumentsUri(authority, parentDocumentId)
        }
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_SIZE,
        )
        resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
            while (cursor.moveToNext()) {
                val name = if (nameIndex >= 0) cursor.getString(nameIndex) else null
                if (!name.equals(expectedName, ignoreCase = true) || idIndex < 0) continue
                val childId = cursor.getString(idIndex)
                val childUri = if (tree) {
                    DocumentsContract.buildDocumentUriUsingTree(sourceUri, childId)
                } else {
                    DocumentsContract.buildDocumentUri(authority, childId)
                }
                val size = if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) cursor.getLong(sizeIndex) else -1L
                resolver.openInputStream(childUri)?.use { it.read() } ?: continue
                return@runCatching LocalFile(childUri, expectedName, size)
            }
        }
        null
    }.getOrNull()

    /**
     * Scoped-storage fallback for Downloads and other shared non-media files.
     *
     * Access is still provider-controlled. The candidate is returned only when it can actually be
     * opened, and the source relative directory is matched whenever MediaStore exposes it.
     */
    private fun findMediaStoreSibling(
        context: Context,
        zip: LocalFile,
        expectedName: String,
    ): LocalFile? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val resolver = context.contentResolver
        val knownRelativePath = runCatching {
            resolver.query(
                zip.uri,
                arrayOf(MediaStore.MediaColumns.RELATIVE_PATH),
                null,
                null,
                null,
            )?.use { cursor ->
                val index = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                if (index >= 0 && cursor.moveToFirst() && !cursor.isNull(index)) {
                    cursor.getString(index)
                } else {
                    null
                }
            }
        }.getOrNull()

        val volumes = runCatching { MediaStore.getExternalVolumeNames(context) }
            .getOrDefault(setOf(MediaStore.VOLUME_EXTERNAL_PRIMARY))

        volumes.forEach { volume ->
            val collection = MediaStore.Files.getContentUri(volume)
            val sourcePaths = linkedSetOf<String>()
            knownRelativePath?.takeIf { it.isNotBlank() }?.let(sourcePaths::add)

            if (sourcePaths.isEmpty()) {
                val selection = buildString {
                    append("${MediaStore.MediaColumns.DISPLAY_NAME}=?")
                    if (zip.sizeBytes >= 0L) append(" AND ${MediaStore.MediaColumns.SIZE}=?")
                }
                val args = if (zip.sizeBytes >= 0L) {
                    arrayOf(zip.displayName, zip.sizeBytes.toString())
                } else {
                    arrayOf(zip.displayName)
                }
                runCatching {
                    resolver.query(
                        collection,
                        arrayOf(MediaStore.MediaColumns.RELATIVE_PATH),
                        selection,
                        args,
                        null,
                    )?.use { cursor ->
                        val pathIndex = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                        while (cursor.moveToNext()) {
                            if (pathIndex >= 0 && !cursor.isNull(pathIndex)) {
                                cursor.getString(pathIndex)?.takeIf { it.isNotBlank() }?.let(sourcePaths::add)
                            }
                        }
                    }
                }
            }

            sourcePaths.forEach { relativePath ->
                val selection =
                    "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
                runCatching {
                    resolver.query(
                        collection,
                        arrayOf(BaseColumns._ID, MediaStore.MediaColumns.SIZE),
                        selection,
                        arrayOf(expectedName, relativePath),
                        null,
                    )?.use { cursor ->
                        val idIndex = cursor.getColumnIndex(BaseColumns._ID)
                        val sizeIndex = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE)
                        while (cursor.moveToNext()) {
                            if (idIndex < 0) continue
                            val candidateUri = ContentUris.withAppendedId(collection, cursor.getLong(idIndex))
                            val size =
                                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) cursor.getLong(sizeIndex) else -1L
                            resolver.openInputStream(candidateUri)?.use { it.read() } ?: continue
                            return LocalFile(candidateUri, expectedName, size)
                        }
                    }
                }
            }
        }
        return null
    }

    /**
     * Performs a bounded, streaming ZIP structure check before any network request.
     * This is intentionally heuristic: it blocks obvious APK/artifact bundles and accepts
     * Android/Gradle or documented SWRLZ source trees without extracting the archive.
     */
    fun inspectSourceZip(context: Context, file: LocalFile): StageValidation {
        if (!file.displayName.endsWith(".zip", ignoreCase = true)) {
            return StageValidation(true, "${file.displayName} is not a ZIP; source-content inspection skipped.")
        }
        val sourceMarkers = setOf(
            "settings.gradle", "settings.gradle.kts", "build.gradle", "build.gradle.kts",
            "gradlew", "gradlew.bat", "androidmanifest.xml", "package.json", "pyproject.toml",
            "requirements.txt", "cargo.toml", "go.mod", "pom.xml", "readme.md", "changelog.md",
        )
        var entriesSeen = 0
        var sourceSignals = 0
        var apkEntries = 0
        var dexEntries = 0
        var manifestEntries = 0
        var codeEntries = 0
        val suspiciousArtifactRoots = mutableSetOf<String>()
        return runCatching {
            context.contentResolver.openInputStream(file.uri)?.use { raw ->
                ZipInputStream(raw.buffered()).use { zip ->
                    while (entriesSeen < 2500) {
                        val entry = zip.nextEntry ?: break
                        if (entry.isDirectory) continue
                        entriesSeen++
                        val normalized = entry.name.replace('\\', '/').trimStart('/')
                        val lower = normalized.lowercase()
                        val base = lower.substringAfterLast('/')
                        val root = lower.substringBefore('/')
                        when {
                            lower.endsWith(".apk") -> { apkEntries++; suspiciousArtifactRoots += root }
                            lower.endsWith("classes.dex") || lower.matches(Regex(".*classes\\d*\\.dex$")) -> dexEntries++
                        }
                        if (base == "androidmanifest.xml") manifestEntries++
                        if (base in sourceMarkers || lower.endsWith("/src/main/androidmanifest.xml")) sourceSignals++
                        if (lower.endsWith(".kt") || lower.endsWith(".java") || lower.endsWith(".xml") ||
                            lower.endsWith(".py") || lower.endsWith(".js") || lower.endsWith(".ts")) {
                            codeEntries++
                        }
                    }
                }
            } ?: return StageValidation(false, "Unable to inspect ${file.displayName}.")

            if (entriesSeen == 0) return StageValidation(false, "${file.displayName} is empty or not a readable ZIP archive.")
            if (apkEntries > 0 || dexEntries > 0) {
                return StageValidation(
                    false,
                    "Blocked before upload: ${file.displayName} looks like a built APK/artifact bundle " +
                        "($apkEntries APK entr${if (apkEntries == 1) "y" else "ies"}, $dexEntries DEX entr${if (dexEntries == 1) "y" else "ies"}). Select the CLIENT or SERVER source ZIP instead.",
                )
            }
            val credibleSource = sourceSignals >= 2 || (manifestEntries > 0 && codeEntries >= 3) || codeEntries >= 12
            if (!credibleSource) {
                return StageValidation(
                    false,
                    "Blocked before upload: ${file.displayName} does not contain enough recognizable source structure " +
                        "($sourceSignals project markers, $codeEntries code/resource files). Disable Source ZIP Guard only when intentionally uploading a nonstandard source archive.",
                )
            }
            StageValidation(true, "Source ZIP Guard accepted ${file.displayName}: $sourceSignals project markers and $codeEntries code/resource files found.")
        }.getOrElse { error ->
            StageValidation(false, "Unable to inspect ${file.displayName}: ${error.message ?: error::class.simpleName}")
        }
    }

    fun isProtectedSourceZip(fileName: String): Boolean {
        val canonical = canonicalSourceFileName(fileName).uppercase()
        return canonical.endsWith(".ZIP") && (canonical.startsWith("CLIENT_") || canonical.startsWith("SERVER_"))
    }

    fun isProtectedSourceChecksum(fileName: String): Boolean {
        val canonical = canonicalSourceFileName(fileName).uppercase()
        return canonical.endsWith(".SHA256") && (canonical.startsWith("CLIENT_") || canonical.startsWith("SERVER_"))
    }

    fun isProtectedSourceManifest(fileName: String): Boolean {
        val canonical = canonicalSourceFileName(fileName).uppercase()
        return canonical.endsWith(".MANIFEST.JSON") && (canonical.startsWith("CLIENT_") || canonical.startsWith("SERVER_"))
    }

    suspend fun validateSourcePairs(
        context: Context,
        files: List<LocalFile>,
        requireChecksum: Boolean = true,
        requireManifest: Boolean = true,
    ): StageValidation {
        val byName = files.associateBy { logicalSourceKey(it.displayName) }
        val sourceZips = files.filter { isProtectedSourceZip(it.displayName) }
        if (sourceZips.isEmpty()) {
            return StageValidation(true, "No protected CLIENT/SERVER source ZIPs staged; generic files may upload without package companions.")
        }
        for (zip in sourceZips) {
            val shaName = checksumNameForZip(zip.displayName)
            val manifestName = manifestNameForZip(zip.displayName)
            val sha = byName[shaName.lowercase()]
            val manifest = byName[manifestName.lowercase()]
            if (requireChecksum && sha == null) return StageValidation(false, "Missing checksum file: $shaName")
            if (requireManifest && manifest == null) return StageValidation(false, "Missing manifest file: $manifestName")

            var expectedHash: String? = null
            if (sha != null) {
                val parsedHash = context.contentResolver.openInputStream(sha.uri)?.bufferedReader()?.use { it.readText() }
                    ?.trim()?.split(Regex("\\s+"))?.firstOrNull()?.lowercase()
                    ?: return StageValidation(false, "Unable to read $shaName")
                if (!parsedHash.matches(Regex("[0-9a-f]{64}"))) return StageValidation(false, "$shaName does not contain a valid SHA-256 hash.")
                expectedHash = parsedHash
                val digest = MessageDigest.getInstance("SHA-256")
                context.contentResolver.openInputStream(zip.uri)?.use { input ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (count > 0) digest.update(buffer, 0, count)
                    }
                } ?: return StageValidation(false, "Unable to read ${zip.displayName}")
                val actual = digest.digest().joinToString("") { "%02x".format(it) }
                if (actual != parsedHash) return StageValidation(false, "Checksum mismatch for ${zip.displayName}. Expected $parsedHash, calculated $actual.")
            }

            if (manifest != null) {
                val text = context.contentResolver.openInputStream(manifest.uri)?.bufferedReader()?.use { it.readText() }
                    ?: return StageValidation(false, "Unable to read $manifestName")
                val manifestZip = Regex("\"zip\"\\s*:\\s*\"([^\"]+)\"").find(text)?.groupValues?.getOrNull(1)
                    ?: return StageValidation(false, "$manifestName is missing canonical field: zip")
                val manifestHash = Regex("\"sha256\"\\s*:\\s*\"([0-9a-fA-F]{64})\"").find(text)?.groupValues?.getOrNull(1)?.lowercase()
                    ?: return StageValidation(false, "$manifestName is missing canonical field: sha256")
                val verified = Regex("\"verified\"\\s*:\\s*(true|false)", RegexOption.IGNORE_CASE).find(text)?.groupValues?.getOrNull(1)?.equals("true", true) == true
                if (!verified) return StageValidation(false, "$manifestName does not declare verified: true")
                if (!canonicalSourceFileName(manifestZip).equals(canonicalSourceFileName(zip.displayName), ignoreCase = true)) {
                    return StageValidation(false, "$manifestName names $manifestZip instead of ${canonicalSourceFileName(zip.displayName)}")
                }
                if (expectedHash != null && manifestHash != expectedHash) {
                    return StageValidation(false, "$manifestName SHA-256 disagrees with $shaName")
                }
            }
        }

        if (requireChecksum) {
            val orphanChecksums = files.filter { isProtectedSourceChecksum(it.displayName) }.filter { checksum ->
                val canonicalChecksum = canonicalSourceFileName(checksum.displayName)
                val zipName = canonicalChecksum.dropLast(7) + ".zip"
                byName[zipName.lowercase()] == null
            }
            if (orphanChecksums.isNotEmpty()) return StageValidation(false, "Checksum selected without matching ZIP: ${orphanChecksums.joinToString { it.displayName }}")
        }
        if (requireManifest) {
            val orphanManifests = files.filter { isProtectedSourceManifest(it.displayName) }.filter { manifest ->
                val canonicalManifest = canonicalSourceFileName(manifest.displayName)
                val zipName = canonicalManifest.removeSuffix(".manifest.json") + ".zip"
                byName[zipName.lowercase()] == null
            }
            if (orphanManifests.isNotEmpty()) return StageValidation(false, "Manifest selected without matching ZIP: ${orphanManifests.joinToString { it.displayName }}")
        }
        return StageValidation(true, "Verified ${sourceZips.size} source package unit(s) locally: ZIP${if (requireChecksum) " + SHA-256" else ""}${if (requireManifest) " + manifest" else ""}.")
    }

    suspend fun listRepositoryPath(
        owner: String,
        repository: String,
        branch: String,
        token: String,
        path: String = "",
    ): List<RepositoryItem> {
        require(owner.isNotBlank() && repository.isNotBlank()) { "Repository owner and name are required." }
        val normalizedPath = repositoryPath(path)
        val encodedPath = normalizedPath.split('/').filter { it.isNotBlank() }.joinToString("/") { it.encodeURLPathPart() }
        val suffix = if (encodedPath.isBlank()) "/contents?ref=${branch.trim().encodeURLParameter()}" else "/contents/$encodedPath?ref=${branch.trim().encodeURLParameter()}"
        val response = client.get(repoBase(owner, repository) + suffix) { githubHeaders(auth(token)) }
        ensureSuccess(response)
        val body = response.body<String>()
        val items = runCatching { json.decodeFromString<List<RepositoryContentItemResponse>>(body) }.getOrElse {
            listOf(json.decodeFromString<RepositoryContentItemResponse>(body))
        }
        return items.map { RepositoryItem(it.name, it.path, it.type, it.size, it.sha) }
    }

    suspend fun readRepositoryText(
        owner: String,
        repository: String,
        branch: String,
        token: String,
        path: String,
    ): String {
        val normalizedPath = repositoryPath(path)
        require(normalizedPath.isNotBlank()) { "Repository file path is required." }
        val encodedPath = normalizedPath.split('/').joinToString("/") { it.encodeURLPathPart() }
        val body = getJson<RepositoryContentTextResponse>(
            "${repoBase(owner, repository)}/contents/$encodedPath?ref=${branch.trim().encodeURLParameter()}",
            auth(token),
        )
        require(body.type == "file") { "$normalizedPath is not a file." }
        require(body.encoding.equals("base64", ignoreCase = true)) { "Unsupported GitHub content encoding: ${body.encoding}" }
        return java.util.Base64.getMimeDecoder().decode(body.content).toString(Charsets.UTF_8)
    }

    suspend fun writeRepositoryText(
        owner: String,
        repository: String,
        branch: String,
        token: String,
        path: String,
        text: String,
        commitMessage: String,
    ): RepositoryWriteResult {
        val normalizedPath = repositoryPath(path)
        require(normalizedPath.isNotBlank()) { "Repository file path is required." }
        val authorization = auth(token)
        val encodedPath = normalizedPath.split('/').joinToString("/") { it.encodeURLPathPart() }
        val url = "${repoBase(owner, repository)}/contents/$encodedPath"
        val existingSha = try {
            getJson<RepositoryContentResponse>("$url?ref=${branch.trim().encodeURLParameter()}", authorization).sha
        } catch (failure: GitHubRequestException) {
            if (failure.statusCode == 404) null else throw failure
        }
        val response = putJson<ContentWriteRequest, ContentMutationResponse>(
            url,
            authorization,
            ContentWriteRequest(
                message = commitMessage.trim().ifBlank { "Update $normalizedPath through SWRLZ Forge" },
                content = java.util.Base64.getEncoder().encodeToString(text.toByteArray(Charsets.UTF_8)),
                branch = branch.trim(),
                sha = existingSha,
            ),
        )
        return RepositoryWriteResult(normalizedPath, response.commit.sha, response.content?.sha.orEmpty())
    }

    suspend fun deleteRepositoryFile(
        owner: String,
        repository: String,
        branch: String,
        token: String,
        path: String,
        commitMessage: String,
    ): String {
        val normalizedPath = repositoryPath(path)
        require(normalizedPath.isNotBlank()) { "Repository file path is required." }
        val authorization = auth(token)
        val encodedPath = normalizedPath.split('/').joinToString("/") { it.encodeURLPathPart() }
        val url = "${repoBase(owner, repository)}/contents/$encodedPath"
        val existing = getJson<RepositoryContentResponse>("$url?ref=${branch.trim().encodeURLParameter()}", authorization)
        val response = deleteJson<ContentDeleteRequest, ContentMutationResponse>(
            url,
            authorization,
            ContentDeleteRequest(
                message = commitMessage.trim().ifBlank { "Delete $normalizedPath through SWRLZ Forge" },
                sha = existing.sha,
                branch = branch.trim(),
            ),
        )
        return response.commit.sha
    }

    suspend fun createRepositoryBranch(
        owner: String,
        repository: String,
        token: String,
        newBranch: String,
        baseBranch: String,
    ): String {
        val branchName = repositoryBranch(newBranch)
        val baseName = repositoryBranch(baseBranch)
        val authorization = auth(token)
        val base = getJson<RefResponse>("${repoBase(owner, repository)}/git/ref/heads/$baseName", authorization)
        val created = postJson<CreateRefRequest, CreateRefResponse>(
            "${repoBase(owner, repository)}/git/refs",
            authorization,
            CreateRefRequest("refs/heads/$branchName", base.`object`.sha),
        )
        return created.ref
    }

    suspend fun downloadRepositoryFile(
        owner: String,
        repository: String,
        token: String,
        sha: String,
    ): ByteArray {
        require(sha.isNotBlank()) { "Repository blob SHA is required." }
        val blob = getJson<GitBlobContentResponse>("${repoBase(owner, repository)}/git/blobs/${sha.trim()}", auth(token))
        require(blob.encoding.equals("base64", ignoreCase = true)) { "Unsupported GitHub blob encoding: ${blob.encoding}" }
        return java.util.Base64.getMimeDecoder().decode(blob.content)
    }

    suspend fun listRepositoryBranches(
        owner: String,
        repository: String,
        token: String,
    ): List<RepositoryBranch> {
        require(owner.isNotBlank() && repository.isNotBlank()) { "Repository owner and name are required." }
        return getJson<List<RepositoryBranchResponse>>(
            "${repoBase(owner, repository)}/branches?per_page=100",
            auth(token),
        ).map { RepositoryBranch(it.name) }
    }

    suspend fun listRepositoryWorkflows(
        owner: String,
        repository: String,
        token: String,
    ): List<WorkflowDescriptor> {
        require(owner.isNotBlank() && repository.isNotBlank()) { "Repository owner and name are required." }
        return getJson<RepositoryWorkflowsResponse>(
            "${repoBase(owner, repository)}/actions/workflows?per_page=100",
            auth(token),
        ).workflows.map { WorkflowDescriptor(it.id, it.name, it.path, it.state, it.htmlUrl) }
    }

    /**
     * Parses the flat workflow_dispatch input contract used by GitHub Actions. It intentionally
     * understands only the input metadata needed by Forge (description, required, type, default,
     * options) and ignores the rest of the workflow rather than pretending to be a general YAML parser.
     */
    fun parseWorkflowDispatchInputs(workflowYaml: String): List<WorkflowInput> {
        val lines = workflowYaml.lines()
        fun indent(raw: String): Int = raw.takeWhile { it == ' ' }.length
        fun scalar(raw: String): String {
            val value = raw.trim().substringAfter(':', "").trim()
            return value.removeSurrounding("\"").removeSurrounding("'")
        }

        var dispatchIndent = -1
        var inputsIndent = -1
        var currentName: String? = null
        var currentIndent = -1
        var description = ""
        var required = false
        var type = "string"
        var defaultValue = ""
        val options = mutableListOf<String>()
        val result = mutableListOf<WorkflowInput>()

        fun flush() {
            val name = currentName ?: return
            result += WorkflowInput(name, description, required, type.ifBlank { "string" }, defaultValue, options.toList())
            currentName = null
            description = ""
            required = false
            type = "string"
            defaultValue = ""
            options.clear()
        }

        for (raw in lines) {
            if (raw.isBlank() || raw.trimStart().startsWith('#')) continue
            val trimmed = raw.trim()
            val level = indent(raw)
            if (dispatchIndent < 0) {
                if (trimmed == "workflow_dispatch:" || trimmed.startsWith("workflow_dispatch: ")) {
                    dispatchIndent = level
                }
                continue
            }
            if (level <= dispatchIndent && !trimmed.startsWith("workflow_dispatch:")) break
            if (inputsIndent < 0) {
                if (trimmed == "inputs:" && level > dispatchIndent) inputsIndent = level
                continue
            }
            if (level <= inputsIndent) break

            if (level == inputsIndent + 2 && trimmed.endsWith(':') && !trimmed.startsWith('-')) {
                flush()
                currentName = trimmed.removeSuffix(":").trim()
                currentIndent = level
                continue
            }
            if (currentName == null || level <= currentIndent) continue
            when {
                trimmed.startsWith("description:") -> description = scalar(trimmed)
                trimmed.startsWith("required:") -> required = scalar(trimmed).equals("true", ignoreCase = true)
                trimmed.startsWith("type:") -> type = scalar(trimmed).lowercase()
                trimmed.startsWith("default:") -> defaultValue = scalar(trimmed)
                trimmed.startsWith("- ") -> options += trimmed.removePrefix("- ").trim().removeSurrounding("\"").removeSurrounding("'")
            }
        }
        flush()
        return result
    }

    suspend fun dispatchWorkflow(
        owner: String,
        repository: String,
        workflowId: Long,
        ref: String,
        inputs: Map<String, String>,
        token: String,
    ): WorkflowDispatchResult {
        require(workflowId > 0) { "Workflow ID is required." }
        require(ref.isNotBlank()) { "Workflow branch or tag is required." }
        val response = client.post("${repoBase(owner, repository)}/actions/workflows/$workflowId/dispatches") {
            githubHeaders(auth(token))
            setBody(WorkflowDispatchRequest(ref.trim(), inputs))
        }
        ensureSuccess(response)
        if (response.status.value == 204) return WorkflowDispatchResult()
        val body = runCatching { response.body<String>() }.getOrDefault("").trim()
        if (body.isBlank()) return WorkflowDispatchResult()
        val parsed = runCatching { json.decodeFromString<WorkflowDispatchResponse>(body) }.getOrNull()
        return WorkflowDispatchResult(parsed?.workflowRunId, parsed?.htmlUrl)
    }

    suspend fun moveRepositoryFiles(
        owner: String,
        repository: String,
        branch: String,
        token: String,
        moves: List<RepositoryMove>,
        commitMessage: String,
    ): RepositoryMutationResult {
        require(moves.isNotEmpty()) { "Select at least one repository file to move." }
        val normalized = moves.map { move ->
            val source = repositoryPath(move.sourcePath)
            val destination = repositoryPath(move.destinationPath)
            require(source.isNotBlank() && destination.isNotBlank()) { "Source and destination paths are required." }
            require(source != destination) { "$source is already at the requested destination." }
            Triple(source, destination, move.sha)
        }
        require(normalized.map { it.second.lowercase() }.distinct().size == normalized.size) { "Two selected files resolve to the same destination." }
        val sourcePaths = normalized.map { it.first }.toSet()
        val authorization = auth(token)
        val entries = mutableListOf<TreeMutationEntry>()
        for ((source, destination, suppliedSha) in normalized) {
            require(destination !in sourcePaths) { "Moving onto another selected source path is not supported in one transaction: $destination" }
            val sourceBody = getRepositoryContent(owner, repository, branch, authorization, source)
                ?: error("Source file no longer exists: $source")
            require(sourceBody.type == "file" || sourceBody.type.isBlank()) { "Only files can be moved from this browser: $source" }
            val sha = suppliedSha.ifBlank { sourceBody.sha }
            require(sha == sourceBody.sha) { "Repository changed since selection; refresh before moving $source." }
            require(getRepositoryContent(owner, repository, branch, authorization, destination) == null) {
                "Destination already exists: $destination"
            }
            entries += TreeMutationEntry(destination, "100644", "blob", sha)
            entries += TreeMutationEntry(source, "100644", "blob", null)
        }
        val commitSha = commitRepositoryTreeMutation(owner, repository, branch, authorization, entries, commitMessage.ifBlank { "Move repository files through SWRLZ Forge" })
        return RepositoryMutationResult(commitSha, normalized.flatMap { listOf(it.first, it.second) })
    }

    suspend fun deleteRepositoryFiles(
        owner: String,
        repository: String,
        branch: String,
        token: String,
        paths: List<String>,
        commitMessage: String,
    ): RepositoryMutationResult {
        val normalized = paths.map(::repositoryPath).filter { it.isNotBlank() }.distinct()
        require(normalized.isNotEmpty()) { "Select at least one repository file to delete." }
        val authorization = auth(token)
        normalized.forEach { path ->
            val source = getRepositoryContent(owner, repository, branch, authorization, path)
                ?: error("Repository file no longer exists: $path")
            require(source.type == "file" || source.type.isBlank()) { "Only files can be deleted from this browser: $path" }
        }
        val entries = normalized.map { TreeMutationEntry(it, "100644", "blob", null) }
        val commitSha = commitRepositoryTreeMutation(owner, repository, branch, authorization, entries, commitMessage.ifBlank { "Delete repository files through SWRLZ Forge" })
        return RepositoryMutationResult(commitSha, normalized)
    }

    private suspend fun getRepositoryContent(
        owner: String,
        repository: String,
        branch: String,
        authorization: String,
        path: String,
    ): RepositoryContentResponse? {
        val encodedPath = repositoryPath(path).split('/').joinToString("/") { it.encodeURLPathPart() }
        return try {
            getJson<RepositoryContentResponse>(
                "${repoBase(owner, repository)}/contents/$encodedPath?ref=${branch.trim().encodeURLParameter()}",
                authorization,
            )
        } catch (failure: GitHubRequestException) {
            if (failure.statusCode == 404) null else throw failure
        }
    }

    private suspend fun commitRepositoryTreeMutation(
        owner: String,
        repository: String,
        branch: String,
        authorization: String,
        entries: List<TreeMutationEntry>,
        commitMessage: String,
    ): String {
        var lastFailure: Throwable? = null
        repeat(3) { index ->
            val ref = getJson<RefResponse>("${repoBase(owner, repository)}/git/ref/heads/${repositoryBranch(branch)}", authorization)
            val parentSha = ref.`object`.sha
            val parentCommit = getJson<CommitResponse>("${repoBase(owner, repository)}/git/commits/$parentSha", authorization)
            val tree = postJson<TreeMutationRequest, TreeResponse>(
                "${repoBase(owner, repository)}/git/trees",
                authorization,
                TreeMutationRequest(parentCommit.tree.sha, entries),
            )
            require(tree.sha != parentCommit.tree.sha) { "No repository content changed." }
            val commit = postJson<NewCommitRequest, NewCommitResponse>(
                "${repoBase(owner, repository)}/git/commits",
                authorization,
                NewCommitRequest(commitMessage.trim(), tree.sha, listOf(parentSha)),
            )
            try {
                patchJson("${repoBase(owner, repository)}/git/refs/heads/${repositoryBranch(branch)}", authorization, UpdateRefRequest(commit.sha, false))
                return commit.sha
            } catch (failure: GitHubRequestException) {
                lastFailure = failure
                if (failure.statusCode !in setOf(409, 422) || index == 2) throw failure
            }
        }
        throw lastFailure ?: IllegalStateException("Repository transaction could not update the branch.")
    }

    private fun repositoryPath(path: String): String {
        val normalized = path.replace('\\', '/').trim().trim('/')
        if (normalized.isBlank()) return ""
        val segments = normalized.split('/').filter { it.isNotBlank() && it != "." }
        require(segments.none { it == ".." || it.equals(".git", ignoreCase = true) }) { "Unsafe repository path: $path" }
        return segments.joinToString("/")
    }

    private fun repositoryBranch(branch: String): String {
        val value = branch.trim().removePrefix("refs/heads/")
        require(value.isNotBlank() && !value.contains("..") && !value.startsWith('/') && !value.endsWith('/') && !value.contains(' ')) {
            "Invalid Git branch name: $branch"
        }
        return value
    }

    suspend fun listWorkflowJobs(owner: String, repository: String, runId: Long, token: String): List<WorkflowJob> {
        require(owner.isNotBlank() && repository.isNotBlank()) { "Repository owner and name are required." }
        val url = "https://api.github.com/repos/${owner.trim()}/${repository.trim()}/actions/runs/$runId/jobs?per_page=100"
        return getJson<WorkflowJobsResponse>(url, auth(token)).jobs.map { job ->
            WorkflowJob(
                id = job.id,
                name = job.name,
                status = job.status,
                conclusion = job.conclusion,
                startedAt = job.startedAt,
                completedAt = job.completedAt,
                steps = job.steps.map { step -> WorkflowStep(step.name, step.status, step.conclusion, step.number) },
            )
        }
    }

    suspend fun listWorkflowRuns(owner: String, repository: String, branch: String, token: String): List<WorkflowRun> {
        val url = buildString {
            append(repoBase(owner, repository)); append("/actions/runs?per_page=50")
            if (branch.isNotBlank()) append("&branch=").append(branch.trim())
        }
        return getJson<WorkflowRunsResponse>(url, auth(token)).workflowRuns.map {
            WorkflowRun(it.id, it.name, it.displayTitle, it.status, it.conclusion, it.headBranch.orEmpty(), it.headSha.orEmpty(), it.event, it.createdAt, it.updatedAt, it.runStartedAt, it.htmlUrl)
        }
    }

    suspend fun cancelWorkflowRun(owner: String, repository: String, runId: Long, token: String) {
        val response = client.post("${repoBase(owner, repository)}/actions/runs/$runId/cancel") { githubHeaders(auth(token)) }
        ensureSuccess(response)
    }

    suspend fun rerunWorkflowRun(owner: String, repository: String, runId: Long, token: String) {
        val response = client.post("${repoBase(owner, repository)}/actions/runs/$runId/rerun") { githubHeaders(auth(token)) }
        ensureSuccess(response)
    }

    suspend fun listArtifacts(owner: String, repository: String, runId: Long, token: String): List<Artifact> {
        val body = getJson<ArtifactsResponse>("${repoBase(owner, repository)}/actions/runs/$runId/artifacts?per_page=100", auth(token))
        return body.artifacts.map { Artifact(it.id, it.name, it.sizeInBytes, it.expired, it.createdAt) }
    }

    suspend fun downloadArtifact(owner: String, repository: String, artifactId: Long, token: String): ByteArray {
        val response = client.get("${repoBase(owner, repository)}/actions/artifacts/$artifactId/zip") { githubHeaders(auth(token)) }
        ensureSuccess(response)
        return response.body()
    }

    suspend fun downloadWorkflowLogs(owner: String, repository: String, runId: Long, token: String): ByteArray {
        require(owner.isNotBlank() && repository.isNotBlank()) { "Repository owner and name are required." }
        val response = client.get("${repoBase(owner, repository)}/actions/runs/$runId/logs") {
            githubHeaders(auth(token))
        }
        ensureSuccess(response)
        return response.body()
    }

    fun writeArtifact(context: Context, destination: Uri, bytes: ByteArray) {
        context.contentResolver.openOutputStream(destination, "w")?.use { it.write(bytes) }
            ?: error("Unable to open selected download destination.")
    }

    fun describe(context: Context, uri: Uri): LocalFile {
        var name = uri.lastPathSegment ?: "upload.bin"
        var size = -1L
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        return LocalFile(uri, name, size)
    }

    fun destinationPath(
        fileName: String,
        fallbackDirectory: String,
        autoRoute: Boolean,
        clientSourceDirectory: String = GitHubConnectionStore.DEFAULT_CLIENT_SOURCE_DIRECTORY,
        serverSourceDirectory: String = GitHubConnectionStore.DEFAULT_SERVER_SOURCE_DIRECTORY,
    ): String {
        val safe = sanitizeFileName(canonicalSourceFileName(fileName))
        val upper = safe.uppercase()
        val directory = when {
            autoRoute && upper.startsWith("CLIENT_") -> clientSourceDirectory.trim().trim('/')
            autoRoute && upper.startsWith("SERVER_") -> serverSourceDirectory.trim().trim('/')
            else -> fallbackDirectory.trim().trim('/')
        }
        return if (directory.isBlank()) safe else "$directory/$safe"
    }

    private fun repoBase(owner: String, repository: String) = "https://api.github.com/repos/${owner.trim()}/${repository.trim()}"
    private fun auth(token: String) = "Bearer ${normalizeToken(token)}"
    private fun sanitizeFileName(value: String) = value.replace("/", "_").replace("\\", "_").ifBlank { "upload.bin" }


    private suspend fun verifyUploadedPaths(
        repoBase: String,
        authorization: String,
        branch: String,
        expectedBlobByPath: Map<String, String>,
    ) {
        val mismatches = mutableListOf<String>()
        expectedBlobByPath.forEach { (path, expectedSha) ->
            val encodedPath = path.split('/').joinToString("/") { it.encodeURLPathPart() }
            val encodedBranch = branch.encodeURLParameter()
            val content = getJson<RepositoryContentResponse>(
                "$repoBase/contents/$encodedPath?ref=$encodedBranch",
                authorization,
            )
            if (content.sha != expectedSha) {
                mismatches += "$path expected ${expectedSha.take(12)} but repository resolved ${content.sha.take(12)}"
            }
        }
        check(mismatches.isEmpty()) {
            "Branch confirmation succeeded, but uploaded-path verification failed: ${mismatches.joinToString("; ")}"
        }
    }

    private data class ArchiveEntryPlan(
        val sourceName: String,
        val path: String,
        val sizeBytes: Long,
    )

    private data class ArchiveExpansionPlan(
        val archive: LocalFile,
        val cacheFile: File,
        val entries: List<ArchiveEntryPlan>,
        val totalBytes: Long,
    )

    private fun prepareArchiveExpansion(context: Context, archive: LocalFile, rootDirectory: String): ArchiveExpansionPlan {
        require(archive.displayName.endsWith(".zip", ignoreCase = true)) { "Archive expansion requires a ZIP file." }
        require(!isProtectedSourceZip(archive.displayName)) {
            "Protected CLIENT/SERVER source ZIPs are not expanded. Upload them as source packages so ZIP/SHA lineage remains intact."
        }
        val cacheDirectory = File(context.cacheDir, "forge-archive-expansion").apply { mkdirs() }
        val cacheFile = File(cacheDirectory, "${UUID.randomUUID()}-${sanitizeFileName(archive.displayName)}")
        try {
            openLocalInputStream(context, archive).use { input ->
                cacheFile.outputStream().buffered().use { output -> input.copyTo(output, DEFAULT_BUFFER_SIZE) }
            }
            val planned = mutableListOf<ArchiveEntryPlan>()
            val seen = mutableSetOf<String>()
            var totalBytes = 0L
            ZipFile(cacheFile).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    if (entry.isDirectory) continue
                    require(planned.size < ARCHIVE_EXPANSION_ENTRY_LIMIT) {
                        "${archive.displayName} contains more than $ARCHIVE_EXPANSION_ENTRY_LIMIT files. Split the bootstrap into smaller repository transactions."
                    }
                    val size = entry.size
                    require(size >= 0L) { "Unable to determine expanded size for ${entry.name}. Repack the ZIP with standard central-directory metadata." }
                    require(size <= GITHUB_BLOB_LIMIT_BYTES) {
                        "${entry.name} expands to more than 100 MiB and cannot be stored as a regular GitHub blob."
                    }
                    totalBytes += size
                    require(totalBytes <= ARCHIVE_EXPANSION_LIMIT_BYTES) {
                        "${archive.displayName} expands beyond 512 MiB. Split it before repository expansion."
                    }
                    val path = archiveEntryRepositoryPath(entry.name, rootDirectory)
                    val key = path.lowercase()
                    require(seen.add(key)) { "${archive.displayName} contains duplicate or case-colliding repository path: $path" }
                    planned += ArchiveEntryPlan(entry.name, path, size)
                }
            }
            require(planned.isNotEmpty()) { "${archive.displayName} contains no files to expand." }
            return ArchiveExpansionPlan(archive, cacheFile, planned, totalBytes)
        } catch (failure: Throwable) {
            runCatching { cacheFile.delete() }
            throw failure
        }
    }

    fun archiveEntryRepositoryPath(entryName: String, rootDirectory: String = ""): String {
        val raw = entryName.replace('\\', '/')
        require(raw.isNotBlank()) { "ZIP contains an empty entry path." }
        require(!raw.startsWith('/')) { "ZIP entry uses an absolute path: $entryName" }
        require(!Regex("^[A-Za-z]:/").containsMatchIn(raw)) { "ZIP entry uses an absolute drive path: $entryName" }
        require('\u0000' !in raw) { "ZIP entry contains a NUL byte." }
        val segments = raw.split('/').filter { it.isNotBlank() && it != "." }
        require(segments.isNotEmpty()) { "ZIP entry has no repository path: $entryName" }
        require(segments.none { it == ".." }) { "ZIP entry attempts path traversal: $entryName" }
        require(segments.none { it.equals(".git", ignoreCase = true) }) { "ZIP entry attempts to write Git metadata: $entryName" }
        val relative = segments.joinToString("/")
        val root = rootDirectory.replace('\\', '/').trim().trim('/')
        if (root.isBlank()) return relative
        require(root.split('/').none { it.isBlank() || it == "." || it == ".." || it.equals(".git", ignoreCase = true) }) {
            "Archive expansion root is unsafe: $rootDirectory"
        }
        return "$root/$relative"
    }

    private fun openLocalInputStream(context: Context, file: LocalFile): InputStream {
        if (file.uri.scheme.equals("file", ignoreCase = true)) {
            val path = file.uri.path ?: error("Unable to resolve ${file.displayName} local file path.")
            return FileInputStream(File(path))
        }
        return context.contentResolver.openInputStream(file.uri)
            ?: error("Unable to read ${file.displayName}")
    }

    private suspend fun postBlobStream(
        url: String,
        authorization: String,
        context: Context,
        file: LocalFile,
        onBytesSent: suspend (Long, Long) -> Unit,
    ): BlobResponse = postBlobInputStream(
        url = url,
        authorization = authorization,
        displayName = file.displayName,
        sizeBytes = file.sizeBytes,
        openInput = { openLocalInputStream(context, file) },
        onBytesSent = onBytesSent,
    )

    private suspend fun postBlobInputStream(
        url: String,
        authorization: String,
        displayName: String,
        sizeBytes: Long,
        openInput: () -> InputStream,
        onBytesSent: suspend (Long, Long) -> Unit,
    ): BlobResponse {
        val prefix = "{\"content\":\"".toByteArray(Charsets.UTF_8)
        val suffix = "\",\"encoding\":\"base64\"}".toByteArray(Charsets.UTF_8)
        val rawLength = sizeBytes.takeIf { it >= 0L }
        rawLength?.let { require(it <= GITHUB_BLOB_LIMIT_BYTES) { "$displayName exceeds GitHub's 100 MiB regular Git blob limit." } }
        val encodedLength = rawLength?.let { 4L * ((it + 2L) / 3L) }

        val response = client.post(url) {
            githubHeaders(authorization)
            setBody(object : OutgoingContent.WriteChannelContent() {
                override val contentType: ContentType = ContentType.Application.Json
                override val contentLength: Long? = encodedLength?.let { prefix.size + it + suffix.size }

                override suspend fun writeTo(channel: ByteWriteChannel) {
                    channel.writeFully(prefix)
                    openInput().use { stream ->
                        val inputBuffer = ByteArray(192 * 1024)
                        var carry = ByteArray(0)
                        var sent = 0L
                        var lastReported = 0L
                        while (true) {
                            val read = stream.read(inputBuffer)
                            if (read < 0) break
                            if (read == 0) continue
                            sent += read
                            require(sent <= GITHUB_BLOB_LIMIT_BYTES) { "$displayName exceeded GitHub's 100 MiB regular Git blob limit while streaming." }
                            val combined = ByteArray(carry.size + read)
                            if (carry.isNotEmpty()) carry.copyInto(combined, 0)
                            inputBuffer.copyInto(combined, carry.size, 0, read)
                            val complete = combined.size - (combined.size % 3)
                            if (complete > 0) {
                                val encoded = java.util.Base64.getEncoder().encode(combined.copyOfRange(0, complete))
                                channel.writeFully(encoded)
                            }
                            carry = if (complete < combined.size) combined.copyOfRange(complete, combined.size) else ByteArray(0)
                            if (sent - lastReported >= 512 * 1024 || (rawLength != null && sent >= rawLength)) {
                                onBytesSent(sent, rawLength ?: -1L)
                                lastReported = sent
                            }
                        }
                        if (carry.isNotEmpty()) channel.writeFully(java.util.Base64.getEncoder().encode(carry))
                        onBytesSent(sent, rawLength ?: sent)
                    }
                    channel.writeFully(suffix)
                }
            })
        }
        ensureSuccess(response)
        return response.body()
    }

    private suspend inline fun <reified T> getJson(url: String, authorization: String): T {
        val response = client.get(url) { githubHeaders(authorization) }
        ensureSuccess(response)
        return response.body()
    }
    private suspend inline fun <reified Req : Any, reified Res> postJson(url: String, authorization: String, body: Req): Res {
        val response = client.post(url) { githubHeaders(authorization); setBody(body) }
        ensureSuccess(response)
        return response.body()
    }
    private suspend inline fun <reified Req : Any, reified Res> putJson(url: String, authorization: String, body: Req): Res {
        val response = client.put(url) { githubHeaders(authorization); setBody(body) }
        ensureSuccess(response)
        return response.body()
    }
    private suspend inline fun <reified Req : Any, reified Res> deleteJson(url: String, authorization: String, body: Req): Res {
        val response = client.delete(url) { githubHeaders(authorization); setBody(body) }
        ensureSuccess(response)
        return response.body()
    }
    private suspend fun patchJson(url: String, authorization: String, body: UpdateRefRequest) {
        val response = client.patch(url) { githubHeaders(authorization); setBody(body) }
        ensureSuccess(response)
    }
    private fun HttpRequestBuilder.githubHeaders(authorization: String) {
        header(HttpHeaders.Authorization, authorization)
        header(HttpHeaders.Accept, "application/vnd.github+json")
        header(HttpHeaders.ContentType, ContentType.Application.Json)
        header("X-GitHub-Api-Version", "2022-11-28")
    }
    private suspend fun ensureSuccess(response: HttpResponse) {
        if (response.status.isSuccess()) return
        val body = response.body<String>().take(500)
        val requestId = response.headers["X-GitHub-Request-Id"].orEmpty()
        val acceptedPermissions = response.headers["X-Accepted-GitHub-Permissions"].orEmpty()
        val evidence = buildString {
            if (requestId.isNotBlank()) append(" request_id=$requestId")
            if (acceptedPermissions.isNotBlank()) append(" accepted_permissions=$acceptedPermissions")
        }
        val message = when {
            response.status.value == 401 ->
                "GitHub returned 401 for this operation. Authentication must be re-probed before retiring the credential.$evidence"
            response.status.value == 403 && body.contains("Resource not accessible by personal access token", ignoreCase = true) ->
                "GitHub authenticated the request but denied the required repository capability. Forge needs Contents: Read and write for repository mutations; Actions access is evaluated separately.$evidence"
            response.status.value == 422 && body.contains("input was too large", ignoreCase = true) ->
                "GitHub 422: the REST Git-blob request was too large to process. The credential is not implicated; use a smaller bootstrap source or chunked transport.$evidence"
            else -> "GitHub ${response.status.value}: $body$evidence"
        }
        throw GitHubRequestException(response.status.value, message)
    }
}

class GitHubRequestException(val statusCode: Int, message: String) : IllegalStateException(message)

@Serializable private data class RepositoryContentResponse(val path: String = "", val sha: String = "", val type: String = "")
@Serializable private data class RepositoryContentItemResponse(val name: String = "", val path: String = "", val type: String = "", val size: Long = 0, val sha: String = "")
@Serializable private data class RepositoryContentTextResponse(val name: String = "", val path: String = "", val type: String = "", val size: Long = 0, val sha: String = "", val encoding: String = "", val content: String = "")
@Serializable private data class ContentWriteRequest(val message: String, val content: String, val branch: String, val sha: String? = null)
@Serializable private data class ContentDeleteRequest(val message: String, val sha: String, val branch: String)
@Serializable private data class ContentMutationResponse(val content: MutationContent? = null, val commit: MutationCommit = MutationCommit())
@Serializable private data class MutationContent(val sha: String = "")
@Serializable private data class MutationCommit(val sha: String = "")
@Serializable private data class CreateRefRequest(val ref: String, val sha: String)
@Serializable private data class CreateRefResponse(val ref: String = "")

@Serializable private data class RefResponse(@SerialName("object") val `object`: GitObject)
@Serializable private data class GitObject(val sha: String)
@Serializable private data class CommitResponse(val tree: GitTree)
@Serializable private data class GitTree(val sha: String)
@Serializable private data class BlobRequest(val content: String, val encoding: String)
@Serializable private data class BlobResponse(val sha: String)
@Serializable private data class TreeEntry(val path: String, val mode: String, val type: String, val sha: String)
@Serializable private data class TreeRequest(@SerialName("base_tree") val baseTree: String, val tree: List<TreeEntry>)
@Serializable private data class TreeResponse(val sha: String)
@Serializable private data class NewCommitRequest(val message: String, val tree: String, val parents: List<String>)
@Serializable private data class NewCommitResponse(val sha: String)
@Serializable private data class UpdateRefRequest(val sha: String, val force: Boolean)
@Serializable private data class WorkflowDispatchRequest(val ref: String, val inputs: Map<String, String> = emptyMap())
@Serializable private data class UserProfileResponse(val login: String, @SerialName("avatar_url") val avatarUrl: String? = null)
@Serializable private data class DeviceCodeResponse(@SerialName("device_code") val deviceCode: String, @SerialName("user_code") val userCode: String, @SerialName("verification_uri") val verificationUri: String, @SerialName("expires_in") val expiresIn: Int, val interval: Int = 5)
@Serializable private data class DeviceTokenResponse(
    @SerialName("access_token") val accessToken: String? = null,
    @SerialName("refresh_token") val refreshToken: String? = null,
    @SerialName("expires_in") val expiresIn: Int? = null,
    @SerialName("refresh_token_expires_in") val refreshTokenExpiresIn: Int? = null,
    @SerialName("token_type") val tokenType: String? = null,
    val error: String? = null,
    @SerialName("error_description") val errorDescription: String? = null,
)
@Serializable private data class WorkflowJobsResponse(val jobs: List<WorkflowJobResponse> = emptyList())
@Serializable private data class WorkflowJobResponse(
    val id: Long,
    val name: String = "Job",
    val status: String = "unknown",
    val conclusion: String? = null,
    @SerialName("started_at") val startedAt: String? = null,
    @SerialName("completed_at") val completedAt: String? = null,
    val steps: List<WorkflowStepResponse> = emptyList(),
)
@Serializable private data class WorkflowStepResponse(
    val name: String = "Step",
    val status: String = "unknown",
    val conclusion: String? = null,
    val number: Int = 0,
)
@Serializable private data class WorkflowRunsResponse(@SerialName("workflow_runs") val workflowRuns: List<WorkflowRunResponse> = emptyList())
@Serializable private data class WorkflowRunResponse(
    val id: Long,
    val name: String = "Workflow",
    @SerialName("display_title") val displayTitle: String = "",
    val status: String = "unknown",
    val conclusion: String? = null,
    @SerialName("head_branch") val headBranch: String? = null,
    @SerialName("head_sha") val headSha: String? = null,
    val event: String = "",
    @SerialName("created_at") val createdAt: String = "",
    @SerialName("updated_at") val updatedAt: String = "",
    @SerialName("run_started_at") val runStartedAt: String? = null,
    @SerialName("html_url") val htmlUrl: String = "",
)
@Serializable private data class GitBlobContentResponse(val encoding: String = "", val content: String = "")
@Serializable private data class RepositoryBranchResponse(val name: String = "")
@Serializable private data class RepositoryWorkflowsResponse(val workflows: List<RepositoryWorkflowResponse> = emptyList())
@Serializable private data class RepositoryWorkflowResponse(
    val id: Long,
    val name: String = "Workflow",
    val path: String = "",
    val state: String = "unknown",
    @SerialName("html_url") val htmlUrl: String = "",
)
@Serializable private data class WorkflowDispatchResponse(
    @SerialName("workflow_run_id") val workflowRunId: Long? = null,
    @SerialName("html_url") val htmlUrl: String? = null,
)
@Serializable private data class TreeMutationEntry(val path: String, val mode: String, val type: String, val sha: String?)
@Serializable private data class TreeMutationRequest(@SerialName("base_tree") val baseTree: String, val tree: List<TreeMutationEntry>)
@Serializable private data class ArtifactsResponse(val artifacts: List<ArtifactResponse> = emptyList())
@Serializable private data class ArtifactResponse(val id: Long, val name: String, @SerialName("size_in_bytes") val sizeInBytes: Long = 0, val expired: Boolean = false, @SerialName("created_at") val createdAt: String = "")
