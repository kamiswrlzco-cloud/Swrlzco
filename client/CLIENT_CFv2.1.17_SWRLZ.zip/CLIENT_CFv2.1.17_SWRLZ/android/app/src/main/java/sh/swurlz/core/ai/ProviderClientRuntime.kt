package sh.swurlz.core.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import sh.swurlz.core.net.CoreNodeApi
import sh.swrlz.provider.ProviderHealthStatus
import sh.swrlz.provider.ProviderHealthV1
import sh.swrlz.provider.ProviderId
import sh.swrlz.provider.ProviderMeshSnapshotV1

/** CLIENT-visible provider health. Secrets never cross this boundary. */
object ProviderClientRuntime {
    private val mutableSnapshot = MutableStateFlow(localFallback())
    val snapshot: StateFlow<ProviderMeshSnapshotV1> = mutableSnapshot.asStateFlow()

    suspend fun refresh(context: Context): ProviderMeshSnapshotV1 = withContext(Dispatchers.IO) {
        val value = runCatching { CoreNodeApi.providerStatus(context) }.getOrElse { failure ->
            localFallback(failure.message)
        }
        mutableSnapshot.value = value
        value
    }

    suspend fun probeAll(context: Context): ProviderMeshSnapshotV1 = withContext(Dispatchers.IO) {
        val value = runCatching { CoreNodeApi.probeProviders(context, providerId = null, deep = true) }.getOrElse { failure ->
            localFallback(failure.message)
        }
        mutableSnapshot.value = value
        value
    }

    suspend fun selectModel(context: Context, providerId: String, modelId: String): ProviderMeshSnapshotV1 = withContext(Dispatchers.IO) {
        val value = CoreNodeApi.selectProviderModel(context, providerId, modelId)
        mutableSnapshot.value = value
        value
    }

    private fun localFallback(detail: String? = null): ProviderMeshSnapshotV1 = ProviderMeshSnapshotV1(
        swrlzIdentity = "SWRLZ CLIENT",
        localFirst = true,
        providers = listOf(
            ProviderHealthV1(
                providerId = ProviderId.LOCAL_CLIENT.wireId,
                status = ProviderHealthStatus.READY,
                credentialConfigured = true,
                selectedModel = "swrlz-client-local",
                detail = "CLIENT-local SWRLZ is available.",
            ),
            ProviderHealthV1(
                providerId = ProviderId.OPENAI.wireId,
                status = ProviderHealthStatus.OFFLINE,
                detail = detail?.take(180) ?: "SERVER provider mesh has not been reached yet.",
            ),
            ProviderHealthV1(
                providerId = ProviderId.GEMINI.wireId,
                status = ProviderHealthStatus.OFFLINE,
                detail = detail?.take(180) ?: "SERVER provider mesh has not been reached yet.",
            ),
        ),
    )
}

object ProviderSourceIntentParser {
    data class Intent(val component: String, val providerHint: String?)

    fun parse(text: String): Intent? {
        val lower = text.lowercase()
        val asksAnalyze = listOf("analyze", "review", "inspect", "study", "look at", "send").any { it in lower }
        val latestSource = "latest" in lower && ("source" in lower || ".zip" in lower || "zip" in lower)
        if (!asksAnalyze || !latestSource || "swrlz" !in lower) return null
        val component = when {
            "server" in lower -> "SERVER"
            "client" in lower -> "CLIENT"
            else -> return null
        }
        val provider = when {
            "gemini" in lower -> "gemini"
            "gpt" in lower || "openai" in lower || "chatgpt" in lower -> "openai"
            "both" in lower || "council" in lower -> "council"
            else -> null
        }
        return Intent(component, provider)
    }
}
