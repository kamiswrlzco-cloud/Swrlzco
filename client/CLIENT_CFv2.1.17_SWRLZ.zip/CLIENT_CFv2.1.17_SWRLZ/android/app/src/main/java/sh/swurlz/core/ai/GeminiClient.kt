package sh.swurlz.core.ai

import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

object GeminiClient {
    private const val MODEL = "gemini-3.6-flash"
    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    data class Result(val text: String? = null, val error: String? = null) { val ok: Boolean get() = !text.isNullOrBlank() }

    fun generate(apiKey: String, prompt: String): Result {
        if (apiKey.isBlank()) return Result(error = "Gemini API key is not configured.")
        val connection = (URL(ENDPOINT).openConnection() as HttpURLConnection)
        return try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 20_000
            connection.readTimeout = 90_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("x-goog-api-key", apiKey.trim())
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", "You are the AI reasoning provider inside SWRLZ. Reply clearly. Never claim an action was executed unless SWRLZ confirms it."))))
                .put("contents", org.json.JSONArray().put(JSONObject().put("role", "user").put("parts", org.json.JSONArray().put(JSONObject().put("text", prompt)))))
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val raw = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val message = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                Result(error = message?.takeIf { it.isNotBlank() } ?: "Gemini request failed (HTTP $code).")
            } else {
                val json = JSONObject(raw)
                val candidates = json.optJSONArray("candidates")
                val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                val text = buildString { if (parts != null) for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty()) }.trim()
                if (text.isBlank()) Result(error = "Gemini returned no text.") else Result(text = text)
            }
        } catch (t: Throwable) { Result(error = t.message ?: t::class.java.simpleName) } finally { connection.disconnect() }
    }
}
