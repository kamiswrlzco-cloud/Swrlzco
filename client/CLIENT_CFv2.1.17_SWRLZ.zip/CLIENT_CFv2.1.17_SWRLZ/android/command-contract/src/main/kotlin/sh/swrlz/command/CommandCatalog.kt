package sh.swrlz.command

/**
 * Discoverable SWRLZ command catalog. UI surfaces may insert these natural-language templates
 * into Chat or copy them for review. Canonical capability IDs remain the execution authority.
 */
enum class CommandCategory { FORGE, AI, PROFILES, MISSIONS, CONNECTIONS, FILES, CHAT, SYSTEM }

data class SwrlzCommandV1(
    val id: String,
    val title: String,
    val category: CommandCategory,
    val template: String,
    val description: String,
    val aliases: List<String> = emptyList(),
    val capabilityId: String? = null,
    val safeForImmediateInsert: Boolean = true,
)

object SwrlzCommandCatalog {
    val all: List<SwrlzCommandV1> = listOf(
        SwrlzCommandV1("forge.start", "Start Forge", CommandCategory.FORGE, "start Forge", "Open the canonical Forge flow.", listOf("initiate forge", "begin forge"), "forge.start"),
        SwrlzCommandV1("forge.client.latest", "Forge latest CLIENT", CommandCategory.FORGE, "forge latest SWRLZ CLIENT source", "Stage the latest canonical CLIENT ZIP + checksum + manifest package unit.", capabilityId = "forge.source.client.latest"),
        SwrlzCommandV1("forge.server.latest", "Forge latest SERVER", CommandCategory.FORGE, "forge latest SWRLZ SERVER source", "Stage the latest canonical SERVER ZIP + checksum + manifest package unit.", capabilityId = "forge.source.server.latest"),
        SwrlzCommandV1("forge.combo.latest", "Forge CLIENT + SERVER", CommandCategory.FORGE, "forge latest SWRLZ CLIENT and SERVER sources", "Stage both canonical package triples as one Forge transaction without merging their identities.", capabilityId = "forge.source.combo.latest"),
        SwrlzCommandV1("forge.stop", "Stop Forge", CommandCategory.FORGE, "stop Forge", "Cancel the active Chat Forge operation.", capabilityId = "forge.stop"),
        SwrlzCommandV1("ai.gpt", "Ask GPT", CommandCategory.AI, "@gpt ", "Route this message through the SERVER-custodied OpenAI provider.", listOf("@openai", "@chatgpt"), "provider.openai"),
        SwrlzCommandV1("ai.gemini", "Ask Gemini", CommandCategory.AI, "@gemini ", "Route this message through the SERVER-custodied Gemini provider.", capabilityId = "provider.gemini"),
        SwrlzCommandV1("ai.council", "GPT + Gemini Council", CommandCategory.AI, "@both ", "Ask GPT and Gemini independently and let SWRLZ synthesize the result.", listOf("@council"), "provider.council"),
        SwrlzCommandV1("ai.compare", "Compare providers", CommandCategory.AI, "@compare ", "Request independent provider contributions plus SWRLZ comparison.", capabilityId = "provider.compare"),
        SwrlzCommandV1("ai.probe", "Probe providers", CommandCategory.AI, "probe all AI providers", "Refresh reachability/model status without exposing provider secrets.", capabilityId = "provider.probe"),
        SwrlzCommandV1("profile.switch.client", "Switch CLIENT profile", CommandCategory.PROFILES, "switch CLIENT SWRLZ profile to ", "Select a saved CLIENT endpoint profile.", capabilityId = "profile.client.select"),
        SwrlzCommandV1("profile.switch.server", "Switch SERVER profile", CommandCategory.PROFILES, "switch SERVER SWRLZ profile to ", "Select a saved SERVER endpoint profile.", capabilityId = "profile.server.select"),
        SwrlzCommandV1("mission.start", "Start mission", CommandCategory.MISSIONS, "make this a mission: ", "Promote an intent into the normal mission planning/approval path.", capabilityId = "mission.plan"),
        SwrlzCommandV1("mission.pause", "Pause mission", CommandCategory.MISSIONS, "pause mission", "Pause the active mission without changing its authority model.", capabilityId = "mission.pause"),
        SwrlzCommandV1("mission.resume", "Resume mission", CommandCategory.MISSIONS, "resume mission", "Resume a paused mission.", capabilityId = "mission.resume"),
        SwrlzCommandV1("connection.status", "Connection status", CommandCategory.CONNECTIONS, "show SWRLZ connection status", "Show CLIENT/SERVER/node reachability and trust state.", capabilityId = "connection.status"),
        SwrlzCommandV1("files.attach", "Attach file", CommandCategory.FILES, "analyze this attached file: ", "Stage a file for local/SWRLZ analysis before any remote-sharing approval.", capabilityId = "files.attach"),
        SwrlzCommandV1("files.client.gpt", "Latest CLIENT → GPT", CommandCategory.FILES, "send the latest SWRLZ CLIENT source to GPT and analyze it", "Resolve the canonical CLIENT source, verify/sanitize it, then route to GPT.", capabilityId = "provider.source.client.openai"),
        SwrlzCommandV1("files.combo.council", "Latest CLIENT + SERVER → Council", CommandCategory.FILES, "send the latest SWRLZ CLIENT and SERVER sources to GPT and Gemini and analyze them together", "Resolve both source authorities and route sanitized bundles through Council.", capabilityId = "provider.source.combo.council"),
        SwrlzCommandV1("chat.settings", "Open Chat settings", CommandCategory.CHAT, "open Chat settings", "Open conversation, provider, profile, terminology, and context controls.", capabilityId = "settings.chat"),
        SwrlzCommandV1("system.settings", "Open Android settings", CommandCategory.SYSTEM, "open device settings", "Request the existing Settings quick action.", capabilityId = "system.settings"),
    )

    fun search(query: String, category: CommandCategory? = null): List<SwrlzCommandV1> {
        val needle = query.trim().lowercase()
        return all.filter { command ->
            (category == null || command.category == category) &&
                (needle.isBlank() || listOf(command.title, command.template, command.description, command.id, *command.aliases.toTypedArray()).any { needle in it.lowercase() })
        }
    }
}
