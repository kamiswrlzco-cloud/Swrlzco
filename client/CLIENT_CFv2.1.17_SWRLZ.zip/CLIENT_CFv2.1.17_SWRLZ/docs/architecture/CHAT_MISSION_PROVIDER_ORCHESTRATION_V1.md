# SWRLZ Chat / Mission / Provider Orchestration V1

Council Chat is the operator-facing control surface. AI providers are private capabilities and do not replace the SWRLZ identity.

## Routing classes

`CHAT` → conversational response only.  
`QUESTION` → answer locally or consult a provider; may offer an executable follow-up.  
`SYSTEM_STATE` → query authoritative runtime/configuration state.  
`QUICK_ACTION` → deterministic low-cost action without mission lifecycle overhead.  
`FORGE` → Forge orchestration session and inline operational card.  
`MISSION` → stateful observe/plan/act/verify loop.

## Provider rule
SWRLZ asks memory/local capabilities first. A configured LLM may provide reasoning or a structured plan. Provider output must be converted into SWRLZ action contracts and validated before execution.

## Mission-result rule
A mission must finish with an observable result. Completion publishes a chat milestone/result and restores the user to the SWRLZ conversation surface when appropriate.

## UI event rule
High-frequency operational updates update cards/status rails in place. Only meaningful state transitions become persistent chat messages. Activity remains the detailed audit surface.


## Command Center rule
The Command Center is a discoverability/insertion surface over canonical capability IDs. CLIENT Chat quick actions insert editable natural-language templates; they do not bypass normal routing, approvals, mission authority, Forge validation, or provider policy. Forge intents may preselect CLIENT, SERVER, BOTH, or FILES package targets.
