# SWRLZ Command Center and Forge Package Contract V1

## Command definition

Every discoverable command has a stable ID, category, title, natural-language template, optional aliases, and optional canonical capability ID. UI surfaces may search, favorite, insert, or copy command templates. A command template never grants authority by itself.

## Protected package roles

Recognized protected source roles are `CLIENT_` and `SERVER_`. A package unit consists of ZIP + checksum + manifest with one canonical logical stem.

### Checksum aliases

Accepted transport names:

- `.sha256`
- `.sha256.txt`
- `.sha`

All normalize to `.sha256` for logical matching and repository routing. Multiple physical aliases that disagree must not be treated as one verified package.

### Manifest

The canonical manifest companion is `<stem>.manifest.json` and must name the canonical ZIP, contain a 64-character SHA-256 matching the receipt, and declare `verified: true`. Forge may discover a manifest but must not synthesize one from incomplete metadata.

## BOTH transaction

`BOTH` means one repository transaction containing one CLIENT package unit and one SERVER package unit. Each role retains independent checksum, manifest, destination lane, version, and lineage.

## Defaults

Auto-route protected source packages: ON.
Auto-resolve checksum: ON.
Auto-resolve manifest: ON.
Source ZIP guard: ON.
CLIENT+SERVER one transaction: ON.
Destination preview: ON.

## Failure rule

Checksum mismatch, manifest mismatch, role-target mismatch, or missing strict companion blocks commit. Forge must surface the reason; it must not silently weaken package validation.
