# CLIENT Engineering Log

## 2026-07-27 — INT-FORGE-039E

Advanced CLIENT to CFv2.1.17 / VC115 / `2.1.17-forge-rescue-default-theme-v1` as a temporary Forge rescue/bootstrap edition. Runtime logs from the installed VC108 uploader showed authentication and repository access succeeding before later REST Git operations were broadly classified as bad credentials; separate runtime evidence showed GitHub 422 `input was too large` for the large source blob path. Added a pre-transfer Contents-write probe using a tiny unreferenced Git blob, re-probe-before-retire behavior for later 401 responses, and truthful 422 transport classification. To make the repair itself transportable through the older uploader, the bootstrap registry exposes only default Glitch Dragon Glass and omits optional theme/ignition artwork. Source-only; no GitHub write/build/device/release action performed during packaging.


## 2026-07-27 — INT-THEME-039C

Advanced CLIENT to CFv2.1.16 / versionCode 114 / `2.1.16-theme-progress-semantic-anchor-v1`. Runtime evidence from an older installed VC108 build showed that 100% progress did not terminate at Jester's right green emerald. Inspection of the current CFv2.1.15 renderer confirmed the underlying geometry flaw remained present: Jester used a hard-coded 87.5% track endpoint and progress-head travel aligned different head edges at 0% and 100%. Replaced the Jester-only layout branch with a theme-aware semantic geometry resolver, calibrated the Jester end anchor to 89.5%, and made the head center track the exact progress boundary. Manifest-v1/shared ThemePack contract bytes are unchanged; uncalibrated themes retain declared dp insets. Source/static checkpoint only; build, device, GitHub promotion, release, deployment, and installation are not claimed.

## 2026-07-27 — INT-THEME-039A

Verified parent `CLIENT_CFv2.1.14_SWRLZ.zip` at SHA-256 `2ab12d7646bd4a733fa6986375c31715f106a3d181b315b79271d215ba946f7e` and verified the user-supplied `SWRLZ_Core_Ignition_Resource_Pack_Jester_to_Kamileon.zip` at SHA-256 `fc5e41188e429cf5b088f8da47ead713ba0e39849b75e79e6f5011e532d58c3c`. The resource pack root manifest contains 54 listed entries; all declared byte counts and SHA-256 values were revalidated before integration.

Advanced CLIENT source identity to CFv2.1.15 / versionCode 113 / `2.1.15-theme-ignition-family-completion-v1`. Preserved the existing Jester ignition and added full eight-role ignition mappings for Dragon Kamileon, Jade, Frost, Crystal Cyber, and Inferno. The runtime startup compositor now uses a theme-generic function name but retains the same readiness-truthful timeline and reduced-motion semantics.

No SERVER runtime, protocol, trust, Truth Firewall, permission, mission, Forge, provider/profile contract, local/remote distinction, workflow, build, APK, GitHub write, release, deployment, or installation action was changed or run.

## 2026-07-27 — INT-CHAT-037A

Advanced CLIENT to CFv2.1.11 / versionCode 109 / `2.1.11-chat-control-center-v1`. Expanded the existing Chat & Commands settings domain into nested Conversation Flow, Personality & Response, and Privacy & Context controls. Added CLIENT-local persisted ChatSettings, response-top follow targeting with trailing viewport reserve, live-event focus preference, and SWRLZ profile guidance for optional reasoning providers. Deterministic mission/Forge/system truth remains outside personality control.

The separately requested Forge quick-action menu, automatic source companion pairing, learned terminology aliases, and INT-THEME-036C progress HUD calibration are not included. No build/workflow/repository write/release/deployment/installation action was run.

## 2026-07-27 — INT-THEME-036A

Verified supplied `CLIENT_CFv2.1.9_SWRLZ.zip` at SHA-256
`87a09a5032751dbf74f5a277a6d9b0e1f9bc48e38e48006c50d0c107cd3d30ac`
before extraction.

Real-device CFv2.1.9 screenshots showed that the Jester determinate filler and
streaming layers were still visually mis-contained despite earlier static geometry
checks. Alpha inspection of the 1024×126 Jester frame located the clear track near
x=207..898 and y=37..94. The CLIENT renderer now enforces normalized Jester
insets matching that opening, keeps ambient energy as a low-alpha underlay, clips
fill/particles/highlight to one active progress window, and draws the decorative
frame after every streaming layer.

Advanced CLIENT source identity to CFv2.1.10 / versionCode 108 /
`2.1.10-progress-layering-clipping-repair-v1`. Shared ThemePack contracts and
runtime assets are unchanged. The separately requested Chat response-top
auto-follow behavior is not included in this checkpoint.

No Gradle/APK/workflow/repository write/release/deployment/installation action was run.


## 2026-07-26 — INT-THEME-035D

PR #1 promoted CLIENT CFv2.1.8 to `main` at merge commit
`bc80d7a4d28d656f640ac1a511b9ae340e8b45ee`.

Source Package Integrity run `30222384992` and APK Router run `30222384996`
both selected the expected CFv2.1.8 ZIP at SHA-256
`d344e683cc76756020b1a02e118b2417c03d6552eeb032dd5dd91058c0f7f055`.
The checksum matched, but the sidecar manifest used `sourcePackage` and `bytes`
instead of the repository verifier's canonical `zip` and `size_bytes` fields
and omitted `verified: true`. Both workflows failed before Android compilation;
no APK was produced.

Advanced the packaging/identity successor to CLIENT CFv2.1.9 / versionCode 107.
Theme behavior is unchanged from CFv2.1.8. The new manifest retains the richer
checkpoint fields and adds the exact verifier contract. Failed CFv2.1.8 evidence
remains preserved as lineage.

## 2026-07-26 — INT-THEME-035C

Verified canonical parent `CLIENT_CFv2.1.7_SWRLZ.zip` at SHA-256 `bc5b941e9b0c86e28581d8f6019b6c54722243279ef666aa3c35c4f97745fe76`.

Advanced the CLIENT-only source successor to CFv2.1.8 / versionCode 106. The implementation replaces the default legacy launcher, completes per-theme identity/chrome mappings, introduces reusable full-shell ThemePack backdrop/Kapanion/panel renderers, contains progress artwork inside one calibrated track, and stages the Jester ignition sequence. Existing distinct Kapanion assets were reused; no Jester art was copied into other families and no AI-generated replacement art was required.

The authority diff remains presentation-only. SERVER, protocol, network, trust, identity proof, permission, mission, Forge transaction, accessibility automation, local/remote, and offline-first sources are unchanged.

Source-only integrity evidence is recorded in `docs/checkpoints/INT-THEME-035C_CLIENT_THEME_CHROME_RUNTIME_REPAIR.md`. Gradle, tests, APK, device acceptance, workflow execution, release, and deployment are not run or claimed.

## 2026-07-26 — INT-THEME-035B

Workflow run `30216145763` resolved and verified `CLIENT_CFv2.1.6_SWRLZ.zip`, and resolver unit tests passed 6/6. Kotlin compilation then failed at `ThemedProgress.kt:175` and `:190` because nested Compose `Box` scopes could not implicitly resolve the enclosing `BoxWithConstraints.maxWidth`.

Advanced the source successor to CLIENT CFv2.1.7 / versionCode 105 and captured the outer width as `availableWidth` before both nested scopes. The two fill images now use `Modifier.width(availableWidth)`. No build was run in this checkpoint; static repair/package verification only.

## 2026-07-26 — INT-THEME-035A

Parent `CLIENT_CFv2.1.5_SWRLZ.zip` was verified at SHA-256 `c7ed3942c9a14a110ea3a085316011b3522153e757d09614050aa15d20f9ac58` and retained as rollback.

Implemented the source-only declarative ThemePack checkpoint as CLIENT CFv2.1.6 / versionCode 104:

- shared contract and validation;
- stable legacy migration plus seven new built-ins;
- deterministic 101-resource runtime visual catalog;
- independent local CLIENT selection and staged preview;
- launcher/Kapanion/bubble/notification identity;
- Jester startup reference and safe fallbacks;
- truthful layered progress and reduced-motion behavior;
- architecture, contract, checkpoint, implementation, and release documentation.

Static XML/JSON, asset integrity, shared-contract, alias, changed-source lexical, and authority-scope checks passed. Gradle, APK, device, GitHub, commit, push, release, and deployment actions were not run.

Repository documentation publication is pending a separately authorized source promotion.


## 2026-07-27 — INT-THEME-036A
CLIENT CFv2.1.10 source-only progress-layering/clipping successor. Runtime-reported Jester progress geometry was recalibrated; build/device evidence remained separate.

## 2026-07-27 — INT-CHAT-037A
CLIENT CFv2.1.11 source-only Chat Control Center successor. Added conversation-flow/personality/context controls and response-top follow semantics.

## 2026-07-27 — INT-PROFILE-037B
CLIENT CFv2.1.12 source-only distributed profile successor. Added shared profile contract, endpoint/relationship/provider assignments, inheritance, named custom profiles, and authority-safe precedence.

## 2026-07-27 — INT-AI-038A
CLIENT CFv2.1.13 source-only provider-mesh successor. Added provider routing/status/model surfaces, server-custodied GPT/Gemini semantics, saved profile lifecycle, and canonical source-analysis dispatch groundwork.

## 2026-07-27 — INT-CHAT-FORGE-038C
Advanced CLIENT to CFv2.1.14 / versionCode 112. Added shared Command Center, Chat composer quick actions, CLIENT/SERVER/BOTH package targeting, checksum alias + manifest companion automation, strict package validation, combo staging, and Documentation Gate. SERVER common-Forge parity is paired in SERVER CFv2.1.7. No build/workflow/GitHub promotion/release/deploy claimed.
